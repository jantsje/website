window.YTD.periscope_account_information.part0 = [
  {
    "periscopeAccountInformation" : {
      "displayName" : "Jantsje Mol",
      "digitsId" : "",
      "username" : "JantsjeMol",
      "twitterId" : "1096413470554292225",
      "id" : "1drQerebgJvKb",
      "twitterScreenName" : "JantsjeMol",
      "isTwitterUser" : true,
      "createdAt" : "2019-04-01T13:14:58.169925387Z"
    }
  }
]