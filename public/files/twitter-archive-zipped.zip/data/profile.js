window.YTD.profile.part0 = [
  {
    "profile" : {
      "description" : {
        "bio" : "Senior researcher @CoEHRTech formerly Postdoc @ CREED @UvA_ASE, PhD from @VU_IVM Amsterdam. Excited about volleyball, tall ship sailing and board games.",
        "website" : "https://t.co/SGp3bygses",
        "location" : "Rotterdam, Nederland"
      },
      "avatarMediaUrl" : "https://pbs.twimg.com/profile_images/1859937639119396864/ah_LbNzb.jpg",
      "headerMediaUrl" : "https://pbs.twimg.com/profile_banners/1096413470554292225/1627044208"
    }
  }
]