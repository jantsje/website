window.YTD.account_timezone.part0 = [
  {
    "accountTimezone" : {
      "accountId" : "1096413470554292225"
    }
  }
]