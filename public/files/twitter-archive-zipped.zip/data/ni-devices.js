window.YTD.ni_devices.part0 = [
  {
    "niDeviceResponse" : {
      "messagingDevice" : {
        "deviceType" : "Auth",
        "carrier" : "tmobile_nl",
        "phoneNumber" : "+31623206073",
        "createdDate" : "2019.02.15"
      }
    }
  }
]