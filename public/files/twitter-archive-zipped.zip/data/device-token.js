window.YTD.device_token.part0 = [
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "LoNjDthjvD8xHRBWXH4829PfWf52CAmaJJnDv55c",
      "createdAt" : "2024-03-27T08:38:50.831Z",
      "lastSeenAt" : "2024-03-27T08:38:50.832Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "A2V4TtBXe66yQUwFIWHncJ9c3c5OttRNH37YrjEe",
      "createdAt" : "2024-10-02T06:59:52.907Z",
      "lastSeenAt" : "2024-10-02T06:59:52.909Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "OLBQurqgGZRP5xlVg3uxsbCkKeEZj04fAiPMucfP",
      "createdAt" : "2024-09-25T09:09:35.720Z",
      "lastSeenAt" : "2024-11-22T12:30:47.377Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  }
]