window.YTD.connected_application.part0 = [
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "Small World",
        "url" : "https://github.com/devonzuegel/smallworld",
        "privacyPolicyUrl" : "https://smallworld.kiwi/privacy-policy.html",
        "termsAndConditionsUrl" : "https://smallworld.kiwi/terms-and-conditions.html"
      },
      "name" : "Small World 🌎",
      "description" : "Stay in touch with your friends as you travel!\n\nyou can find the description of the app here: https://twitter.com/devonzuegel/status/1468617214572077056",
      "permissions" : [
        "read",
        "emailaddress"
      ],
      "approvedAt" : "2022-06-09T09:48:01.000Z",
      "id" : "9258522"
    }
  }
]