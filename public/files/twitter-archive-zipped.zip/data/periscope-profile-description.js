window.YTD.periscope_profile_description.part0 = [
  {
    "periscopeProfileDescription" : {
      "bio" : "Senior researcher @CoEHRTech formerly Postdoc @ CREED @UvA_ASE, PhD from @VU_IVM Amsterdam. Excited about volleyball, tall ship sailing and board games."
    }
  }
]