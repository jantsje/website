window.YTD.ad_impressions.part0 = [
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1894731492313768292",
                "tweetText" : "Jezelf voorbereiden op de huidige en de volgende golf van Bitcoin-adoptie?\nDownload de gratis Bitcoin Bundel ⬇️\n\nInhoud:\n✅ Mini-cursus\n✅ Bitcoin Bullmarkt rapport\n✅ Bitcoin DCA sheet \nen meer..\n\nDownload gratis: https://t.co/tpU3tZM8LZ",
                "urls" : [
                  "https://t.co/tpU3tZM8LZ"
                ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Madelon Vos",
                "screenName" : "@MadelonBackup"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "Dutch"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2025-04-09 07:35:34"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1861376858413015222",
                "tweetText" : "Het kost 7.000 liter water om slechts één jeans te produceren. Dutch Clean Tech bouwt waterzuiveringen waardoor de textielindustrie water kan hergebruiken. Dit is een unieke kans om te beleggen met impact. Vraag vandaag de brochure nog aan.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Dutch Clean Tech",
                "screenName" : "@Dutchclean_tech"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                }
              ],
              "impressionTime" : "2025-04-09 07:35:27"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1909550937472987375",
                "tweetText" : "Ready to transform your body with just 15 minutes a day?\n\n💪 Join thousands who are getting sculpted with Wall Pilates by Zing!\n\n✨ Fast results, AI body scan tracking &amp; fun workouts you’ll love!\n\n🧘‍♀️ Start your journey today — your future self will thank you!",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Zing",
                "screenName" : "@ZingAICoach"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "The Netherlands"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                }
              ],
              "impressionTime" : "2025-04-09 07:35:23"
            }
          ]
        }
      }
    }
  }
]