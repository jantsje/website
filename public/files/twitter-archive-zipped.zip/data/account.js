window.YTD.account.part0 = [
  {
    "account" : {
      "email" : "jantsje@gmail.com",
      "createdVia" : "oauth:268278",
      "username" : "JantsjeMol",
      "accountId" : "1096413470554292225",
      "createdAt" : "2019-02-15T14:18:36.536Z",
      "accountDisplayName" : "Jantsje Mol"
    }
  }
]