window.YTD.like.part0 = [
  {
    "like" : {
      "tweetId" : "1859157316534190374",
      "fullText" : "Super Happy to see this finally out in print! 🎉 https://t.co/7t6DqSJFN6",
      "expandedUrl" : "https://twitter.com/i/web/status/1859157316534190374"
    }
  },
  {
    "like" : {
      "tweetId" : "1804032199622086942",
      "fullText" : "Fantastic news! 🥳 https://t.co/yM06sX581K",
      "expandedUrl" : "https://twitter.com/i/web/status/1804032199622086942"
    }
  },
  {
    "like" : {
      "tweetId" : "1778479339358577088",
      "fullText" : "Today, I gave my last lecture. First step towards full retirement a little more than a year from now. Still some seminars and response classes, which I will teach with great pleasure. Happy about this step!",
      "expandedUrl" : "https://twitter.com/i/web/status/1778479339358577088"
    }
  },
  {
    "like" : {
      "tweetId" : "1778739587646431698",
      "fullText" : "Exciting! 🎉🥳I am humbled&amp;honored to have been awarded a 2,5 million EUR @ERC_Research Advanced Grant to study how data infrastructure govern the social. After @data_ctive, it’s now time for DATAGOV! Stay tuned:we’ll hire 7 ppl @UvA_Humanities @UvA_Amsterdam! #HorizonEU #ERCAdG https://t.co/rrXCyxjCiE",
      "expandedUrl" : "https://twitter.com/i/web/status/1778739587646431698"
    }
  },
  {
    "like" : {
      "tweetId" : "1752294593339457741",
      "fullText" : "Excited that \"Morals in Multi-Unit Markets\" is now out at @JEEA_News!👇🏻\nhttps://t.co/PYYGcN0bfM https://t.co/kfAkgTI82t",
      "expandedUrl" : "https://twitter.com/i/web/status/1752294593339457741"
    }
  },
  {
    "like" : {
      "tweetId" : "1735794659853770965",
      "fullText" : "We increasingly recognize the role of Social Norms in many domains (employment, gender roles, etc), but solid empirical work on norms requires an appropriate understanding of the methods 👉 new WP with @fbogliacino &amp; @bemusement https://t.co/Fwkg9bw22O",
      "expandedUrl" : "https://twitter.com/i/web/status/1735794659853770965"
    }
  },
  {
    "like" : {
      "tweetId" : "1734959286478930065",
      "fullText" : "Vacancy alert! 📢\nWe are looking for a researcher on data visualisation &amp; sci-art. Do you have the skills to combine qualitative &amp; quantitative data on drought-to-flood events? Please apply. Deadline: 10 Jan 24, expected start date: 1 Mar 24. More info: https://t.co/CWuZb3mvL1",
      "expandedUrl" : "https://twitter.com/i/web/status/1734959286478930065"
    }
  },
  {
    "like" : {
      "tweetId" : "1734649836710855064",
      "fullText" : "Vandaag 40 jaar geleden ontmoette ik die gast rechts voor de eerste keer. Nog even en we vieren 40 jaar samen! ❤️ https://t.co/LhMtjtOFSi",
      "expandedUrl" : "https://twitter.com/i/web/status/1734649836710855064"
    }
  },
  {
    "like" : {
      "tweetId" : "1732714698607616511",
      "fullText" : "I've had the privilege to co-author a paper with @CassSunstein: 'Do People Like Financial Nudges?' \n\nAnd people do! But they have a strong preference for nudges that target savings and system 2. We don't find any effect of transparency, or messenger.\n\nhttps://t.co/qBiVQGEqEF https://t.co/IvEjoM13AK",
      "expandedUrl" : "https://twitter.com/i/web/status/1732714698607616511"
    }
  },
  {
    "like" : {
      "tweetId" : "1730447193792770472",
      "fullText" : "Job Market candidates: the hiring committee is meeting for the first time today. We only just got the reviews in from our colleagues. More meetings next week. Don't expect to hear from us before Tuesday/Wednesday. I'll provide updates along the way!",
      "expandedUrl" : "https://twitter.com/i/web/status/1730447193792770472"
    }
  },
  {
    "like" : {
      "tweetId" : "1730216061419520265",
      "fullText" : "I’m happy to announce that as of 1 Jan 2024 I will become a Research Professor at the WZB. Behavioral Economics and Human Agency.",
      "expandedUrl" : "https://twitter.com/i/web/status/1730216061419520265"
    }
  },
  {
    "like" : {
      "tweetId" : "1726988902240858592",
      "fullText" : "Extremely happy to get this paper published! https://t.co/vW6nGoGDDi",
      "expandedUrl" : "https://twitter.com/i/web/status/1726988902240858592"
    }
  },
  {
    "like" : {
      "tweetId" : "1726593271340892349",
      "fullText" : "Job market candidates: We have now completed a first-round review. Out of 860 applications, we have passed 218 for in-depth departmental review to our colleagues. They have until November 28 to finish their reviews. The committee meets the week after to determine interviews.",
      "expandedUrl" : "https://twitter.com/i/web/status/1726593271340892349"
    }
  },
  {
    "like" : {
      "tweetId" : "1711470075553710416",
      "fullText" : "The Symposium on Hurricane Risk in a Changing Climate: Early bird deadline approaching: click here to learn more and register https://t.co/9NsXAdDLOv\nThe main objective of the symposium is to increase understanding of and better ways to deal with TC risks.",
      "expandedUrl" : "https://twitter.com/i/web/status/1711470075553710416"
    }
  },
  {
    "like" : {
      "tweetId" : "1702145069153702044",
      "fullText" : "Made an implementation and procedures guide for conducting online experiments (through oTree and Heroku) that I hope is helpful to others. I see this as a public good for those of us running online experiments 🥳 https://t.co/kinf3bi3jR #otree #economics #experiments #research",
      "expandedUrl" : "https://twitter.com/i/web/status/1702145069153702044"
    }
  },
  {
    "like" : {
      "tweetId" : "1708861148018225241",
      "fullText" : "Norm nudges—potentially very powerful—are not universally nor unconditionally so. @jantsjemol et al find descriptive social norm-nudges to encourage home owners to reduce the risk of flood damage don’t work—likely because flooding is not a familiar issue: https://t.co/9g8N5rvKkA https://t.co/ExbnNgs3hY",
      "expandedUrl" : "https://twitter.com/i/web/status/1708861148018225241"
    }
  },
  {
    "like" : {
      "tweetId" : "1706560216114790905",
      "fullText" : "BON (@BestuurBon) vindt het het Wetvoorstel Internationalisering in Balans niet ver genoeg gaan en wil dat al het bekostigde onderwijs in het Nederlands wordt verzorgd. Daarnaast BON zet reacties van anderen weg als “misvattingen\". Vandaar een reactie: https://t.co/iwaYXKUqIz",
      "expandedUrl" : "https://twitter.com/i/web/status/1706560216114790905"
    }
  },
  {
    "like" : {
      "tweetId" : "1686839454030315520",
      "fullText" : "We took the opportunity to make this workshop a farewell for @CesarMant and @mblanco_rebel, who are leaving the Colombian experimentalist community in person but will always be part of it from a distance. Their RAs in @UR_REBEL gave them this detail. https://t.co/mbKpBI6UOC",
      "expandedUrl" : "https://twitter.com/i/web/status/1686839454030315520"
    }
  },
  {
    "like" : {
      "tweetId" : "1684313341626290182",
      "fullText" : "@Danielf_Parra @mblanco_rebel Espacio limitado = almuerzos limitados.\n\n¡Inscríbanse!",
      "expandedUrl" : "https://twitter.com/i/web/status/1684313341626290182"
    }
  },
  {
    "like" : {
      "tweetId" : "1676879648649539590",
      "fullText" : "⚡ We are hiring a 2-3 year postdoc!\n\n✅ Are you interested in the physical and economic dimension of climate risk?\n✅ Would you like to help European regions to adapt to climate change?\n✅ Would you love to work as a researcher at Deltares?\n\nhttps://t.co/vtHRJia5Au \n\n@Lijnonline",
      "expandedUrl" : "https://twitter.com/i/web/status/1676879648649539590"
    }
  },
  {
    "like" : {
      "tweetId" : "1676239325040721920",
      "fullText" : "I'm thrilled to share that I've been granted the Vidi award from NWO (Dutch Research Council). This allows me to investigate the key financial and psychological drivers that influence professional investors in their belief formation and their sustainable investment decisions. https://t.co/VZcYwFfHEx",
      "expandedUrl" : "https://twitter.com/i/web/status/1676239325040721920"
    }
  },
  {
    "like" : {
      "tweetId" : "1676469959587659776",
      "fullText" : "Would you be more likely to avoid meat if you are observed? New research with @evaweingaertner just out in @jeem_tweets says the answer is Yes for women and No for men. And too much pressure on people's #foodchoice may backfire. https://t.co/0mMoECDq7Z\n#meatless #envecon https://t.co/ic0gUp2Hij",
      "expandedUrl" : "https://twitter.com/i/web/status/1676469959587659776"
    }
  },
  {
    "like" : {
      "tweetId" : "1676360111449837569",
      "fullText" : "A great news for the @EcScienceAssoc and researchers in experimental economists who have another well-recognised outlet to publish their research.\nShout-out to all past editors who have build up this journal from the ground. https://t.co/Dal2LdiHu3",
      "expandedUrl" : "https://twitter.com/i/web/status/1676360111449837569"
    }
  },
  {
    "like" : {
      "tweetId" : "1675085002969608193",
      "fullText" : "Whaaat a re-union 🔥 @TiUEconomics  colleagues at #ESAworld23 in Lyon \nBig thanks to @SSuetens  for making this happen! 🧡 https://t.co/Jk3UfIT2ce",
      "expandedUrl" : "https://twitter.com/i/web/status/1675085002969608193"
    }
  },
  {
    "like" : {
      "tweetId" : "1673914873057800197",
      "fullText" : "So many thanks @mc_villeval, Astrid, and Fabio for such a wonderful @EcScienceAssoc conference. Airtight through and through! We are all so very proud. \n\nCan’t wait to come back to Lyon and to participate in upcoming ESA meetings. Step by step this group is changing the world.",
      "expandedUrl" : "https://twitter.com/i/web/status/1673914873057800197"
    }
  },
  {
    "like" : {
      "tweetId" : "1674361992990056450",
      "fullText" : "So happy with the experience at #ESA #Lyon 2023! Incredible people, interesting talks and beautiful city. Thanks to the organizers for everything! And to everyone I met (again or for the first time) looking forward to seeing you at next year's ESA in Colombia!",
      "expandedUrl" : "https://twitter.com/i/web/status/1674361992990056450"
    }
  },
  {
    "like" : {
      "tweetId" : "1673955472804659200",
      "fullText" : "⁦@mc_villeval⁩ Presidential Address ⁦@ESA_Lyon_2023⁩ explains the social construction of ignorance. Fantastic experiments and insights. https://t.co/JUvmks8C4D",
      "expandedUrl" : "https://twitter.com/i/web/status/1673955472804659200"
    }
  },
  {
    "like" : {
      "tweetId" : "1673771745457631232",
      "fullText" : "@ESA_Lyon_2023 Glasses on the riverside! Refreshing! https://t.co/MPYa1tMob7",
      "expandedUrl" : "https://twitter.com/i/web/status/1673771745457631232"
    }
  },
  {
    "like" : {
      "tweetId" : "1673674758280433664",
      "fullText" : "@l_stangenberg Together we are spreading the warmth at this excellent conference!",
      "expandedUrl" : "https://twitter.com/i/web/status/1673674758280433664"
    }
  },
  {
    "like" : {
      "tweetId" : "1673361425996152837",
      "fullText" : "@JantsjeMol @ESA_Lyon_2023 at one point I thought this is European Space Agency meeting lol..",
      "expandedUrl" : "https://twitter.com/i/web/status/1673361425996152837"
    }
  },
  {
    "like" : {
      "tweetId" : "1673347289312550914",
      "fullText" : "Great start of #ESAworld23 with our first plenary talk by the great John List @Econ_4_Everyone https://t.co/dloX11fbfz",
      "expandedUrl" : "https://twitter.com/i/web/status/1673347289312550914"
    }
  },
  {
    "like" : {
      "tweetId" : "1671970363557683216",
      "fullText" : "We had a special day today at @TiUEconomics , Eric van Damme delivered his valedictory address, as usual, a super inspirational speech! What an influential economist and role model for us, opened the way for many and what a fantastic professor/colleague he is! https://t.co/DRNRDMPjhX",
      "expandedUrl" : "https://twitter.com/i/web/status/1671970363557683216"
    }
  },
  {
    "like" : {
      "tweetId" : "1671887699907874816",
      "expandedUrl" : "https://twitter.com/i/web/status/1671887699907874816"
    }
  },
  {
    "like" : {
      "tweetId" : "1664145981863018496",
      "fullText" : "Today is my 1st day back from maternity leave, my 1st day commuting from our new house (ps already in love with my bike route😍), and my 1st day at the new job @KNMI ! And, coincidentally, today also marks the start of the hurricane season🌀🙃 https://t.co/T7bDZV7KB4",
      "expandedUrl" : "https://twitter.com/i/web/status/1664145981863018496"
    }
  },
  {
    "like" : {
      "tweetId" : "1660549701903478784",
      "expandedUrl" : "https://twitter.com/i/web/status/1660549701903478784"
    }
  },
  {
    "like" : {
      "tweetId" : "1649790169971671042",
      "fullText" : "Researchers report that most people feel \"psychologically close\" to #climatechange, seeing it not as a future problem but as an issue that needs to be addressed now.\n\n@AnneValkengoed @univgroningen Goda Perlaviciute, Linda Steg\n\nRead more in @OneEarth_CP: https://t.co/Yi7MMHnrYI https://t.co/EblISqRmuP",
      "expandedUrl" : "https://twitter.com/i/web/status/1649790169971671042"
    }
  },
  {
    "like" : {
      "tweetId" : "1648662046207008770",
      "fullText" : "Very happy to have our paper “Identity breeds inequality: Evidence from a laboratory experiment on redistribution” forthcoming at Journal of Public Economics - by Fischbacher, Grammling, Hausfeld, @vojtech_zika \n\nhttps://t.co/knjw8c8N85\nthread below (1/6)",
      "expandedUrl" : "https://twitter.com/i/web/status/1648662046207008770"
    }
  },
  {
    "like" : {
      "tweetId" : "1627589877528240128",
      "fullText" : "Our PlasticFree research is gaining momentos. Hoe duurzaamheidsscores helpen om groenere keuzes te maken https://t.co/t31EJgdB5H via @VUamsterdam",
      "expandedUrl" : "https://twitter.com/i/web/status/1627589877528240128"
    }
  },
  {
    "like" : {
      "tweetId" : "1622550357980086277",
      "fullText" : "Exciting start of the week! Happy to begin my first research stay as a PhD student with @g_spadaro90 at @VUamsterdam https://t.co/HQ4CYfH2CQ",
      "expandedUrl" : "https://twitter.com/i/web/status/1622550357980086277"
    }
  },
  {
    "like" : {
      "tweetId" : "1603181169666834434",
      "fullText" : "Drought group Sinterklaas / Christmas get together! What a lovely evening with wonderful colleagues! ☺️ We have grown so much over the past two years (and many even still missing from this photo). https://t.co/WcYhjT2rC2",
      "expandedUrl" : "https://twitter.com/i/web/status/1603181169666834434"
    }
  },
  {
    "like" : {
      "tweetId" : "1601597213528190977",
      "fullText" : "New paper in JEL: Carbon Taxes. Compelling read. \"One critical question missing from the carbon tax literature is how does the carbon tax influence poverty.\" \nhttps://t.co/tsxq1rk5Xe https://t.co/vY2ff0tyfS",
      "expandedUrl" : "https://twitter.com/i/web/status/1601597213528190977"
    }
  },
  {
    "like" : {
      "tweetId" : "1597891990632353792",
      "fullText" : "The first working paper is officially out! @Matze_Weber @rshereme \n\nNudging Civilian Evacuation During War: Evidence from Ukraine\n\nhttps://t.co/013ivzu17I https://t.co/Aqt8FIjiad",
      "expandedUrl" : "https://twitter.com/i/web/status/1597891990632353792"
    }
  },
  {
    "like" : {
      "tweetId" : "1597602601784283136",
      "fullText" : "The winner of Dutch Data Prize 2021 🏆 Dr. @Bloemendaal_N from @VUamsterdam giving an inspiring keynote at #dutchdataprize 🎉 https://t.co/YCDbrbTL4p",
      "expandedUrl" : "https://twitter.com/i/web/status/1597602601784283136"
    }
  },
  {
    "like" : {
      "tweetId" : "1597645911551008768",
      "fullText" : "I had the honor to be a keynote speaker at the FAIR data day and talk about the role of FAIR data in climate risk science 😊 \n\nAnd uh ... it was a nice copresentation between me and the future generation 😉 The twins learned a lot today!! https://t.co/ZkrMfI50NR",
      "expandedUrl" : "https://twitter.com/i/web/status/1597645911551008768"
    }
  },
  {
    "like" : {
      "tweetId" : "1597545111566815232",
      "fullText" : "That's why it's called a t-test. https://t.co/pCXI0PyCVF",
      "expandedUrl" : "https://twitter.com/i/web/status/1597545111566815232"
    }
  },
  {
    "like" : {
      "tweetId" : "1595799779421917184",
      "expandedUrl" : "https://twitter.com/i/web/status/1595799779421917184"
    }
  },
  {
    "like" : {
      "tweetId" : "1595743606966751233",
      "fullText" : "This picture might not look like much, but it represents a new answer to the question, ‘how can I do the most good?’ \n \nIt's taken over 3 years and 10,000 hours of research to get here.\n \nWhat am I talking about?🧵to explain.\nPlease read, then AMA about this research! https://t.co/zMpAYrUwiF",
      "expandedUrl" : "https://twitter.com/i/web/status/1595743606966751233"
    }
  },
  {
    "like" : {
      "tweetId" : "1595342154540384256",
      "fullText" : "Associate Professor @BorisLeeuwen @TilburgU_TiSEM has received a prestigious @ERC_Research grant for new research on the role of emotional intelligence in strategic interactions and markets. #ERCStG https://t.co/nTjxu3Jc0p https://t.co/mfkb498YU6",
      "expandedUrl" : "https://twitter.com/i/web/status/1595342154540384256"
    }
  },
  {
    "like" : {
      "tweetId" : "1595398894984339457",
      "fullText" : "My all-time favourite movie Twister (for obvious reasons) is being broadcasted tonight on Dutch TV and it's also the night before I turn 30 and it feels like the universe is coming together and I haven't felt this excited in a very long time 🌪️🥳 https://t.co/T5UoGWXhBg",
      "expandedUrl" : "https://twitter.com/i/web/status/1595398894984339457"
    }
  },
  {
    "like" : {
      "tweetId" : "1595338893502676993",
      "fullText" : "The #PDD22 at the #berlinscienceweek was a great event to connect!\nHonored to have received a prize for the best presentation on how #AI can corrupt human ethical behavior\nJoint work with the amazing @iyadrahwan @JFBonnefon @r_m_rilke B. Irlenbusch, M.Hagens, M. Leib &amp; Z. Rahwan https://t.co/ceC4OMrokC",
      "expandedUrl" : "https://twitter.com/i/web/status/1595338893502676993"
    }
  },
  {
    "like" : {
      "tweetId" : "1489296151555805194",
      "fullText" : "My grandma's response to my first manuscript acceptance #BlackHistoryMonth \n#BlackinSTEM https://t.co/9bI2jIpbYd",
      "expandedUrl" : "https://twitter.com/i/web/status/1489296151555805194"
    }
  },
  {
    "like" : {
      "tweetId" : "1489582598800162822",
      "fullText" : "@ridderjeroen @DeJongeAkademie Heel erg graag! Eisen zijn Nederlands en herhaalbaar experiment. Heel graag meer aandacht voor alfa en gamma!",
      "expandedUrl" : "https://twitter.com/i/web/status/1489582598800162822"
    }
  },
  {
    "like" : {
      "tweetId" : "1489395777105453061",
      "fullText" : "teaching tomorrow, working on my slides https://t.co/D3XfLkcgCT",
      "expandedUrl" : "https://twitter.com/i/web/status/1489395777105453061"
    }
  },
  {
    "like" : {
      "tweetId" : "1489576617911496708",
      "fullText" : "Dit ziet er echt heel tof en inspirerend uit! Allemaal kijken. Maar waar zijn de sociale en geesteswetenschappen, @DiederikJekel? Is er al een seizoen 2 geboekt? @DeJongeAkademie denkt graag met je mee. https://t.co/ewyYCC1aR4",
      "expandedUrl" : "https://twitter.com/i/web/status/1489576617911496708"
    }
  },
  {
    "like" : {
      "tweetId" : "1489541367785304065",
      "fullText" : "Hey @OpenAcademics @PhDVoice @PhDfriendSana @PhDspeaks! Just yesterday, my first paper was published (https://t.co/sZdQBFRqT1) and today I received my first invitation to publish in a #PredatoryJournal! Does that mean I'm finally an academic? #AcademicTwitter #AcademicChatter https://t.co/rIWsZevQpg",
      "expandedUrl" : "https://twitter.com/i/web/status/1489541367785304065"
    }
  },
  {
    "like" : {
      "tweetId" : "1489519170903588866",
      "fullText" : "New paper out 📢 You can read Dr. Mol's final PhD paper in Judgment and Decision Making journal: After the virtual flood! This is a #VirtualReality #EconTwitter experiment on #riskcommunication https://t.co/c7uqCfhjeR https://t.co/ZgyQPxJtf1",
      "expandedUrl" : "https://twitter.com/i/web/status/1489519170903588866"
    }
  },
  {
    "like" : {
      "tweetId" : "1488457782865108992",
      "fullText" : "Registrations are open for our IWDS workshop on the Digital Society! Register here by Feb 14: https://t.co/MZbtDJgdes\n\nWith 26 submissions, the (fully online) program is very rich and it involves: lightning talks, poster sessions, and speed dating!",
      "expandedUrl" : "https://twitter.com/i/web/status/1488457782865108992"
    }
  },
  {
    "like" : {
      "tweetId" : "1488963984141258753",
      "fullText" : "Aanstaande zaterdag 19.50 op NPO2 start mijn nieuwe programma! In Jekels Jacht kruip ik 8x in de huid van grootse Nederlandse wetenschappers en ga ik hun beroemdste experimenten over doen! Met stoomtreinen, kanonnen, droppings op de Noordzee en meer. https://t.co/qG25WVB4xj",
      "expandedUrl" : "https://twitter.com/i/web/status/1488963984141258753"
    }
  },
  {
    "like" : {
      "tweetId" : "1488886126031126531",
      "fullText" : "Surveying the Surveyors to Address Risk Perception and Adaptive Behaviour Cross-study Comparability \n#RiskSoS Discussion @EGU_NHESS with @m_de_Brito @emelinecomby @AlexanderFekete Peter Robinson, Iuliana Armas, Wouter Botzen, Christian Kuhlicke \nhttps://t.co/6OwZIHKoBE",
      "expandedUrl" : "https://twitter.com/i/web/status/1488886126031126531"
    }
  },
  {
    "like" : {
      "tweetId" : "1488902002176413706",
      "fullText" : "Lots of useful advice. https://t.co/UIhXE8iMgK",
      "expandedUrl" : "https://twitter.com/i/web/status/1488902002176413706"
    }
  },
  {
    "like" : {
      "tweetId" : "1488878050049675266",
      "fullText" : "[IVMers in Africa] Habari ya leo? This week we are in Isiolo county, Kenya, to visit county offices together with @ICPAC &amp; @CA_Latest for the @D2E_Project. We aim to create collaborations and discuss #drought,#environment &amp; #climatechange challenges. https://t.co/7fdN23xWwl",
      "expandedUrl" : "https://twitter.com/i/web/status/1488878050049675266"
    }
  },
  {
    "like" : {
      "tweetId" : "1488635756759461892",
      "fullText" : "@serapath @ninabreznik https://t.co/2uOpanS6HB",
      "expandedUrl" : "https://twitter.com/i/web/status/1488635756759461892"
    }
  },
  {
    "like" : {
      "tweetId" : "1488647448469950482",
      "fullText" : "@steen1969 Be interesting of this could be applied to generate behavioral changes for healthcare risks... https://t.co/p7ldNdeKMK",
      "expandedUrl" : "https://twitter.com/i/web/status/1488647448469950482"
    }
  },
  {
    "like" : {
      "tweetId" : "1488798000948420609",
      "fullText" : "Back in the lab with @VU_FBW students Jip and Eva and postdoc @DGeerse evaluating the merit of the increased field of view of #HoloLens2 for mixed-reality obstacle avoidance (https://t.co/hZwbulgf70), cueing (https://t.co/ohwoRT9o97) and target stepping (https://t.co/z0ao9BWqif) https://t.co/gCuEHwws2i",
      "expandedUrl" : "https://twitter.com/i/web/status/1488798000948420609"
    }
  },
  {
    "like" : {
      "tweetId" : "1488646993035804672",
      "fullText" : "It is exciting to see novel thinking about what #VR might do well for the remote [worker]. This paper demonstrates how experiencing a low probability hi impact event, changes one's #decisionmaking https://t.co/zwtqecYeSv",
      "expandedUrl" : "https://twitter.com/i/web/status/1488646993035804672"
    }
  },
  {
    "like" : {
      "tweetId" : "1488526668876632065",
      "fullText" : "Following yesterday's #StormCorrie I briefly explained to my American project partners how European windstorms are named. NL, UK &amp; IE use the same alphabetical naming list, &amp; GE has its own naming system. Just found out that GE was hit by Storm Nadia last weekend🙈 https://t.co/kQpjX86C4f",
      "expandedUrl" : "https://twitter.com/i/web/status/1488526668876632065"
    }
  },
  {
    "like" : {
      "tweetId" : "1488520946797498377",
      "expandedUrl" : "https://twitter.com/i/web/status/1488520946797498377"
    }
  },
  {
    "like" : {
      "tweetId" : "1488470085664661509",
      "fullText" : "Last month @Nature published an editorial about how to fight climate change. NO MENTION of the social sciences!\n\nOur new Letter in @Nature (led by @JKeersmaecker) clarifies the pivotal role of human behavior &amp; public support in solving the climate crisis!\n\nhttps://t.co/L6Qg27eE0f https://t.co/4MmBlEFpJQ",
      "expandedUrl" : "https://twitter.com/i/web/status/1488470085664661509"
    }
  },
  {
    "like" : {
      "tweetId" : "1488432169068417024",
      "fullText" : "Opinie: Help, de Nederlandse Middeleeuwen dreigen in de marge te verdwijnen https://t.co/1Ub2aREWsF via @volkskrant",
      "expandedUrl" : "https://twitter.com/i/web/status/1488432169068417024"
    }
  },
  {
    "like" : {
      "tweetId" : "1488142522450731011",
      "fullText" : "An open-source tool for online interactive coalition formation research (oTree based) @JoeriWissink @tilapronk @nielsvandeven \n\nhttps://t.co/gz4Zyr9hOl https://t.co/REE5Q4J3MB",
      "expandedUrl" : "https://twitter.com/i/web/status/1488142522450731011"
    }
  },
  {
    "like" : {
      "tweetId" : "1488326990411485185",
      "fullText" : "Hi! I'm the Department of Economics at Stockholm University. \n\nActually, I'm an account run by @jhaushofer.\n\nTo complicate matters, he sometimes gets instructions from his department chair what to post, even if he finds it embarrassing.\n\nUnrelatedly, @jhaushofer is now professor. https://t.co/Avsh1HOamT",
      "expandedUrl" : "https://twitter.com/i/web/status/1488326990411485185"
    }
  },
  {
    "like" : {
      "tweetId" : "1488100514982252550",
      "fullText" : "Oops 🙈\n\n#StormCorrie https://t.co/tFkPtz9EQv",
      "expandedUrl" : "https://twitter.com/i/web/status/1488100514982252550"
    }
  },
  {
    "like" : {
      "tweetId" : "1486279444213997570",
      "fullText" : "@JantsjeMol @ivanhaigh Yes yes a thousand times YES! 😍",
      "expandedUrl" : "https://twitter.com/i/web/status/1486279444213997570"
    }
  },
  {
    "like" : {
      "tweetId" : "1486274944929603585",
      "fullText" : "Nice \"Dos and don’ts of data visualisation\" by @EUEnvironment https://t.co/APMeJxcT35 https://t.co/eTvpEflaeN",
      "expandedUrl" : "https://twitter.com/i/web/status/1486274944929603585"
    }
  },
  {
    "like" : {
      "tweetId" : "1486226844185935873",
      "fullText" : "Check the view! https://t.co/TPRzbdNT6t",
      "expandedUrl" : "https://twitter.com/i/web/status/1486226844185935873"
    }
  },
  {
    "like" : {
      "tweetId" : "1485570795258716160",
      "fullText" : "Enjoying Yan Feng’s PhD Defense on using VR for pedestrian wayfinding &amp; evacuation behaviour @YanFeng520 @TUDelft_CT https://t.co/6lGApYgq1V",
      "expandedUrl" : "https://twitter.com/i/web/status/1485570795258716160"
    }
  },
  {
    "like" : {
      "tweetId" : "1485750776752398341",
      "expandedUrl" : "https://twitter.com/i/web/status/1485750776752398341"
    }
  },
  {
    "like" : {
      "tweetId" : "1484581848172974082",
      "expandedUrl" : "https://twitter.com/i/web/status/1484581848172974082"
    }
  },
  {
    "like" : {
      "tweetId" : "1484520648177340421",
      "fullText" : "Next Monday on 24th January, I will defend my PhD dissertation titled Pedestrian Wayfinding and Evacuation in Virtual Reality. I’ll first give the layman’s talk at 12:00 and the defence ceremony starts at 12:30. Welcome to join me online 🙌🏻 https://t.co/OVoq4qd14P",
      "expandedUrl" : "https://twitter.com/i/web/status/1484520648177340421"
    }
  },
  {
    "like" : {
      "tweetId" : "1484170550578610177",
      "expandedUrl" : "https://twitter.com/i/web/status/1484170550578610177"
    }
  },
  {
    "like" : {
      "tweetId" : "1484080222039330816",
      "fullText" : "Whoop paper accepted. A nice start to the day.",
      "expandedUrl" : "https://twitter.com/i/web/status/1484080222039330816"
    }
  },
  {
    "like" : {
      "tweetId" : "1483914357138460682",
      "fullText" : "Co-authors are like buses. You don't hear anything for months and then all of a sudden three show up at the same time.",
      "expandedUrl" : "https://twitter.com/i/web/status/1483914357138460682"
    }
  },
  {
    "like" : {
      "tweetId" : "1483821687795863553",
      "fullText" : "Er wordt veel tijd gestopt in het ontwikkelen van interventies, maar weinig nagedacht of deze aansluiten bij de doelgroep, of geevalueerd of ze effectief waren. \n\nInterventies om vleesconsumptie te verminderen kunnen effectiever volgens deze 4 stappen: https://t.co/q0dk6uzbO2",
      "expandedUrl" : "https://twitter.com/i/web/status/1483821687795863553"
    }
  },
  {
    "like" : {
      "tweetId" : "1483702796163719171",
      "fullText" : "(in case it isn't obvious, this tweet was a joke.)",
      "expandedUrl" : "https://twitter.com/i/web/status/1483702796163719171"
    }
  },
  {
    "like" : {
      "tweetId" : "1483262498547855360",
      "fullText" : "- Graphic designer: What do you want to achieve with your color scale?\n- @tagesschau: Maximize confusion! \n- Graphic designer: I have just the thing for you https://t.co/kLN3ugop1O",
      "expandedUrl" : "https://twitter.com/i/web/status/1483262498547855360"
    }
  },
  {
    "like" : {
      "tweetId" : "1483263152733429760",
      "fullText" : "🧐 https://t.co/pLC2Y90mVT",
      "expandedUrl" : "https://twitter.com/i/web/status/1483263152733429760"
    }
  },
  {
    "like" : {
      "tweetId" : "1483404043179466752",
      "fullText" : "📣Our new paper is out now! Key message: accounting for seasonality matters when assessing  flood risk. Excellent research by @anaiscouasnon 🥳 https://t.co/DwWcn2Dw9z",
      "expandedUrl" : "https://twitter.com/i/web/status/1483404043179466752"
    }
  },
  {
    "like" : {
      "tweetId" : "1483148684497879043",
      "fullText" : "You’re unable to view this Post because this account owner limits who can view their Posts. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1483148684497879043"
    }
  },
  {
    "like" : {
      "tweetId" : "1483349774720028679",
      "fullText" : "@thomasthaler8 If the wind is going in the right direction, maybe add a sail?",
      "expandedUrl" : "https://twitter.com/i/web/status/1483349774720028679"
    }
  },
  {
    "like" : {
      "tweetId" : "1483303438943494149",
      "fullText" : "Hypothesis Generation https://t.co/RjhhCCeSZC https://t.co/PGLFtAiA5T",
      "expandedUrl" : "https://twitter.com/i/web/status/1483303438943494149"
    }
  },
  {
    "like" : {
      "tweetId" : "1483080716569165826",
      "fullText" : "As of today we are the official owners of this pile of dirt! \n\nNow we'll wait till the contractor turns this into our new home 😊 🏡 https://t.co/QXGD9wFEA5",
      "expandedUrl" : "https://twitter.com/i/web/status/1483080716569165826"
    }
  },
  {
    "like" : {
      "tweetId" : "1483106705470902279",
      "fullText" : "My son expressed the ambition to become a ghost and as a psychologist that provides such a fun view on dealing with ambitions https://t.co/ozre4wt1wC",
      "expandedUrl" : "https://twitter.com/i/web/status/1483106705470902279"
    }
  },
  {
    "like" : {
      "tweetId" : "1483056385868939269",
      "fullText" : "Is taxing meat really a good idea? Our new study evaluates meat taxes from a public economics perspective https://t.co/11XpabOdXn (1/9) @FunkeFranziska @Treich13 @camjhep @INETOxford @TheSmithSchool @oxfordgeography @oxmartinschool",
      "expandedUrl" : "https://twitter.com/i/web/status/1483056385868939269"
    }
  },
  {
    "like" : {
      "tweetId" : "1482429694742077448",
      "fullText" : "Last week I handed in my thesis, and this week I started my first post-doc! What a start to 2022! ✨ \n#phdchat #phdlife #thesis https://t.co/kOzRK1eimr",
      "expandedUrl" : "https://twitter.com/i/web/status/1482429694742077448"
    }
  },
  {
    "like" : {
      "tweetId" : "1482668980267622405",
      "expandedUrl" : "https://twitter.com/i/web/status/1482668980267622405"
    }
  },
  {
    "like" : {
      "tweetId" : "1481619578983784448",
      "fullText" : "Great kick-off of the @BSE_Berlin INSIGHTS workshop 'Communicating Climate Change Economics' with @Liliann_F. Looking forward to two inspiring workshop days! https://t.co/smfSkFMFU3",
      "expandedUrl" : "https://twitter.com/i/web/status/1481619578983784448"
    }
  },
  {
    "like" : {
      "tweetId" : "1481652700215275522",
      "fullText" : "I was just awarded @ESHPM_EUR Frans Rutten Research Award. Huge honour to receive this recognition from colleagues, esp. as its namesake was core to founding the institute and health econ. in NL. https://t.co/24RIS5SnhQ",
      "expandedUrl" : "https://twitter.com/i/web/status/1481652700215275522"
    }
  },
  {
    "like" : {
      "tweetId" : "1481573553686339585",
      "fullText" : "Laptops aansluiten op projectoren. https://t.co/HvZIR9nLjA",
      "expandedUrl" : "https://twitter.com/i/web/status/1481573553686339585"
    }
  },
  {
    "like" : {
      "tweetId" : "1481215927718928384",
      "fullText" : "We do love a good index.... https://t.co/g75wzo9qxv",
      "expandedUrl" : "https://twitter.com/i/web/status/1481215927718928384"
    }
  },
  {
    "like" : {
      "tweetId" : "1481258453167489035",
      "fullText" : "Cool live presentation! https://t.co/IAU9cXxdPH",
      "expandedUrl" : "https://twitter.com/i/web/status/1481258453167489035"
    }
  },
  {
    "like" : {
      "tweetId" : "1480836961426366467",
      "fullText" : "Reviewer 2 provided 8 pages of comments and suggestions that are brilliant, and I am so excited about it. https://t.co/p2oi28XiWn",
      "expandedUrl" : "https://twitter.com/i/web/status/1480836961426366467"
    }
  },
  {
    "like" : {
      "tweetId" : "1480853892971827201",
      "fullText" : "I wonder if the effectiveness of vaccines is generally underestimated b/c people are more likely to share surprising outcomes (\"Got Covid despite three jabs!\"), making these instances more available.\n\nTo counteract this: Had 3 shots and no Covid!",
      "expandedUrl" : "https://twitter.com/i/web/status/1480853892971827201"
    }
  },
  {
    "like" : {
      "tweetId" : "1480803562951168002",
      "fullText" : "Last chance to sign up for my #oTree workshop, happening on January 17th, 18th, 29th &amp; 21st from 09:00 to 14:30 CET (EU Time). Sign up here: https://t.co/8jBdy9gDDS",
      "expandedUrl" : "https://twitter.com/i/web/status/1480803562951168002"
    }
  },
  {
    "like" : {
      "tweetId" : "1480496389675098113",
      "fullText" : "Incredibly happy to share this wonderful news: I've been awarded an @ERC_Research Starting Grant for my project FLORA (Sustainable and healthy food solutions: system dynamics and trade-offs)! 4 researchers &amp; I will provide data, modelling &amp; analysis for sustainable food #ERCStG https://t.co/7daYIUkCsK",
      "expandedUrl" : "https://twitter.com/i/web/status/1480496389675098113"
    }
  },
  {
    "like" : {
      "tweetId" : "1480086965311651840",
      "fullText" : "Hoera, we zijn jarig! https://t.co/rWr9betHkl",
      "expandedUrl" : "https://twitter.com/i/web/status/1480086965311651840"
    }
  },
  {
    "like" : {
      "tweetId" : "1479375784326447106",
      "fullText" : "Eindelijk, de papieren versie van Nederland in Cijfers van ⁦@statistiekcbs⁩ https://t.co/kvuMps4qmg https://t.co/34FaLVxnRq",
      "expandedUrl" : "https://twitter.com/i/web/status/1479375784326447106"
    }
  },
  {
    "like" : {
      "tweetId" : "1479112012558782464",
      "fullText" : "Home sweet home in winter wonderland @KranjskaGora https://t.co/f36oVf8c8g",
      "expandedUrl" : "https://twitter.com/i/web/status/1479112012558782464"
    }
  },
  {
    "like" : {
      "tweetId" : "1478760475689160715",
      "expandedUrl" : "https://twitter.com/i/web/status/1478760475689160715"
    }
  },
  {
    "like" : {
      "tweetId" : "1478751959964340229",
      "fullText" : "When do nudges work? Our new meta-analysis compares the effect sizes of different choice architecture interventions across behavioral domains. https://t.co/vGqG7CpPkS",
      "expandedUrl" : "https://twitter.com/i/web/status/1478751959964340229"
    }
  },
  {
    "like" : {
      "tweetId" : "1478433166960447490",
      "fullText" : "Check out my new R package — eumaps! eumaps makes it easy to make professional-quality choropleth maps of the #EuropeanUnion with only a few lines of code. A dev version’s now available on GitHub! Here’s a 🧵 with examples #rstats #dataviz https://t.co/KwEYwOjxP5 https://t.co/Yof1LToBfc",
      "expandedUrl" : "https://twitter.com/i/web/status/1478433166960447490"
    }
  },
  {
    "like" : {
      "tweetId" : "1478392306516516868",
      "fullText" : "Hi everyone! I’m Sandra Geiger (@SandraJGeiger), PhD student at @EnvPsyVienna and one of the faces behind this Twitter account. I get excited about many topics in environmental psychology, including behavior change, nature connectedness, decision-making, and spillover effects. https://t.co/8DuFeKO1uW",
      "expandedUrl" : "https://twitter.com/i/web/status/1478392306516516868"
    }
  },
  {
    "like" : {
      "tweetId" : "1478650156866314240",
      "fullText" : "@EADM_1993 Imagine my horror when I pointed out to my partner Prof. Mindy’s annoying tendency to launch into full-on lecture-mode mid-conversation and he told me that I occasionally do that too 😱😬",
      "expandedUrl" : "https://twitter.com/i/web/status/1478650156866314240"
    }
  },
  {
    "like" : {
      "tweetId" : "1478455211001851918",
      "fullText" : "@SlinkyScience AND YOU CAN DO IT!",
      "expandedUrl" : "https://twitter.com/i/web/status/1478455211001851918"
    }
  },
  {
    "like" : {
      "tweetId" : "1478367043485323268",
      "fullText" : "@c_a_gravert https://t.co/3apNlPUsDt",
      "expandedUrl" : "https://twitter.com/i/web/status/1478367043485323268"
    }
  },
  {
    "like" : {
      "tweetId" : "1477976994193231872",
      "fullText" : "Those that know me can attest that I’ve been pretty vocal about my hopes of a career in academia. Amidst announcements by far more experienced (and deserving) scholars, I’m very excited to announce that as of 2022 I’m tenured! A thread: (1/n)",
      "expandedUrl" : "https://twitter.com/i/web/status/1477976994193231872"
    }
  },
  {
    "like" : {
      "tweetId" : "1477941739977678850",
      "fullText" : "Best wishes for 2022! Let the sun shine through the clouds! 🌤️ https://t.co/fJ8KJnHy9G",
      "expandedUrl" : "https://twitter.com/i/web/status/1477941739977678850"
    }
  },
  {
    "like" : {
      "tweetId" : "1475241218271555590",
      "fullText" : "https://t.co/rWLcIu2QqX also seems like a worthy cause. Donate at least $100, and I'll send you a @UChicago quad desk plaque. Just DM me the receipt and a proper mailing address. https://t.co/iNJvEY7PWX https://t.co/C8Ucd22PqO",
      "expandedUrl" : "https://twitter.com/i/web/status/1475241218271555590"
    }
  },
  {
    "like" : {
      "tweetId" : "1473853308930600962",
      "fullText" : "Honesty is not the best policy. \n\nA carbon tax with compensatory reductions in distortionary taxes is the best policy.",
      "expandedUrl" : "https://twitter.com/i/web/status/1473853308930600962"
    }
  },
  {
    "like" : {
      "tweetId" : "1473992495004540931",
      "fullText" : "A shout out to our master students in Spatial Engineering program \n@FacultyITC! All three groups did wonderful presenting their interventions on Iran's groundwater issue and Maasai, Kenya's food security improvement. (while keeping safe distance). Koodos! #proudteacher https://t.co/tIRvXv9Owk",
      "expandedUrl" : "https://twitter.com/i/web/status/1473992495004540931"
    }
  },
  {
    "like" : {
      "tweetId" : "1473947388180062208",
      "fullText" : "\"Rijkswaterstaat: op meer dan 40 procent van de Nederlandse wegen is de maximumsnelheid hoger dan verantwoord voor het omliggende landschap\" https://t.co/UO1vMLM0di",
      "expandedUrl" : "https://twitter.com/i/web/status/1473947388180062208"
    }
  },
  {
    "like" : {
      "tweetId" : "1473934408113606660",
      "fullText" : "#teaching #personalfinance doesn't work. Throwing information at people doesn't working according to #behavioralscience. Right?\n\nHowever, a recent analysis reviewing #research in this topic shows that teaching #finance does work!\n\nWhat changed?\n\n#money \n\nhttps://t.co/eT6aQgAEq8",
      "expandedUrl" : "https://twitter.com/i/web/status/1473934408113606660"
    }
  },
  {
    "like" : {
      "tweetId" : "1473718334986330120",
      "fullText" : "Piushaven, Tilburg https://t.co/OX0v6fwIMC",
      "expandedUrl" : "https://twitter.com/i/web/status/1473718334986330120"
    }
  },
  {
    "like" : {
      "tweetId" : "1473697389907222538",
      "fullText" : "Waking up to a \"Manuscript Accepted\" email as a Christmas Miracle! \nThis paper went through 4 rounds of R&amp;R and since its very first submission to a journal, it has been more than 684 days. This is a PR for me.\nI will tweet about it once it becomes available online.",
      "expandedUrl" : "https://twitter.com/i/web/status/1473697389907222538"
    }
  },
  {
    "like" : {
      "tweetId" : "1473552229286260738",
      "fullText" : "Wij spraken @egerrit, tot een half jaar geleden de hoogste ambtenaar van VWS, over corona als 'ongetemd probleem'\n\n'Had je midden in de shit weg kunnen komen met: “Beste mensen, u wilt perspectief? (...) Sorry, maar dat kan niet, want we weten het niet\"' \n\nhttps://t.co/eDoFZX9OMt",
      "expandedUrl" : "https://twitter.com/i/web/status/1473552229286260738"
    }
  },
  {
    "like" : {
      "tweetId" : "1473346339442511875",
      "fullText" : "Excited about my first publication, together with Giorgia Romagnoli and Theo Offerman! Check the link below for the paper👇🏻 https://t.co/BJRUOztoiw",
      "expandedUrl" : "https://twitter.com/i/web/status/1473346339442511875"
    }
  },
  {
    "like" : {
      "tweetId" : "1472997575380906006",
      "expandedUrl" : "https://twitter.com/i/web/status/1472997575380906006"
    }
  },
  {
    "like" : {
      "tweetId" : "1471893794807287809",
      "fullText" : "Overall, I am very happy with the way my office turned out 😊 https://t.co/x6QJU11sv1",
      "expandedUrl" : "https://twitter.com/i/web/status/1471893794807287809"
    }
  },
  {
    "like" : {
      "tweetId" : "1471487640100687874",
      "fullText" : "Received this from @FacultyITC besides all the other nice gifts 😁 I know what to do after today's work: put up the tree! One more tree for the world! https://t.co/oW5u2Kh7ov",
      "expandedUrl" : "https://twitter.com/i/web/status/1471487640100687874"
    }
  },
  {
    "like" : {
      "tweetId" : "1471514996072873984",
      "expandedUrl" : "https://twitter.com/i/web/status/1471514996072873984"
    }
  },
  {
    "like" : {
      "tweetId" : "1471399989003882497",
      "fullText" : "Empiricists need to know with real world data, and that is messy, and requires advanced techniques. \n\nBut experimenters engineer their data generating process.\n\nSo, this is your job, experimenters: fine tune your design till all you need is comparing two distributions. https://t.co/towxYfvowL",
      "expandedUrl" : "https://twitter.com/i/web/status/1471399989003882497"
    }
  },
  {
    "like" : {
      "tweetId" : "1471153139814391813",
      "fullText" : "Today was the last day of my visit at @TheChoiceLab. Thanks to everyone at @NHHEcon for being so welcoming and I hope I’ll be back soon! 😊 https://t.co/SGtrdd23Fi",
      "expandedUrl" : "https://twitter.com/i/web/status/1471153139814391813"
    }
  },
  {
    "like" : {
      "tweetId" : "1471070108441268227",
      "expandedUrl" : "https://twitter.com/i/web/status/1471070108441268227"
    }
  },
  {
    "like" : {
      "tweetId" : "1470864367692521477",
      "fullText" : "5-min madness presentation ready for #AGU21 tomorrow at the H32D: Advancing Flood Characterization, Modeling, and Communication! \nLonger (more relax/detailed) version available at https://t.co/bgaG76Fw1L! https://t.co/RztwEmYJyV",
      "expandedUrl" : "https://twitter.com/i/web/status/1470864367692521477"
    }
  },
  {
    "like" : {
      "tweetId" : "1470615221991616514",
      "fullText" : "You’re unable to view this Post because this account owner limits who can view their Posts. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1470615221991616514"
    }
  },
  {
    "like" : {
      "tweetId" : "1470664199244234752",
      "fullText" : "I've always thought humour was a great strategy to deal with aggression. In this case, it seems like \"all you need is love\" https://t.co/zBpJpe0z7L",
      "expandedUrl" : "https://twitter.com/i/web/status/1470664199244234752"
    }
  },
  {
    "like" : {
      "tweetId" : "1469335354436202496",
      "fullText" : "@JantsjeMol Ooo I didn't realise I didn't have open DMs. Open now, thank you!",
      "expandedUrl" : "https://twitter.com/i/web/status/1469335354436202496"
    }
  },
  {
    "like" : {
      "tweetId" : "1469282624065753088",
      "fullText" : "Net kreeg ik goed nieuws van de decaan van @ErasmusESL waar ik blij mee ben! Ik ben met terugwerkende kracht benoemd tot universitair hoofddocent. 🥳 Dat worden bubbels vanavond https://t.co/vbdCUaEJ1C",
      "expandedUrl" : "https://twitter.com/i/web/status/1469282624065753088"
    }
  },
  {
    "like" : {
      "tweetId" : "1469085049748439050",
      "fullText" : "Reading exam papers late night, and seeing these notes on papers makes it fun☺️ https://t.co/ilfo8H9aiY",
      "expandedUrl" : "https://twitter.com/i/web/status/1469085049748439050"
    }
  },
  {
    "like" : {
      "tweetId" : "1468952565035323395",
      "fullText" : "@MicaelCasta @steffenhuck Agree with this take, tho maybe there’s room for both. Seems that changing the editorial boards of leading journals requires playing the (very) long game..",
      "expandedUrl" : "https://twitter.com/i/web/status/1468952565035323395"
    }
  },
  {
    "like" : {
      "tweetId" : "1468678802431787016",
      "fullText" : "I have a question for all working in behavioral econ. Would you consider submitting to a new open access journal with a first-rate editorial board, swift turnaround and a very reasonable fee (APC)? Aim would be to be the best outlet after GEB, EE and JEBO.",
      "expandedUrl" : "https://twitter.com/i/web/status/1468678802431787016"
    }
  },
  {
    "like" : {
      "tweetId" : "1468868797926944771",
      "expandedUrl" : "https://twitter.com/i/web/status/1468868797926944771"
    }
  },
  {
    "like" : {
      "tweetId" : "1468500686522523654",
      "fullText" : "Zometeen college Methoden en Technieken I over het goed kijken naar en interpreteren van statistische figuren. Ik gebruik o.a. het boek \"How charts lie: Getting smarter about visual information\" van @AlbertoCairo. Poes Soes is fan. https://t.co/1LXOxoc2rb",
      "expandedUrl" : "https://twitter.com/i/web/status/1468500686522523654"
    }
  },
  {
    "like" : {
      "tweetId" : "1468207021933613076",
      "expandedUrl" : "https://twitter.com/i/web/status/1468207021933613076"
    }
  },
  {
    "like" : {
      "tweetId" : "1468145296341454848",
      "fullText" : "And my visa application has been approved, yes!!! 🤩",
      "expandedUrl" : "https://twitter.com/i/web/status/1468145296341454848"
    }
  },
  {
    "like" : {
      "tweetId" : "1466773697029672967",
      "fullText" : "That feeling when you open your favorite newsletter from the @nytimes to read about their 8 favorite books of 2021 and find your book at the top of the list 🤯https://t.co/NKej3uWiTy https://t.co/2xkMskWOoo",
      "expandedUrl" : "https://twitter.com/i/web/status/1466773697029672967"
    }
  },
  {
    "like" : {
      "tweetId" : "1466736380449546241",
      "fullText" : "I'm overjoyed to be awarded the cum laude recognition (top &lt;5 % graduating PhD in the field) for my dissertation @ErasmusESE on   Thursday 01.12.2021 ❤️ Thank you so much for your kindest of trust in my scholarship @juliahberg @ThomasBuser @pilargargo, Malia and Dinand!!! https://t.co/RzkgrHfxRV",
      "expandedUrl" : "https://twitter.com/i/web/status/1466736380449546241"
    }
  },
  {
    "like" : {
      "tweetId" : "1466442091194732553",
      "fullText" : "@SanneJWWillems @caal @ionicasmeets Van harte met jullie mooie stuk over kanswoorden in @onzetaal ! Ook wel jaloers, toptijdschrift.",
      "expandedUrl" : "https://twitter.com/i/web/status/1466442091194732553"
    }
  },
  {
    "like" : {
      "tweetId" : "1466515966431576067",
      "fullText" : "Hey #EconTwitter, I'm a behavioral economist from @BSE_Berlin and @WZB_Berlin.\n\nWebsite: https://t.co/XI9zssocdX\n\nNow is my turn to create a thread about my JMP. But, instead, let me use an infographic👇\n\nTLDR: People prefer not to lie, but benefiting others makes it easier. https://t.co/TPKrWBCnic",
      "expandedUrl" : "https://twitter.com/i/web/status/1466515966431576067"
    }
  },
  {
    "like" : {
      "tweetId" : "1466399389790912513",
      "fullText" : "@wxpizza @mkvaalst @LamontEarth @SCamargo @profadamsobel @Columbia @climatesociety @RCClimate @FacultyITC @columbiaclimate I also want to throw fellow great researchers @amynpolen @JantsjeMol and @Jennife80870085 in the loop here as we are also working on improving people's risk perception through a new hurricane classification system :)",
      "expandedUrl" : "https://twitter.com/i/web/status/1466399389790912513"
    }
  },
  {
    "like" : {
      "tweetId" : "1466086267037360132",
      "fullText" : "Our paper “Impacts of compound hot–dry extremes on US soybean yields” is now published in @EGU_ESD: https://t.co/OM927ulHM1 (written with @AnneVanLoon, @JeroenAerts4  and @DimCoumou, fyi @IVM). See thread (🧵) below explaining the main findings. [1/7]\n#compound #hot #dry #impacts",
      "expandedUrl" : "https://twitter.com/i/web/status/1466086267037360132"
    }
  },
  {
    "like" : {
      "tweetId" : "1465652493837389828",
      "fullText" : "[IVMer of the week] Hi, I’m Marthe Wens, a PhD candidate focussing on integrating human adaptive behaviour in #drought disaster risk assessments. This week, we are in #Texel with my drought research group where we will focus on proposal, paper, and in my case, #PhDThesis writing. https://t.co/TQt73u87vf",
      "expandedUrl" : "https://twitter.com/i/web/status/1465652493837389828"
    }
  },
  {
    "like" : {
      "tweetId" : "1465649987564584962",
      "fullText" : "Been trying to build a tropical cyclone rainfall model. Kept ending up at way too low rainfall accumulation numbers (factor 2 too low compared to observations). \"Improved\" the model a bit. Now my model is producing 4m of rainfall for a single storm. 😅🥴 https://t.co/Lcfz4ErI7k",
      "expandedUrl" : "https://twitter.com/i/web/status/1465649987564584962"
    }
  },
  {
    "like" : {
      "tweetId" : "1465346084771975174",
      "fullText" : "Is roddelen slecht? Niet per se, vertelt @TDoresCruz in dit interview met Het @Parool. \"Als we niet roddelen, zouden we niet weten wie we kunnen vertrouwen.\"  https://t.co/XfE9vwdSPp",
      "expandedUrl" : "https://twitter.com/i/web/status/1465346084771975174"
    }
  },
  {
    "like" : {
      "tweetId" : "1465451805719113736",
      "fullText" : "I want to share with you all this great JMP from a great colleague and even better economist, @yunxiaoecon. I've had the pleasure to discuss with her about this paper and I have to say, that it is a pleasure to see research done this way. Thorough, methodical and with impact. https://t.co/BfKsFs2L99",
      "expandedUrl" : "https://twitter.com/i/web/status/1465451805719113736"
    }
  },
  {
    "like" : {
      "tweetId" : "1465319980682121217",
      "fullText" : "Bent\nArt Blocks Curated\n1023 mints | Dutch Auction\nToday | 12pm Central Time\nhttps://t.co/SgIcdcpvvB https://t.co/Sat7ckdtDa",
      "expandedUrl" : "https://twitter.com/i/web/status/1465319980682121217"
    }
  },
  {
    "like" : {
      "tweetId" : "1465084818442493953",
      "expandedUrl" : "https://twitter.com/i/web/status/1465084818442493953"
    }
  },
  {
    "like" : {
      "tweetId" : "1465261820147601409",
      "fullText" : "Onto my #phd #viva now. Wish me luck!",
      "expandedUrl" : "https://twitter.com/i/web/status/1465261820147601409"
    }
  },
  {
    "like" : {
      "tweetId" : "1463544344883908610",
      "fullText" : "Goed, even pauze, tijd voor stukje kritiek op iets wat me al langer dwars zit: het #OMT en 'de kwestie gedrag'. 🧵 (1/10) https://t.co/fWRes4psZm",
      "expandedUrl" : "https://twitter.com/i/web/status/1463544344883908610"
    }
  },
  {
    "like" : {
      "tweetId" : "1463456008026611713",
      "fullText" : "Recensie van @NRC en HET IS EEN HELE FIJNE MET VIER BOLLEN OF STERREN OF HOE JE DIE DINGEN OOK NOEMT, ik ben zó godvergeten blij. HAAAAA.\nhttps://t.co/etU8XEYaxU",
      "expandedUrl" : "https://twitter.com/i/web/status/1463456008026611713"
    }
  },
  {
    "like" : {
      "tweetId" : "1463426610724585472",
      "fullText" : "And more happy news, we just got revisions back on our STORM climate change paper (after two desk rejections🙈). So happy about this, really want to get this work published! &amp; A really cool birthday gift to find in my inbox this morning 🙃 (that's the last happy news item😜)",
      "expandedUrl" : "https://twitter.com/i/web/status/1463426610724585472"
    }
  },
  {
    "like" : {
      "tweetId" : "1463168503272386570",
      "fullText" : "Super interesting from economist Catherine Eckel on pros/cons of incentives vs surveys\n\n\"Overall, the evidence does not support the general belief that incentivized tasks are superior in all (or most) cases, implying that surveys may warrant increased usage in certain contexts\" https://t.co/3NSoSdf1KL",
      "expandedUrl" : "https://twitter.com/i/web/status/1463168503272386570"
    }
  },
  {
    "like" : {
      "tweetId" : "1462739809026428928",
      "fullText" : "I will run another #oTree Workshop on January the 17th, 18th 20th &amp; 21st from  9:00 to 14:30 CET. Sign up here: https://t.co/3FzSBlgBj6 , more information here: https://t.co/uxOAjGjwks #EconTwitter . I would be glad if you could share the news with people who may be interested",
      "expandedUrl" : "https://twitter.com/i/web/status/1462739809026428928"
    }
  },
  {
    "like" : {
      "tweetId" : "1462819571275083780",
      "fullText" : "Realising how much academic development is (or should be) about building #confidence. Yes, you increase your understanding of processes &amp; learn to apply new methods, but you also learn that you have something important to contribute and that your voice matters. #AcademicTwitter",
      "expandedUrl" : "https://twitter.com/i/web/status/1462819571275083780"
    }
  },
  {
    "like" : {
      "tweetId" : "1462745045833064457",
      "fullText" : "Paper alert📄\nNew publication of #VR and #wayfinding study in #SafetyScience. \nWe develop and evaluate the validity and usability of a VR research tool (WayR) that is designed to study pedestrian wayfinding behaviour in a multi-story building. \nOpen access:https://t.co/PI50R3cQay https://t.co/2ewpwJBGEV",
      "expandedUrl" : "https://twitter.com/i/web/status/1462745045833064457"
    }
  },
  {
    "like" : {
      "tweetId" : "1462817062565425153",
      "fullText" : "Very excited about presenting my work on cooperation at the upcoming Cooperation Colloquium this Friday! https://t.co/fBewKNKEvO",
      "expandedUrl" : "https://twitter.com/i/web/status/1462817062565425153"
    }
  },
  {
    "like" : {
      "tweetId" : "1461641377176039424",
      "fullText" : "Presenting tropical cyclone risk research for the Dutch Caribbean at the Dutch meteorology conference ...  in my favourite meteo-sweater 😎☁️ https://t.co/qbmkPn2f20",
      "expandedUrl" : "https://twitter.com/i/web/status/1461641377176039424"
    }
  },
  {
    "like" : {
      "tweetId" : "1460969287879995399",
      "fullText" : "Hey everyone, \nIf you use the Overleaf online editor, today I'm publishing Shortleaf, a Chrome extension that adds to it fully customizable keyboard shortcuts!\nUse it to type your Greek letters easily, insert Latex commands or something else, up to you. Some screenshots below\n1/2 https://t.co/jAQejqX2um",
      "expandedUrl" : "https://twitter.com/i/web/status/1460969287879995399"
    }
  },
  {
    "like" : {
      "tweetId" : "1460536822988165128",
      "fullText" : "Fantastic! After 8 years of developing this journal together with many colleagues at the Society for Experimental Finance and beyond, this journal will finally enter the SSCI and receive an impact factor. A big thanks to everyone who contributed to make this outlet a success. https://t.co/0U2crJ3oyu",
      "expandedUrl" : "https://twitter.com/i/web/status/1460536822988165128"
    }
  },
  {
    "like" : {
      "tweetId" : "1459164279203106820",
      "fullText" : "@JantsjeMol I thought such revisions are just a myth!",
      "expandedUrl" : "https://twitter.com/i/web/status/1459164279203106820"
    }
  },
  {
    "like" : {
      "tweetId" : "1459157341627105282",
      "fullText" : "A treemap on the NYT homepage https://t.co/oomBHoSj3p",
      "expandedUrl" : "https://twitter.com/i/web/status/1459157341627105282"
    }
  },
  {
    "like" : {
      "tweetId" : "1459172477511294976",
      "fullText" : "@JantsjeMol Congrats!",
      "expandedUrl" : "https://twitter.com/i/web/status/1459172477511294976"
    }
  },
  {
    "like" : {
      "tweetId" : "1459139028721311749",
      "expandedUrl" : "https://twitter.com/i/web/status/1459139028721311749"
    }
  },
  {
    "like" : {
      "tweetId" : "1458896778674294789",
      "fullText" : "Vaccinatie werkt 😎 (en strakke zelfisolatie met afstand houden, maximaal ventileren, en mondneusmaskers waar nodig ook).\n\nHet enige wat niet werkt is dat ik niet voor @Ipie33 kan zorgen zoals ik dat normaal zou doen. Maar we slaan ons er doorheen 💪 https://t.co/XlvHzeru3n https://t.co/RYoXr0fYuf",
      "expandedUrl" : "https://twitter.com/i/web/status/1458896778674294789"
    }
  },
  {
    "like" : {
      "tweetId" : "1458846361361780739",
      "fullText" : "@Bloemendaal_N @ivanhaigh @ISTORMnetwork Sign me up!",
      "expandedUrl" : "https://twitter.com/i/web/status/1458846361361780739"
    }
  },
  {
    "like" : {
      "tweetId" : "1458797767409782794",
      "fullText" : "@JacopoMazza This is a crime.",
      "expandedUrl" : "https://twitter.com/i/web/status/1458797767409782794"
    }
  },
  {
    "like" : {
      "tweetId" : "1458798827746516997",
      "fullText" : "@SCamargo @ivanhaigh @ISTORMnetwork I will take you on a tour of our flood defenses if you ever find yourself in the Netherlands 😉",
      "expandedUrl" : "https://twitter.com/i/web/status/1458798827746516997"
    }
  },
  {
    "like" : {
      "tweetId" : "1458727930125815808",
      "fullText" : "During the last three days, @AnneVanLoon, @Mar_Schaafsma, @MauriMazzoleni, Lotte Muller and Marthe Wens participated in the Kick-off of the #H2020 project I-CISK on innovating climate services through integrating scientific and local knowledge @ihedelft. https://t.co/f3AkXIOxMw",
      "expandedUrl" : "https://twitter.com/i/web/status/1458727930125815808"
    }
  },
  {
    "like" : {
      "tweetId" : "1458549495491334144",
      "fullText" : "Our paper “Does Losing Lead to Winning? An Empirical Analysis for Four Sports” (with @MJvandenAssem and @boukekt) has been accepted at Management Science! https://t.co/I72aITlVBs",
      "expandedUrl" : "https://twitter.com/i/web/status/1458549495491334144"
    }
  },
  {
    "like" : {
      "tweetId" : "1458468564856459274",
      "expandedUrl" : "https://twitter.com/i/web/status/1458468564856459274"
    }
  },
  {
    "like" : {
      "tweetId" : "1458109269568589837",
      "fullText" : "Really cool to find myself among the awardees for the  Virtual Outstanding Student and PhD candidate Presentation (vOSPP) Awards 2021 @EGU_NP  https://t.co/gyIrhrrqxR",
      "expandedUrl" : "https://twitter.com/i/web/status/1458109269568589837"
    }
  },
  {
    "like" : {
      "tweetId" : "1457415353022169091",
      "fullText" : "Some photos of my defense ceremony last Wednesday. The first photo is my favourite, this was the exact moment the rector announced I graduated cum laude. I particularly like everyone's facial expressions :)\n\n(Thanks @pleunbonekamp for the photos!!) https://t.co/dWwxKQDIAN",
      "expandedUrl" : "https://twitter.com/i/web/status/1457415353022169091"
    }
  },
  {
    "like" : {
      "tweetId" : "1456350190001131522",
      "fullText" : "The final paper from my PhD is out! In “Drivers behind the summer 2010 wave train leading to Russian heatwave and Pakistan flooding”  we explore how soil moisture and high-latitude land warming can affect 2010 extremes. Thread will follow https://t.co/oHoSs8fRVq",
      "expandedUrl" : "https://twitter.com/i/web/status/1456350190001131522"
    }
  },
  {
    "like" : {
      "tweetId" : "1456519848486375443",
      "fullText" : "New \"scheduling\" app that allows users to book a time to play a multiplayer game: https://t.co/HqPPfsNftZ https://t.co/BJ7QB3LoQZ",
      "expandedUrl" : "https://twitter.com/i/web/status/1456519848486375443"
    }
  },
  {
    "like" : {
      "tweetId" : "1456191800318832645",
      "fullText" : "#EconTwitter #EconJobMarket #EJME @LMU_Muenchen @FlorianEnglmai1\n\nWe are hiring assistant professors in Econ (any field, incl. Behavioral&amp;Experimental Economics)!\n\nMunich = wonderful &amp; welcoming place with great people. \n\nMore info at: https://t.co/ZzOlxfRhSb!",
      "expandedUrl" : "https://twitter.com/i/web/status/1456191800318832645"
    }
  },
  {
    "like" : {
      "tweetId" : "1455938559215652865",
      "fullText" : "@Bloemendaal_N @Henriqueta_Dorr Congratulations! Excellent thesis and defense. Thanks for the opportunity to participate, I really enjoyed being part of it.",
      "expandedUrl" : "https://twitter.com/i/web/status/1455938559215652865"
    }
  },
  {
    "like" : {
      "tweetId" : "1455907504873934850",
      "fullText" : "Happening soon! Nadia Bloemendaal will defend her thesis titled 'Weathering the storm: Tropical cyclone risk under climate change'. You can watch online here at 15:45 CET https://t.co/go79hDMyuq",
      "expandedUrl" : "https://twitter.com/i/web/status/1455907504873934850"
    }
  },
  {
    "like" : {
      "tweetId" : "1455493752487911427",
      "fullText" : "We are happy to announce our updated @otree tutorial series for beginners. This free tutorial comprises of three videos that cover the basics of creating and running your first @otree app using oTree version 5 and higher.\nhttps://t.co/Ks70kG4FlC",
      "expandedUrl" : "https://twitter.com/i/web/status/1455493752487911427"
    }
  },
  {
    "like" : {
      "tweetId" : "1455155910645633028",
      "fullText" : "This week, I'm taking over the twitter account of @EADM_1993 😎 I'm excited to hear y'all chime in! https://t.co/dlBitkR8Id",
      "expandedUrl" : "https://twitter.com/i/web/status/1455155910645633028"
    }
  },
  {
    "like" : {
      "tweetId" : "1454016144403275778",
      "fullText" : "Fantastic opportunity in one of the best and nicest experimental groups. https://t.co/chB8DqClDH",
      "expandedUrl" : "https://twitter.com/i/web/status/1454016144403275778"
    }
  },
  {
    "like" : {
      "tweetId" : "1453997326188548096",
      "fullText" : "IVMer @DebonneNiels featured in de @volkskrant where he comments on the causes and consequences of declining global calorie production\nhttps://t.co/AAeMEDqRVv",
      "expandedUrl" : "https://twitter.com/i/web/status/1453997326188548096"
    }
  },
  {
    "like" : {
      "tweetId" : "1453453569944956934",
      "fullText" : "Paper besties 🥰 https://t.co/Vwi1ryIc0B",
      "expandedUrl" : "https://twitter.com/i/web/status/1453453569944956934"
    }
  },
  {
    "like" : {
      "tweetId" : "1453406014045396994",
      "fullText" : "Date for the #PhD #viva has been set!",
      "expandedUrl" : "https://twitter.com/i/web/status/1453406014045396994"
    }
  },
  {
    "like" : {
      "tweetId" : "1452619444761636874",
      "expandedUrl" : "https://twitter.com/i/web/status/1452619444761636874"
    }
  },
  {
    "like" : {
      "tweetId" : "1452596966093991949",
      "fullText" : "The \"Dutch IPCC report\" is out! With lots of new insights into the effects of climate change for NL. As a Dutch scientist, I am extremely proud that I got to co-author the Dutch Caribbean (hurricane) chapter,  providing information on hurricane chances using STORM! https://t.co/fwzbGo2JVm",
      "expandedUrl" : "https://twitter.com/i/web/status/1452596966093991949"
    }
  },
  {
    "like" : {
      "tweetId" : "1451190427772620801",
      "fullText" : "Beautiful views from #UvA #Roeterseiland campus @UvA_Amsterdam https://t.co/y2iQtlvYTQ",
      "expandedUrl" : "https://twitter.com/i/web/status/1451190427772620801"
    }
  },
  {
    "like" : {
      "tweetId" : "1451093682178953219",
      "fullText" : "Wat denk jij: betalen consumenten vrijwillig de Echte Prijs voor producten? Test je intuïtie hier: \nhttps://t.co/e09IquV44z  @wwaterlander https://t.co/zwdayQ2vzp",
      "expandedUrl" : "https://twitter.com/i/web/status/1451093682178953219"
    }
  },
  {
    "like" : {
      "tweetId" : "1450847859566419980",
      "fullText" : "📢Join the 1st online KLI PhD colloquium on the 27th of October at 1600 CEST📢\n\nThe amazing @AnneValkengoed (@univgroningen) will present her work titled \"Adapting to climate change – the role and future of psychological science\"\n\nOpen sign up: https://t.co/lWwq5LHSsg\n\nAbstract⬇️ https://t.co/rV4gMPflKs",
      "expandedUrl" : "https://twitter.com/i/web/status/1450847859566419980"
    }
  },
  {
    "like" : {
      "tweetId" : "1450546945756471309",
      "expandedUrl" : "https://twitter.com/i/web/status/1450546945756471309"
    }
  },
  {
    "like" : {
      "tweetId" : "1450478993703153670",
      "fullText" : "VERY🥰that this is finally published. The typical econ route that took forever...\n\nWe (w/ Bolton &amp; Schmidt) evaluate when &amp; why simple reputation #nudges (one's (un)ethical actions being observed by others) can backfire. Details in🧵👇\n\nPaper: https://t.co/VkVTr7MOk9\n#EconTwitter https://t.co/G0edEjJbSA https://t.co/UIdd1H9T6J",
      "expandedUrl" : "https://twitter.com/i/web/status/1450478993703153670"
    }
  },
  {
    "like" : {
      "tweetId" : "1450386481982447617",
      "expandedUrl" : "https://twitter.com/i/web/status/1450386481982447617"
    }
  },
  {
    "like" : {
      "tweetId" : "1450157172525047808",
      "fullText" : "Mapo Tofu Time #EconCookingTwitter https://t.co/Pi6hODDe2h",
      "expandedUrl" : "https://twitter.com/i/web/status/1450157172525047808"
    }
  },
  {
    "like" : {
      "tweetId" : "1449983963586564097",
      "fullText" : "You’re unable to view this Post because this account owner limits who can view their Posts. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1449983963586564097"
    }
  },
  {
    "like" : {
      "tweetId" : "1449400169049513987",
      "fullText" : "My PhD book has been printed 😍😍😍 https://t.co/qqnlgxWcW7",
      "expandedUrl" : "https://twitter.com/i/web/status/1449400169049513987"
    }
  },
  {
    "like" : {
      "tweetId" : "1449283865814700035",
      "fullText" : "I'm really enjoying the holidays I've been on this month. Honestly, you need to take proper breaks... @AcademicChatter",
      "expandedUrl" : "https://twitter.com/i/web/status/1449283865814700035"
    }
  },
  {
    "like" : {
      "tweetId" : "1449022228759187461",
      "fullText" : "@LisaDeBruine I’m going to work for @RethinkPriors. Really excited!",
      "expandedUrl" : "https://twitter.com/i/web/status/1449022228759187461"
    }
  },
  {
    "like" : {
      "tweetId" : "1448760825355902981",
      "fullText" : "@HemmatiMona @SciReports @LamontEarth @columbiaclimate @climatesociety @HussamN_Mahmoud @AndyCrooks @JantsjeMol perhaps an interesting paper for you to read? :)",
      "expandedUrl" : "https://twitter.com/i/web/status/1448760825355902981"
    }
  },
  {
    "like" : {
      "tweetId" : "1448279141187457031",
      "fullText" : "If you're interested in a deep and thorough discussion of the concept of irrationality, this book is for you.\n\nAs one of the lucky souls who got to read the early drafts, I can tell you: it is brilliant 👌\n\nCan't wait to read the final version 😊 https://t.co/ment9yTDXb",
      "expandedUrl" : "https://twitter.com/i/web/status/1448279141187457031"
    }
  },
  {
    "like" : {
      "tweetId" : "1447894881763004421",
      "fullText" : "We interview @FialaLenka who went from the #PhD to being an Assist. Prof.! We talk about her journey, knowing what you want &amp; how to manage time:\n\nYouTube: https://t.co/ck00BxvLBs\nPodbean: https://t.co/JYtxvBTGYy\nSpotify: https://t.co/SiZtBV6V7L\nApple: https://t.co/ryvqVt2ZF2 https://t.co/ss1j5p612V",
      "expandedUrl" : "https://twitter.com/i/web/status/1447894881763004421"
    }
  },
  {
    "like" : {
      "tweetId" : "1448040157760868359",
      "fullText" : "After a long permit saga, I can finally announce that I have started my new post as senior lecturer @UoE_Economics. Updated website: https://t.co/IJgl3nXJP6. Office picture: https://t.co/MTffdja3WZ",
      "expandedUrl" : "https://twitter.com/i/web/status/1448040157760868359"
    }
  },
  {
    "like" : {
      "tweetId" : "1447510693872242691",
      "expandedUrl" : "https://twitter.com/i/web/status/1447510693872242691"
    }
  },
  {
    "like" : {
      "tweetId" : "1447478732936069123",
      "expandedUrl" : "https://twitter.com/i/web/status/1447478732936069123"
    }
  },
  {
    "like" : {
      "tweetId" : "1446404253011042312",
      "fullText" : "Even after 5 years of being a researcher I still wonder what is considered \"unreasonable\" because I would very much like to unreasonably request some data just for the fun of it. \n\n@ConnieEClare and @4TUResearchData\nyay for open-access datasets! https://t.co/CgpY51Kv5Q",
      "expandedUrl" : "https://twitter.com/i/web/status/1446404253011042312"
    }
  },
  {
    "like" : {
      "tweetId" : "1446149942846926848",
      "fullText" : "RFF's history and groundbreaking work inspired me long before I joined. I am celebrating this day by scrolling through NHTSA's 682-page rulemaking document on the fuel economy standards! Consider supporting our work: https://t.co/sD8j8Ml3FX https://t.co/xWnXVsr0fX",
      "expandedUrl" : "https://twitter.com/i/web/status/1446149942846926848"
    }
  },
  {
    "like" : {
      "tweetId" : "1445739225689702405",
      "fullText" : "Ray as always dropping words of wisdom and encouragement for early career researchers (up and down the 🧵)\n#EconTwitter https://t.co/dLaDPP8ILx",
      "expandedUrl" : "https://twitter.com/i/web/status/1445739225689702405"
    }
  },
  {
    "like" : {
      "tweetId" : "1445690669138251780",
      "fullText" : "[IVMer of the week] Myself and a whole gaggle of talented researchers from @VU_IVM are presenting at @NatRiskChange in Potsdam 🇩🇪 Are you here? Come and find us! Here's me and my poster ⬆️ 🌊 😬 #floodrisk #DRR https://t.co/OH7rc3w87z",
      "expandedUrl" : "https://twitter.com/i/web/status/1445690669138251780"
    }
  },
  {
    "like" : {
      "tweetId" : "1445122038297989127",
      "fullText" : "having a programming problem. googled it. found a hit asking exactly the same question I have. clicked it. IT WAS ME FROM THREE YEARS AGO. No responses. I feel a great sense of kinship with 2018 Julia.",
      "expandedUrl" : "https://twitter.com/i/web/status/1445122038297989127"
    }
  },
  {
    "like" : {
      "tweetId" : "1445327730061594631",
      "fullText" : "❗️Fresh off the press: The NEWCOMERS reflection on a research agenda on clean #energycommunities published open access in #ERSS 👏🏼\n\n🔎Find the article at @sciencedirect: https://t.co/SXU8lPV0P0\nRead more about it: https://t.co/bFVtAv2bvT https://t.co/satbbPu3JV",
      "expandedUrl" : "https://twitter.com/i/web/status/1445327730061594631"
    }
  },
  {
    "like" : {
      "tweetId" : "1445360006711451660",
      "fullText" : "[IVMer of the week] 👋 I'm #PhD Eric Mortensen. After studying water resources at @UIowaEngr, @UWMadEngr, and @NelsonInstitute, I hopped across the pond! I now study global flood risk adaptation at @VU_IVM. This week I will show you my activities. https://t.co/yW8GXnUfeo https://t.co/TNragEftTx",
      "expandedUrl" : "https://twitter.com/i/web/status/1445360006711451660"
    }
  },
  {
    "like" : {
      "tweetId" : "1445140880600485888",
      "fullText" : "Meanwhile, we are up and running! 😍 😁  #TeXLaTeX #Overleaf",
      "expandedUrl" : "https://twitter.com/i/web/status/1445140880600485888"
    }
  },
  {
    "like" : {
      "tweetId" : "1445300721692422145",
      "fullText" : "Here is me with the lovely @jimalkhalili talking about rivers, floods, climate change and the joy of science on the #LifeScientific on @BBCradio4 now https://t.co/cQJJzw2O0P",
      "expandedUrl" : "https://twitter.com/i/web/status/1445300721692422145"
    }
  },
  {
    "like" : {
      "tweetId" : "1445279882473263105",
      "fullText" : "First day of the #NatRiskChange2021 conference. Feeling lucky to meet international colleagues in person for a loooong time https://t.co/W79v8ntdwu",
      "expandedUrl" : "https://twitter.com/i/web/status/1445279882473263105"
    }
  },
  {
    "like" : {
      "tweetId" : "1445298587173335043",
      "fullText" : "FYI, I just ran the study, analyzed the data and submitted my manuscript to a top journal. After I missed to write even *one* paper on COVID, I won't make the same mistake again... https://t.co/gKKI8GJeHJ",
      "expandedUrl" : "https://twitter.com/i/web/status/1445298587173335043"
    }
  },
  {
    "like" : {
      "tweetId" : "1445019495077187595",
      "fullText" : "Forthcoming in the AER: \"Self-Persuasion: Evidence from Field Experiments at International Debating Competitions\" by Peter Schwardmann, Egon Tripodi, and Joël J. van der Weele. https://t.co/MIUbvXU0Cn",
      "expandedUrl" : "https://twitter.com/i/web/status/1445019495077187595"
    }
  },
  {
    "like" : {
      "tweetId" : "1445064885193388032",
      "fullText" : "One man's trash is another cat's treasure (reusing is even better than recycling!) https://t.co/KGD8JDBRpM",
      "expandedUrl" : "https://twitter.com/i/web/status/1445064885193388032"
    }
  },
  {
    "like" : {
      "tweetId" : "1444972490237829121",
      "fullText" : "🚨Very proud and excited to share our new paper in #PhilTransB @RSocPublishing 🚨\n\nUsing experience sampling, we show that the content, context, and communication of gossip in everyday life can support reputation-based cooperation\n\n#OpenAccess at https://t.co/41fljtSQwO\n\nThread🔽 https://t.co/X6Mz91DWt5",
      "expandedUrl" : "https://twitter.com/i/web/status/1444972490237829121"
    }
  },
  {
    "like" : {
      "tweetId" : "1444620897751552003",
      "fullText" : "It's been a great week for me: I've submitted the PhD and now I'm celebrating my 26th birthday in Vienna with my family :)",
      "expandedUrl" : "https://twitter.com/i/web/status/1444620897751552003"
    }
  },
  {
    "like" : {
      "tweetId" : "1440282073646784513",
      "fullText" : "Last week I was interviewed (in Dutch) by local newspaper @AD_GroeneHart about my research, what drives me and my 'Eureka' moment. You can read the article below! @ESHPM_EUR @EsCHER_EUR https://t.co/7nRcUsCs67",
      "expandedUrl" : "https://twitter.com/i/web/status/1440282073646784513"
    }
  },
  {
    "like" : {
      "tweetId" : "1442547502004113410",
      "fullText" : "I submitted the #PhD thesis.\n\nIt's done.\n\n#AcademicTwitter @firstphdchat https://t.co/csL4sJd9XB",
      "expandedUrl" : "https://twitter.com/i/web/status/1442547502004113410"
    }
  },
  {
    "like" : {
      "tweetId" : "1443621872944439303",
      "fullText" : "I had a blast in Heidelberg during the last two years, but the universe *cough* job market has taken me to another medieval city🏰 (I L-O-V-E castles❤️)\n\nSo excited to be starting a new postdoc at @Economics_UGent @ugent in the beautiful city of Ghent tomorrow 🥳🥳🥳 https://t.co/FJS1x5FaSN",
      "expandedUrl" : "https://twitter.com/i/web/status/1443621872944439303"
    }
  },
  {
    "like" : {
      "tweetId" : "1443540259120287748",
      "fullText" : "@Marleen_Ruiter rocking the explanation of the MYRIAD of multi-hazard, multi-risk, multi-sector, multi-timescale, multi-spatial scale interactions (incl. effects of adaptation measures) by showing examples of real world cases. 👍 https://t.co/znbtKQhbY9 https://t.co/VmFwlR9mY5",
      "expandedUrl" : "https://twitter.com/i/web/status/1443540259120287748"
    }
  },
  {
    "like" : {
      "tweetId" : "1443241468232179723",
      "fullText" : "If anyone is interested in using this material in their classroom, let me know! I'd be happy to share the slidedeck with simple rules and the app to keep score (This would maybe justify having spent so much time on this, haha!)",
      "expandedUrl" : "https://twitter.com/i/web/status/1443241468232179723"
    }
  },
  {
    "like" : {
      "tweetId" : "1442951633718050831",
      "fullText" : "OMG - Cromvoirt heeft een oogje op @Vught :) @ijzerenmanvught https://t.co/fyhwC8os4n @shertogenbosch https://t.co/VnO43bXF6F",
      "expandedUrl" : "https://twitter.com/i/web/status/1442951633718050831"
    }
  },
  {
    "like" : {
      "tweetId" : "1442868287856021511",
      "fullText" : "😂😂👌 https://t.co/chkZfwfHWd",
      "expandedUrl" : "https://twitter.com/i/web/status/1442868287856021511"
    }
  },
  {
    "like" : {
      "tweetId" : "1442784449675071491",
      "fullText" : "'Weeks of code can save you from hours of planning.' Some quote from @lambrechts https://t.co/CSGeToA0U3",
      "expandedUrl" : "https://twitter.com/i/web/status/1442784449675071491"
    }
  },
  {
    "like" : {
      "tweetId" : "1442792844062777348",
      "fullText" : "10 techniques for making better maps, shared by @tjukanov at @MediaCityBergen Hack datajournalism conference 👇",
      "expandedUrl" : "https://twitter.com/i/web/status/1442792844062777348"
    }
  },
  {
    "like" : {
      "tweetId" : "1442507347914629123",
      "fullText" : "We are pre-finalists of the Amsterdam Science &amp; Innovation Award!\nVote for our spin-off company S2S-AI such that we can accelerate scientific innovations within subseasonal-to-seasonal weather predictions and bring them to society! @DimCoumou @IXA_Amsterdam @VU_IVM #amsia #IXA https://t.co/uf1IFtLGWx",
      "expandedUrl" : "https://twitter.com/i/web/status/1442507347914629123"
    }
  },
  {
    "like" : {
      "tweetId" : "1442080395508420613",
      "fullText" : "Twitterles Dan Balliet has been promoted to Full Professor of Human Cooperation @VUamsterdam. Here is the link to his inaugural lecture. I can't wait to see the future work by the Amsterdam Cooperation Lab. https://t.co/yKeORh9MEf",
      "expandedUrl" : "https://twitter.com/i/web/status/1442080395508420613"
    }
  },
  {
    "like" : {
      "tweetId" : "1441305270995480586",
      "fullText" : "Clear and credible #dataviz 👇🏻 https://t.co/DoDhapKWBn",
      "expandedUrl" : "https://twitter.com/i/web/status/1441305270995480586"
    }
  },
  {
    "like" : {
      "tweetId" : "1441040756911837185",
      "fullText" : "Zometeen praat ik met @coenensander over dit interview! https://t.co/3DM5R7c3QL",
      "expandedUrl" : "https://twitter.com/i/web/status/1441040756911837185"
    }
  },
  {
    "like" : {
      "tweetId" : "1441076107562733568",
      "fullText" : "@JantsjeMol @ionicasmeets @CaAl @FialaLenka @matt_motta @ChristinaLeuker Some great papers on lying (totally agree with rec of @AlbertoCairo) and on how to present data better by @d_spiegel and Rocio Garcia-Retamero, among others. Also in my book, https://t.co/7scRMKOnDw (more focused on how to do it better). Happy to share papers if you DM me.",
      "expandedUrl" : "https://twitter.com/i/web/status/1441076107562733568"
    }
  },
  {
    "like" : {
      "tweetId" : "1441023486885912577",
      "fullText" : "I developed a set of classroom experiments in oTree. The results can be accessed in real time using oTree’s admin report feature. Download the code for the experiments here: https://t.co/a7QrybyCY2 or test them out here: https://t.co/6JRViK6oMm . https://t.co/EkGiBRfSMd",
      "expandedUrl" : "https://twitter.com/i/web/status/1441023486885912577"
    }
  },
  {
    "like" : {
      "tweetId" : "1441017035425734666",
      "expandedUrl" : "https://twitter.com/i/web/status/1441017035425734666"
    }
  },
  {
    "like" : {
      "tweetId" : "1441001650097958912",
      "fullText" : "I am so extremely proud of my fellow colleagues @Rhian14800441  and @Marleen_Ruiter  for their book publication! https://t.co/LgKjQ0BO29 https://t.co/oSduQlj89U",
      "expandedUrl" : "https://twitter.com/i/web/status/1441001650097958912"
    }
  },
  {
    "like" : {
      "tweetId" : "1440782699149422598",
      "fullText" : "How green is your food? Eco-labels can change the way we eat, https://t.co/5GogZtgORI",
      "expandedUrl" : "https://twitter.com/i/web/status/1440782699149422598"
    }
  },
  {
    "like" : {
      "tweetId" : "1440912584320987139",
      "fullText" : "What happened after the 2012 Sandy Hook shooting when firearm sales surged? States that implemented laws that delay gun purchases witnessed fewer gun sales and homicides.\n\nThrilled that my job market paper is now forthcoming @restatjournal: https://t.co/o0OKOT1cVW \n\nA 🧵:",
      "expandedUrl" : "https://twitter.com/i/web/status/1440912584320987139"
    }
  },
  {
    "like" : {
      "tweetId" : "1440772749463416839",
      "fullText" : "Solo-taught my first class today (guest lecture for undergrad Experimental Econ). The students were so kind and it went well! 🥰 https://t.co/uEuu4sMUgk",
      "expandedUrl" : "https://twitter.com/i/web/status/1440772749463416839"
    }
  },
  {
    "like" : {
      "tweetId" : "1440613197258453000",
      "fullText" : "hey chart obsessives (yeah you know who are): what's your fave most comprehensive library of *all charts ever* online atm? thanks in advance.",
      "expandedUrl" : "https://twitter.com/i/web/status/1440613197258453000"
    }
  },
  {
    "like" : {
      "tweetId" : "1440605204395618308",
      "fullText" : "(Lastly, for those confused about terminology, a cyclone is defined as an atmospheric closed circulation 🙃 that means that hurricanes and typhones are also (tropical) cyclones 😇. And in e.g. Europe we often see extratropical cyclones 😉)",
      "expandedUrl" : "https://twitter.com/i/web/status/1440605204395618308"
    }
  },
  {
    "like" : {
      "tweetId" : "1440346333013950474",
      "fullText" : "Our application deadline is coming up fast! (Oct 1). We particularly welcome applications from scholars who are from populations historically underrepresented in the academy, and/or who have experience working with diverse populations. Come join us in beautiful Oregon! https://t.co/OfEcadY4KM",
      "expandedUrl" : "https://twitter.com/i/web/status/1440346333013950474"
    }
  },
  {
    "like" : {
      "tweetId" : "1430847005560090625",
      "expandedUrl" : "https://twitter.com/i/web/status/1430847005560090625"
    }
  },
  {
    "like" : {
      "tweetId" : "1439983663043780615",
      "fullText" : "“Iedereen kan een beetje (plant)aardiger zijn.” De een op eigen kracht. De ander via de Schijf van Vijf. En weer een ander met hulp van diëtist en/of Schijf for life. Iedereen tevreden. Iedereen een beetje meer plantaardig. Weinig discussie nodig 😇  https://t.co/ao9tIOLFjc",
      "expandedUrl" : "https://twitter.com/i/web/status/1439983663043780615"
    }
  },
  {
    "like" : {
      "tweetId" : "1440057423750844422",
      "fullText" : "The first in-person class of the last two years at @UtrechtUni @USE_UU  A fresh start with Game Theory 👩🏻‍💼 https://t.co/QKQvS0LSQa",
      "expandedUrl" : "https://twitter.com/i/web/status/1440057423750844422"
    }
  },
  {
    "like" : {
      "tweetId" : "1439273288618938374",
      "fullText" : "I'm thinking about learning Python. Of course, I can always hire RAs to do my Python stuff for me, but I really don't want to become the equivalent of the old professor running regressions in Eviews (or the lawyer with the kitty face on Zoom).",
      "expandedUrl" : "https://twitter.com/i/web/status/1439273288618938374"
    }
  },
  {
    "like" : {
      "tweetId" : "1438893557356679169",
      "fullText" : "@JantsjeMol Or as some say: the leek talk! (for the non-Dutch: layman's summary of the thesis) https://t.co/gSAZsBTHEm",
      "expandedUrl" : "https://twitter.com/i/web/status/1438893557356679169"
    }
  },
  {
    "like" : {
      "tweetId" : "1435620188876070915",
      "fullText" : "Congrats to the new Dr. Di Capua! https://t.co/7KniyTJP22",
      "expandedUrl" : "https://twitter.com/i/web/status/1435620188876070915"
    }
  },
  {
    "like" : {
      "tweetId" : "1438791892704051202",
      "fullText" : "[IVMer of the week] When working at 38 degrees C in concrete Belgrade jungle became too hot to handle, I decided to try something new! Greetings from Karanfil, Prokletije @ 2550m https://t.co/jv93en5ZmI https://t.co/eEHZPe1Y5n",
      "expandedUrl" : "https://twitter.com/i/web/status/1438791892704051202"
    }
  },
  {
    "like" : {
      "tweetId" : "1438799994308501506",
      "fullText" : "It's not much, but it's the first eso-x office! https://t.co/G4orScOA1O",
      "expandedUrl" : "https://twitter.com/i/web/status/1438799994308501506"
    }
  },
  {
    "like" : {
      "tweetId" : "1438870162002882562",
      "fullText" : "🖨 Our paper with @ManuMunozHerrer and Luis A. Palacio has found its home.  You can download the paper for free until November the 6th. https://t.co/kW8OJgDp7b",
      "expandedUrl" : "https://twitter.com/i/web/status/1438870162002882562"
    }
  },
  {
    "like" : {
      "tweetId" : "1438516275886518281",
      "expandedUrl" : "https://twitter.com/i/web/status/1438516275886518281"
    }
  },
  {
    "like" : {
      "tweetId" : "1438510274152001545",
      "fullText" : "In this discussion I find interesting this notion of 'fair pricing'. Is price discrimination something that is 'unfair'? Is it unfair to charge early bookers less than late bookers? It seems that in certain sectors price discrimination is completely acceptable while in others not https://t.co/XfnG0caNFJ",
      "expandedUrl" : "https://twitter.com/i/web/status/1438510274152001545"
    }
  },
  {
    "like" : {
      "tweetId" : "1438080843235397639",
      "fullText" : "18 months later, back in the lab ⚗️🎉🎉 https://t.co/CiXerQg58I",
      "expandedUrl" : "https://twitter.com/i/web/status/1438080843235397639"
    }
  },
  {
    "like" : {
      "tweetId" : "1438139905129988102",
      "fullText" : "@DrGurerk @JantsjeMol Thanks, Özgür. Very interesting.",
      "expandedUrl" : "https://twitter.com/i/web/status/1438139905129988102"
    }
  },
  {
    "like" : {
      "tweetId" : "1438158138637758471",
      "fullText" : "@JantsjeMol @Bloemendaal_N @VUamsterdam Well done! I hope you enjoyed the celebrations! 🥳",
      "expandedUrl" : "https://twitter.com/i/web/status/1438158138637758471"
    }
  },
  {
    "like" : {
      "tweetId" : "1438036273927708674",
      "fullText" : "@JantsjeMol @amynpolen I think such a map would definitely help in risk communication :) https://t.co/eyTdXeqYAg",
      "expandedUrl" : "https://twitter.com/i/web/status/1438036273927708674"
    }
  },
  {
    "like" : {
      "tweetId" : "1437719180275552258",
      "fullText" : "The Supreme Nudge trial will be featured in the Dutch TV show Over Gewicht, aired on Net5 upcoming winter 🍎🍎🍎 https://t.co/GCCjGm7VHS",
      "expandedUrl" : "https://twitter.com/i/web/status/1437719180275552258"
    }
  },
  {
    "like" : {
      "tweetId" : "1437692944044204034",
      "fullText" : "I'll be defending my PhD thesis on tropical cyclone risk under climate change on Wed. 3 Nov at 15:45h CET! Due to covid, I cannot invite you all to join in the VU aula, but you can watch the ceremony via YouTube (https://t.co/b0CTMsFNLQ) :). Cover by the amazing @Henriqueta_Dorr! https://t.co/Es1oSisxBn",
      "expandedUrl" : "https://twitter.com/i/web/status/1437692944044204034"
    }
  },
  {
    "like" : {
      "tweetId" : "1437591096431874049",
      "fullText" : "We won't be able to fix the disconnect between science and policy without improved numeracy and basic understanding of statistics *in the population at large*. A huge task. Who takes it on? @WZB_Berlin @maxplanckpress @LeibnizWGL @JA_Allmendinger @BSE_Berlin @bbe_berlin",
      "expandedUrl" : "https://twitter.com/i/web/status/1437591096431874049"
    }
  },
  {
    "like" : {
      "tweetId" : "1437478181150371840",
      "fullText" : "I am Rhoda Odongo, a PhD researcher @VU_IVM. My research investigates to what extent the influence of climate variability and anthropogenic \nactivities on the hydrological system can influence sub-surface droughts and their impacts in EA  #BIGWeek2021 #BlackInGeoscienceRollCall",
      "expandedUrl" : "https://twitter.com/i/web/status/1437478181150371840"
    }
  },
  {
    "like" : {
      "tweetId" : "1437421414894686213",
      "fullText" : "My first work trip after two years. It was a pleasure being in the PhD defense Committee of @JantsjeMol. Congrats for a superb thesis with a great methodological variety including a virtual reality experiment. https://t.co/ra6JFWF1X1",
      "expandedUrl" : "https://twitter.com/i/web/status/1437421414894686213"
    }
  },
  {
    "like" : {
      "tweetId" : "1436754635704848390",
      "fullText" : "Very strong state of the art thesis from outstanding @MaastrichtU program. \n\nCareful control for risk aversion shows no diff in competition preferences for men vs women https://t.co/OCOAoGxSbR https://t.co/rSCMoakg78",
      "expandedUrl" : "https://twitter.com/i/web/status/1436754635704848390"
    }
  },
  {
    "like" : {
      "tweetId" : "1436070126642733058",
      "fullText" : "@JantsjeMol All the best, Jantsje!",
      "expandedUrl" : "https://twitter.com/i/web/status/1436070126642733058"
    }
  },
  {
    "like" : {
      "tweetId" : "1435684753253019662",
      "fullText" : "@MartenvdMeulen Wij wetenschappers draaien daar onze hand niet voor om, toch Marten? 😉",
      "expandedUrl" : "https://twitter.com/i/web/status/1435684753253019662"
    }
  },
  {
    "like" : {
      "tweetId" : "1435860078633095172",
      "fullText" : "On my way to the office for my very first day as an assistant prof @Unibo. Very exciting! #AcademicChatter",
      "expandedUrl" : "https://twitter.com/i/web/status/1435860078633095172"
    }
  },
  {
    "like" : {
      "tweetId" : "1435700978418913285",
      "expandedUrl" : "https://twitter.com/i/web/status/1435700978418913285"
    }
  },
  {
    "like" : {
      "tweetId" : "1435703063973613569",
      "fullText" : "Claude Montmarquette passed away this morning. Professor at the Univ. of Montreal and one of the founders of CIRANO, he was a pioneer in the development of experimental economics in Quebec and an ardent promoter of its use for public policy.  He was our friend. My heart bleeds.",
      "expandedUrl" : "https://twitter.com/i/web/status/1435703063973613569"
    }
  },
  {
    "like" : {
      "tweetId" : "1435589611745595393",
      "fullText" : "Starting soon, IVMer Giorgia Di Capua (@giodc3) will be defending her thesis titled 'The Indian Monsoon and its interaction with the mid-latitude circulation'. The livestream ceremony starts at 15:45 . More information : https://t.co/9qV3xI8URU",
      "expandedUrl" : "https://twitter.com/i/web/status/1435589611745595393"
    }
  },
  {
    "like" : {
      "tweetId" : "1435268406287245314",
      "fullText" : "Offering undergraduate students the option of performing a cumulative replication study for their theses—instead of an original research project—would improve both science and education. \n\nMy new opinion piece in @NatureHumBehav \n\nhttps://t.co/0fm9mViRP7",
      "expandedUrl" : "https://twitter.com/i/web/status/1435268406287245314"
    }
  },
  {
    "like" : {
      "tweetId" : "1435237653809618954",
      "fullText" : "I've never been much of a morning person, but starting work earlier to finish earlier and enjoy the sun is really doing something for me 🌞🌞 💖",
      "expandedUrl" : "https://twitter.com/i/web/status/1435237653809618954"
    }
  },
  {
    "like" : {
      "tweetId" : "1435156230138433540",
      "fullText" : "A little bit of love for the European railroad network - no need to take the plane, the train from Amsterdam will take me directly to Berlin Hauptbahnhof, and I have a comfortable spot to work (with wifi and electricity) during the ride! 🚄 https://t.co/I9in6kEb9m",
      "expandedUrl" : "https://twitter.com/i/web/status/1435156230138433540"
    }
  },
  {
    "like" : {
      "tweetId" : "1435199478164824065",
      "fullText" : "@ZigaMalek I couldn't agree more. What if the thesis gets lost along the train track between Amsterdam and Berlin?",
      "expandedUrl" : "https://twitter.com/i/web/status/1435199478164824065"
    }
  },
  {
    "like" : {
      "tweetId" : "1435044697194573828",
      "fullText" : "It’s nice to be able to check it off my to do list, but I still feel like that’s not quite enough….I feel like when I submit a referee report (especially on time), confetti should fall from the sky &amp; maybe a singing telegram or festive cocktail should appear at my desk. 🎉🎊🍹🤷‍♀️",
      "expandedUrl" : "https://twitter.com/i/web/status/1435044697194573828"
    }
  },
  {
    "like" : {
      "tweetId" : "1433746848427167744",
      "fullText" : "Instead the takeaway is: Fight for your ideas and your contribution. Your vocal critics, smart as they are, may be hobbled by their paradigm. If you do the best work you can by your own criteria, you'll find your audience.\n\nTo all of you who continue to read my work, thank you.",
      "expandedUrl" : "https://twitter.com/i/web/status/1433746848427167744"
    }
  },
  {
    "like" : {
      "tweetId" : "1433785695152361481",
      "fullText" : "@JantsjeMol @FialaLenka Best of luck!",
      "expandedUrl" : "https://twitter.com/i/web/status/1433785695152361481"
    }
  },
  {
    "like" : {
      "tweetId" : "1433354978035478531",
      "expandedUrl" : "https://twitter.com/i/web/status/1433354978035478531"
    }
  },
  {
    "like" : {
      "tweetId" : "1433106333029605380",
      "fullText" : "Kate = Nadia in the final stages of her PhD thesis https://t.co/uAbSjFQEvM",
      "expandedUrl" : "https://twitter.com/i/web/status/1433106333029605380"
    }
  },
  {
    "like" : {
      "tweetId" : "1433078520222306313",
      "fullText" : "My office helper today has room for improvement. She is facing the wrong way for a start. https://t.co/DOYxdpM5AO",
      "expandedUrl" : "https://twitter.com/i/web/status/1433078520222306313"
    }
  },
  {
    "like" : {
      "tweetId" : "1432770954120343569",
      "fullText" : "Twee van mijn grote passies in één: house muziek en steden (twee dingen die onlosmakelijk met elkaar verbonden zijn). Een goeie track over gentrificatie in Detroit: https://t.co/WD3XHIDnpL",
      "expandedUrl" : "https://twitter.com/i/web/status/1432770954120343569"
    }
  },
  {
    "like" : {
      "tweetId" : "1432753889061789696",
      "fullText" : "So psyched that my paper \"The Impact of Short-Term Employment for Low-Income Youth\" with @TeacherStellaQ was just accepted at @restatjournal!  🎉🎉🎉\n\nIZA Working Paper: https://t.co/L7bmZhS2cP https://t.co/r8GVAMyaAM",
      "expandedUrl" : "https://twitter.com/i/web/status/1432753889061789696"
    }
  },
  {
    "like" : {
      "tweetId" : "1431482588116525056",
      "expandedUrl" : "https://twitter.com/i/web/status/1431482588116525056"
    }
  },
  {
    "like" : {
      "tweetId" : "1428619498949685249",
      "fullText" : "Very much on-brand, it's an experiment! Thanks for helping us with the hybrid format💚\n\nIn case of any IT-help needed, join the main zoom room and ask for Lenka ;)",
      "expandedUrl" : "https://twitter.com/i/web/status/1428619498949685249"
    }
  },
  {
    "like" : {
      "tweetId" : "1428612801766084610",
      "fullText" : "Good morning! Zoom sessions are now open, in-person presenters have started setting up their talks, we can't wait! 🥳💚",
      "expandedUrl" : "https://twitter.com/i/web/status/1428612801766084610"
    }
  },
  {
    "like" : {
      "tweetId" : "1428015326302810113",
      "fullText" : "@Manwei_Liu and Sili Zhang study whether reading biased narratives influences your views even if you *know* that what you are reading is biased. On top of that, they show whether it helps to reason about the issue. As always, no spoilers, see this great experiment for yourself!💚",
      "expandedUrl" : "https://twitter.com/i/web/status/1428015326302810113"
    }
  },
  {
    "like" : {
      "tweetId" : "1426832049063743494",
      "fullText" : "And second, Linh Vu discusses a meta-analysis on willful ignorance. We promise it is in your interest to find out more, so check out the video and fight ignorance😉\nCo-authors: Ivan Soraperra, Margarita Leib, @JoelvdWeele &amp; Shaul Shalvi.\nhttps://t.co/pD1BNomH12",
      "expandedUrl" : "https://twitter.com/i/web/status/1426832049063743494"
    }
  },
  {
    "like" : {
      "tweetId" : "1426672067043340291",
      "fullText" : "Cabin nights in Switzerland https://t.co/C8B6GlgACA",
      "expandedUrl" : "https://twitter.com/i/web/status/1426672067043340291"
    }
  },
  {
    "like" : {
      "tweetId" : "1418330013439512586",
      "fullText" : "感染対策して観戦\n　\n#Tokyo2020 https://t.co/gp4JyoiVHz",
      "expandedUrl" : "https://twitter.com/i/web/status/1418330013439512586"
    }
  },
  {
    "like" : {
      "tweetId" : "1418228774143922177",
      "fullText" : "Don't forget that @tibertilburg is organising a free conference on the 20th of August:\n\nhttps://t.co/W7rYVeEmjc",
      "expandedUrl" : "https://twitter.com/i/web/status/1418228774143922177"
    }
  },
  {
    "like" : {
      "tweetId" : "1417737341612011523",
      "fullText" : "So far only 6 people have signed up for my oTree workshop next week, which will take place from 26. - 29.7. from 13:00 to 18:00 European time (CEST) which is 7:00 - 12:00 US east time. It would be great to have a few more participants 😀: https://t.co/LIBAB3AABA  #EconTwitter",
      "expandedUrl" : "https://twitter.com/i/web/status/1417737341612011523"
    }
  },
  {
    "like" : {
      "tweetId" : "1417388006151835651",
      "fullText" : "Fresh batch of oTree samples! Longitudinal studies, quiz with feedback, detecting dropouts, comprehension test with max attempts, \"constant sum\" widget, graphic slider, custom chat box, and more: https://t.co/HO9v8tLO0k",
      "expandedUrl" : "https://twitter.com/i/web/status/1417388006151835651"
    }
  },
  {
    "like" : {
      "tweetId" : "1417076199306801156",
      "fullText" : "Happy to share the new paper with \n@MWerthschulte on the role of present bias and biased price beliefs in household energy consumption. It is forthcoming in the Journal of Environmental Economics and Management @JEEM_tweets. Open access version: https://t.co/HX2twcdlP7 \nThread 👇 https://t.co/Jg5rw06Lcf",
      "expandedUrl" : "https://twitter.com/i/web/status/1417076199306801156"
    }
  },
  {
    "like" : {
      "tweetId" : "1413483760457109506",
      "fullText" : "Hey, #EconTwitter join us and celebrate some good news. In academia, achievements take too much to happen so we need to enjoy every single time we have one. Thanks a lot to my amazing coauthors \n@agnekaj, @UriGneezy, and @tilmanfries. \nLink: https://t.co/AHhS1DYL72",
      "expandedUrl" : "https://twitter.com/i/web/status/1413483760457109506"
    }
  },
  {
    "like" : {
      "tweetId" : "1595319567160598529",
      "fullText" : "Little Robin Redbreast sat upon a tree\nUp went pussycat and down went he\nDown came pussycat, away Robin ran,\nSays little Robin Redbreast, \"Catch me if you can!\"\n\nHappy Wednesday!🐈\n#cats #catsoftwitter #CatsOnTwitter https://t.co/PL2C5Xik7Z",
      "expandedUrl" : "https://twitter.com/i/web/status/1595319567160598529"
    }
  },
  {
    "like" : {
      "tweetId" : "1595012436758855681",
      "fullText" : "So proud of my colleague @BorisLeeuwen @TilburgU @TilburgU_TiSEM for winning an ERC Starting Grant! He has an exciting research agenda! Congratulations, Boris! 🎉🎉🎉 https://t.co/9519g0XlzS",
      "expandedUrl" : "https://twitter.com/i/web/status/1595012436758855681"
    }
  },
  {
    "like" : {
      "tweetId" : "1594782776720605184",
      "fullText" : "So I just learnt that with the {magick} package you can add an a images gif to a ggplot. \n\nBeware, oh attendees to my future presentation, for I will use this in oddly inappropriate ways! https://t.co/tvhkpA0UGw",
      "expandedUrl" : "https://twitter.com/i/web/status/1594782776720605184"
    }
  },
  {
    "like" : {
      "tweetId" : "1593457510798790657",
      "fullText" : "Spread the word, it's almost weekend!\nHappy Friday from the entire family of adorable fluffies🥰\n#CatsOfTwitter #CatsOnTwitter #cats https://t.co/bMLgZdEZy0",
      "expandedUrl" : "https://twitter.com/i/web/status/1593457510798790657"
    }
  },
  {
    "like" : {
      "tweetId" : "1592896624589737986",
      "fullText" : "Been there https://t.co/UEeJiIcCJ3",
      "expandedUrl" : "https://twitter.com/i/web/status/1592896624589737986"
    }
  },
  {
    "like" : {
      "tweetId" : "1592542109030297603",
      "fullText" : "@jenniferdoleac @p_ganong @Josh_Merfeld @AEAInformation I switched the browser and it also worked 🎉🎉",
      "expandedUrl" : "https://twitter.com/i/web/status/1592542109030297603"
    }
  },
  {
    "like" : {
      "tweetId" : "1592302180706701312",
      "fullText" : "Sadly, being honest about uncertainty of findings does make people trust findings, and you, a little bit less :-(  \n\nhttps://t.co/PxUb5AXUOR https://t.co/04OeIfBgCT",
      "expandedUrl" : "https://twitter.com/i/web/status/1592302180706701312"
    }
  },
  {
    "like" : {
      "tweetId" : "1592159781690933249",
      "fullText" : "Paper submitted! Celebrating a small accomplishment with cappuccino ☕️ https://t.co/HyIJ09rQbR",
      "expandedUrl" : "https://twitter.com/i/web/status/1592159781690933249"
    }
  },
  {
    "like" : {
      "tweetId" : "1592072375608430593",
      "fullText" : "Congratulations to our recently graduated #MBA cohort! Thank you for the Teacher of the Year award. Proud of this 7th such award across Amsterdam Business School programs over the years. I look forward to seeing the exciting things you will do as our ambassadors! @UvA_Amsterdam https://t.co/nH5qiYfyIL",
      "expandedUrl" : "https://twitter.com/i/web/status/1592072375608430593"
    }
  },
  {
    "like" : {
      "tweetId" : "1591261615969939456",
      "fullText" : "Healthy plant gifting etiquette:\n\nYou buy a plant as a gift that fits all of their needs and desires. You then proceed to buy a second plant, exactly the same as the first. For yourself.\n\n#treatyourself #plantlady",
      "expandedUrl" : "https://twitter.com/i/web/status/1591261615969939456"
    }
  },
  {
    "like" : {
      "tweetId" : "1590649056484655104",
      "expandedUrl" : "https://twitter.com/i/web/status/1590649056484655104"
    }
  },
  {
    "like" : {
      "tweetId" : "1590380644097720320",
      "fullText" : "🚨 Job Market Paper Alert 🚨\n\nMany governments provide disaster preparedness information, but does this change people’s behavior?\n\nIn my JMP, I use a large-scale RCT in flood-prone urban Mozambique with data from over 25,000 photos to show it does! \n\nA JMP thread 🧵#EconTwitter https://t.co/SZa4ai1wcx",
      "expandedUrl" : "https://twitter.com/i/web/status/1590380644097720320"
    }
  },
  {
    "like" : {
      "tweetId" : "1590024294029201415",
      "expandedUrl" : "https://twitter.com/i/web/status/1590024294029201415"
    }
  },
  {
    "like" : {
      "tweetId" : "1589598382099570689",
      "fullText" : "*Is on Paternity leave Nov 2022 &amp; April - July 2023*\nI will not be posting much work content at these times.",
      "expandedUrl" : "https://twitter.com/i/web/status/1589598382099570689"
    }
  },
  {
    "like" : {
      "tweetId" : "1589546719376990208",
      "fullText" : "Our lab started a rejection list where we collect any rejections, from grant applications to conference and paper submissions (on a voluntary basis). Once we reach 25 rejections, we'll host a Rejection Party🎉Our list is filling up quickly, and we look forward to our first party. https://t.co/WipUvxdhch",
      "expandedUrl" : "https://twitter.com/i/web/status/1589546719376990208"
    }
  },
  {
    "like" : {
      "tweetId" : "1588613508371197952",
      "fullText" : "As @EliraKuka &amp; I work on expanding the pool of mentors for Adopt a Paper, I’m reminded that while there are some bad actors in economics, many more are brilliant, kind &amp; generous. \n\nSee our mentors for Rounds 1 and 2. \n\nBe like them!  Help junior faculty: https://t.co/7xIASQztkI https://t.co/JXbWTs07zA",
      "expandedUrl" : "https://twitter.com/i/web/status/1588613508371197952"
    }
  },
  {
    "like" : {
      "tweetId" : "1588622955898015746",
      "fullText" : "Inoculation protects against the social media infodemic! \n\nVery cool new study finding that in a simulated social media interface, inoculating users led to fewer 'likes' &amp; 'love' reactions and less sharing of misinformation posts\n\nNot moderated by CRT \n\nhttps://t.co/nkkVfVfNjM https://t.co/H4CvjL0g9M",
      "expandedUrl" : "https://twitter.com/i/web/status/1588622955898015746"
    }
  },
  {
    "like" : {
      "tweetId" : "1587798951385767938",
      "expandedUrl" : "https://twitter.com/i/web/status/1587798951385767938"
    }
  },
  {
    "like" : {
      "tweetId" : "1587747136346521600",
      "fullText" : "Check me out at work, sitting in the sun, reading papers on #personalfinance from #debt repayment to #retirement savings. @dilipsoman several papers were yours, of course! https://t.co/JkjeARgH6Q",
      "expandedUrl" : "https://twitter.com/i/web/status/1587747136346521600"
    }
  },
  {
    "like" : {
      "tweetId" : "1587443211697627138",
      "fullText" : "Very relevant paper for people doing research on result-based payments for Agri-Environmental Climate Measures\n\nhttps://t.co/xgXXIt9CRo https://t.co/Dzev3tC5qj",
      "expandedUrl" : "https://twitter.com/i/web/status/1587443211697627138"
    }
  },
  {
    "like" : {
      "tweetId" : "1587168455610011650",
      "fullText" : "Happy Halloween folks!🐈‍⬛🐈‍⬛\n#cathalloween #cats #CatsOfTwitter #CatsOnTwitter https://t.co/LZTpJEJPBH",
      "expandedUrl" : "https://twitter.com/i/web/status/1587168455610011650"
    }
  },
  {
    "like" : {
      "tweetId" : "1587045293262004224",
      "fullText" : "How best to elicit beliefs in online surveys? \n\nWith our Click-and-Drag belief elicitation interface -- now with a ready-made Qualtrics plugin!\n\nInfo, new working paper, access to the Qualtrics plugin, live demos, and more here: https://t.co/43ZbyyJeEc\n\nRead the 🧵for details https://t.co/TMwvJefBgE",
      "expandedUrl" : "https://twitter.com/i/web/status/1587045293262004224"
    }
  },
  {
    "like" : {
      "tweetId" : "1585917472065978368",
      "fullText" : "Klaar is Kees!\n\n#PhDone \n\nLooking forward to the public defense at Thu 8 December 11:45, at the VU Amsterdam! https://t.co/EJGBD4ZvCg",
      "expandedUrl" : "https://twitter.com/i/web/status/1585917472065978368"
    }
  },
  {
    "like" : {
      "tweetId" : "1585636393987948547",
      "fullText" : "Seems like a very interesting position https://t.co/u3oKxm8eZJ",
      "expandedUrl" : "https://twitter.com/i/web/status/1585636393987948547"
    }
  },
  {
    "like" : {
      "tweetId" : "1585245353439531009",
      "fullText" : "More relatable than what I would like https://t.co/cNIArXbAPY",
      "expandedUrl" : "https://twitter.com/i/web/status/1585245353439531009"
    }
  },
  {
    "like" : {
      "tweetId" : "1413166469375012867",
      "expandedUrl" : "https://twitter.com/i/web/status/1413166469375012867"
    }
  },
  {
    "like" : {
      "tweetId" : "1413186743231209477",
      "fullText" : "Aaaaand ... I handed in my thesis today!\n\nNow someone please tell me .. what do people do with all this extra time?🙈 https://t.co/M8DKApOIue",
      "expandedUrl" : "https://twitter.com/i/web/status/1413186743231209477"
    }
  },
  {
    "like" : {
      "tweetId" : "1413009805049057280",
      "fullText" : "@HWFencebreaker @EcScienceAssoc 🤣 https://t.co/4D27EwvT6v",
      "expandedUrl" : "https://twitter.com/i/web/status/1413009805049057280"
    }
  },
  {
    "like" : {
      "tweetId" : "1412871017048023047",
      "fullText" : "Ladies and gentlemen,boys and girls, the moment is finally here: \n\n 🥁🥁🥁🥁🥁🥁🥁🥁🥁🥁🥁\n\nI am finalizing my thesis tonight! AL-MOST FINISHED (just a few more cross-references to go!) https://t.co/3IxFm4kZGj",
      "expandedUrl" : "https://twitter.com/i/web/status/1412871017048023047"
    }
  },
  {
    "like" : {
      "tweetId" : "1412749232914714626",
      "fullText" : "Hey experimentalist in #EconTwitter, I will present today at 8 pm CET at the 2021 ESA Global Online Meetings a paper about prosociality as an self-serving excuse to lie. See you all then! https://t.co/4MC6L7B2Nr",
      "expandedUrl" : "https://twitter.com/i/web/status/1412749232914714626"
    }
  },
  {
    "like" : {
      "tweetId" : "1412715874293780480",
      "fullText" : "📢Exciting personal news 👇\n\nIn September I'll join the Economics department of @Unibo! I'm thrilled to meet all my new colleagues: see you very soon!\n\nA big thank you to my colleagues at @unimib. I always felt welcome and supported in the department. Good luck! https://t.co/JRm4aivxDi",
      "expandedUrl" : "https://twitter.com/i/web/status/1412715874293780480"
    }
  },
  {
    "like" : {
      "tweetId" : "1412686794127200256",
      "fullText" : "Great lecture by dr. Nelleke IJssenagger, director from the Fryske Akademy, about the Viking Age in Early Medieval Frisia and the importance of not only taking Latin-Christian sources as starting point. Germanic studies and Historical Linguistics matter!\n#Frisian #OFSS #UGSummer https://t.co/6JJu4beyTO",
      "expandedUrl" : "https://twitter.com/i/web/status/1412686794127200256"
    }
  },
  {
    "like" : {
      "tweetId" : "1412434750371946502",
      "fullText" : "New paper on fighting climate change! A thread.\n\nIt is crucial to understand what determines people's willingness to fight climate change. We shed light on 3 behavioral determinants: social norms, preferences, moral values.\n\nhttps://t.co/lUauoU5I6v  [1/N]",
      "expandedUrl" : "https://twitter.com/i/web/status/1412434750371946502"
    }
  },
  {
    "like" : {
      "tweetId" : "1412453243750211590",
      "fullText" : "I am really happy to see one of the chapters of my dissertation just got published: \"Linking Risk Preferences and Risk Perceptions of Climate Change: A Prospect Theory Approach\"\nNow available at Agricultural Economics. A thread (1/n)\nhttps://t.co/A5NN24GR2m",
      "expandedUrl" : "https://twitter.com/i/web/status/1412453243750211590"
    }
  },
  {
    "like" : {
      "tweetId" : "1411818176225099776",
      "fullText" : "Delayed flight, so I naturally came to a sports bar to drink a beer and code. 😊 https://t.co/VrGCvdiN22",
      "expandedUrl" : "https://twitter.com/i/web/status/1411818176225099776"
    }
  },
  {
    "like" : {
      "tweetId" : "1411781206757232665",
      "fullText" : "Please RT!\n🚨Vacant Post-Doc; PhD positions🚨\nThe beautiful location of Lausanne👇, 🇨🇭pay, fascinating topic, a fantastic team with the 1 and only @sb_vogt!\nWhat more can the academic heart desire?\nPost-Doc: https://t.co/WwKJYepWFP\nPhD: https://t.co/KhODZP2jmT\n#academicpositions https://t.co/zNnLMYtjdR",
      "expandedUrl" : "https://twitter.com/i/web/status/1411781206757232665"
    }
  },
  {
    "like" : {
      "tweetId" : "1411960026177183746",
      "expandedUrl" : "https://twitter.com/i/web/status/1411960026177183746"
    }
  },
  {
    "like" : {
      "tweetId" : "1410578776791076866",
      "fullText" : "Excited to be in the office ⁦⁦@VUamsterdam⁩ for the first time since September. Wonderful to put zoom aside (for a bit) and catch up with ⁦@VU_IVM⁩ colleagues ⁦@P_Pattberg⁩ ⁦@OscarWiderberg⁩ ⁦@AnneVanLoon⁩ ⁦@KateNegacz⁩ ⁦&amp; others https://t.co/IlLaFHtvqL",
      "expandedUrl" : "https://twitter.com/i/web/status/1410578776791076866"
    }
  },
  {
    "like" : {
      "tweetId" : "1410582885267087365",
      "fullText" : "You’re unable to view this Post because this account owner limits who can view their Posts. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1410582885267087365"
    }
  },
  {
    "like" : {
      "tweetId" : "1410562500458917888",
      "fullText" : "PhD thesis has been successfully printed 🥳📚☔️ https://t.co/Q5AtTmXZEZ",
      "expandedUrl" : "https://twitter.com/i/web/status/1410562500458917888"
    }
  },
  {
    "like" : {
      "tweetId" : "1410311308478758915",
      "fullText" : "Today was my last day as Editor at Experimental Economics, after five years! It has been a fantastic and enjoyable experience, thanks to the great team! Welcome to Arno Riedl who will replace me on board! https://t.co/vjQKfxe6W5",
      "expandedUrl" : "https://twitter.com/i/web/status/1410311308478758915"
    }
  },
  {
    "like" : {
      "tweetId" : "1409950980247068672",
      "fullText" : "Lieve Limburg, I'm sorry to tell you this maar we liggen sinds zondag al uit het EK. Groetjes de rest van Nederland https://t.co/QYbf36sGWI",
      "expandedUrl" : "https://twitter.com/i/web/status/1409950980247068672"
    }
  },
  {
    "like" : {
      "tweetId" : "1409834331397361664",
      "fullText" : "Happy to share this exiting new research! Great achievement by Job Dullaart in collaboration with @deltares and @eScienceCenter https://t.co/7d8Rb0ipjV",
      "expandedUrl" : "https://twitter.com/i/web/status/1409834331397361664"
    }
  },
  {
    "like" : {
      "tweetId" : "1409421742628655106",
      "fullText" : "This is big news! Traffic-light system of ‘eco-scores’ to be piloted on British food labels https://t.co/8EXwa1m8MB",
      "expandedUrl" : "https://twitter.com/i/web/status/1409421742628655106"
    }
  },
  {
    "like" : {
      "tweetId" : "1408094449016655872",
      "fullText" : "I have been called \"too enthousiastic\" about my research topic ... \n\nWell excuse my passion. If you don't like seeing or interacting with a passionate researcher, there's the door, byebye👋 https://t.co/oqlFwMXJOO",
      "expandedUrl" : "https://twitter.com/i/web/status/1408094449016655872"
    }
  },
  {
    "like" : {
      "tweetId" : "1407973391559233537",
      "fullText" : "Today at 3:00 PM CET our colleague @mc_villeval will present “Teaching Norms: Direct Evidence of Parental Transmission” at @bbe_berlin ✨",
      "expandedUrl" : "https://twitter.com/i/web/status/1407973391559233537"
    }
  },
  {
    "like" : {
      "tweetId" : "1407705107341484036",
      "fullText" : "Tomorrow at 2pm EDT! Register now to listen to Helen Wiley join @NOAADigCoast's discussion on relocation: https://t.co/rpyGiO5cRi https://t.co/GFHbjWtGGU",
      "expandedUrl" : "https://twitter.com/i/web/status/1407705107341484036"
    }
  },
  {
    "like" : {
      "tweetId" : "1407043065190178822",
      "fullText" : "Time has finally come to my first mission with @wfp_mozambique. Can't wait for all interesting discussions on drought forecasting and anticipatory action. https://t.co/ARNcPg7yRU",
      "expandedUrl" : "https://twitter.com/i/web/status/1407043065190178822"
    }
  },
  {
    "like" : {
      "tweetId" : "1405853880458649603",
      "expandedUrl" : "https://twitter.com/i/web/status/1405853880458649603"
    }
  },
  {
    "like" : {
      "tweetId" : "1405779109507080199",
      "expandedUrl" : "https://twitter.com/i/web/status/1405779109507080199"
    }
  },
  {
    "like" : {
      "tweetId" : "1405591534398062592",
      "fullText" : "I know it technically counts as humble bragging on this website, but I’m just a damn proud supervisor today, because two of my master students got an ‘A’ for their thesis @infomedia_uib.",
      "expandedUrl" : "https://twitter.com/i/web/status/1405591534398062592"
    }
  },
  {
    "like" : {
      "tweetId" : "1405194303421440002",
      "fullText" : "I released a new #oTree tutorial video, in which I discuss how to validate user input: https://t.co/gLWriK8Hvx \n\nThis video and a lot more can also be found in my oTree course on Udemy: https://t.co/d4zTapvUAU \n\n#EconTwitter",
      "expandedUrl" : "https://twitter.com/i/web/status/1405194303421440002"
    }
  },
  {
    "like" : {
      "tweetId" : "1404888138833707014",
      "fullText" : "🚨 Thread alert 🚨 \n\nDiscover the Experimental and Behavioral Economics Lab (REBEL, @UR_REBEL), an experimental economics lab and research group based at Universidad del Rosario @URosario. They also run experiments for external researchers.",
      "expandedUrl" : "https://twitter.com/i/web/status/1404888138833707014"
    }
  },
  {
    "like" : {
      "tweetId" : "1404874663877087232",
      "fullText" : "You’re unable to view this Post because this account owner limits who can view their Posts. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1404874663877087232"
    }
  },
  {
    "like" : {
      "tweetId" : "1404460054699458562",
      "fullText" : "We often find in the lab that Republicans can be persuaded on climate. But one question we often get is whether we can do the same out in the real world.\n\nWe find strong results in a field experiment using targeted ads, now out in @NatureClimate!\n\nhttps://t.co/oAT4aEpkYr\n\n1/x https://t.co/v3bDKaCHFq",
      "expandedUrl" : "https://twitter.com/i/web/status/1404460054699458562"
    }
  },
  {
    "like" : {
      "tweetId" : "1404431958663438338",
      "fullText" : "today in the meeting, I: why do you have six frameworks in your thesis? Student (frustrated): over my six years in university I realize the more frameworks I put in a report the higher score I get. It seems to me that academia likes frameworks. #YetAnotherFramework",
      "expandedUrl" : "https://twitter.com/i/web/status/1404431958663438338"
    }
  },
  {
    "like" : {
      "tweetId" : "1404518108329615361",
      "fullText" : "Look who's a serious PhD student with pink hair. #NewProfilePic https://t.co/Jdw1W8cyxG",
      "expandedUrl" : "https://twitter.com/i/web/status/1404518108329615361"
    }
  },
  {
    "like" : {
      "tweetId" : "1404187550097477636",
      "fullText" : "Applied agricultural economics https://t.co/TOgtfis50A",
      "expandedUrl" : "https://twitter.com/i/web/status/1404187550097477636"
    }
  },
  {
    "like" : {
      "tweetId" : "1403267726613827590",
      "fullText" : "Hadden een lunchbezorging van 'Goeie Broikes'. Vanwege de naam wilde ik dit gewoon even mededelen",
      "expandedUrl" : "https://twitter.com/i/web/status/1403267726613827590"
    }
  },
  {
    "like" : {
      "tweetId" : "1403028300537249796",
      "fullText" : "Very good experimental session at the #AFSE2021. Papers were of good quality and interesting. Dealt with measurement of risk attitudes, effect of role models (@FialaLenka), and trust in experts. I presented paper with @PaoloCrosetto on the dynamics of consumer choice revisions. https://t.co/b7pYtbb3kq",
      "expandedUrl" : "https://twitter.com/i/web/status/1403028300537249796"
    }
  },
  {
    "like" : {
      "tweetId" : "1402949926125031425",
      "fullText" : "#SolarEclipse #potsdam my first ever attempt to take a picture of a solar eclipse with… polarized (sunglasses) lenses https://t.co/wqW880dPgf",
      "expandedUrl" : "https://twitter.com/i/web/status/1402949926125031425"
    }
  },
  {
    "like" : {
      "tweetId" : "1402958447226785793",
      "fullText" : "The moon took a cute little bite out of the sun here in NL #Eclipse2021\n\n(Unfortunately I don't have eclipse glasses so the best I could to was punch a hole in a piece of cardboard and look at the shadow. Our max was 17% coverage, which was around the time I took this photo) https://t.co/9OzbyjFbyj",
      "expandedUrl" : "https://twitter.com/i/web/status/1402958447226785793"
    }
  },
  {
    "like" : {
      "tweetId" : "1402645207305310208",
      "fullText" : "Very excited to announce that I’ll be joining @RadboudFdM Economics department as an Associate Professor of Practice in Economics and Behavior. Looking forward to working with @emsent and colleagues at the chair of economic theory and economic policy!",
      "expandedUrl" : "https://twitter.com/i/web/status/1402645207305310208"
    }
  },
  {
    "like" : {
      "tweetId" : "1401886792433950721",
      "fullText" : "🥰Happy to finally see this paper out in JEBO!\n\nThis is the 1st project @CBicchieri &amp; I ever worked on. It kicked off a prolonged collaboration that became a turning point for me🙏\n\nPaper: https://t.co/Ku7SXWBcsI\nSummary of findings in the tweet below.\n#EconTwitter @penn_csnbd https://t.co/VGZbLHwFCI https://t.co/9OrN0iAoNY",
      "expandedUrl" : "https://twitter.com/i/web/status/1401886792433950721"
    }
  },
  {
    "like" : {
      "tweetId" : "1401499903482814467",
      "fullText" : "Is this you at seminars? 🧵 https://t.co/rfknSTfYjH",
      "expandedUrl" : "https://twitter.com/i/web/status/1401499903482814467"
    }
  },
  {
    "like" : {
      "tweetId" : "1400868114212999170",
      "fullText" : "@JantsjeMol Nice, congratulations! Also, very nicely designed thesis!",
      "expandedUrl" : "https://twitter.com/i/web/status/1400868114212999170"
    }
  },
  {
    "like" : {
      "tweetId" : "1400801382555435010",
      "expandedUrl" : "https://twitter.com/i/web/status/1400801382555435010"
    }
  },
  {
    "like" : {
      "tweetId" : "1400488641210769408",
      "fullText" : "Our review on how #AI can corrupt human ethical behavior just got published in @NatureHumBehav.\nSuper excited about it!!!\nWith a true dream team of @iyadrahwan @JFBonnefon \nYou can read it here: https://t.co/eBF0xhLd8j\nP.s. coincidentally it drops right during #UNGASS2021",
      "expandedUrl" : "https://twitter.com/i/web/status/1400488641210769408"
    }
  },
  {
    "like" : {
      "tweetId" : "1399043973793173504",
      "fullText" : "The wisdom of crowds is surprisingly powerful, even if the crowd is drunk. This paper got undergrads drunk &amp; found that while intoxicated individuals make a lot more errors, the consensus of groups of drunks is as accurate as that of groups of sober folks. https://t.co/KLLCsylGS2 https://t.co/nCKsUqP089",
      "expandedUrl" : "https://twitter.com/i/web/status/1399043973793173504"
    }
  },
  {
    "like" : {
      "tweetId" : "1399635501469077504",
      "fullText" : "Such an exciting opportunity for @JosineStuber who is taking the lead on this large and exciting trial across 8 supermarkets in the Netherlands where we will investigate the effect of #nudging, #pricing and a #physicalactivityapp https://t.co/qZqm30w6pH",
      "expandedUrl" : "https://twitter.com/i/web/status/1399635501469077504"
    }
  },
  {
    "like" : {
      "tweetId" : "1399401927528660997",
      "fullText" : "Two takes and then some! Recorded a lecture at @UniversiteitNL today, and now I’m endlessly impatient to see the final edited video on reading minds (#processtracing research in disguise). https://t.co/7hwtNZcADp",
      "expandedUrl" : "https://twitter.com/i/web/status/1399401927528660997"
    }
  },
  {
    "like" : {
      "tweetId" : "1397955166968729601",
      "fullText" : "Looks like I am heading back to the UK after 11ish years. Don't know if I can say where/why at the mo, but trying to plan out an international move in **waves hand around** this is a little annoying to say the least.",
      "expandedUrl" : "https://twitter.com/i/web/status/1397955166968729601"
    }
  },
  {
    "like" : {
      "tweetId" : "1397892251418832896",
      "fullText" : "Very happy to share that my dissertation entitled 'The psychology of nudging - An investigation of effectiveness and acceptability' has been approved by the assessment committee!",
      "expandedUrl" : "https://twitter.com/i/web/status/1397892251418832896"
    }
  },
  {
    "like" : {
      "tweetId" : "1397880159521415169",
      "fullText" : "In a webinar, I do get a bit jumpy when I am just a participant and a host/panel person is also called 'Paul' I know its not me, but my little heart still does a panic when they are speaking to other Paul",
      "expandedUrl" : "https://twitter.com/i/web/status/1397880159521415169"
    }
  },
  {
    "like" : {
      "tweetId" : "1397875980891459589",
      "fullText" : "Starting soon...! I will be presenting some of my research into #marineplastic innovation for the #EUGreenWeek Plastics challenge Hackathon 2021 hosted by the Sumy National Agrarian University @VU_IVM @CLAIM_H2020 https://t.co/x75TPWBB8O",
      "expandedUrl" : "https://twitter.com/i/web/status/1397875980891459589"
    }
  },
  {
    "like" : {
      "tweetId" : "1397618880781168650",
      "fullText" : "It has been a demanding teaching year, teaching several game theory &amp; micro courses fully online, receiving emails like this one keeps me going☺️ https://t.co/I7IibxwbxV",
      "expandedUrl" : "https://twitter.com/i/web/status/1397618880781168650"
    }
  },
  {
    "like" : {
      "tweetId" : "1397095696659107840",
      "fullText" : "Trouw opent vandaag met zgn. 'tipping points' (kantelpunten). Wat zijn dat? Wat heeft het met klimaatverandering te maken? Een draadje uit mijn promotie-onderzoek. @EstherBijlo @DeltaresNL @VU_IVM @TanjaFilatova @DetlefvanVuuren @Lijnonline [1/7] https://t.co/HcwLJUmqgG",
      "expandedUrl" : "https://twitter.com/i/web/status/1397095696659107840"
    }
  },
  {
    "like" : {
      "tweetId" : "1397138805120020482",
      "fullText" : "Looking forward to presenting at #RiskKAN!! https://t.co/Z3ydbr9mwe",
      "expandedUrl" : "https://twitter.com/i/web/status/1397138805120020482"
    }
  },
  {
    "like" : {
      "tweetId" : "1395434626605371392",
      "fullText" : "I had to keep this silent for a while.. but I can now share that our STORM paper has won 2nd place in the Lloyd's Science of Risk prize! It was amazing to present the paper for the insurance sector, and a huge congrats to the other winners!!\n(The paper: https://t.co/uZhDyAdvh5) https://t.co/UvpU3FoLUs",
      "expandedUrl" : "https://twitter.com/i/web/status/1395434626605371392"
    }
  },
  {
    "like" : {
      "tweetId" : "1395632197084794882",
      "fullText" : "Congrats Nadia! Happy to see our paper is recognized to contribute to a better understanding of climate risks in insurance https://t.co/wKAyTNlsjw",
      "expandedUrl" : "https://twitter.com/i/web/status/1395632197084794882"
    }
  },
  {
    "like" : {
      "tweetId" : "1395082026668236802",
      "fullText" : "Since #paywall - Here a link where you can read the paper: https://t.co/cuA3IIp1OM\nPing me if you want a pdf of the paper.",
      "expandedUrl" : "https://twitter.com/i/web/status/1395082026668236802"
    }
  },
  {
    "like" : {
      "tweetId" : "1395046876353908745",
      "fullText" : "Anyone interested in a thinking (and reading) slow book club? 🙋🏻‍♀️ https://t.co/B3dZBq2ERh",
      "expandedUrl" : "https://twitter.com/i/web/status/1395046876353908745"
    }
  },
  {
    "like" : {
      "tweetId" : "1395024090331762690",
      "fullText" : "[IVMer of the Week] Working from home can make it difficult to get to know your new colleagues. We therefore scheduled informal coffee breaks on Wednesdays with the PhDs and other young staff at the EE department. Today I discussed vacation plans with @hannadijkstra and Max. https://t.co/oTHoRjWPp5",
      "expandedUrl" : "https://twitter.com/i/web/status/1395024090331762690"
    }
  },
  {
    "like" : {
      "tweetId" : "1394945207779708933",
      "fullText" : "Interested in learning how to use R to prepare, analyze, and visualize data? Join me during my two week summer school course! More info can be found here: https://t.co/n0KmESJ8IF",
      "expandedUrl" : "https://twitter.com/i/web/status/1394945207779708933"
    }
  },
  {
    "like" : {
      "tweetId" : "1394658252537860113",
      "fullText" : "Proud owner of a \"cheat-bike\"👋. I now cycle to uni (30km total) + I have energy left to work/enjoy my evening when I get home. Moreover, I can still cycle when my right leg is having an off-day, so my MS is no longer a limiting factor in cycling somewhere!💪 https://t.co/ZyYq4f2jCF",
      "expandedUrl" : "https://twitter.com/i/web/status/1394658252537860113"
    }
  },
  {
    "like" : {
      "tweetId" : "1394629142340059138",
      "fullText" : "How often were you late, because they were inspecting a bridge #justdutchthings https://t.co/tU6Xn39I7u",
      "expandedUrl" : "https://twitter.com/i/web/status/1394629142340059138"
    }
  },
  {
    "like" : {
      "tweetId" : "1394387194115153925",
      "fullText" : "We had to cancel the 2021 Winter Workshop in Experimental Food Economics in the Alps, but @EspinosaRomain came to the rescue organizing an online workshop @RennesSB.\n\nSo this Thursday tune in here https://t.co/1AwWVDGRuo for an overview of recent research on food &amp; experiments!",
      "expandedUrl" : "https://twitter.com/i/web/status/1394387194115153925"
    }
  },
  {
    "like" : {
      "tweetId" : "1394326001715404802",
      "fullText" : "@SchrieksTeun @D2E_Project @rhodaodongo @IleenStreefkerk @TimBusker [IVMer of the week] In the afternoon I had the first lecture of an advanced academic writing course. It seems to be a very useful course, but I am now really tired from a full day of zoom calls. Luckily it stopped raining, so I will close my laptop and go outside to play tennis!",
      "expandedUrl" : "https://twitter.com/i/web/status/1394326001715404802"
    }
  },
  {
    "like" : {
      "tweetId" : "1393129032095608834",
      "fullText" : "Important new meta-analysis of climate interventions from Jacob Rode et al. @Harvard. Scientific consensus messages have a significant pos effect (n = 20) on climate attitudes (g = 0.09), larger than most interventions &amp; no backfire amongst conservatives!\n\nhttps://t.co/VP00ObHp7f https://t.co/KqHnTklLAR",
      "expandedUrl" : "https://twitter.com/i/web/status/1393129032095608834"
    }
  },
  {
    "like" : {
      "tweetId" : "1393134022453235713",
      "fullText" : "@giladfeldman is doing amazing work on replications in psychology/JDM. By mobilizing students @HKUniversity, he is able to replicate at scale. He is interested in people's predictions of what will replicate. Vote in the thread below (if you know the original study). https://t.co/obiKKlz8Y0",
      "expandedUrl" : "https://twitter.com/i/web/status/1393134022453235713"
    }
  },
  {
    "like" : {
      "tweetId" : "1393083817532051456",
      "fullText" : "Een promotieonderzoek over het effect van onethisch leiderschap op werknemersproductiviteit van @TheBrouwer. https://t.co/E0crXSCztq https://t.co/s7Q2OKdWTm",
      "expandedUrl" : "https://twitter.com/i/web/status/1393083817532051456"
    }
  },
  {
    "like" : {
      "tweetId" : "1392789131474972674",
      "fullText" : "Ik had dit zeker nu, zo graag willen maken... Maar goed, showcolade is natuurlijk ook tof #afgekeurdepitch https://t.co/nzKkmgnbhb",
      "expandedUrl" : "https://twitter.com/i/web/status/1392789131474972674"
    }
  },
  {
    "like" : {
      "tweetId" : "1392762370989101060",
      "fullText" : "I love this! If you overestimate small probabilities coupled with large payoff consequences (like getting serious vaccine side effects), you may also do that for winning the lottery. Great use of behavioral economics! https://t.co/eAeDH62k0i",
      "expandedUrl" : "https://twitter.com/i/web/status/1392762370989101060"
    }
  },
  {
    "like" : {
      "tweetId" : "1392365653538058240",
      "fullText" : "Excel https://t.co/EqieVxNPGN",
      "expandedUrl" : "https://twitter.com/i/web/status/1392365653538058240"
    }
  },
  {
    "like" : {
      "tweetId" : "1392138467363205121",
      "fullText" : "The first paper of my PhD project has been published in \"Decision\" (together with Stefan Zeisberger , @MarsZeelenberg and @smbreugelmans)! We explore how greed influences individual trading behavior. The link is not as straightforward as often thought!\n\nhttps://t.co/YSK0c5lYg3",
      "expandedUrl" : "https://twitter.com/i/web/status/1392138467363205121"
    }
  },
  {
    "like" : {
      "tweetId" : "1392099134853861376",
      "fullText" : "What can we learn from a null result with norm nudges? \n\nNew &amp; Open Access in #FirstView \n\nA deep dive into #Nudge failure; lab experiments on household flood preparedness\n\nOpen Access in #FirstView \n👉 https://t.co/WWediHKVcy \n\n#SocialNorms #PresentBias #floods https://t.co/7iUSUsKxrR",
      "expandedUrl" : "https://twitter.com/i/web/status/1392099134853861376"
    }
  },
  {
    "like" : {
      "tweetId" : "1392217592094470146",
      "fullText" : "I quickly checked the report for stats on surge and rainfall near Cocodrie. Now, my topo skills of that area aren't top-notch so I am not sure whether the data was all within 100km from landfall, but on our scale Zeta was already a Cat3 before update. After update likely Cat4. https://t.co/yEVZRuUFfc",
      "expandedUrl" : "https://twitter.com/i/web/status/1392217592094470146"
    }
  },
  {
    "like" : {
      "tweetId" : "1392091438121422848",
      "fullText" : "Excited to present my work at @sig_chi #CHI2021 student research competition. I talked about the comparison of pedestrian route and exit choice behaviour, and user experience between Desktop #VR and HMD VR. It's amazing to know the #HCI community and see the diversity work! https://t.co/FrD52kOjKl",
      "expandedUrl" : "https://twitter.com/i/web/status/1392091438121422848"
    }
  },
  {
    "like" : {
      "tweetId" : "1392078061714251776",
      "fullText" : "I think when it comes to coding, people get scared off quite quickly.\n\nHere's a pro-tip: the only language you really need to have mastered is English. The bloody error message will probably tell you exactly what went wrong.\n\nAlso Google. Google everything...",
      "expandedUrl" : "https://twitter.com/i/web/status/1392078061714251776"
    }
  },
  {
    "like" : {
      "tweetId" : "1391753525017862144",
      "fullText" : "📢Vacancy alert❗️ Looking for a PhD position in multi-hazard risk? We're looking for 2 colleagues to join our team (@PhilipWard_ @Marleen_Ruiter) on the H2020 MYRIAD-EU project. #multirisk @VU_Science \n\nFor more information, see:\n\nhttps://t.co/Vd1IrVv0uQ\n\nhttps://t.co/DWYme4XRa1",
      "expandedUrl" : "https://twitter.com/i/web/status/1391753525017862144"
    }
  },
  {
    "like" : {
      "tweetId" : "1391748412022919169",
      "fullText" : "Our paper “Do descriptive social norms drive peer punishment? Conditional punishment strategies and their impact on cooperation” is available online @EvolHumBehav. You can download it (open access) here: https://t.co/CPt037ojgE. A thread below 👇",
      "expandedUrl" : "https://twitter.com/i/web/status/1391748412022919169"
    }
  },
  {
    "like" : {
      "tweetId" : "1390725066443345925",
      "fullText" : "Today we welcomed Zachary Grossman (@ucmerced), who gave a very interesting and thought-provoking talk on what is still not fully understood about “Information avoidance in social decisions”. https://t.co/WzOJSDbllj",
      "expandedUrl" : "https://twitter.com/i/web/status/1390725066443345925"
    }
  },
  {
    "like" : {
      "tweetId" : "1390649704233545729",
      "fullText" : "Great meeting welcoming @TimBusker and @Perilaro to the IVM Twitter Team 🎉 Together with @hannadijkstra and @CateMarinetti we are in charge of IVM's tweets. Any suggestions for how we can make the most of Twitter and improve #SciComm? Let us know! https://t.co/NyHv0UaEds",
      "expandedUrl" : "https://twitter.com/i/web/status/1390649704233545729"
    }
  },
  {
    "like" : {
      "tweetId" : "1390350005345603584",
      "fullText" : "@JantsjeMol @WhartonRiskCtr @BPPjournal 🥳 it’s a nice paper https://t.co/GAr4AmmwN4",
      "expandedUrl" : "https://twitter.com/i/web/status/1390350005345603584"
    }
  },
  {
    "like" : {
      "tweetId" : "1390339573692059663",
      "fullText" : "Did this instead of figuring out how the new Qualtrics design works. https://t.co/1oG8ZLpuc0",
      "expandedUrl" : "https://twitter.com/i/web/status/1390339573692059663"
    }
  },
  {
    "like" : {
      "tweetId" : "1390305914213785600",
      "fullText" : "Woke up to positive news in my inbox this AM — the rumors of reviewers being nice &amp; instant-accepting papers are seemingly true🥳\n\n[R2 enters the chat]\nAs expected, R2 is pushing us to do better (&amp; we will)\n\n(old tweet below, updated version: https://t.co/vgqb7itNHi)\n#EconTwitter https://t.co/7j1rXZKQPT https://t.co/gY9IsNnab6",
      "expandedUrl" : "https://twitter.com/i/web/status/1390305914213785600"
    }
  },
  {
    "like" : {
      "tweetId" : "1390300616375767041",
      "fullText" : "and now I have a vaccine appointment",
      "expandedUrl" : "https://twitter.com/i/web/status/1390300616375767041"
    }
  },
  {
    "like" : {
      "tweetId" : "1390027071452327943",
      "expandedUrl" : "https://twitter.com/i/web/status/1390027071452327943"
    }
  },
  {
    "like" : {
      "tweetId" : "1389655517845508104",
      "fullText" : "Today is Remembrance Day in the Netherlands, to commemorate those who died during war and in peace-keeping missions. This rainbow formed right after our National Ceremony on Dam Square ended. Lest we forget/Opdat wij niet vergeten. https://t.co/9dIbtW2wmi",
      "expandedUrl" : "https://twitter.com/i/web/status/1389655517845508104"
    }
  },
  {
    "like" : {
      "tweetId" : "1389264683270647813",
      "fullText" : "🔥 very proud of this collaboration between @VU_IVM and USF! https://t.co/bhwnUHCbdV",
      "expandedUrl" : "https://twitter.com/i/web/status/1389264683270647813"
    }
  },
  {
    "like" : {
      "tweetId" : "1388943470103048194",
      "fullText" : "You’re unable to view this Post because this account owner limits who can view their Posts. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1388943470103048194"
    }
  },
  {
    "like" : {
      "tweetId" : "1388161770334957570",
      "fullText" : "For new APs / postdocs in economics: Probably you’re about to say yes to too many referee requests. Declining is easier when you have a rule. This is the finite automaton that implements my rule. https://t.co/SGqXjXTSiR",
      "expandedUrl" : "https://twitter.com/i/web/status/1388161770334957570"
    }
  },
  {
    "like" : {
      "tweetId" : "1388189651832344578",
      "fullText" : "Nog even de algen controleren.. 👩‍🔬🌱 https://t.co/p13PDfMyXC",
      "expandedUrl" : "https://twitter.com/i/web/status/1388189651832344578"
    }
  },
  {
    "like" : {
      "tweetId" : "1388189549025710081",
      "fullText" : "Yes! 1962 is aan de beurt en ik heb afspraken voor mijn vaccinaties! 💉",
      "expandedUrl" : "https://twitter.com/i/web/status/1388189549025710081"
    }
  },
  {
    "like" : {
      "tweetId" : "1388065628544765952",
      "fullText" : "@Bloemendaal_N @JeroenAerts4 @MuisSanne @Hans_deMoel @flowcharts [IVMer of the week] And for my final tweet, I would like to tell anyone reading this and considering doing a PhD: go for it. Sending in my application 5 years ago was the best decision I could have made, hands down. \n\nThank you for joining me on the last few days of my PhD! :)",
      "expandedUrl" : "https://twitter.com/i/web/status/1388065628544765952"
    }
  },
  {
    "like" : {
      "tweetId" : "1388064654166040578",
      "fullText" : "@Bloemendaal_N @JeroenAerts4 @MuisSanne @Hans_deMoel @flowcharts [IVMer of the week] The best thing about my PhD was studying the thing I've always been passionate about: extreme weather! I definitely was (&amp; am) that researcher running around the department telling everyone a high-impact hurricane was about to make landfall (sorry not sorry!)",
      "expandedUrl" : "https://twitter.com/i/web/status/1388064654166040578"
    }
  },
  {
    "like" : {
      "tweetId" : "1388103936318525441",
      "fullText" : "@Bloemendaal_N Most important is that you look happy on both days",
      "expandedUrl" : "https://twitter.com/i/web/status/1388103936318525441"
    }
  },
  {
    "like" : {
      "tweetId" : "1387882384377454594",
      "fullText" : "Just out in @PNASNews: Our new megastudy of text messages designed to nudge vaccination. The top-performing message conveyed that a vaccine was \"reserved for you.\" A dream team of scientists worked on this @ChangeBcfg @PennNudgeUnit project to save lives: https://t.co/O5C44UB57l",
      "expandedUrl" : "https://twitter.com/i/web/status/1387882384377454594"
    }
  },
  {
    "like" : {
      "tweetId" : "1387959463785664529",
      "fullText" : "Surprisingly, some counties also exhibit a lower than average rate... Who would have thought that both of these could be possible? https://t.co/nvemdzpp2x",
      "expandedUrl" : "https://twitter.com/i/web/status/1387959463785664529"
    }
  },
  {
    "like" : {
      "tweetId" : "1387785183223369731",
      "fullText" : "Thanks to all who participated! 🙏 \n\nAnd welcome to the 100 new followers 🤗 https://t.co/A0VrgDFglo",
      "expandedUrl" : "https://twitter.com/i/web/status/1387785183223369731"
    }
  },
  {
    "like" : {
      "tweetId" : "1387785161731809281",
      "fullText" : "The results of the experiment are in!\nEmojis:\nRT: 1.33\n❤️ : 5.17\n\nNon emojis:\nRT: 1.33\n❤️ : 5.67\n\n🤔 The null hypothesis is, for the moment, retained. https://t.co/RCwRUSiY3q",
      "expandedUrl" : "https://twitter.com/i/web/status/1387785161731809281"
    }
  },
  {
    "like" : {
      "tweetId" : "1387752341227589634",
      "fullText" : "You’re unable to view this Post because this account owner limits who can view their Posts. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1387752341227589634"
    }
  },
  {
    "like" : {
      "tweetId" : "1387782955058221067",
      "fullText" : "This Post is from a suspended account. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1387782955058221067"
    }
  },
  {
    "like" : {
      "tweetId" : "1387763601574973449",
      "fullText" : "I've been away from this space for quite a while 📅\nOur daughter arrived two months ago, and I've been preoccupied with getting adjusted to the happy changes in our family 👨‍👩‍👧‍👦\nWe are all doing well 💚\nFeeling more than grateful @UBVU 🌺 https://t.co/CeqUqcFzmL",
      "expandedUrl" : "https://twitter.com/i/web/status/1387763601574973449"
    }
  },
  {
    "like" : {
      "tweetId" : "1387042955597205513",
      "fullText" : "Current mood after weeks of gathering data, cleaning it up, and merging with my main dataset... @Stata https://t.co/p072WjV9lW",
      "expandedUrl" : "https://twitter.com/i/web/status/1387042955597205513"
    }
  },
  {
    "like" : {
      "tweetId" : "1387329274110259200",
      "fullText" : "[IVMer of the week] Hi all! My name is Nadia (@Bloemendaal_N ) and welcome to my work life! I am in the final 3 days (!) of my PhD on Tropical Cyclone Risk under Climate Change and working really hard to finish my thesis in time :) https://t.co/qkA3Ooxf1H",
      "expandedUrl" : "https://twitter.com/i/web/status/1387329274110259200"
    }
  },
  {
    "like" : {
      "tweetId" : "1387128007970762753",
      "fullText" : "Finally out! Placing meat substitutes next to meats (vs. in the vegetarian aisle) increased sales by 171% in actual supermarkets\nby Vandenbroele, Slabbinck, Van Kerckhove, Vermeir #OBHDP https://t.co/Qb1h8AKVR0 https://t.co/P8x48fYp9H",
      "expandedUrl" : "https://twitter.com/i/web/status/1387128007970762753"
    }
  },
  {
    "like" : {
      "tweetId" : "1385841846656581635",
      "fullText" : "@JuliaBlasch @JantsjeMol Wonderful outcome of 5 different disciplines joining forces. Well done!",
      "expandedUrl" : "https://twitter.com/i/web/status/1385841846656581635"
    }
  },
  {
    "like" : {
      "tweetId" : "1383070151227105285",
      "fullText" : "In sum, there is still room for improvement in terms of replicability. However, it seems that things are getting better over time, as authors are getting used to provide proper replication packages with data, code, and documentation. (12/12)",
      "expandedUrl" : "https://twitter.com/i/web/status/1383070151227105285"
    }
  },
  {
    "like" : {
      "tweetId" : "1385700045790629902",
      "fullText" : "Update: https://t.co/VlRvtrYJSC",
      "expandedUrl" : "https://twitter.com/i/web/status/1385700045790629902"
    }
  },
  {
    "like" : {
      "tweetId" : "1385698110815539203",
      "expandedUrl" : "https://twitter.com/i/web/status/1385698110815539203"
    }
  },
  {
    "like" : {
      "tweetId" : "1385620939157745664",
      "fullText" : "Dr Christian Reynolds @sartorialfoodie @FoodPolicyCity comments in @guardian on eating more sustainably:\n\n“The average family wastes 244kg of food annually. That’s equivalent to about one in every four shopping bags that are being wasted.”\n\n@CityUniLondon\n\nhttps://t.co/qP8dBj9Gjo",
      "expandedUrl" : "https://twitter.com/i/web/status/1385620939157745664"
    }
  },
  {
    "like" : {
      "tweetId" : "1385640670992510976",
      "fullText" : "Been holding onto this news for a while, but excited to finally share that I've signed a book contract!\n\nFrom summer onwards, I'll be writing \"A Student’s Guide to the Replication Crisis: How to use Open Science to Reform Psychology\". \n\n 🤩📚☕#StudentsGuidetoOS\n@OpenUniPress",
      "expandedUrl" : "https://twitter.com/i/web/status/1385640670992510976"
    }
  },
  {
    "like" : {
      "tweetId" : "1385645435126231049",
      "fullText" : "Congratulations @JantsjeMol &amp; @JuliaBlasch &amp; @ZigaMalek!",
      "expandedUrl" : "https://twitter.com/i/web/status/1385645435126231049"
    }
  },
  {
    "like" : {
      "tweetId" : "1385616292237938693",
      "fullText" : "Exciting new paper on sustainable diets! It was extremely pleasant working with @JantsjeMol @JuliaBlasch @VU_IVM and Meike Morren, and I am happy to see what came out of a small idea and a small grant! Check @JantsjeMol thread for more info https://t.co/QKsM1iT81s",
      "expandedUrl" : "https://twitter.com/i/web/status/1385616292237938693"
    }
  },
  {
    "like" : {
      "tweetId" : "1385614005407035397",
      "fullText" : "The result of two years of inspiring cross-departmental collaboration 🙌 A new paper on stimulating sustainable diets is published: https://t.co/EZe21qpTSh Summarized nicely below by @JantsjeMol 👇 https://t.co/Q1ogX84uao",
      "expandedUrl" : "https://twitter.com/i/web/status/1385614005407035397"
    }
  },
  {
    "like" : {
      "tweetId" : "1385530347480305665",
      "fullText" : "Note to the #RecSys community: if you wish to repurpose your work for nudging / behavioral economics outlet, call your recommender systems ‘algorithmic nudges’. Or smart defaults. https://t.co/hxrvp46knK",
      "expandedUrl" : "https://twitter.com/i/web/status/1385530347480305665"
    }
  },
  {
    "like" : {
      "tweetId" : "1385597586472570882",
      "fullText" : "I’m currently reviewing a paper in another discipline that’s motivated as a direct extension of one of my own papers. Mine is still a WP under review. I have a feeling that this extension will be published before the original work.\n\nPublishing in econ is weird. #EconTwitter https://t.co/jyuehnHjoj",
      "expandedUrl" : "https://twitter.com/i/web/status/1385597586472570882"
    }
  },
  {
    "like" : {
      "tweetId" : "1384870086675152902",
      "fullText" : "How do you typically visualize change between two points? 🤔📊\n\nI love using slopegraphs!\n\nIn this makeover of the original paired bar chart, the slopegraph clearly shows that \"will not celebrate\" is the only category going up. \n\nColor also helps highlight the main slope. https://t.co/AgS3oXPrch",
      "expandedUrl" : "https://twitter.com/i/web/status/1384870086675152902"
    }
  },
  {
    "like" : {
      "tweetId" : "1384767623838195712",
      "fullText" : "Did you guys know about this??? A truly amazing reason to learn R. https://t.co/40kY9DF2L8",
      "expandedUrl" : "https://twitter.com/i/web/status/1384767623838195712"
    }
  },
  {
    "like" : {
      "tweetId" : "1384575209328500736",
      "fullText" : "🔥Don’t miss out on the opportunity to see my amazing mentor &amp; co-author Simon Gächter present new work on the logic of rule following &amp; my friend Nils @NCKobis do the academic opening act on cross-cultural corruption (w/ @Shaul_Shalvi)\n\nLink: https://t.co/s11uhUa8Fq\n#EconTwitter https://t.co/ziLGenLYkU",
      "expandedUrl" : "https://twitter.com/i/web/status/1384575209328500736"
    }
  },
  {
    "like" : {
      "tweetId" : "1384797183275327489",
      "fullText" : "We are recruiting for a paid on-site study in central London: Virtual Reality Experiment - Movement Under Threat: https://t.co/KhuvHzmGzI",
      "expandedUrl" : "https://twitter.com/i/web/status/1384797183275327489"
    }
  },
  {
    "like" : {
      "tweetId" : "1384810758412853248",
      "fullText" : "Risk perception of climate change and natural hazards in global mountain regions\n\nScience of Total Environment @STOTEN_journal\n\nStefan Schneiderbauer @pao_fonpisa J Delves, L Pedoth @SamuelRufat M Erschbamer @thomasthaler8 F Carnelli, S Granados @UNUEHS\n\nhttps://t.co/gN6WnQn5Wd",
      "expandedUrl" : "https://twitter.com/i/web/status/1384810758412853248"
    }
  },
  {
    "like" : {
      "tweetId" : "1384769086559768578",
      "fullText" : "For those interested, I will give a seminar to explain my work tomorrow. Can also be watched afterwards. https://t.co/4MeH8gNvXM\n\nThank you @TUe_EIRES for the tweet :) https://t.co/0INF0diaJW",
      "expandedUrl" : "https://twitter.com/i/web/status/1384769086559768578"
    }
  },
  {
    "like" : {
      "tweetId" : "1384467059111772171",
      "fullText" : "Thank you @DIFFERenergy! I am very honored to be nominated! \n\nFor anyone interested what my work is about: I will give a talk! Video will be available after. Link here: https://t.co/4MeH8gNvXM\n\nVote here: https://t.co/YynOj0R5sR\nThank you! https://t.co/f2BBbnK2Dy",
      "expandedUrl" : "https://twitter.com/i/web/status/1384467059111772171"
    }
  },
  {
    "like" : {
      "tweetId" : "1376835989453279232",
      "fullText" : "'Nu wordt vaak gedacht dat als we klimaatverandering tegengaan, dat mensen diep ongelukkig worden...' \n\nStevinlaureaat Linda Steg vertelt in deze video wat haar drijft en waar zij haar Stevinpremie voor wil inzetten. \n@univgroningen https://t.co/5TsxpBwZzt",
      "expandedUrl" : "https://twitter.com/i/web/status/1376835989453279232"
    }
  },
  {
    "like" : {
      "tweetId" : "1384253541150183424",
      "fullText" : "This journal-agnostic peer review model is the future, imo. Submit your paper to a community of experts who do open, rigorous review, then choose which journal gets to “publish” it.\n@CollabraOA is part of this initiative* for Registered Reports.\nhttps://t.co/uuEgAFAH3N",
      "expandedUrl" : "https://twitter.com/i/web/status/1384253541150183424"
    }
  },
  {
    "like" : {
      "tweetId" : "1384145636346318865",
      "fullText" : "*Context: I have not emailed our university librarian in a while*\nMe: Dear Librarian, I'm a PhD Candidate in the Economics Department...\nLibrarian: Kelsi, I know who you are...",
      "expandedUrl" : "https://twitter.com/i/web/status/1384145636346318865"
    }
  },
  {
    "like" : {
      "tweetId" : "1382744210873389060",
      "fullText" : "I taught my dad the term “empirical microeconomics” and now I’m pretty sure all 4,000 people in my hometown have heard that my dad’s daughter is an “empirical microeconomist — not macro! It’s different”",
      "expandedUrl" : "https://twitter.com/i/web/status/1382744210873389060"
    }
  },
  {
    "like" : {
      "tweetId" : "1382778019840983044",
      "fullText" : "@ericneumannpsyc He replied; I like a quiet train ride. We chuckled and continued talking. At the train station, the colleague asked about my plans. I told her about my meeting with the prsident. The man got up, also left the train and said; guess I’ll see you in the meeting. It was the president",
      "expandedUrl" : "https://twitter.com/i/web/status/1382778019840983044"
    }
  },
  {
    "like" : {
      "tweetId" : "1382763476377083906",
      "fullText" : "You know it's a good day when someone delivers the first book from @katy_milkman! I know a lot of people have been waiting for this one &amp; it lives up to the hype... https://t.co/mHstWsLmmP https://t.co/V7iUMzmUqF",
      "expandedUrl" : "https://twitter.com/i/web/status/1382763476377083906"
    }
  },
  {
    "like" : {
      "tweetId" : "1382102400031412229",
      "fullText" : "Frustrated with journals, I've been tinkering with ideas for a better way to read papers than static/linear. I have a v0.1 demo - would be great to get feedback. Would you find something like this useful? What else should be included? More details in 🧵👇\n\nhttps://t.co/IteGjMudLV https://t.co/4nZM1HBuaL",
      "expandedUrl" : "https://twitter.com/i/web/status/1382102400031412229"
    }
  },
  {
    "like" : {
      "tweetId" : "1382409117558579205",
      "fullText" : "Look what just came in a big box! ⁦@portfoliobooks⁩ ⁦@penguinusa⁩ \n#FirstTimeAuthor #ThisIsSoExciting https://t.co/5FezHu2vfw",
      "expandedUrl" : "https://twitter.com/i/web/status/1382409117558579205"
    }
  },
  {
    "like" : {
      "tweetId" : "1382344029879246851",
      "fullText" : "R&amp;R on a paper that I love - but that has not received much love from referees (in the past)!\n\nPausing everything to quickly update my webpage and CV 🥳",
      "expandedUrl" : "https://twitter.com/i/web/status/1382344029879246851"
    }
  },
  {
    "like" : {
      "tweetId" : "1381632748448841732",
      "fullText" : "A PhD won't guarantee you a job or big salary. It won't build your confidence over night!\n\nIt will give you a sense of achievement of overcoming challenges. \n\nThat will stay with you forever.\n\nWhat else do you gain from a PhD?\n\n#PhDgenie #AcademicChatter #phdvoice @OpenAcademics",
      "expandedUrl" : "https://twitter.com/i/web/status/1381632748448841732"
    }
  },
  {
    "like" : {
      "tweetId" : "1380375063665516544",
      "fullText" : "It's very special to me to present at my alma mater @vwl_regensburg \nand in such a line-up👇14 June 👇 Looking forward! https://t.co/8u55qQ1DVC",
      "expandedUrl" : "https://twitter.com/i/web/status/1380375063665516544"
    }
  },
  {
    "like" : {
      "tweetId" : "1380172167229415424",
      "fullText" : "Today I have conducted my first experiment (remotely due to Covid) and I can tell you that I have never been so sure that starting a PhD was the best decision of my life 🤩 #phdchat #phdlife #academictwitter #phdfriend #phdvoice @OpenAcademics @AcademicChatter https://t.co/B8Gd3QLysH",
      "expandedUrl" : "https://twitter.com/i/web/status/1380172167229415424"
    }
  },
  {
    "like" : {
      "tweetId" : "1380207013767090181",
      "fullText" : "After numerous planetary revolutions, my intensly detailed knowledge tells me I still have not gathered all knowledge on tropical cyclone risk 😬 https://t.co/d9O5wkEOgK",
      "expandedUrl" : "https://twitter.com/i/web/status/1380207013767090181"
    }
  },
  {
    "like" : {
      "tweetId" : "1379545603269607427",
      "expandedUrl" : "https://twitter.com/i/web/status/1379545603269607427"
    }
  },
  {
    "like" : {
      "tweetId" : "1379376090494435334",
      "fullText" : "en coronaproof publiek in de zon! https://t.co/mfAZNEoFZ2",
      "expandedUrl" : "https://twitter.com/i/web/status/1379376090494435334"
    }
  },
  {
    "like" : {
      "tweetId" : "1377508214082842624",
      "fullText" : "Despite years of budget cuts, researchers continue to explore the unknown, helping society to cope with complex issues. We call upon the Dutch government to invest an additional 1,1 billion euros per annum so that universities can do their work properly! #nap #wateraandelippen https://t.co/8s0TAwgTUV",
      "expandedUrl" : "https://twitter.com/i/web/status/1377508214082842624"
    }
  },
  {
    "like" : {
      "tweetId" : "1376254151479459843",
      "fullText" : "Just a quick heads up that we are taking a break from publishing our episodes for a couple of weeks to get some other work (PhD etc.) done, and actually enjoy the Easter break!\n\nDon't worry, we will be back with more great interviews! https://t.co/XLNRvpmBK7",
      "expandedUrl" : "https://twitter.com/i/web/status/1376254151479459843"
    }
  },
  {
    "like" : {
      "tweetId" : "1375535870514724866",
      "fullText" : "@JantsjeMol Congratulations, Jantsje! 🥳👏🏽",
      "expandedUrl" : "https://twitter.com/i/web/status/1375535870514724866"
    }
  },
  {
    "like" : {
      "tweetId" : "1375504165900840960",
      "fullText" : "@JantsjeMol Awesome, congrats!",
      "expandedUrl" : "https://twitter.com/i/web/status/1375504165900840960"
    }
  },
  {
    "like" : {
      "tweetId" : "1375465622512005122",
      "fullText" : "@JantsjeMol ZIN IN!!!!! https://t.co/EibUvNGbqt",
      "expandedUrl" : "https://twitter.com/i/web/status/1375465622512005122"
    }
  },
  {
    "like" : {
      "tweetId" : "1375461549809274880",
      "fullText" : "@JantsjeMol congratulation. Now its your turn to pace around as a bundle of nerves :)",
      "expandedUrl" : "https://twitter.com/i/web/status/1375461549809274880"
    }
  },
  {
    "like" : {
      "tweetId" : "1375168720495075338",
      "fullText" : "1) As a former sailor here’s my hot take on the stuck boat in the Suez. I’m actually in admiration of the skill of whoever did this. They managed a crash in one of the busiest water ways and all they damaged was a wall. No lives lost. No other boat involved, no damaged cargo. A+",
      "expandedUrl" : "https://twitter.com/i/web/status/1375168720495075338"
    }
  },
  {
    "like" : {
      "tweetId" : "1375373057888546816",
      "fullText" : "In our recent article on food neophobia we explore the underpinnings of the variation in willingness to eat novel meats and novel plants: \n\nhttps://t.co/F4Yu6J5ZpR",
      "expandedUrl" : "https://twitter.com/i/web/status/1375373057888546816"
    }
  },
  {
    "like" : {
      "tweetId" : "1375347927313481730",
      "fullText" : "https://t.co/es9xGXMUo6",
      "expandedUrl" : "https://twitter.com/i/web/status/1375347927313481730"
    }
  },
  {
    "like" : {
      "tweetId" : "1375226528221569026",
      "fullText" : "@causalinf @nickchk I'm glad to see applied micro getting the kind of scrutiny that experimental studies routinely get.",
      "expandedUrl" : "https://twitter.com/i/web/status/1375226528221569026"
    }
  },
  {
    "like" : {
      "tweetId" : "1375006195111628800",
      "fullText" : "Oh, it's in *economics*. Of course, it could never happen in &lt;our field&gt;. https://t.co/baoFjFpLGr",
      "expandedUrl" : "https://twitter.com/i/web/status/1375006195111628800"
    }
  },
  {
    "like" : {
      "tweetId" : "1374748502522204161",
      "fullText" : "Thanks to quarantines, closed kindergartens, online teaching, etc., I even missed @AEAjournals advertising our forthcoming article on #AEJmicro! Let's fix this with a topic! https://t.co/CC29mps5PA",
      "expandedUrl" : "https://twitter.com/i/web/status/1374748502522204161"
    }
  },
  {
    "like" : {
      "tweetId" : "1374717344740737025",
      "fullText" : "Ik mag mijn mouw vooralsnog alleen nog maar opstropen om mijn chronische ziekte onder controle te houden ... wanneer mag ik 'm opstropen voor een vaccinatie Hugo, zodat ik beschermd ben van een opleving van MS symptomen door corona (of erger..)? #VergeetOnsNietHugo https://t.co/5ThPO9fkAU",
      "expandedUrl" : "https://twitter.com/i/web/status/1374717344740737025"
    }
  },
  {
    "like" : {
      "tweetId" : "1374695548956119041",
      "fullText" : "Klaar voor brokje positief (nerd)nieuwtje? Komt ie: LaTeX in Word! \n(Je bent niet alleen @SotoyKoel, dit hebben ze ook bijzonder goed voor mij geheim gehouden) https://t.co/h2AEntGs8o https://t.co/jzSYxo5gWu",
      "expandedUrl" : "https://twitter.com/i/web/status/1374695548956119041"
    }
  },
  {
    "like" : {
      "tweetId" : "1374681033560428546",
      "fullText" : "Today, Ben Vollaard will give a presentation about \"Mediation analysis\" #mediationanalysis #specificmediator #treatmenteffect #improvedselfcontrol #statements #economists #analysis #heterogeneity #newapproach #Economics #research https://t.co/MKA9UH2IGC",
      "expandedUrl" : "https://twitter.com/i/web/status/1374681033560428546"
    }
  },
  {
    "like" : {
      "tweetId" : "1374382621329821697",
      "fullText" : "📢Call for papers:\n\nM-BEES and M-BEPS will take place online this year, on June 7&amp;8 2021. \n\nDeadline: April 9\n\nWe have some amazing keynote speakers this year:\n\n@Gerhard_Fehr \nDaniel Friedman\nNagore Iriberri\n@CameliaKuhnen \n@ImranRasul3 \n\nMore details 👇\n\nhttps://t.co/xN7GFL5Odk",
      "expandedUrl" : "https://twitter.com/i/web/status/1374382621329821697"
    }
  },
  {
    "like" : {
      "tweetId" : "1374146073107775498",
      "fullText" : "\"after engaging in unethical behavior, individuals’ memories of their actions become obfuscated over time because of the psychological distress and discomfort such misdeeds cause..people experience unethical amnesia: unethical actions tend to be forgotten\" https://t.co/aLxWCXvlX0 https://t.co/g4Y5q7lC66",
      "expandedUrl" : "https://twitter.com/i/web/status/1374146073107775498"
    }
  },
  {
    "like" : {
      "tweetId" : "1374119102122459138",
      "fullText" : "Need to show something to a friend. How many academics have had a paper rejected outright? It’s normal right? #AcademicChatter #AcademicTwitter please ‘like’ this if you’ve had a paper rejected outright!",
      "expandedUrl" : "https://twitter.com/i/web/status/1374119102122459138"
    }
  },
  {
    "like" : {
      "tweetId" : "1374277137327341568",
      "fullText" : "Today we celebrate the most amazing research field there is: Happy World Meteorological Day! ☀️🌩️🌪️🌈❄️☁️ https://t.co/KXtOzoyCGo",
      "expandedUrl" : "https://twitter.com/i/web/status/1374277137327341568"
    }
  },
  {
    "like" : {
      "tweetId" : "1373792756749983744",
      "fullText" : "The entirety of one of the best Econometrica papers. Certainly the best to contain the phrase \"ceiling, celery, ceremony, cease, cedar, celestial, celibacy\" https://t.co/5ezMeuFNrU",
      "expandedUrl" : "https://twitter.com/i/web/status/1373792756749983744"
    }
  },
  {
    "like" : {
      "tweetId" : "1373651596811325442",
      "fullText" : "Gefeliciteerd @SanneRaghoebar!  Wat deed je het fantastisch! Geweldig trots op onze @WURconsumption collega! https://t.co/aJn74b9C5k",
      "expandedUrl" : "https://twitter.com/i/web/status/1373651596811325442"
    }
  },
  {
    "like" : {
      "tweetId" : "1372937627792506889",
      "fullText" : "Old bar: write a Twitter thread\nNew bar: make a gif! https://t.co/zIUB4zjfu0",
      "expandedUrl" : "https://twitter.com/i/web/status/1372937627792506889"
    }
  },
  {
    "like" : {
      "tweetId" : "1372850267646001153",
      "fullText" : "If you are looking for a short paper to read today, let it be this lovely 2-pager article by @ADAlthousePhD \nhttps://t.co/eN1uTDXv1t https://t.co/OAMaG9poUZ",
      "expandedUrl" : "https://twitter.com/i/web/status/1372850267646001153"
    }
  },
  {
    "like" : {
      "tweetId" : "1372570063836999681",
      "fullText" : "Tomorrow at 4 PM I will defend my thesis: ‘How physical cues in micro food environments influence consumption: A social norm account’. Here you can find more information and the livestream if you are interested 😊 ⬇️ https://t.co/nojbfylZK8 via @WUR",
      "expandedUrl" : "https://twitter.com/i/web/status/1372570063836999681"
    }
  },
  {
    "like" : {
      "tweetId" : "1372266446122840066",
      "fullText" : "Wuuuuuuuut! The Greek Alphabet is officially withdrawn from use in hurrcane naming 😱 https://t.co/sSx1Vd7aBY",
      "expandedUrl" : "https://twitter.com/i/web/status/1372266446122840066"
    }
  },
  {
    "like" : {
      "tweetId" : "1372129970743615496",
      "fullText" : "Yesterday our article \"A new European land systems representation accounting for landscape characteristics\" is published! https://t.co/hyWIgdAZHK\nThe (beautiful) map is also publicly available via https://t.co/prtQ6oJcFQ \n#landsystem #openscience",
      "expandedUrl" : "https://twitter.com/i/web/status/1372129970743615496"
    }
  },
  {
    "like" : {
      "tweetId" : "1372115277119418371",
      "fullText" : "@dsquintana I bet you have no clue who that is in your GIF 😀",
      "expandedUrl" : "https://twitter.com/i/web/status/1372115277119418371"
    }
  },
  {
    "like" : {
      "tweetId" : "1371846627967827972",
      "fullText" : "im on a plane https://t.co/MfTHCbn4bC",
      "expandedUrl" : "https://twitter.com/i/web/status/1371846627967827972"
    }
  },
  {
    "like" : {
      "tweetId" : "1371842540102684686",
      "fullText" : "Super excited to see our paper on prospective metacognition🧠. We show a unique and causal role of anterior lateral PFC in estimating our chances of future success. Check it out👇 https://t.co/hCnkqkJFjU",
      "expandedUrl" : "https://twitter.com/i/web/status/1371842540102684686"
    }
  },
  {
    "like" : {
      "tweetId" : "1371531639344541696",
      "fullText" : "New paper out @ JEBO\n\"Favoring your in-group can harm both them and you: Ethnicity and public goods provision in China\"\nwith Ling Zhou, Charlotte Wang, Donghui Yang, Suping Shen, and Paul Seabright. https://t.co/oXCIhUaHJg",
      "expandedUrl" : "https://twitter.com/i/web/status/1371531639344541696"
    }
  },
  {
    "like" : {
      "tweetId" : "1371559380341166080",
      "fullText" : "This Post is from a suspended account. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1371559380341166080"
    }
  },
  {
    "like" : {
      "tweetId" : "1371053764585590785",
      "fullText" : "Het zat er al vroeg in... ik vind een multomap (weet iemand nog wat dat is?) uit ongeveer 1973. Ik werkte de geschiedenislessen thuis uit voor mezelf... https://t.co/i9g6jNX53J",
      "expandedUrl" : "https://twitter.com/i/web/status/1371053764585590785"
    }
  },
  {
    "like" : {
      "tweetId" : "1370723638320709637",
      "fullText" : "I just sent out a #postdoc application that I would just be so damn happy to get - like over the moon and back a few times.\n\nPray for me #AcademicTwitter",
      "expandedUrl" : "https://twitter.com/i/web/status/1370723638320709637"
    }
  },
  {
    "like" : {
      "tweetId" : "1370161719121616898",
      "expandedUrl" : "https://twitter.com/i/web/status/1370161719121616898"
    }
  },
  {
    "like" : {
      "tweetId" : "1370284811659608065",
      "fullText" : "Nieuw bericht: Buitenlanders aan het werk: Op radio 1 hoorde ik Andries Tunru vertellen dat hij alle verkiezingsprogramma’s gelezen had en in dat van de ChristenUnie het mooiste getal had gevonden. Ik zocht het thuis na en het klopt: Voor onze… https://t.co/L2dsmv1mZW",
      "expandedUrl" : "https://twitter.com/i/web/status/1370284811659608065"
    }
  },
  {
    "like" : {
      "tweetId" : "1369676829402013697",
      "fullText" : "We* got terrific news this week: Our paper on positive results in RRs vs standard papers has been accepted at AMPPS!\nJust updated the preprint to the final version: https://t.co/R8nWkqUO0w (analyses/results unchanged).\n\n* still Twitter-less Mitchell Schijen, @lakens, and myself https://t.co/6KNP2md2JP",
      "expandedUrl" : "https://twitter.com/i/web/status/1369676829402013697"
    }
  },
  {
    "like" : {
      "tweetId" : "1370022361219616769",
      "fullText" : "Got my first manuscript review request and I feel so flattered...and powerful...and terrified 😳 all this and I haven’t even started reading the paper yet #EconTwitter",
      "expandedUrl" : "https://twitter.com/i/web/status/1370022361219616769"
    }
  },
  {
    "like" : {
      "tweetId" : "1369703643394568192",
      "fullText" : "@gracedou https://t.co/n50lHoQBe8",
      "expandedUrl" : "https://twitter.com/i/web/status/1369703643394568192"
    }
  },
  {
    "like" : {
      "tweetId" : "1369662758833291271",
      "fullText" : "My lockdown top publication: \"Why are my guinea pigs screaming at me at 11AM? Identifying the correlation between high-pitched wheeking, empty food bowls, and my loss of concentration: a case study of Magnus and Nino\" https://t.co/LPJeVZkUAy",
      "expandedUrl" : "https://twitter.com/i/web/status/1369662758833291271"
    }
  },
  {
    "like" : {
      "tweetId" : "1369426858001973252",
      "expandedUrl" : "https://twitter.com/i/web/status/1369426858001973252"
    }
  },
  {
    "like" : {
      "tweetId" : "1369294737463775233",
      "fullText" : "Finally!\n\n... though I do not remember preordering two🤔 https://t.co/fuiSf1nwNO",
      "expandedUrl" : "https://twitter.com/i/web/status/1369294737463775233"
    }
  },
  {
    "like" : {
      "tweetId" : "1369283860161310724",
      "fullText" : "Not to utilize the scarcity principle but:\n\nthis is the🔥last chance🔥to be part of the #nudge forecasting study!\n\nGet💰in return for your educated guesses on what nudges (don’t) work wrt increasing mask-wearing👇🏻\n\nPls spread the word &amp; help out your fellow academics\n#EconTwitter https://t.co/ELpDPKyLdl https://t.co/lU2bELyu4w",
      "expandedUrl" : "https://twitter.com/i/web/status/1369283860161310724"
    }
  },
  {
    "like" : {
      "tweetId" : "1369216864660946945",
      "fullText" : "The TIBER symposium 2021 will take place on August 20, 2021, Friday. We are happy to announce that Anna Dreber and Eveline Crone @EACrone will be this year's keynotes. More details about the format, registration, and abstract submission will follow.",
      "expandedUrl" : "https://twitter.com/i/web/status/1369216864660946945"
    }
  },
  {
    "like" : {
      "tweetId" : "1369196078009102336",
      "fullText" : "Having fun creating a course on causal inference in big data @FSW_VU https://t.co/T1QLTheuSD",
      "expandedUrl" : "https://twitter.com/i/web/status/1369196078009102336"
    }
  },
  {
    "like" : {
      "tweetId" : "1369050215957733381",
      "fullText" : "I normally tweet about paper rejections, but last Sunday I got two papers accepted ... in the same day! What are the odds?!",
      "expandedUrl" : "https://twitter.com/i/web/status/1369050215957733381"
    }
  },
  {
    "like" : {
      "tweetId" : "1369028405690314754",
      "fullText" : "Back from a run. Check the mail. I'd be really excited about this issue even if my  paper wasn't in it 😁😁😁 https://t.co/1VmMMByeP3",
      "expandedUrl" : "https://twitter.com/i/web/status/1369028405690314754"
    }
  },
  {
    "like" : {
      "tweetId" : "1369047151142187012",
      "expandedUrl" : "https://twitter.com/i/web/status/1369047151142187012"
    }
  },
  {
    "like" : {
      "tweetId" : "1368905331783462921",
      "fullText" : "So, a Bachelor student just told me that I am the coolest female scientist they know. I can't, my heart just melted 🥺😭 What a way to kick off the new week and #InternationalWomensDay 💪 To all the women out there, keep it up!",
      "expandedUrl" : "https://twitter.com/i/web/status/1368905331783462921"
    }
  },
  {
    "like" : {
      "tweetId" : "1368920018952613888",
      "fullText" : "This is graphic/cartoon is great! https://t.co/DrtPobtz35",
      "expandedUrl" : "https://twitter.com/i/web/status/1368920018952613888"
    }
  },
  {
    "like" : {
      "tweetId" : "1368631196213731328",
      "fullText" : "https://t.co/xPQzgHiz6Z",
      "expandedUrl" : "https://twitter.com/i/web/status/1368631196213731328"
    }
  },
  {
    "like" : {
      "tweetId" : "1368503327491829767",
      "fullText" : "@UtzWeitzel Had only four options, thought &lt;5 was too uncommon. Maybe I need to update beliefs.",
      "expandedUrl" : "https://twitter.com/i/web/status/1368503327491829767"
    }
  },
  {
    "like" : {
      "tweetId" : "1368616520637677569",
      "fullText" : "Goed begin van mijn zestigste levensjaar: met mijn ouders! https://t.co/3YAYYZ1TJW",
      "expandedUrl" : "https://twitter.com/i/web/status/1368616520637677569"
    }
  },
  {
    "like" : {
      "tweetId" : "1367741442731433984",
      "fullText" : "@TrishHerps4Life nah, not the only one. Working too much is also not a good sign.",
      "expandedUrl" : "https://twitter.com/i/web/status/1367741442731433984"
    }
  },
  {
    "like" : {
      "tweetId" : "1367590384046514176",
      "fullText" : "Even a small country can have sizeable regional difference in culture.  The beautiful region of Twente, with about half a million people, stands out — also in warning those who may consider becoming a leader in Twente. https://t.co/Iz8AkqiRai",
      "expandedUrl" : "https://twitter.com/i/web/status/1367590384046514176"
    }
  },
  {
    "like" : {
      "tweetId" : "1367553281313144835",
      "fullText" : "Mijn #klimaatstreepjescode bij een belangrijk nieuwsbericht:\n\n➡️ Kabinet, gemeenten, bedrijven, er moet een tandje bij, ter voorkoming van verregaande negatieve klimaatveranderingseffecten wereldwijd.\n\nhttps://t.co/OyOjZw6EJy https://t.co/ZmI35FmIQo",
      "expandedUrl" : "https://twitter.com/i/web/status/1367553281313144835"
    }
  },
  {
    "like" : {
      "tweetId" : "1367493704886456330",
      "fullText" : "@KirbyKNielsen There is Peter Moffatt's book (below) but more is needed, for sure.  https://t.co/iHpanJLyRw",
      "expandedUrl" : "https://twitter.com/i/web/status/1367493704886456330"
    }
  },
  {
    "like" : {
      "tweetId" : "1367501912183046147",
      "fullText" : "Next week I'm presenting a completely new set of results @liraes_Paris. Although this flyer may suggest otherwise, I'm not planning embarrass myself by trying to give the seminar in French. You can join to confirm! #excited https://t.co/OKR6fpwgAV",
      "expandedUrl" : "https://twitter.com/i/web/status/1367501912183046147"
    }
  },
  {
    "like" : {
      "tweetId" : "1367130737598738435",
      "fullText" : "@TSEinfo and @IASToulouse summer school: interested in studying economic and political institutions with H. Larreguy, M. Saleh and P. Seabright or the evolution of human sociality with @ingelaalger @jorgeapenas @j_stieglitz ? Still a few places left: https://t.co/5qbC5MPwUr\n#phd https://t.co/dl7c4YBAhr",
      "expandedUrl" : "https://twitter.com/i/web/status/1367130737598738435"
    }
  },
  {
    "like" : {
      "tweetId" : "1367139894540304391",
      "fullText" : "[IVMer of the week] I ran a software test for students and produced some beauty on the side. (GRASS GIS flow direction in the stream-network on Tenerife). https://t.co/QzNMTjmMwd",
      "expandedUrl" : "https://twitter.com/i/web/status/1367139894540304391"
    }
  },
  {
    "like" : {
      "tweetId" : "1367125148634124292",
      "expandedUrl" : "https://twitter.com/i/web/status/1367125148634124292"
    }
  },
  {
    "like" : {
      "tweetId" : "1367056081936121856",
      "fullText" : "You’re unable to view this Post because this account owner limits who can view their Posts. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1367056081936121856"
    }
  },
  {
    "like" : {
      "tweetId" : "1367011373872533507",
      "fullText" : "Data-visualisation nightmare come true 😫 https://t.co/k1NZWarGSi",
      "expandedUrl" : "https://twitter.com/i/web/status/1367011373872533507"
    }
  },
  {
    "like" : {
      "tweetId" : "1366426648921391105",
      "fullText" : "A student in my R programming class shared this and I can’t stop laughing about it https://t.co/YlbcOwv6wr",
      "expandedUrl" : "https://twitter.com/i/web/status/1366426648921391105"
    }
  },
  {
    "like" : {
      "tweetId" : "1366290196929646592",
      "fullText" : "Update: they will fix it. https://t.co/zMjQYz7Tz6",
      "expandedUrl" : "https://twitter.com/i/web/status/1366290196929646592"
    }
  },
  {
    "like" : {
      "tweetId" : "1365201533432963073",
      "fullText" : "Iemand appt met de vraag of ik nog een gaatje in mijn agenda voor haar heb. Eindelijk kan ik deze foto een keer gebruiken https://t.co/gkPdr2bwU6",
      "expandedUrl" : "https://twitter.com/i/web/status/1365201533432963073"
    }
  },
  {
    "like" : {
      "tweetId" : "1364700954252173312",
      "fullText" : "My grandmother didn't want to get vaccinated with 'strange new mRNA stuff'. I explained it with a sketch &amp; cooking analogy. She's now been vaccinated with the BionTech vaccine. I thought this might be useful for others who know vaccine skeptics, too. Feel free to share, use &amp; RT: https://t.co/6SnRZNCAeG",
      "expandedUrl" : "https://twitter.com/i/web/status/1364700954252173312"
    }
  },
  {
    "like" : {
      "tweetId" : "1365085629000785923",
      "fullText" : "A vast array of approaches for eliciting expert judgments exist. Some are supported by research, some by practicality. Our paper summarizes common steps, evidence, and areas for further research. @tina_nane @ubcforestry @CEBRA_UoM  @SocRiskAnalysis https://t.co/m9onpS5LPA",
      "expandedUrl" : "https://twitter.com/i/web/status/1365085629000785923"
    }
  },
  {
    "like" : {
      "tweetId" : "1365009594045640711",
      "fullText" : "Proudly presenting the cover of my PhD dissertation - e-book also available #Defence #countingdown #19march https://t.co/WB0G1DAnEv",
      "expandedUrl" : "https://twitter.com/i/web/status/1365009594045640711"
    }
  },
  {
    "like" : {
      "tweetId" : "1364942589946953730",
      "fullText" : "Poging tot... https://t.co/eWuJ0YbWzG",
      "expandedUrl" : "https://twitter.com/i/web/status/1364942589946953730"
    }
  },
  {
    "like" : {
      "tweetId" : "1364899443917619204",
      "fullText" : "And just like that, the last chapter of my Ph.D. dissertation is accepted for publication. Now I'm really #Phdone\nExcited to see the results of this collaboration come to fruition. https://t.co/J5OZYOACSD",
      "expandedUrl" : "https://twitter.com/i/web/status/1364899443917619204"
    }
  },
  {
    "like" : {
      "tweetId" : "1364656788319203331",
      "fullText" : "@CFCamerer @arindube true story - at AEA many years ago for a session and previous session had Joe Stiglitz who left his name tag on the table. My colleague put it on as a joke. Someone asked him “How is Columbia?” 😂",
      "expandedUrl" : "https://twitter.com/i/web/status/1364656788319203331"
    }
  },
  {
    "like" : {
      "tweetId" : "1364700040456003585",
      "fullText" : "The only thing that I can ask you, if you are reading is, is for you to choose to be different. For those interested in what I did, here is a review on the field that a few have so adamantly rejected. https://t.co/dHauRhhXJM",
      "expandedUrl" : "https://twitter.com/i/web/status/1364700040456003585"
    }
  },
  {
    "like" : {
      "tweetId" : "1364749148264615936",
      "fullText" : "I cannot stress enough how much I appreciate a good statistics teacher.\n\nIn undergrad, it was explained terribly and it took me 2 years to understand why a DV is called a DV.\n\nNow, it is explained beautifully and I find myself rewatching lectures... out of fun! 😱 https://t.co/OiNw7JVu6j",
      "expandedUrl" : "https://twitter.com/i/web/status/1364749148264615936"
    }
  },
  {
    "like" : {
      "tweetId" : "1364660268144463877",
      "fullText" : "Had an interview regarding my #GameStop article for a German Radio station today. It was great!\n\nThe most fun part? They are going to dub over my English speaking voice with a German speaking voice.\n\nBloody hilarious. I hope \"I\" still sound like I know what I'm talking about 😅",
      "expandedUrl" : "https://twitter.com/i/web/status/1364660268144463877"
    }
  },
  {
    "like" : {
      "tweetId" : "1364566502561710080",
      "fullText" : "Cool paper. Get ready for geographic basis risk is weather-related financial contracts to become an even more important problem. https://t.co/7ja0N9tDEn",
      "expandedUrl" : "https://twitter.com/i/web/status/1364566502561710080"
    }
  },
  {
    "like" : {
      "tweetId" : "1364112690885574656",
      "fullText" : "I am super excited to announce that I will be joining @ZEW as a post-doctoral researcher in health economics this fall! 🥳\n\nI'd like to thank my advisors and colleagues at @TilburgU, family, and friends for their support over the last months.",
      "expandedUrl" : "https://twitter.com/i/web/status/1364112690885574656"
    }
  },
  {
    "like" : {
      "tweetId" : "1364171264924016641",
      "fullText" : "Real life Stroop Task 🙂 https://t.co/eeBNO8BRVH",
      "expandedUrl" : "https://twitter.com/i/web/status/1364171264924016641"
    }
  },
  {
    "like" : {
      "tweetId" : "1364191722696151050",
      "fullText" : "Wow. It was never reviewer 2. It was always reviewer 3, and reviewer 2 got the blame. What a jerk. Ht @metmaven https://t.co/3hMnUtC3H4 https://t.co/WO8QvBcdds",
      "expandedUrl" : "https://twitter.com/i/web/status/1364191722696151050"
    }
  },
  {
    "like" : {
      "tweetId" : "1364200654693163008",
      "fullText" : "Something odd happened to the blog for some reason, so I had to redesign quite a bit of it.\n\nBut at least now we have a slightly new look! https://t.co/5RTQILgSLE",
      "expandedUrl" : "https://twitter.com/i/web/status/1364200654693163008"
    }
  },
  {
    "like" : {
      "tweetId" : "1364093101942398976",
      "fullText" : "You’re unable to view this Post because this account owner limits who can view their Posts. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1364093101942398976"
    }
  },
  {
    "like" : {
      "tweetId" : "1364036200508448768",
      "expandedUrl" : "https://twitter.com/i/web/status/1364036200508448768"
    }
  },
  {
    "like" : {
      "tweetId" : "1363850997634850818",
      "fullText" : "Day 3 ✅ https://t.co/eTLZmjnOFV",
      "expandedUrl" : "https://twitter.com/i/web/status/1363850997634850818"
    }
  },
  {
    "like" : {
      "tweetId" : "1323200769299013632",
      "fullText" : "thanks for the suggestion https://t.co/MK6qJOqd3q",
      "expandedUrl" : "https://twitter.com/i/web/status/1323200769299013632"
    }
  },
  {
    "like" : {
      "tweetId" : "1363764138212737024",
      "fullText" : "Ah, it is a strange feeling picking up a project again after a year(ish), I had the feeling that something needed work but now I am not sure. Was Past Paul correct and Future Paul able to solve this problem...or is it just the effect of Monday morning.",
      "expandedUrl" : "https://twitter.com/i/web/status/1363764138212737024"
    }
  },
  {
    "like" : {
      "tweetId" : "1362773736298934283",
      "fullText" : "@ZigaMalek Good whiskers always make boxplots more attractive to cats.",
      "expandedUrl" : "https://twitter.com/i/web/status/1362773736298934283"
    }
  },
  {
    "like" : {
      "tweetId" : "1362758997284163585",
      "fullText" : "Dear philosophers of science, for some much needed variation, you can now replace 'black swan' with 'yellow penguin'. You are welcome. https://t.co/jyuxCFPYSC",
      "expandedUrl" : "https://twitter.com/i/web/status/1362758997284163585"
    }
  },
  {
    "like" : {
      "tweetId" : "1362687568463212545",
      "fullText" : "We prefer not to use questionnaires (alone) for presence. What I really prefer is an analogy based on colour science. Perceptions of colour are quantified, but there is no questionnaire like \"How red is this?\" It is all based on comparisons. See eg https://t.co/edFssU4eh7 https://t.co/tgemwbYJqq",
      "expandedUrl" : "https://twitter.com/i/web/status/1362687568463212545"
    }
  },
  {
    "like" : {
      "tweetId" : "1362416735962415110",
      "fullText" : "Mijn vriend stormt net de kamer binnen terwijl ik een college over aarzelingen (\"uh\") voorbereid. Hij kijkt vertwijfeld rond en zegt: \"oh, huh? Ik hoorde een mannenstem hele rare geluiden maken 🤔 Iets van: uh uh uh...\" Nu twijfel ik of het wel geschikt is 😆 #phdlife https://t.co/IpHYMgLXRX",
      "expandedUrl" : "https://twitter.com/i/web/status/1362416735962415110"
    }
  },
  {
    "like" : {
      "tweetId" : "1362485924605661186",
      "expandedUrl" : "https://twitter.com/i/web/status/1362485924605661186"
    }
  },
  {
    "like" : {
      "tweetId" : "1362492988853747716",
      "fullText" : "@JantsjeMol As tweets go, its pretty up there!",
      "expandedUrl" : "https://twitter.com/i/web/status/1362492988853747716"
    }
  },
  {
    "like" : {
      "tweetId" : "1362493196291485699",
      "fullText" : "@JantsjeMol Woohooooo!!!!!!!!!!! https://t.co/VL79uOnYFh",
      "expandedUrl" : "https://twitter.com/i/web/status/1362493196291485699"
    }
  },
  {
    "like" : {
      "tweetId" : "1362493081283678210",
      "fullText" : "@JantsjeMol @FialaLenka let's be honest. Everything calls for more cheesecake.",
      "expandedUrl" : "https://twitter.com/i/web/status/1362493081283678210"
    }
  },
  {
    "like" : {
      "tweetId" : "1362481262036975621",
      "fullText" : "@JantsjeMol There you go then ;) just dm",
      "expandedUrl" : "https://twitter.com/i/web/status/1362481262036975621"
    }
  },
  {
    "like" : {
      "tweetId" : "1362358635305852932",
      "fullText" : "🚨Please spread the word🚨\n\nCan you predict the effectiveness of #nudge interventions?🤔\n\nWe (incl. @MicheleJGelfand, Anna Dreber et al.) are launching a 𝐍𝐮𝐝𝐠𝐞 𝐅𝐨𝐫𝐞𝐜𝐚𝐬𝐭𝐢𝐧𝐠 𝐒𝐭𝐮𝐝𝐲.\n\nIt takes 20mins &amp; you can earn💰💸\n\nStudy: https://t.co/rDDO9zroYh\n#EconTwitter https://t.co/mjrXiIdIyH",
      "expandedUrl" : "https://twitter.com/i/web/status/1362358635305852932"
    }
  },
  {
    "like" : {
      "tweetId" : "1362065720310431746",
      "fullText" : "WANTED: Testers for the new #statcheck Word add-in! Check your stats while you're typing up your manuscript.\n\nSee the instructions below to try out the beta version and let @willemsleegers &amp; me know what you think! \n\n🤓🖥️✍️🔢🤖✅\n\nhttps://t.co/oPA9CJ8apm https://t.co/MxGTFkSjpE",
      "expandedUrl" : "https://twitter.com/i/web/status/1362065720310431746"
    }
  },
  {
    "like" : {
      "tweetId" : "1361975976637440000",
      "fullText" : "Now, I want an alpaca to help with my stats. https://t.co/RnxOQKjOHh",
      "expandedUrl" : "https://twitter.com/i/web/status/1361975976637440000"
    }
  },
  {
    "like" : {
      "tweetId" : "1361674954425708547",
      "fullText" : "This is more or less the distance of the west coast of the Netherlands, which I will follow. I don't know if I will make it, but I think I trained enough to have a fair chance of finishing. I consider doing a fund raiser, but I found it too expensive and too much of a hassle. https://t.co/xg97CR5YZx",
      "expandedUrl" : "https://twitter.com/i/web/status/1361674954425708547"
    }
  },
  {
    "like" : {
      "tweetId" : "1361668641826209794",
      "fullText" : "New fun family activity for lockdown: Teaching my brother Stata\n\nFirst lessons, i) use do-files ii) help iii) regressions\nNext up, introducing Nick Cox! https://t.co/nvZA1HaYa1",
      "expandedUrl" : "https://twitter.com/i/web/status/1361668641826209794"
    }
  },
  {
    "like" : {
      "tweetId" : "1361612042059321346",
      "fullText" : "Interested in #BehavioralEthics?\nCheck out this brand new page of the Behavioral Ethics Lab led by @Shaul_Shalvi in Amsterdam (@UvA_Amsterdam)\nhttps://t.co/5uMUutQe9L",
      "expandedUrl" : "https://twitter.com/i/web/status/1361612042059321346"
    }
  },
  {
    "like" : {
      "tweetId" : "1361635333801209858",
      "fullText" : "Prima fotoredactie. https://t.co/pCGRaJEbRP",
      "expandedUrl" : "https://twitter.com/i/web/status/1361635333801209858"
    }
  },
  {
    "like" : {
      "tweetId" : "1361214451853242369",
      "fullText" : "The Nuffield College Centre for Experimental Social Sciences @NuffieldCESS just released an oTree add-on that allows the experimenter to chat with their participants live during the experiment and it looks amazing! Great job 👏👏👏\n\nCode available here: https://t.co/dB5n5t93PB https://t.co/0q9z5o0PYK",
      "expandedUrl" : "https://twitter.com/i/web/status/1361214451853242369"
    }
  },
  {
    "like" : {
      "tweetId" : "1361545021980217345",
      "fullText" : "A new series to introduce the autocorrelation function (ACF) w/ time series data, with special thanks to @robjhyndman for feedback &amp; suggestions! 👾\n\n🧵1/9: Meet the monster family. The youngest generation is on the right (that's our host). https://t.co/9iBtV88KfU",
      "expandedUrl" : "https://twitter.com/i/web/status/1361545021980217345"
    }
  },
  {
    "like" : {
      "tweetId" : "1361352009987874817",
      "fullText" : "Me, trying to give a lecture in my native language — which I use maybe once a week — on a subject for which I only know the terminology in English.\n\n#PhDchat @OpenAcademics https://t.co/31PRxc9jux",
      "expandedUrl" : "https://twitter.com/i/web/status/1361352009987874817"
    }
  },
  {
    "like" : {
      "tweetId" : "1361319518409281542",
      "fullText" : "💥Paper submitted💥Its been a real endurance effort &amp; quite typical of some common academic challenges: 8 yrs since fieldwork, 4 affiliations, 3 rejections (after review). Im moving to institute #5 soon but hope that at least the paper will have found its final home in journal #4",
      "expandedUrl" : "https://twitter.com/i/web/status/1361319518409281542"
    }
  },
  {
    "like" : {
      "tweetId" : "1360236129639882755",
      "fullText" : "It's official: I was granted tenure today at Maastricht University @MaastrichtU @umsbe. 🥳",
      "expandedUrl" : "https://twitter.com/i/web/status/1360236129639882755"
    }
  },
  {
    "like" : {
      "tweetId" : "1359959831248068614",
      "fullText" : "Gotta start that behavioral science training early.\n\nWhat would Reviewer #2 say?\n#EconTwitter https://t.co/v3STJfZiiO",
      "expandedUrl" : "https://twitter.com/i/web/status/1359959831248068614"
    }
  },
  {
    "like" : {
      "tweetId" : "1359340820164448258",
      "fullText" : "I sometimes still think about the student in my first ever game theory course who wrote “I leave this proof as an exercise to the reader” ON HIS PROBLEM SET.",
      "expandedUrl" : "https://twitter.com/i/web/status/1359340820164448258"
    }
  },
  {
    "like" : {
      "tweetId" : "1359236801248980993",
      "fullText" : "@JantsjeMol @DrGBuckingham In the meanwhile, you can check this out\nhttps://t.co/n3saipz1AX",
      "expandedUrl" : "https://twitter.com/i/web/status/1359236801248980993"
    }
  },
  {
    "like" : {
      "tweetId" : "1358956405047234561",
      "fullText" : "This is Grendel. He was wondering if you’d like a strawberry. He has extras so it’s really no pawblem. 13/10 berry nice of him https://t.co/rh0EvP0u28",
      "expandedUrl" : "https://twitter.com/i/web/status/1358956405047234561"
    }
  },
  {
    "like" : {
      "tweetId" : "1358808868629975042",
      "fullText" : "For the first time in history Leiden University has a female Rector Magnificus! Hester Bijl accepted the chain of office. #dies21 https://t.co/WriWLzZfdQ",
      "expandedUrl" : "https://twitter.com/i/web/status/1358808868629975042"
    }
  },
  {
    "like" : {
      "tweetId" : "1359045052459323392",
      "fullText" : "What happens when you put together a Cultural Anthropologist and an Environmental Geographer, asked no-one ever. But it happened anyway, and me and \n@Vincent_walstra wrote a blog about it: an #interdisciplinary dialogue about Governing the commons @TERRANOVA4EU https://t.co/xVLELuPxU3",
      "expandedUrl" : "https://twitter.com/i/web/status/1359045052459323392"
    }
  },
  {
    "like" : {
      "tweetId" : "1358878052009336832",
      "fullText" : "Does Eye-Tracking Have an Effect on Economic Behavior? https://t.co/8QgriPt1eW \n\"[...] experiments may incorporate eye-tracking equipment without inducing changes in the economic behavior of participants, particularly after observations with low eye-tracking quality are removed.\"",
      "expandedUrl" : "https://twitter.com/i/web/status/1358878052009336832"
    }
  },
  {
    "like" : {
      "tweetId" : "1358435500315598850",
      "fullText" : "*submits several postdoc applications* #academicchatter #academictwitter #phdchat #phdvoice #phdfriend @OpenAcademics https://t.co/qJvPJpEOJi",
      "expandedUrl" : "https://twitter.com/i/web/status/1358435500315598850"
    }
  },
  {
    "like" : {
      "tweetId" : "1358374950638346240",
      "fullText" : "https://t.co/nGwlrVN9xq",
      "expandedUrl" : "https://twitter.com/i/web/status/1358374950638346240"
    }
  },
  {
    "like" : {
      "tweetId" : "1358364031959056385",
      "fullText" : "Did this extreme-weather geek go out with tapeline to measure the height of various snow dunes in our street? Well sure I did😎, and the winner was this one with a spectacular height of 67 cm! ☃️ https://t.co/0RUfaQ6l4b",
      "expandedUrl" : "https://twitter.com/i/web/status/1358364031959056385"
    }
  },
  {
    "like" : {
      "tweetId" : "1585178736424386560",
      "fullText" : "9/ Ik ben nu dus weer positief over de toekomst, ook al gaat beter worden nog wel wat tijd kosten. Maar met hulp van @Ipie33, vrienden, en professionele hulp uiteraard, heb ik er alle vertrouwen in.\n\nPS: Even achter een slotje uit zelfbescherming.",
      "expandedUrl" : "https://twitter.com/i/web/status/1585178736424386560"
    }
  },
  {
    "like" : {
      "tweetId" : "1584995993925189632",
      "fullText" : "The importance of a good opening sentence https://t.co/yXWvC8pKmZ",
      "expandedUrl" : "https://twitter.com/i/web/status/1584995993925189632"
    }
  },
  {
    "like" : {
      "tweetId" : "1584914434744623112",
      "fullText" : "Mr. Cat himself is sending you good vibes on this rainy afternoon🥰\n\n#cats #catsoftwitter #catsontwitter #academicswithcats https://t.co/W5po0wJ69p",
      "expandedUrl" : "https://twitter.com/i/web/status/1584914434744623112"
    }
  },
  {
    "like" : {
      "tweetId" : "1584568398574678016",
      "fullText" : "New favorite comment from my student evaluations:\n\n“He seemed knowledgable and was not afraid to admit when he did not know anything.” ✨\n\nI guess I’ve become Socrates.",
      "expandedUrl" : "https://twitter.com/i/web/status/1584568398574678016"
    }
  },
  {
    "like" : {
      "tweetId" : "1584600632992104448",
      "fullText" : "In Dublin to present research on labeling in the lab at @ESRIDublin and at the Behavioural Science and Sustainable Food Consumption organised by @EconPsyPol. You can follow the Workshop on zoom, info here: https://t.co/eJZEycVrdO https://t.co/MOoh6uOxF2",
      "expandedUrl" : "https://twitter.com/i/web/status/1584600632992104448"
    }
  },
  {
    "like" : {
      "tweetId" : "1584524371845971968",
      "fullText" : "Early next year, we will start analysing sludge and administrative burden in Ireland's Climate Action Plan. We will hire a PostDoc to work on this in Dublin for 2 years. Please get in touch if you are interested in this work or the position. Will share more details soon.",
      "expandedUrl" : "https://twitter.com/i/web/status/1584524371845971968"
    }
  },
  {
    "like" : {
      "tweetId" : "1583402107042164736",
      "fullText" : "It was really great to have visited CREED @UvA_Amsterdam. People there were so nice and doing very interesting research.\n\nDankjewel voor je vriendelijkheid. Tot ziens! https://t.co/6eGpJDFm58",
      "expandedUrl" : "https://twitter.com/i/web/status/1583402107042164736"
    }
  },
  {
    "like" : {
      "tweetId" : "1583361999341162496",
      "fullText" : "Good morning from this lovely ginger boy near the university museum🥰🧡\n\n#CatsOnTwitter #catsoftwitter #academicswithcats https://t.co/UqCRxlkF6u",
      "expandedUrl" : "https://twitter.com/i/web/status/1583361999341162496"
    }
  },
  {
    "like" : {
      "tweetId" : "1582802701519589376",
      "fullText" : "Don't assume the audience knows stuff, eg don't say  \"I am sure you all know this\". Currently attending a lecture given to a very diverse audience, topic is interesting but outside my research field, and I am clearly not part of the \"you\", so I'm feeling a bit excluded now🤦‍♀️. https://t.co/zyvHD7sjC9",
      "expandedUrl" : "https://twitter.com/i/web/status/1582802701519589376"
    }
  },
  {
    "like" : {
      "tweetId" : "1582394069300350976",
      "fullText" : "Normaal houd ik me een beetje in met privézaken op Twitter maar deze foto van onze zoveelste terugkeer in Venetië wil ik jullie niet onthouden. https://t.co/4yK12HdtIm",
      "expandedUrl" : "https://twitter.com/i/web/status/1582394069300350976"
    }
  },
  {
    "like" : {
      "tweetId" : "1582021615306493964",
      "fullText" : "You’re unable to view this Post because this account owner limits who can view their Posts. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1582021615306493964"
    }
  },
  {
    "like" : {
      "tweetId" : "1582027748432019456",
      "fullText" : "Do you have an RA position? Call for papers? Conference you’d like the #ExperimentalEcon #EconTwitter community to know about? tag @EcScienceAssoc and we will try and re-tweet your post https://t.co/h3plb6G852",
      "expandedUrl" : "https://twitter.com/i/web/status/1582027748432019456"
    }
  },
  {
    "like" : {
      "tweetId" : "1582220603272343552",
      "fullText" : "Dear All, I will be on the job market! I am a research fellow at @NUSingapore and working on microeconomic theory, public and behavioral economics: https://t.co/cJtN9Ap5hj\nPlease let me know about interesting job postings at your faculty. #econjobmarket #EconTwitter https://t.co/rwaMJ6jqLV",
      "expandedUrl" : "https://twitter.com/i/web/status/1582220603272343552"
    }
  },
  {
    "like" : {
      "tweetId" : "1581989565153570816",
      "fullText" : "I am not sure how many times this will continue to fail to replicate but nice new study in @APA : SCIENCE LITERACY DOES NOT AMPLIFY (POLITICALLY) MOTIVATED REASONING (ON CLIMATE CHANGE)!  \n\nhttps://t.co/fPkJjnvUGs https://t.co/P8c0BBPrz0",
      "expandedUrl" : "https://twitter.com/i/web/status/1581989565153570816"
    }
  },
  {
    "like" : {
      "tweetId" : "1580851904489234433",
      "fullText" : "How to compensate poor and energy-intensive household under ambitious climate policy? Final version of our paper with @Max_Franks_, @mkalkuhl and #Edenhofer published in @JEEM_tweets. Findings are also relevant for the energy crisis! See why👇\nPaper: https://t.co/ElTi1mrxUn https://t.co/Xx4yvNPRyz",
      "expandedUrl" : "https://twitter.com/i/web/status/1580851904489234433"
    }
  },
  {
    "like" : {
      "tweetId" : "1580186967127789568",
      "fullText" : "Including this figure in a paper. Should we go with 2D or 3D? #timegeography\n\nThe figure shows how the frequency of public transport services varies across the day in regions of different income levels. Figure by @joaopbazzo using #rstats #ggplot2 #rayshader https://t.co/nxOM0Nuo1X",
      "expandedUrl" : "https://twitter.com/i/web/status/1580186967127789568"
    }
  },
  {
    "like" : {
      "tweetId" : "1580217780334305282",
      "fullText" : "Amazed by fantastic presentations of the junior faculty from @ECONMunich @ifo_Institut @ifo_Education at Kochel am See. @m_paffenholz @MIwanowsky @VBurdea @D_D_Pace @francisawong @A_Ferey @_andrew_proctor @MoritzDG @CKrolage https://t.co/UtfajSKwFf",
      "expandedUrl" : "https://twitter.com/i/web/status/1580217780334305282"
    }
  },
  {
    "like" : {
      "tweetId" : "1579854897583124483",
      "fullText" : "Proud of this nice afterburner from my PhD, produced with @mc_villeval and @_FabioGaleotti_ while visiting @GATE_LSE https://t.co/jXHD4PADGZ",
      "expandedUrl" : "https://twitter.com/i/web/status/1579854897583124483"
    }
  },
  {
    "like" : {
      "tweetId" : "1579810053825384448",
      "fullText" : "Starting a project on climate data visualization 🌍📈with a student, to investigate ways to improve climate graphs to 1. better convey information and 2. get people to act on it. \n\nInterested in collaborating, or have pointers (an awful graph you'd like to see improve)? DM me!",
      "expandedUrl" : "https://twitter.com/i/web/status/1579810053825384448"
    }
  },
  {
    "like" : {
      "tweetId" : "1579720135568687104",
      "fullText" : "Look, but we really shine at predicting anything else! https://t.co/aBQqgPBH0O",
      "expandedUrl" : "https://twitter.com/i/web/status/1579720135568687104"
    }
  },
  {
    "like" : {
      "tweetId" : "1579803278543818753",
      "expandedUrl" : "https://twitter.com/i/web/status/1579803278543818753"
    }
  },
  {
    "like" : {
      "tweetId" : "1579387517291606016",
      "fullText" : "Today is national #Sustainability day! The @UvA_Amsterdam Green Office is organizing an interactive discussion on the theme. Join us at Amsterdam Business School M-building room M0.02 at 1pm! https://t.co/6M8ZRKCbKJ",
      "expandedUrl" : "https://twitter.com/i/web/status/1579387517291606016"
    }
  },
  {
    "like" : {
      "tweetId" : "1579429275018874882",
      "expandedUrl" : "https://twitter.com/i/web/status/1579429275018874882"
    }
  },
  {
    "like" : {
      "tweetId" : "1579214521004339200",
      "fullText" : "Vandaag tweeënhalf jaar geleden viel voor mij het rouletteballetje in het goede vakje en kreeg ik te horen dat ik toch geen terminale ziekte had. Dan geniet je zo’n mooi weekend als dit toch extra… 🙏🏼",
      "expandedUrl" : "https://twitter.com/i/web/status/1579214521004339200"
    }
  },
  {
    "like" : {
      "tweetId" : "1578066346671226889",
      "fullText" : "Why is the “zebra pad” the only “safe” space to pass? We need more  space for walking, biking, playing and being right?! Reclaiming the streets! 🚲💪 Poetic public art by Lieke van der Meer at the Roetersstraat today at @UvA_Amsterdam @FMG_UvA #art @fietsprofessor @MelanievdHorst https://t.co/oco0xIRmI8",
      "expandedUrl" : "https://twitter.com/i/web/status/1578066346671226889"
    }
  },
  {
    "like" : {
      "tweetId" : "1357674577799831552",
      "fullText" : "[IVMerOfTheWeek] Yesterday, @VUamsterdam international office organized an online gathering to celebrate #ChineseNewYear! We were making dumplings together! What a warm and heartfelt activity for Chinese employees like me who can't go back to the home country for the new year! https://t.co/HL37lv3H54",
      "expandedUrl" : "https://twitter.com/i/web/status/1357674577799831552"
    }
  },
  {
    "like" : {
      "tweetId" : "1357661167871791104",
      "fullText" : "New doctor in the house! We congratulate our colleague Dr. Niels Debonne on successfully defending his PhD dissertation! https://t.co/t3SCTfQY23",
      "expandedUrl" : "https://twitter.com/i/web/status/1357661167871791104"
    }
  },
  {
    "like" : {
      "tweetId" : "1357407127082594306",
      "fullText" : "A study by @mzelst and me (both from @OrgStudies_TiU)  was recently published in Simulation &amp; Gaming. This research is about facilitating serious games.  What is serious gaming and what is the role of facilitators according to our research? 👇",
      "expandedUrl" : "https://twitter.com/i/web/status/1357407127082594306"
    }
  },
  {
    "like" : {
      "tweetId" : "1357620219892621314",
      "fullText" : "A happy personal announcement!😊 https://t.co/pi1a7to0rr",
      "expandedUrl" : "https://twitter.com/i/web/status/1357620219892621314"
    }
  },
  {
    "like" : {
      "tweetId" : "1357599283839664131",
      "fullText" : "Today our colleague Niels Debonne is defending his PhD thesis entitled “New actors and scales of agriculture: a land system science perspective.”\n\nYou can watch his defence live online starting at 11:45 here: https://t.co/SvGRHgvwpO",
      "expandedUrl" : "https://twitter.com/i/web/status/1357599283839664131"
    }
  },
  {
    "like" : {
      "tweetId" : "1356971215097896960",
      "fullText" : "You’re unable to view this Post because this account owner limits who can view their Posts. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1356971215097896960"
    }
  },
  {
    "like" : {
      "tweetId" : "1357299931304894466",
      "fullText" : "THREAD (1/3)\n\nDear all,\n\nThe high-resolution PDF of The @ethicsinbricks 2021 Calendar is sitting on my hard drive doing nothing, while it's already February.\n\n(1/3) https://t.co/wG8fBZQatE",
      "expandedUrl" : "https://twitter.com/i/web/status/1357299931304894466"
    }
  },
  {
    "like" : {
      "tweetId" : "1357012978042871820",
      "fullText" : "I sometimes forget for how long recommender systems have been around. Here's Jeff Bezos in 1999, talking about Amazon's personalized recommendations \"on the internet\" for books and music https://t.co/W8CPXsBpPw",
      "expandedUrl" : "https://twitter.com/i/web/status/1357012978042871820"
    }
  },
  {
    "like" : {
      "tweetId" : "1357013119663542272",
      "fullText" : "Uit! https://t.co/1DRuu5VcDS",
      "expandedUrl" : "https://twitter.com/i/web/status/1357013119663542272"
    }
  },
  {
    "like" : {
      "tweetId" : "1356880901968449538",
      "fullText" : "Ah, my fav. comment - please get the paper checked by a native English speaker. **looks at self, looks at passports from two English speaking countries** Think we are good here until I remember how to spell dyslexic",
      "expandedUrl" : "https://twitter.com/i/web/status/1356880901968449538"
    }
  },
  {
    "like" : {
      "tweetId" : "1356550258449412097",
      "expandedUrl" : "https://twitter.com/i/web/status/1356550258449412097"
    }
  },
  {
    "like" : {
      "tweetId" : "1356519070624006146",
      "fullText" : "“Papa, als je hem niet mag gebruiken, waarom heb je dan een middelvinger?”\nDe vijfjarige voelt de stemming goed aan.",
      "expandedUrl" : "https://twitter.com/i/web/status/1356519070624006146"
    }
  },
  {
    "like" : {
      "tweetId" : "1356264123596738561",
      "fullText" : "How it started                           How it’s going\n\n20 years ago I fell in love with the plants in my Nan's garden. This morning my #PhD thesis corrections were accepted and I became Bethany Nichols, Doctor of #Botany 💚🌿\n\n#PhDchat #AcademicChatter https://t.co/qe1jzR53w0",
      "expandedUrl" : "https://twitter.com/i/web/status/1356264123596738561"
    }
  },
  {
    "like" : {
      "tweetId" : "1356257598127923200",
      "fullText" : "https://t.co/m9j4pZvSRZ",
      "expandedUrl" : "https://twitter.com/i/web/status/1356257598127923200"
    }
  },
  {
    "like" : {
      "tweetId" : "1356208785862361097",
      "fullText" : "@JantsjeMol Like my dad did for me... Good luck!",
      "expandedUrl" : "https://twitter.com/i/web/status/1356208785862361097"
    }
  },
  {
    "like" : {
      "tweetId" : "1356137804317814785",
      "fullText" : "Even though I don't play chess and follow tournaments myself anymore (my bf still does), I am extremely proud that 21-year old Jorden won the Wijk aan Zee supertournament! Not to mention that he won after a tiebreak against Anish Giri, who is also Dutch 🇳🇱 https://t.co/uDveLn6fci",
      "expandedUrl" : "https://twitter.com/i/web/status/1356137804317814785"
    }
  },
  {
    "like" : {
      "tweetId" : "1355931806437093379",
      "fullText" : "Vanmiddag weer een heerlijk stuk gefietst rond Tilburg! Wat een weer! https://t.co/pAF86ochNM",
      "expandedUrl" : "https://twitter.com/i/web/status/1355931806437093379"
    }
  },
  {
    "like" : {
      "tweetId" : "1355908624456044545",
      "fullText" : "Just got this email from my PhD supervisor. 🥺🙌🏼 I want to be this type of supervisor one day @AcademicChatter https://t.co/7raHUINRIR",
      "expandedUrl" : "https://twitter.com/i/web/status/1355908624456044545"
    }
  },
  {
    "like" : {
      "tweetId" : "1355907061725483010",
      "fullText" : "Econ. seminars are known for their \"peculiar\" style, but it seems that some dynamics differ by the speaker's gender.\nFemale presenters are treated differently than their male counterparts. They are asked more questions, which tend to be patronizing or hostile. https://t.co/wy4dySByy6",
      "expandedUrl" : "https://twitter.com/i/web/status/1355907061725483010"
    }
  },
  {
    "like" : {
      "tweetId" : "1355475962343936003",
      "expandedUrl" : "https://twitter.com/i/web/status/1355475962343936003"
    }
  },
  {
    "like" : {
      "tweetId" : "1354975778908213248",
      "fullText" : "#EconTwitter Apologies if this has been asked before, but are there any good resources/courses online for transitioning to R from Stata? I'm want to join in on the R party!",
      "expandedUrl" : "https://twitter.com/i/web/status/1354975778908213248"
    }
  },
  {
    "like" : {
      "tweetId" : "1354818111967399942",
      "fullText" : "Retweeting this ICYMI - next week I'm starting as associate professor at ITU Copenhagen, I moved to 🇩🇰 last week and I'm looking forward to what's next 😊 #AcademicTwitter https://t.co/ltthhAnRf9",
      "expandedUrl" : "https://twitter.com/i/web/status/1354818111967399942"
    }
  },
  {
    "like" : {
      "tweetId" : "1354949905064845320",
      "fullText" : "#econtwitter, I have a story to tell you about misusing a behavioral econ commitment device to make classical threats.  The year is 2011, and I'm running a university debate tournament in Ireland with 180 teams.",
      "expandedUrl" : "https://twitter.com/i/web/status/1354949905064845320"
    }
  },
  {
    "like" : {
      "tweetId" : "1352918266973458434",
      "fullText" : "Dit album sleepte mij (ver na de release) door mijn middelbare school heen. https://t.co/SuCUU9fVIm",
      "expandedUrl" : "https://twitter.com/i/web/status/1352918266973458434"
    }
  },
  {
    "like" : {
      "tweetId" : "1354734485317672968",
      "fullText" : "Alhamdullilah, succesfully defended my dissertation and got the call of the results soon after. Guess I'm finally Dr. Azalia now 😊 #PhDONE\n\n#AcademicTwitter @OpenAcademics @PhdExhausted https://t.co/6RpTTRtVKj",
      "expandedUrl" : "https://twitter.com/i/web/status/1354734485317672968"
    }
  },
  {
    "like" : {
      "tweetId" : "1354710096761249792",
      "fullText" : "Haha, geniaal 😂. Hoe te klinken als een Nederlander die Engels spreekt. Tip: dit kun je dus ook omgekeerd toepassen, om te proberen je Engelse uitspraak te verbeteren 🙃. https://t.co/ARLhRQwDLB",
      "expandedUrl" : "https://twitter.com/i/web/status/1354710096761249792"
    }
  },
  {
    "like" : {
      "tweetId" : "1354748130055626753",
      "fullText" : "I officially declare today to be living-on-the-edge Thursday. Part of this special day consists of pretending warnings don't exist by adding this to my python script:\n\n&gt;import warnings\n&gt;warnings.filterwarnings(\"ignore\")\n\nTime to plan my next living-on-the-edge move🤔 https://t.co/wF7v8bnmMT",
      "expandedUrl" : "https://twitter.com/i/web/status/1354748130055626753"
    }
  },
  {
    "like" : {
      "tweetId" : "1354423460303425541",
      "expandedUrl" : "https://twitter.com/i/web/status/1354423460303425541"
    }
  },
  {
    "like" : {
      "tweetId" : "1354385540859232257",
      "fullText" : "I have chocolate &amp; coffee, time to get some reading done.",
      "expandedUrl" : "https://twitter.com/i/web/status/1354385540859232257"
    }
  },
  {
    "like" : {
      "tweetId" : "1353722280875094016",
      "fullText" : "Crappedy-crap! It worked on the _very first attempt_!! 🤯 That's a first with code changes this big 😮\n\n(well, and then 5 more commits to make some tiny thing with 404 pages work 😅)\n\nSo nice to have my site be so cleaned up, minimal and fast (to build) using just Hugo now ^_^",
      "expandedUrl" : "https://twitter.com/i/web/status/1353722280875094016"
    }
  },
  {
    "like" : {
      "tweetId" : "1353621317682130944",
      "fullText" : "Good morning everyone...except for those who have plastic plants.\n\nI'm definitely in love with the Dutch's favourite plant, My #Pannekoeken (pancake) plant.\n\nYour turn, show me \"1\" add name or nickname.\n\n@OpenAcademics #PileaPeperomioides #urticaceae #ChineseMonkeyPlant https://t.co/kNekcTgtKS",
      "expandedUrl" : "https://twitter.com/i/web/status/1353621317682130944"
    }
  },
  {
    "like" : {
      "tweetId" : "1353609248555618304",
      "fullText" : "\"Don't follow your passion\" is great advice, to which I want to add a few things, relevant for underrepresented minorities being told to follow their passion. https://t.co/b2fmfffd7U",
      "expandedUrl" : "https://twitter.com/i/web/status/1353609248555618304"
    }
  },
  {
    "like" : {
      "tweetId" : "1352526428303204353",
      "fullText" : "2 BIG EVENTS TODAY to wrap up #climate #adaptation week here in #Groningen!! Join Linda Steg 🌟RIGHT NOW 🌟 to learn about the #IPCC and climate #innovation: https://t.co/DhH8WzH8Ji\n@ 13h join @AnneValkengoed for #international #research efforts https://t.co/uuXAQ75tJF https://t.co/2lwqJEThGz",
      "expandedUrl" : "https://twitter.com/i/web/status/1352526428303204353"
    }
  },
  {
    "like" : {
      "tweetId" : "1352535479154069510",
      "fullText" : "The joys of lit review! #AcademicChatter https://t.co/9xLQmrmpws",
      "expandedUrl" : "https://twitter.com/i/web/status/1352535479154069510"
    }
  },
  {
    "like" : {
      "tweetId" : "1352260546872168448",
      "fullText" : "Het plan vandaag was om aan mijn thesis te werken, dat is maar matig gelukt. Kon me niet concentreren. Het valt me elke keer weer tegen hoe veel tijd schrijven kost. Ik vind het schrijven (meestal) wel heel leuk: het helpt je gedachtes te ordenen en tot nieuwe inzichten te komen.",
      "expandedUrl" : "https://twitter.com/i/web/status/1352260546872168448"
    }
  },
  {
    "like" : {
      "tweetId" : "1352218383803179008",
      "fullText" : "@MicheleNuijten @SciReports wow! congratulations!",
      "expandedUrl" : "https://twitter.com/i/web/status/1352218383803179008"
    }
  },
  {
    "like" : {
      "tweetId" : "1352214074222903299",
      "fullText" : "Finally get to share this!!! I won the Dutch Prize for ICT research 2021. I am very happy to receive 50.000 euros for my research, but maybe even more happy to see that my work, which has so often been deemed as \"not computer science\" is seen as both ICT and as valuable! 🎉🎉 https://t.co/NrKGWPTzqK",
      "expandedUrl" : "https://twitter.com/i/web/status/1352214074222903299"
    }
  },
  {
    "like" : {
      "tweetId" : "1352166745704955912",
      "fullText" : "This is it, I have reached the academic Mount Everest: STORM is getting its own special issue 😂\n\n(Mes amis this is \"academic spam\" but this is probably the very first predatory email I've received that actually matches my research topic!) https://t.co/omkAnATVa2",
      "expandedUrl" : "https://twitter.com/i/web/status/1352166745704955912"
    }
  },
  {
    "like" : {
      "tweetId" : "1351998558849949698",
      "fullText" : "Storm op Zee, Stay Safe mannen 👊 https://t.co/GdrL8u2eu1",
      "expandedUrl" : "https://twitter.com/i/web/status/1351998558849949698"
    }
  },
  {
    "like" : {
      "tweetId" : "1351944589045878791",
      "fullText" : "Very excited😊to start as assistant professor in information systems group at @TUeindhoven.  Fellow academics at @AcademicChatter  and @OpenAcademics shower me with your wisdom of do's and don'ts .  \n\n#AcademicTwitter #AcademicChatter #NewJob https://t.co/hk7qcnoFeB",
      "expandedUrl" : "https://twitter.com/i/web/status/1351944589045878791"
    }
  },
  {
    "like" : {
      "tweetId" : "1351919559947665408",
      "fullText" : "Please RT! 🙏\n\nWe are currently conducting a Public Goods Game with farmers in Germany and are asking fellow scientists and experts for their prediction!\n\n#EconTwitter #AgEconTwitter https://t.co/TsJqkxzkFi https://t.co/XYk7xJRLif",
      "expandedUrl" : "https://twitter.com/i/web/status/1351919559947665408"
    }
  },
  {
    "like" : {
      "tweetId" : "1351921884879876099",
      "fullText" : "Thinking about changing my title from Postdoctoral Fellow to Professional Emailer. @OpenAcademics #AcademicChatter #AcademicTwitter",
      "expandedUrl" : "https://twitter.com/i/web/status/1351921884879876099"
    }
  },
  {
    "like" : {
      "tweetId" : "1352018694147334145",
      "fullText" : "When your supervisor tells you he's impressed with your work.\n\n#PhD #phdchat #AcademicTwitter #AcademicChatter https://t.co/p6eyubEJui",
      "expandedUrl" : "https://twitter.com/i/web/status/1352018694147334145"
    }
  },
  {
    "like" : {
      "tweetId" : "1351903720863363073",
      "fullText" : "#EconTwitter We're extremely excited to announce our mini-workshop on #Evolution (in #Economics), with the amazing speakers Pedro Dal Bó, Marco Archetti and Arthur Robson on Feb 4, 4:30-6:30pm CET. If you'd like to attend, please register here: https://t.co/GPZpx2BW4j @ResearchTI https://t.co/pfmgs5mPej",
      "expandedUrl" : "https://twitter.com/i/web/status/1351903720863363073"
    }
  },
  {
    "like" : {
      "tweetId" : "1351869223421804549",
      "expandedUrl" : "https://twitter.com/i/web/status/1351869223421804549"
    }
  },
  {
    "like" : {
      "tweetId" : "1351835400344653824",
      "fullText" : "🔦BEHIND THE DATASET!🔦\n\n#RDNL Dutch Data Prize Winner @Bloemendaal_N talks about her #STORM dataset that has been downloaded almost ✴️3,700✴️times since it was published in the @4TUResearchData repository just a few months ago! \n\nRead Nadia's story👇\nhttps://t.co/lnWfbl3sEu\n\n1/2 https://t.co/FDWrH6VpY5",
      "expandedUrl" : "https://twitter.com/i/web/status/1351835400344653824"
    }
  },
  {
    "like" : {
      "tweetId" : "1351445822882328576",
      "fullText" : "Waiting for the morning coffee to kick in as I have read this paragraph three times, thinking it was new each time.",
      "expandedUrl" : "https://twitter.com/i/web/status/1351445822882328576"
    }
  },
  {
    "like" : {
      "tweetId" : "1351187127346860033",
      "fullText" : "Such a great idea - many online seminar series tend to focus on big names, which I completely understand but can really crowd out junior scholars. This series is inviting early career researchers to film a short 5 minute video on their paper to be played before the talk! https://t.co/D3sUaP08VX",
      "expandedUrl" : "https://twitter.com/i/web/status/1351187127346860033"
    }
  },
  {
    "like" : {
      "tweetId" : "1350099660128612352",
      "fullText" : "[IVMeroftheweek] To end this week in a great way IVM teachers can join a workshop to improve their #onlineteaching, organized by  Roos Haasnoot, @CassantiClara and myself as IVM's Junior lecturers. We focus today on re-using recorded lectures to improve our education @VUamsterdam https://t.co/eARFtjOidI",
      "expandedUrl" : "https://twitter.com/i/web/status/1350099660128612352"
    }
  },
  {
    "like" : {
      "tweetId" : "1350034620818092033",
      "fullText" : "Ik heb vandaag drie uur (voor werktijd n. b.) zitten programmeren, maar ik vertrouw mijn eigen code nog niet 100%. Had de draad al klaar staan, maar uiteindelijk toch niet gedaan. Bij twijfel: niet doen. Ook dat is wetenschap: veel tijd steken in iets wat het daglicht nooit ziet.",
      "expandedUrl" : "https://twitter.com/i/web/status/1350034620818092033"
    }
  },
  {
    "like" : {
      "tweetId" : "1349746141613711361",
      "fullText" : "Hey #EconTwitter, I’m curious to hear about your strategies to reduce bias in teaching evaluations. I have considered discussing the research showing bias against women &amp; minorities in students’ evaluations before asking them to fill out the forms, but worried it might backfire. https://t.co/jGI0pH92Ji",
      "expandedUrl" : "https://twitter.com/i/web/status/1349746141613711361"
    }
  },
  {
    "like" : {
      "tweetId" : "1350014514234863617",
      "fullText" : "A format I've long wanted to do: give readers a map and have them guess the legend (sorry, this one is in Dutch) https://t.co/ngh2iG4Jab",
      "expandedUrl" : "https://twitter.com/i/web/status/1350014514234863617"
    }
  },
  {
    "like" : {
      "tweetId" : "1349857850755989506",
      "fullText" : "2 years ago, against the advice of a couple mentors, I started my postdoc. I'm so grateful I took a leap of faith. Today I'm a stronger researcher, collaborator, &amp; leader. Do other postdocs agree? What impact has your postdoc had? @OpenAcademics #AcademicTwitter #AcademicChatter https://t.co/ZQ7JIuznbm",
      "expandedUrl" : "https://twitter.com/i/web/status/1349857850755989506"
    }
  },
  {
    "like" : {
      "tweetId" : "1349720238837948419",
      "fullText" : "[IVMeroftheweek] To stay healthy and happy when working from home I try to go for a run or walk during my lunchbreak. The days are still short, so I prefer to go outside during the day and work a bit more when it is dark. What do you do to stay healthy? ^Rosa https://t.co/gQ9Tm5VqOQ",
      "expandedUrl" : "https://twitter.com/i/web/status/1349720238837948419"
    }
  },
  {
    "like" : {
      "tweetId" : "1349700766299271173",
      "fullText" : "Increased trust in self-correcting science: \n\nWe got an R&amp;R on a paper reporting mostly null results. We were afraid of an academic uphill battle but the reviewer couldn’t have been more supportive of publishing nulls🥰 those reviewers exist!\n\n#teamnull @JohnHolbein1 #EconTwitter https://t.co/1DEpNUS5LC",
      "expandedUrl" : "https://twitter.com/i/web/status/1349700766299271173"
    }
  },
  {
    "like" : {
      "tweetId" : "1349368080879775746",
      "fullText" : "I do like this idea https://t.co/wfPpQAaZjE",
      "expandedUrl" : "https://twitter.com/i/web/status/1349368080879775746"
    }
  },
  {
    "like" : {
      "tweetId" : "1349007945225428997",
      "fullText" : "Currently very much enjoying 'wasting' the 1/2 hour I have while my partner takes our son for a walk, and which I should be using on my overflowing to-do list, catching up on twitter &amp; news... #procrastination  #wanttobeinformed #metime #academicmom https://t.co/OAtJQraPeV",
      "expandedUrl" : "https://twitter.com/i/web/status/1349007945225428997"
    }
  },
  {
    "like" : {
      "tweetId" : "1348648772738437122",
      "fullText" : "Why study perceptions in conservation? \"Evidence-based conservation needs to embrace a broader perspective and array of methods than evaluations that emerge from the natural science and econometric traditions of examining conservation policies and actions\" https://t.co/MJJPuSMzpy",
      "expandedUrl" : "https://twitter.com/i/web/status/1348648772738437122"
    }
  },
  {
    "like" : {
      "tweetId" : "1348700765024612356",
      "fullText" : "2020 update on my Dutch music landscape poster (four years of @spotify charts). Interesting year with more diversity! Literally the only productive thing I've done during my 3 weeks off lol. Dutchies who want a spare poster print, hmu! https://t.co/oUkJqV5gr5",
      "expandedUrl" : "https://twitter.com/i/web/status/1348700765024612356"
    }
  },
  {
    "like" : {
      "tweetId" : "1348738106481123328",
      "fullText" : "https://t.co/ch7CQhhXIa",
      "expandedUrl" : "https://twitter.com/i/web/status/1348738106481123328"
    }
  },
  {
    "like" : {
      "tweetId" : "1348788043407380485",
      "fullText" : ". @AmandaCook_Econ : go check the timer\n\n(context: there are brownies in the oven)\n\n5-year-old: *runs to kitchen*\n\n...\n\n5-year-old *runs back*: it's going down once every second.",
      "expandedUrl" : "https://twitter.com/i/web/status/1348788043407380485"
    }
  },
  {
    "like" : {
      "tweetId" : "1348622325659394050",
      "fullText" : "Congratulations to our friend, Martin Kocher, the new Minister of labor of Austria! Good luck, Martin!",
      "expandedUrl" : "https://twitter.com/i/web/status/1348622325659394050"
    }
  },
  {
    "like" : {
      "tweetId" : "1348630256899518464",
      "fullText" : "The TCSS is particularly useful for local-scale risk communication, demonstrated using Hurricane Harvey: Harvey's high precipitation totals are the main driver of the higher categorizations over the Houston/Port Arthur area, regions with lower categorizations using the SSHWS. https://t.co/V32mCkpVHw",
      "expandedUrl" : "https://twitter.com/i/web/status/1348630256899518464"
    }
  },
  {
    "like" : {
      "tweetId" : "1348630252990427139",
      "fullText" : "We designed a discrete classification scale using the three main hazard components wind, storm surge, and rainfall and demonstrate that historical high-impact hurricanes are now better categorized than using the traditional Saffir-Simpson Hurricane Wind Scale https://t.co/CIe42HhLOV",
      "expandedUrl" : "https://twitter.com/i/web/status/1348630252990427139"
    }
  },
  {
    "like" : {
      "tweetId" : "1348630249379160072",
      "fullText" : "📢 Our paper is out!! \n\n@JantsjeMol @amynpolen @Jennife80870085, Hans de Moel, Priscilla Bosma and myself have written a paper on improving tropical cyclone categorization using the new Tropical Cyclone Severity Scale! \nhttps://t.co/zH4CHCuTmE",
      "expandedUrl" : "https://twitter.com/i/web/status/1348630249379160072"
    }
  },
  {
    "like" : {
      "tweetId" : "1348544978935549952",
      "fullText" : "@Richie_Research My solution: Write software to improve Word for writing scientific papers. I designed #tidystats to make it easier (and safer) to report APA statistics in Word, using a combination of R and an Office add-in. https://t.co/46xSt0Xogx",
      "expandedUrl" : "https://twitter.com/i/web/status/1348544978935549952"
    }
  },
  {
    "like" : {
      "tweetId" : "1348559173424996353",
      "expandedUrl" : "https://twitter.com/i/web/status/1348559173424996353"
    }
  },
  {
    "like" : {
      "tweetId" : "1347112852130312193",
      "fullText" : "The little joys in academia:\n\nJust saw that the first (ever) paper I've reviewed is now published. Even though I haven't published anything yet myself, I'm glad to see that I can contribute a scientific debate by reviewing other peoples work 💪\n\n#AcademicChatter",
      "expandedUrl" : "https://twitter.com/i/web/status/1347112852130312193"
    }
  },
  {
    "like" : {
      "tweetId" : "1347165228648300545",
      "expandedUrl" : "https://twitter.com/i/web/status/1347165228648300545"
    }
  },
  {
    "like" : {
      "tweetId" : "1346124952395788289",
      "fullText" : "Why is it that I've received an abnormal amount of negative feedback on the article I wrote regarding \"the #PhD Blues\" in which I outline how to deal with feelings of #depression, not being good enough, #impostersyndrome &amp; how to be honest with yourself and your supervisor?!  1/n https://t.co/DYtpdCuPdN",
      "expandedUrl" : "https://twitter.com/i/web/status/1346124952395788289"
    }
  },
  {
    "like" : {
      "tweetId" : "1346839657397575680",
      "fullText" : "Another review of Williams's _The Liar's Dictionary_, if you're following along:\n\nhttps://t.co/nA6dXK2pKB",
      "expandedUrl" : "https://twitter.com/i/web/status/1346839657397575680"
    }
  },
  {
    "like" : {
      "tweetId" : "1346378419769135104",
      "fullText" : "@IleenStreefkerk [IVMerOfTheWeek] The first phase of a PhD is proposal writing. Before the holiday I handed in my literature review. Although it can be confronting to see the coloured text returning, this is the way to learn from the experts @AnneVanLoon @JeroenAerts4 and Toon Haer #supervisors https://t.co/wS33eHODMc",
      "expandedUrl" : "https://twitter.com/i/web/status/1346378419769135104"
    }
  },
  {
    "like" : {
      "tweetId" : "1341752544285093891",
      "fullText" : "One of the good things of this peculiar year was that I had more time than usual to read literature. “What I loved”is one of the best novels I’ve read so far. Such an exquisite writing by the unique Siri Hustvedt 🖤 ✍🏽 https://t.co/rlAdsh1vhI",
      "expandedUrl" : "https://twitter.com/i/web/status/1341752544285093891"
    }
  },
  {
    "like" : {
      "tweetId" : "1341686999049187328",
      "fullText" : "👇 #HarryPotter https://t.co/aEVRHFLFpQ",
      "expandedUrl" : "https://twitter.com/i/web/status/1341686999049187328"
    }
  },
  {
    "like" : {
      "tweetId" : "1341696378414764034",
      "fullText" : "Happy to share the link to our #openaccess paper “When do the expectations of others matters?” joint with @ploteo just published on Theory and Decision https://t.co/jRRDcIMWBD\n #experiments #EconTwitter #psychologicalgames https://t.co/ADjqpd6nkg",
      "expandedUrl" : "https://twitter.com/i/web/status/1341696378414764034"
    }
  },
  {
    "like" : {
      "tweetId" : "1341414822764834816",
      "fullText" : "“I’ll just run this last robustness check and then the paper will be finished...” https://t.co/a5wMWjZAuh",
      "expandedUrl" : "https://twitter.com/i/web/status/1341414822764834816"
    }
  },
  {
    "like" : {
      "tweetId" : "1341421465586044932",
      "fullText" : "New binder clips. Sometimes it’s the little things...\n\n#AcademicTwitter https://t.co/l7RjIhljnd",
      "expandedUrl" : "https://twitter.com/i/web/status/1341421465586044932"
    }
  },
  {
    "like" : {
      "tweetId" : "1341375218430971906",
      "fullText" : "@JantsjeMol @VU_IVM Good luck! And what are you up too next?",
      "expandedUrl" : "https://twitter.com/i/web/status/1341375218430971906"
    }
  },
  {
    "like" : {
      "tweetId" : "1341404743663554563",
      "fullText" : "@JantsjeMol @VU_IVM 💪",
      "expandedUrl" : "https://twitter.com/i/web/status/1341404743663554563"
    }
  },
  {
    "like" : {
      "tweetId" : "1341344188940607488",
      "fullText" : "@Rhian14800441 @JantsjeMol https://t.co/aBuSNTN2XV",
      "expandedUrl" : "https://twitter.com/i/web/status/1341344188940607488"
    }
  },
  {
    "like" : {
      "tweetId" : "1341328693633925122",
      "fullText" : "They will become our future leaders in #sustainability which in my opinion will have a bigger societal impact than the papers we publish... Let's not forget, that our primary role at universities is still to educate!",
      "expandedUrl" : "https://twitter.com/i/web/status/1341328693633925122"
    }
  },
  {
    "like" : {
      "tweetId" : "1341328681982185472",
      "fullText" : "I am now officially a teacher @VUamsterdam!Obtaining the University Teaching Qualification (Basiskvalificatie Onderwijs) was quite an effort,particularly in these times.I am positive that I am a better teacher now, and I cannot wait to get back to the lecture room #zoomfatigue https://t.co/A8BoXnSxkf",
      "expandedUrl" : "https://twitter.com/i/web/status/1341328681982185472"
    }
  },
  {
    "like" : {
      "tweetId" : "1341003017500446721",
      "fullText" : "@ConnieEClare I have a genius idea: can we add a \"playlist\" -section in the @4TUResearchData metadata section of a dataset so that users of the data can listen to the music that helped create the data? 😉 Or perhaps some music to help end-users get \"in the dataset-mood\"?",
      "expandedUrl" : "https://twitter.com/i/web/status/1341003017500446721"
    }
  },
  {
    "like" : {
      "tweetId" : "1339191661163843585",
      "fullText" : "Who uses the possibility of longer parental leave? Short answer: Mothers! \n\nBut why is that? \nIn this working paper, I show that gender norms rather than standard economic incentives explain how couples decide who spends time on child-rearing. [1/8]\nLink: https://t.co/PJOQlnl2GJ https://t.co/vQnR08cIpG",
      "expandedUrl" : "https://twitter.com/i/web/status/1339191661163843585"
    }
  },
  {
    "like" : {
      "tweetId" : "1340962271363776513",
      "fullText" : "During the March lockdown, I had to abruptly shift time trade-off data collection from personal interviews to video-interviews with Zoom. As little or no guidance existed, I made it up as I went. I wrote this paper to help others facing similar challenges https://t.co/sm7Y66xOO1",
      "expandedUrl" : "https://twitter.com/i/web/status/1340962271363776513"
    }
  },
  {
    "like" : {
      "tweetId" : "1338719691905277954",
      "fullText" : "Manuscript under review for 7 months: rejected 😔\n\nBUT helpful comments from editor 👌\n\nToday: resubmitted 🙂\n\nAnyone else on this publication rollercoaster w me? \n\n#phdlife #phdchat @AcademicChatter #academictwitter https://t.co/rW48NVuymc",
      "expandedUrl" : "https://twitter.com/i/web/status/1338719691905277954"
    }
  },
  {
    "like" : {
      "tweetId" : "1339321084353662979",
      "fullText" : "Any free time from 4 till 5AM??? I'll be here, drinking tea and talking about \"Causal interactions between tropics and mid-latitudes in reanalysis data and S2S forecasts \" #AGU20 https://t.co/ckIlcBPFjt",
      "expandedUrl" : "https://twitter.com/i/web/status/1339321084353662979"
    }
  },
  {
    "like" : {
      "tweetId" : "1339210674795372548",
      "fullText" : "Grrreeeeaaattt news! 🎉 https://t.co/3S2Cwe2myP",
      "expandedUrl" : "https://twitter.com/i/web/status/1339210674795372548"
    }
  },
  {
    "like" : {
      "tweetId" : "1339162881900892161",
      "fullText" : "@JantsjeMol @JuliaBlasch @VU_IVM Congratulations Jantsje!",
      "expandedUrl" : "https://twitter.com/i/web/status/1339162881900892161"
    }
  },
  {
    "like" : {
      "tweetId" : "1339148701722349568",
      "fullText" : "Nachtmerries, dagdromen en onvervulde wensen: in de rubriek ’13 vragen aan’ laten studenten en wetenschappers zichzelf van een andere kant zien. Deze keer: meta-onderzoeker Michèle Nuijten, winnaar van een Veni-beurs #TilburgU @MicheleNuijten https://t.co/5aZni8M1El",
      "expandedUrl" : "https://twitter.com/i/web/status/1339148701722349568"
    }
  },
  {
    "like" : {
      "tweetId" : "1338504090226216976",
      "fullText" : "[IVMerOfTheWeek] This is how most of you have been seeing me lately through ZOOM and Skype, in my #homeoffice. https://t.co/A0dcJ5qszs",
      "expandedUrl" : "https://twitter.com/i/web/status/1338504090226216976"
    }
  },
  {
    "like" : {
      "tweetId" : "1339148240462163969",
      "fullText" : "In this article with colleagues of @CREA_Ricerca, we find that the valuation of #precisionfarming technology features is positively influenced by knowledge of fellow farmers who adopted the technology #sustainableagriculture #socialnetworks @Fatima_H2020 https://t.co/HgcdXN4ygZ",
      "expandedUrl" : "https://twitter.com/i/web/status/1339148240462163969"
    }
  },
  {
    "like" : {
      "tweetId" : "1338435521530490883",
      "fullText" : "Sarah Wolff is defending her thesis: Mapping ecosystem services demand and its influence on land use change across space and time: Conceptual and methodological contributions. Follow it live, right now: https://t.co/5c4HfGg4Bb https://t.co/gVS1xir6Xk",
      "expandedUrl" : "https://twitter.com/i/web/status/1338435521530490883"
    }
  },
  {
    "like" : {
      "tweetId" : "1338473818180956161",
      "fullText" : "#EconTwitter question for the dog owner academics: how unprofessional would it be to use a picture with my pup on my research website?\n\n@KirbyKNielsen can we please coordinate and you do the same with your cats? 😅 @Andrew___Baker join us with your 🐶 https://t.co/bZdrtwAvuW",
      "expandedUrl" : "https://twitter.com/i/web/status/1338473818180956161"
    }
  },
  {
    "like" : {
      "tweetId" : "1338299884605157377",
      "fullText" : "Know the difference. RT @_stevewills https://t.co/UnuhQreD7o",
      "expandedUrl" : "https://twitter.com/i/web/status/1338299884605157377"
    }
  },
  {
    "like" : {
      "tweetId" : "1337443838479257603",
      "fullText" : "Shout out to #SJDM2020 organizers for running such a great virtual conference! I have a poster today from 2:30-4:30 (Eastern Time) so check it out below and come join my zoom if you want to chat about it! https://t.co/ws64F9cToc",
      "expandedUrl" : "https://twitter.com/i/web/status/1337443838479257603"
    }
  },
  {
    "like" : {
      "tweetId" : "1337476370834857986",
      "fullText" : "I'm as tired of Zoom as everyone else but it is allowing me to spend time with lots of really smart, fascinating people these days and I love that so much.",
      "expandedUrl" : "https://twitter.com/i/web/status/1337476370834857986"
    }
  },
  {
    "like" : {
      "tweetId" : "1336420151391039489",
      "fullText" : "Behavioral scientists needed! We (@NandiniOomman @advncdhindsight @Arush_Lal @rohinirajgopal) agree! #COVID19 response depends on \"ability to deploy right balance of medical, behavioral &amp; structural interventions.\" Great piece @SemaSgaier &amp; @NeelaSaldanha  https://t.co/IoHf5RVvwd",
      "expandedUrl" : "https://twitter.com/i/web/status/1336420151391039489"
    }
  },
  {
    "like" : {
      "tweetId" : "1337133792746741764",
      "fullText" : "I wrote an R package that allows to make queries to ggplot in natural language. It's like saying \"Alexa, rotate the x-axis labels.\" Here are a few working examples: https://t.co/G05GanmX69 \nHow crazy is this? https://t.co/9YlsAZTpmD",
      "expandedUrl" : "https://twitter.com/i/web/status/1337133792746741764"
    }
  },
  {
    "like" : {
      "tweetId" : "1337365920847712259",
      "fullText" : "Dr. Minou it is 🤩 Trots en dankbaar dat ik gisteren ten overstaan van de (digitale) commissie mijn proefschrift heb mogen verdedigen. Een dag om nooit meer te vergeten 😁 #horaest #phd https://t.co/HqaF1OnG8k",
      "expandedUrl" : "https://twitter.com/i/web/status/1337365920847712259"
    }
  },
  {
    "like" : {
      "tweetId" : "1336958108078379008",
      "fullText" : "Laatste week werk bij @WURmarine is ingegaan. Na 9 jaar ga ik weg bij deze geweldige organisatie waar ik met veel plezier heb gewerkt. Ik maak de overstap naar @WUReconomic. Dichter bij huis (na jaren forensen) en weer een nieuwe interdisciplinaire uitdaging! #antropoloog #zinin https://t.co/i8ZuoXM2Tr",
      "expandedUrl" : "https://twitter.com/i/web/status/1336958108078379008"
    }
  },
  {
    "like" : {
      "tweetId" : "1336664216913276930",
      "fullText" : "Made me think about how I miss econ seminars https://t.co/IVy5DtwJCq",
      "expandedUrl" : "https://twitter.com/i/web/status/1336664216913276930"
    }
  },
  {
    "like" : {
      "tweetId" : "1336915456003813376",
      "fullText" : "It's been two years since I joined Twitter 😱 #MyTwitterAnniversary https://t.co/Y0j9GFgJUm",
      "expandedUrl" : "https://twitter.com/i/web/status/1336915456003813376"
    }
  },
  {
    "like" : {
      "tweetId" : "1336254153534959618",
      "fullText" : "I am the happiest and most grateful DOCTOR! I would never be here without the support of these (and more) amazing people! Thank you to @LHuntNeuro &amp; Tali Sharot for a great discussion and of course, THANK YOU to my brilliant and kind supervisors Matthew Rushworth &amp; @mkwittmann🎓 https://t.co/fQ6UZGPTgU",
      "expandedUrl" : "https://twitter.com/i/web/status/1336254153534959618"
    }
  },
  {
    "like" : {
      "tweetId" : "1336013755268931584",
      "fullText" : "My happy face after presenting at my first international conference! What a great achievement!🎉 This means so much in these times. I hope this will be just my first step in the world of academia 😊🤞🏻 @OpenAcademics @AcademicChatter https://t.co/jwSqECX0Tb",
      "expandedUrl" : "https://twitter.com/i/web/status/1336013755268931584"
    }
  },
  {
    "like" : {
      "tweetId" : "1335997568585752584",
      "fullText" : "My colleague @DimCoumou and I wrote a newspaper article for the Leeuwarder Courant on the record-breaking 2020 hurricane season!\n\n(Sorry to my international twitter friends, but it's in Dutch😅 There are a few English words in the text though!) https://t.co/PXNqUv0IGU",
      "expandedUrl" : "https://twitter.com/i/web/status/1335997568585752584"
    }
  },
  {
    "like" : {
      "tweetId" : "1335765241003712513",
      "fullText" : "Art. Festive decor. Bowl. The future is bright. 10/10 @gitanjaliarao https://t.co/DkHBqN7NXZ",
      "expandedUrl" : "https://twitter.com/i/web/status/1335765241003712513"
    }
  },
  {
    "like" : {
      "tweetId" : "1335541388302282753",
      "fullText" : "Dit👇 https://t.co/u4rWMB3MYo",
      "expandedUrl" : "https://twitter.com/i/web/status/1335541388302282753"
    }
  },
  {
    "like" : {
      "tweetId" : "1334832074142982152",
      "fullText" : "Very pleased to announce a new review paper is published on how to include human behavior and decision making in Coastal- &amp; hydrological models. I particularly discuss the use of agent based models. https://t.co/Y9RsMKOAMr",
      "expandedUrl" : "https://twitter.com/i/web/status/1334832074142982152"
    }
  },
  {
    "like" : {
      "tweetId" : "1334465732206354438",
      "fullText" : "Proud of our mangrove forest Island♥️ Thanks @PhilipWard_ @Marleen_Ruiter and @anaiscouasnon for this fun game!!\n\n(Ps: @GabrielaGNobre for president!) https://t.co/WqmCjX3Viu",
      "expandedUrl" : "https://twitter.com/i/web/status/1334465732206354438"
    }
  },
  {
    "like" : {
      "tweetId" : "1334444811923955715",
      "fullText" : "In other news: I've been granted tenure and promoted to associate professor @TiUEconomics. I'm so grateful to all those advisers, colleagues, editors, referees, students, and everyone else along the way who made this possible. Thanks to all of you!",
      "expandedUrl" : "https://twitter.com/i/web/status/1334444811923955715"
    }
  },
  {
    "like" : {
      "tweetId" : "1334086980871872512",
      "fullText" : "My job market paper on face masks in the job market seminar of the @EcScienceAssoc https://t.co/JHViZw8rK7 #econjobmarket #covid19research #coronaforschung",
      "expandedUrl" : "https://twitter.com/i/web/status/1334086980871872512"
    }
  },
  {
    "like" : {
      "tweetId" : "1333496906945875968",
      "fullText" : "Het is een beetje jammer dat er een pandemie voor nodig was, maar ondertussen heb ik toch ook ontzettend veel waardevolle lessen geleerd en vooral: hele mooie mensen (digitaal) ontmoet en leren kennen :) #CoronaLichtpuntjes",
      "expandedUrl" : "https://twitter.com/i/web/status/1333496906945875968"
    }
  },
  {
    "like" : {
      "tweetId" : "1333380320251482112",
      "fullText" : "@alainstarke @WUR @E_VanLoo Congratulations! As a colleague who went to Wageningen once said, you get to publish more in nature 😅",
      "expandedUrl" : "https://twitter.com/i/web/status/1333380320251482112"
    }
  },
  {
    "like" : {
      "tweetId" : "1333377290537984000",
      "fullText" : "It's beginning to look a lot like December. \n\nAnd that means, as of tomorrow, I'll join the Marketing and Consumer Behavior Group @WUR as a postdoc! \nI'll work with @E_VanLoo and others on Consumer adoption of personalised dietary advice. \n\nStay tuned for more updates 😊. https://t.co/d0MEVMrCEh",
      "expandedUrl" : "https://twitter.com/i/web/status/1333377290537984000"
    }
  },
  {
    "like" : {
      "tweetId" : "1333379994672918528",
      "expandedUrl" : "https://twitter.com/i/web/status/1333379994672918528"
    }
  },
  {
    "like" : {
      "tweetId" : "1331559895515140096",
      "fullText" : "Finally I can share this wonderful news: I've been awarded an @ERC_Research Starting Grant for my project PerfectSTORM (STOrylines of futuRe extreMes)! 5 researchers at @VU_IVM will study socio-hydrological processes behind drought-to-flood events. https://t.co/XM9kCA1dzP #ERCStG https://t.co/g6Xw4iOcTa",
      "expandedUrl" : "https://twitter.com/i/web/status/1331559895515140096"
    }
  },
  {
    "like" : {
      "tweetId" : "1331590185906278402",
      "fullText" : "BEEC es la conferencia más importante de Economía Experimental se America Latina, con invitados internacionales de primera.  El Workshop asociado le ha dado herramientas teóricas y analíticas a muchos estudiantes y profesores. https://t.co/a63HeyOard",
      "expandedUrl" : "https://twitter.com/i/web/status/1331590185906278402"
    }
  },
  {
    "like" : {
      "tweetId" : "1331606252179386368",
      "fullText" : "I guess I do help them by finding bugs, like how you can crash Mathematica by raising an emoji to an emoji power https://t.co/ySLxCoTM4x",
      "expandedUrl" : "https://twitter.com/i/web/status/1331606252179386368"
    }
  },
  {
    "like" : {
      "tweetId" : "1331220647503142913",
      "fullText" : "The Dutch Royal Library has launched a 'medieval memes'-site where you can make your own memes with their manuscript images: https://t.co/CpSHqU2zYN  Great initiative, @KB_Nederland and @Teszelszky !",
      "expandedUrl" : "https://twitter.com/i/web/status/1331220647503142913"
    }
  },
  {
    "like" : {
      "tweetId" : "1331205510679457793",
      "fullText" : "Wrap up van de Dag van het gedrag door spoken word artist Justin Samgar. Tot volgend jaar: 18 november! We hopen dan Cass Sunstein, auteur van het boek ‘Too much information: Understanding what you don’t want to know’ als keynote spreker te ontvangen. #dvhg20 https://t.co/Yc51o4wSKd",
      "expandedUrl" : "https://twitter.com/i/web/status/1331205510679457793"
    }
  },
  {
    "like" : {
      "tweetId" : "1331167798429626368",
      "fullText" : "\"People don't care how much you know until they know how much you care.\" Mooie quote van Cialdini. Ik vind @ReintJanRenes eigenlijk wel een beetje de Nederlandse Cialdini 🙌🙌 #Dvhg20",
      "expandedUrl" : "https://twitter.com/i/web/status/1331167798429626368"
    }
  },
  {
    "like" : {
      "tweetId" : "1331161747802255367",
      "fullText" : "Waarom wel #informatiehonger bij corona, maar niet bij klimaat? #Dvhg20",
      "expandedUrl" : "https://twitter.com/i/web/status/1331161747802255367"
    }
  },
  {
    "like" : {
      "tweetId" : "1331146030549700608",
      "fullText" : "Zit klaar voor de #dagvanhetgedrag. Benieuwd naar het verhaal van @ReintJanRenes! 🤓",
      "expandedUrl" : "https://twitter.com/i/web/status/1331146030549700608"
    }
  },
  {
    "like" : {
      "tweetId" : "1331158135311052805",
      "fullText" : "Benieuwd naar de ervaringen en bevindingen van @ReintJanRenes bij de Corona gedragsunit #Dvhg20",
      "expandedUrl" : "https://twitter.com/i/web/status/1331158135311052805"
    }
  },
  {
    "like" : {
      "tweetId" : "1331155843950260224",
      "fullText" : "Zojuist gelanceerd tijdens de Dag van het gedrag: de BIN NL-kennisbank: https://t.co/Nvz6uXexBQ. Een doorzoekbaar overzicht van projecten binnen de (rijks)overheid waarbij gedragsinterventies wel of niet werkten. Mis je nog een project? Laat het ons weten! #dvhg20 https://t.co/jsxG08A690",
      "expandedUrl" : "https://twitter.com/i/web/status/1331155843950260224"
    }
  },
  {
    "like" : {
      "tweetId" : "1331156296792477701",
      "fullText" : "BIN NL-voorzitter: 1 dec. lancering prijsvraag Covid Behavioural Challenge. Het doel? Kansrijke en innovatieve ideeën verzamelen voor 3 thema's: 1. Thuisblijven en testen bij klachten; 2. Vaccineren tegen COVID-19; 3. Coronaproof samenwerken en samenleven. https://t.co/FesyiotDrj https://t.co/Z9RhndIEtg",
      "expandedUrl" : "https://twitter.com/i/web/status/1331156296792477701"
    }
  },
  {
    "like" : {
      "tweetId" : "1330923681367945220",
      "fullText" : "Not adding any more things to my to do list for the rest of the semester. \n\nI’ve almost finished what I said I would do. That’s enough!\n\n#MondayMotivation #Professional #ToDo #postdoclife #mathlife #mathtwitter #AcademicTwitter #teachertwitter #teacherlife https://t.co/bwYDF3bdVo",
      "expandedUrl" : "https://twitter.com/i/web/status/1330923681367945220"
    }
  },
  {
    "like" : {
      "tweetId" : "1330536761039220745",
      "fullText" : "I've seen so much discussion/tips about how Stata users can start using R easily, but how come nobody (!) talks about this golden tip? \n\nit just feels like I killed my worst enemy (me.) https://t.co/4OqOGEdr91",
      "expandedUrl" : "https://twitter.com/i/web/status/1330536761039220745"
    }
  },
  {
    "like" : {
      "tweetId" : "1329733787702484994",
      "fullText" : "This is major. MAJOR.\n\nLink: https://t.co/U9MyQph6Oe. https://t.co/707SY4WFRc",
      "expandedUrl" : "https://twitter.com/i/web/status/1329733787702484994"
    }
  },
  {
    "like" : {
      "tweetId" : "1329341770728153088",
      "fullText" : "Klaar voor de verdediging van @CTeunenbroek @geveninnl https://t.co/rTPWuuA2zX",
      "expandedUrl" : "https://twitter.com/i/web/status/1329341770728153088"
    }
  },
  {
    "like" : {
      "tweetId" : "1329016623894847490",
      "fullText" : "We are incredibly proud of our @Bloemendaal_N for winning this award! https://t.co/UXrd6osVF0",
      "expandedUrl" : "https://twitter.com/i/web/status/1329016623894847490"
    }
  },
  {
    "like" : {
      "tweetId" : "1329019423253000192",
      "fullText" : "I'm about to present @LeadAmsterdam (Free University Amsterdam) on the importance of social and behavioral sciences to overcome a global health crisis, using a wicked problem perspective on knowledge creation, based on my experience in the @C19RedTeam. Cool opportunity! 🤓",
      "expandedUrl" : "https://twitter.com/i/web/status/1329019423253000192"
    }
  },
  {
    "like" : {
      "tweetId" : "1328735796342484993",
      "fullText" : "Can you detect a smile under a facemask? Very excited about this new project with @CesarMant . Do the survey  at: https://t.co/2BErtKTK8A #SmileUnderYourMask",
      "expandedUrl" : "https://twitter.com/i/web/status/1328735796342484993"
    }
  },
  {
    "like" : {
      "tweetId" : "1328984527138656262",
      "fullText" : "Zijn gedragseconomische inzichten waarde in economische evaluatie? Ja! \n\nIn mijn promotieonderzoek liet ik zien dat gedragsinzichten van belang zijn in gezondheidswaardering, en daardoor ook voor economische evaluatie. In deze bijdrage in het VGE bulletin leest u daarover meer! https://t.co/sebH9PCTMy",
      "expandedUrl" : "https://twitter.com/i/web/status/1328984527138656262"
    }
  },
  {
    "like" : {
      "tweetId" : "1328656468380413952",
      "fullText" : "Happy to share a blog post I have written based on a recent publication in @Climate_Policy! How to engage people with #climatechange in times of #COVID19, economic distress &amp; rising #populism. https://t.co/9JCeNJw4p3",
      "expandedUrl" : "https://twitter.com/i/web/status/1328656468380413952"
    }
  },
  {
    "like" : {
      "tweetId" : "1328616454267269120",
      "fullText" : "Bedrijven kunnen zich nog aanmelden! https://t.co/83yRRjlFai",
      "expandedUrl" : "https://twitter.com/i/web/status/1328616454267269120"
    }
  },
  {
    "like" : {
      "tweetId" : "1328361905472331777",
      "fullText" : "Eigenlijk zouden we elke dag een halfuurtje moeten chat-rouletten: https://t.co/aM4dFDENGD https://t.co/4qgsEQEH2g",
      "expandedUrl" : "https://twitter.com/i/web/status/1328361905472331777"
    }
  },
  {
    "like" : {
      "tweetId" : "1328344281178894337",
      "fullText" : "Love the antique phones. Jar. Shapes. Art. Great curation. 10/10 @byHeatherLong https://t.co/JV3x25YdOe",
      "expandedUrl" : "https://twitter.com/i/web/status/1328344281178894337"
    }
  },
  {
    "like" : {
      "tweetId" : "1327852215940259840",
      "fullText" : "And if all else fails, we always have this foolproof Twitter strategy from @jodiecongirl \n\nhttps://t.co/R9Gqh6LL0q",
      "expandedUrl" : "https://twitter.com/i/web/status/1327852215940259840"
    }
  },
  {
    "like" : {
      "tweetId" : "1327840330901700608",
      "fullText" : "Are you a young researcher new to Twitter, in particular #EconTwitter ? Here's a short thread of all the tips, guides, help, advice we could find on how to use Twitter to make your life better not worse",
      "expandedUrl" : "https://twitter.com/i/web/status/1327840330901700608"
    }
  },
  {
    "like" : {
      "tweetId" : "1327584276355878912",
      "expandedUrl" : "https://twitter.com/i/web/status/1327584276355878912"
    }
  },
  {
    "like" : {
      "tweetId" : "1327587463402033157",
      "fullText" : "Bloemendaal aan zee in Bloemendaal aan Zee! https://t.co/qloRnetTbt",
      "expandedUrl" : "https://twitter.com/i/web/status/1327587463402033157"
    }
  },
  {
    "like" : {
      "tweetId" : "1326989671159705600",
      "fullText" : "This is my first tweet! My name is Ranthony Edmonds. I am a math PhD working as a postdoc at The Ohio State University. I am an algebraist whose research focuses on questions of factorization in commutative settings. The photo is me after my defense in 2018. #BlackinMathRollCall https://t.co/mNdVf12p45",
      "expandedUrl" : "https://twitter.com/i/web/status/1326989671159705600"
    }
  },
  {
    "like" : {
      "tweetId" : "1327168716061220864",
      "fullText" : "😃My first paper has recently been accepted at the Journal Of Behavioral and Experimental Economics.👇 @LoyolaBehLab @LoyolaEcon @LoyolaResearch https://t.co/JFi4F85kb6",
      "expandedUrl" : "https://twitter.com/i/web/status/1327168716061220864"
    }
  },
  {
    "like" : {
      "tweetId" : "1327267523658739713",
      "fullText" : "As (introverted &amp; female) ECR I challenged myself to speak up &amp; ask more questions, as associate professor I challenge myself to shut up &amp; listen more. Interesting to see how skills you need change with career level &amp; role and learning &amp; adaptation never stop. #AcademicChatter",
      "expandedUrl" : "https://twitter.com/i/web/status/1327267523658739713"
    }
  },
  {
    "like" : {
      "tweetId" : "1327266070055571457",
      "fullText" : "I guess the news is out. Soon I will be (virtually) moving to the US! https://t.co/VJtufjNI5f",
      "expandedUrl" : "https://twitter.com/i/web/status/1327266070055571457"
    }
  },
  {
    "like" : {
      "tweetId" : "1326901882741272576",
      "fullText" : "You’re unable to view this Post because this account owner limits who can view their Posts. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1326901882741272576"
    }
  },
  {
    "like" : {
      "tweetId" : "1326876687708073984",
      "fullText" : "Yaaaay 🍾🎊🤩✨ I handed in my PhD thesis, entitled: ‘How physical cues in micro food environments influence consumption: A social norm account’ \n@WURconsumption #wur #phdchat #foodenvironments #socialnorms https://t.co/1JSOS0G40k",
      "expandedUrl" : "https://twitter.com/i/web/status/1326876687708073984"
    }
  },
  {
    "like" : {
      "tweetId" : "1326150839002664960",
      "fullText" : "My PhD student and I are looking for collaborators for a multi-lab multi-study project exploring the validity of statistics anxiety and maths anxiety. Will need to be able to collect samples (non-WEIRD especially welcome) of N &gt; 300 students in 2021. DM @jennyterry if interested.",
      "expandedUrl" : "https://twitter.com/i/web/status/1326150839002664960"
    }
  },
  {
    "like" : {
      "tweetId" : "1326126549863690240",
      "fullText" : "De mogelijkheden van de nieuwe kaartviewer, Atlas van de Regio, zijn ongekend! Ontdek ze zelf via https://t.co/BX2Lvz6O4B\n#verslavingsalert https://t.co/1Qpf1jgr55",
      "expandedUrl" : "https://twitter.com/i/web/status/1326126549863690240"
    }
  },
  {
    "like" : {
      "tweetId" : "1326106675087073285",
      "fullText" : "Our newest work on STORM is published in @ScientificData! In this paper, we calculate global-scale tropical cyclone wind speed probabilities up to the 1-in-10000 year return period. 1/n \n\n@ivanhaigh @VU_IVM @VU_Science \n\nhttps://t.co/KkajdUaiWu",
      "expandedUrl" : "https://twitter.com/i/web/status/1326106675087073285"
    }
  },
  {
    "like" : {
      "tweetId" : "1196567387216199681",
      "fullText" : "Ever wondered how to create a beautiful streetmap in ggplot2? Here is how: https://t.co/7Om5iEPMQe\n\n#rstats, #ggplot2 https://t.co/ueKdeEVl9J",
      "expandedUrl" : "https://twitter.com/i/web/status/1196567387216199681"
    }
  },
  {
    "like" : {
      "tweetId" : "1325956489358397440",
      "fullText" : "C🦠VID may have taken away my graduation and hooding ceremony but at least I got my silly hat and some nice pictures 10 months later. https://t.co/smlnKmmEhc",
      "expandedUrl" : "https://twitter.com/i/web/status/1325956489358397440"
    }
  },
  {
    "like" : {
      "tweetId" : "1325964255259062274",
      "fullText" : "Need more engagement in your Zoom class? I just talked about the prisoner's dilemma in my 200-person social psych class and did a real life simulation for pts. It was mayhem in the chat! Don't worry they get 1 more chance on Fri. Some grassroots organizers have set up a GroupMe. https://t.co/FAzSyUGZJN",
      "expandedUrl" : "https://twitter.com/i/web/status/1325964255259062274"
    }
  },
  {
    "like" : {
      "tweetId" : "1314346524881584128",
      "fullText" : "I’m going to geek out on this thread more than normal b/c new Science paper is WTF bananas awesome, and I don’t want it to get lost in the news cycle. In criminal justice policy, there’s a bad habit of solving problems by increasing punishment. https://t.co/GSLhxVCDD8 1/ https://t.co/CASGxdBCU2",
      "expandedUrl" : "https://twitter.com/i/web/status/1314346524881584128"
    }
  },
  {
    "like" : {
      "tweetId" : "1325706028533559296",
      "fullText" : "Don’t let anyone tell you imposter syndrome is not real...\n\n#phd #phdchat #impostersyndrome #academia #AcademicTwitter #academiclife #AcademicChatter @OpenAcademics https://t.co/BTegxrFRij",
      "expandedUrl" : "https://twitter.com/i/web/status/1325706028533559296"
    }
  },
  {
    "like" : {
      "tweetId" : "1325792476779732992",
      "fullText" : "Academic milestone: received an e-mail from another grad student that thinks the findings of my studies are meaningful and inspiring 😁 can't tell you how flattered I am (and how much my imposter syndrome is kicking in!) 🙈 #phdlife #AcademicChatter @OpenAcademics https://t.co/dQmKM8DFid",
      "expandedUrl" : "https://twitter.com/i/web/status/1325792476779732992"
    }
  },
  {
    "like" : {
      "tweetId" : "1324335372931866624",
      "fullText" : "Quick breather from checking #ElectionResults2020 ⏸️ \nReally stoked to announce that our review on \"The Consequences of Participating in the Sharing Economy\" is out in @Journal_of_Mgmt 🥳\nGreat fun working wt: @Shaul_Shalvi &amp; il grande Soraperra 🙏\nhttps://t.co/b0oapJ61tS\n#P2P",
      "expandedUrl" : "https://twitter.com/i/web/status/1324335372931866624"
    }
  },
  {
    "like" : {
      "tweetId" : "1323682393333653506",
      "fullText" : "Tijd om de boekhandel te steunen. Boekhandelaar in Amsterdam zei me vandaag: helft minder omzet dan normaal in deze periode. Koop een lekkere stapel, zou ik zeggen. #steundeboekhandel #koopeenboek",
      "expandedUrl" : "https://twitter.com/i/web/status/1323682393333653506"
    }
  },
  {
    "like" : {
      "tweetId" : "1324285781771431936",
      "fullText" : "Mij dag begon vandaag met een wandeling met een collega die net haar proefschrift ingediend heeft en zich nu voorbereidt op haar interne verdediging, erg spannend! De prachtige ochtendzon gaf ons in ieder geval beiden de energie om weer hard aan de slag te gaan vandaag 😎 https://t.co/4SkiebnU9E",
      "expandedUrl" : "https://twitter.com/i/web/status/1324285781771431936"
    }
  },
  {
    "like" : {
      "tweetId" : "1324296619710435329",
      "fullText" : "Ben nu verkrijgbaar als plakplaatje bij de Plus in Alphen, voor een boekje van de heemkundekring aldaar! @BRBNTS_ERFGOED @TilburgU Valorisatie!!! https://t.co/6SZiotSkb9",
      "expandedUrl" : "https://twitter.com/i/web/status/1324296619710435329"
    }
  },
  {
    "like" : {
      "tweetId" : "1324113086933094401",
      "expandedUrl" : "https://twitter.com/i/web/status/1324113086933094401"
    }
  },
  {
    "like" : {
      "tweetId" : "1324133673638178827",
      "expandedUrl" : "https://twitter.com/i/web/status/1324133673638178827"
    }
  },
  {
    "like" : {
      "tweetId" : "1323952998029164544",
      "fullText" : "As part of my PhD defence, I presented 4 years of research in  15 minutes, in a way accesible to a general audience. A difficult task. I've recorded the presentation and uploaded it for those of you interested in seeing how I did (again). https://t.co/1HodMRQSeT",
      "expandedUrl" : "https://twitter.com/i/web/status/1323952998029164544"
    }
  },
  {
    "like" : {
      "tweetId" : "1323672387850850305",
      "fullText" : "De voordelen van flexibel werk en thuis werken: ik kon vanmiddag nog even snel een uurtje op de fiets springen én frisgedoucht op tijd klaar zitten voor het webinar! \n\nHet jaagpad richting de Vlaamse Ardennen stelt nooit teleur 📷☀️🚴🚴‍♂️ https://t.co/TZ776wuJCa",
      "expandedUrl" : "https://twitter.com/i/web/status/1323672387850850305"
    }
  },
  {
    "like" : {
      "tweetId" : "1323670481682288640",
      "fullText" : "Day 1 of writing retreat with friends. Lesson of the day: writing is way more fun - or less painful - with good company 🙌🏽. https://t.co/VZpX3rpNFh",
      "expandedUrl" : "https://twitter.com/i/web/status/1323670481682288640"
    }
  },
  {
    "like" : {
      "tweetId" : "1323640747443261445",
      "fullText" : "Go. Vote. Win. https://t.co/eDWhjNH0sD",
      "expandedUrl" : "https://twitter.com/i/web/status/1323640747443261445"
    }
  },
  {
    "like" : {
      "tweetId" : "1323577248998400002",
      "fullText" : "NEW TT position in Behavioural economics at NHH + 2 postdocs (labor and behavioural)! Apply now (deadline nov 25) and work in an inspiring and energetic environment at the center of excellence, FAIR at NHH \n@FAIR_CELE, @NHHnor, @FAIR_choicelab\nhttps://t.co/rRFPeNoJJP",
      "expandedUrl" : "https://twitter.com/i/web/status/1323577248998400002"
    }
  },
  {
    "like" : {
      "tweetId" : "1323526542291619840",
      "fullText" : "☑️ Good coffee\n☑️ My first tweet\n☑️ My first peer-reviewed paper https://t.co/UtKj50B6Y1\n\n\"Sub-seasonal statistical forecasts of eastern United States hot temperature events\"\n\n- Using SST for S2S forecasting\n- Illustrating importance of proper metrics and other stuff!",
      "expandedUrl" : "https://twitter.com/i/web/status/1323526542291619840"
    }
  },
  {
    "like" : {
      "tweetId" : "1323520799496687616",
      "expandedUrl" : "https://twitter.com/i/web/status/1323520799496687616"
    }
  },
  {
    "like" : {
      "tweetId" : "1323354422483820550",
      "fullText" : "This report highlights two interventions we contributed to, \"Promoting healthy lunches\" and \"Separating food waste in containers\". Now available in English https://t.co/AwoEwaRLMD",
      "expandedUrl" : "https://twitter.com/i/web/status/1323354422483820550"
    }
  },
  {
    "like" : {
      "tweetId" : "1323301255238832129",
      "fullText" : "YAY! I can finally reveal my contribution to the new @marketcafemag magazine! 🎉 \nMy \"food-photography-inspired-dataviz-pen-plotted-recipe\" for Banoffee Pie! (obviously).\n\nCan't wait to get a copy of the issue to see the result in the blue+gold 🤩\n\nhttps://t.co/L8DkOAdmVU https://t.co/CPXLgx7NUY",
      "expandedUrl" : "https://twitter.com/i/web/status/1323301255238832129"
    }
  },
  {
    "like" : {
      "tweetId" : "1322938498165493760",
      "fullText" : "Nu écht uit: Ons huis - Boeken - Verloren https://t.co/mU16ZiYMu9",
      "expandedUrl" : "https://twitter.com/i/web/status/1322938498165493760"
    }
  },
  {
    "like" : {
      "tweetId" : "1322461509893689346",
      "expandedUrl" : "https://twitter.com/i/web/status/1322461509893689346"
    }
  },
  {
    "like" : {
      "tweetId" : "1322304147182489602",
      "fullText" : "Ben moe en dankbaar na alle hartverwarmende reacties en de indrukwekkende woorden van Ernst Hirsch Ballin bij de presentatie van mijn boek. Dank aan allen! @UitgVerloren @lochal013 @ErfgoedTilburg @RobbenPetra @jeroenneus @Verhalis @UitgeverijZHC https://t.co/sFPNnQWLp3",
      "expandedUrl" : "https://twitter.com/i/web/status/1322304147182489602"
    }
  },
  {
    "like" : {
      "tweetId" : "1322226687774461953",
      "fullText" : "will dance like this for the whole weekend https://t.co/w0mEzV9Od8",
      "expandedUrl" : "https://twitter.com/i/web/status/1322226687774461953"
    }
  },
  {
    "like" : {
      "tweetId" : "1322227394409889797",
      "fullText" : "Are you looking for a lab where to run your experimental and behavioral economic studies in Latin America? Check this out 👇👇! This is the new lab at Universidad del Rosario in Bogotá, Colombia. #EconTwitter https://t.co/Cgz0e1ZR9O",
      "expandedUrl" : "https://twitter.com/i/web/status/1322227394409889797"
    }
  },
  {
    "like" : {
      "tweetId" : "1322186091324149767",
      "fullText" : "Ik wil onze mensen in de frontlinie (op alle fronten), ondernemers, medemensen die geraakt worden door dit virus en het beleid veel sterkte wensen. Ons kabinet en parlement wens ik alle wijsheid toe.\n\nTot snel! ♥️",
      "expandedUrl" : "https://twitter.com/i/web/status/1322186091324149767"
    }
  },
  {
    "like" : {
      "tweetId" : "1322168021062922242",
      "fullText" : "Ik heb me net aangemeld voor de #DagvanhetGedrag van @BIN_NL (dinsdag 24 november 9:30-11:00). Met onder andere een keynote van @ReintJanRenes en interessante workshops over gedragsbeïnvloeding (o.a. ten aanzien van #COVID19). Gratis aanmelden kan hier: https://t.co/nQi9dTsmNl",
      "expandedUrl" : "https://twitter.com/i/web/status/1322168021062922242"
    }
  },
  {
    "like" : {
      "tweetId" : "1322163108799041538",
      "fullText" : "I am sharing all of this now because I just got a big grant accepted and I would have felt superdirty to only share the happy news here and not also the crap that goes with it. More news on the accepted grant to follow next week! https://t.co/0QGWGtM0YL",
      "expandedUrl" : "https://twitter.com/i/web/status/1322163108799041538"
    }
  },
  {
    "like" : {
      "tweetId" : "1322134135528394752",
      "fullText" : "@JantsjeMol 91!!! https://t.co/JGeJziN5Jn",
      "expandedUrl" : "https://twitter.com/i/web/status/1322134135528394752"
    }
  },
  {
    "like" : {
      "tweetId" : "1321855269245227013",
      "fullText" : "That's what 2020 did to Reviewer 2:\n\nVery interesting research (.). Paper is well structured (.). It is a pleasure for me to review such a perfect manuscript. My only suggestion is making the abstract more condensed.\n\nWhat happened, @GrumpyReviewer2? 😱\n\n@OpenAcademics #PhDchat",
      "expandedUrl" : "https://twitter.com/i/web/status/1321855269245227013"
    }
  },
  {
    "like" : {
      "tweetId" : "1321842852066959362",
      "fullText" : "You’re unable to view this Post because this account owner limits who can view their Posts. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1321842852066959362"
    }
  },
  {
    "like" : {
      "tweetId" : "1321818974351482883",
      "fullText" : "Q: Wacht even, dus eigenlijk weten we het gewoon niet? Waarom heb ik dit draadje dan zitten lezen?\n\nA: Was de spoiler die ik gaf niet duidelijk genoeg dan?",
      "expandedUrl" : "https://twitter.com/i/web/status/1321818974351482883"
    }
  },
  {
    "like" : {
      "tweetId" : "1321813018771148801",
      "fullText" : "Here are 10 behavioral scientists you should know (and follow). Not only incredible leaders, but interesting humans too!\n\n@lauriesantos @abuttenheim @amybphd @katy_milkman @DrDoriRD @ingridmpaulin @cynmcsweet @DrGMerchant @NeelaSaldanha @c_a_gravert\n\nhttps://t.co/XmnwV282vR",
      "expandedUrl" : "https://twitter.com/i/web/status/1321813018771148801"
    }
  },
  {
    "like" : {
      "tweetId" : "1321752362399260672",
      "fullText" : "Congratulations to @OndrejKacha who passed his MPhil viva with an excellent thesis on the role of social &amp; moral norms in pro-environmental behavior. Very proud supervisor raising a virtual toast🍾thanks to examiners @CameronBrick @leedewit @CambPsych @CSDMLab @GirtonCollege https://t.co/xBWl6gwbrG",
      "expandedUrl" : "https://twitter.com/i/web/status/1321752362399260672"
    }
  },
  {
    "like" : {
      "tweetId" : "1321490878528167937",
      "fullText" : "Enjoying the first ever online BCG World Wide Alumni Day Amsterdam. Excellent presentation by alumna and social entrepreneur Sophie van Gool about gender paygap (ceteris paribus lifelong on average €360000!!) ⁦@BCG⁩ https://t.co/KOCWPMizIn",
      "expandedUrl" : "https://twitter.com/i/web/status/1321490878528167937"
    }
  },
  {
    "like" : {
      "tweetId" : "1321482420093394952",
      "fullText" : "@Bloemendaal_N Well done! So proud of you ❤",
      "expandedUrl" : "https://twitter.com/i/web/status/1321482420093394952"
    }
  },
  {
    "like" : {
      "tweetId" : "1321481526463340554",
      "fullText" : "Very proud of our colleagues @GabrielaGNobre and @Bloemendaal_N whose work has been recognized by @Allianz’ climate risk award’\n\nYou can find their essays here:\nhttps://t.co/8fEHoiHL6S https://t.co/eDS4DXtbyy",
      "expandedUrl" : "https://twitter.com/i/web/status/1321481526463340554"
    }
  },
  {
    "like" : {
      "tweetId" : "1321471154113175552",
      "fullText" : "I won 3rd place in the Allianz Climate Risk Research Award!! Very honored that my efforts to better understand global-scale tropical cyclone risk, and how this changes under climate change, are acknowledged by the industry! Also huge congrats to the other finists!! #azucr2020 https://t.co/avKPDb3zxD",
      "expandedUrl" : "https://twitter.com/i/web/status/1321471154113175552"
    }
  },
  {
    "like" : {
      "tweetId" : "1321369188359901184",
      "fullText" : "@MSFTResearch Hi Microsoft - fancy lending one of these to my lab? We investigate object interaction and weight perception",
      "expandedUrl" : "https://twitter.com/i/web/status/1321369188359901184"
    }
  },
  {
    "like" : {
      "tweetId" : "1321206920297041925",
      "expandedUrl" : "https://twitter.com/i/web/status/1321206920297041925"
    }
  },
  {
    "like" : {
      "tweetId" : "1321102128077807622",
      "fullText" : "🚨𝐁𝐑𝐄𝐀𝐊𝐈𝐍𝐆🚨\n\nDutch government just passed into law that 30 km/h is the norm for all streets in built-up area throughout the country.\n\nNow cities should argue why certain streets should have a higher speed limit instead of the other way around.\n\n@suzanne_GL 👏👏 https://t.co/g1awMCGQPF",
      "expandedUrl" : "https://twitter.com/i/web/status/1321102128077807622"
    }
  },
  {
    "like" : {
      "tweetId" : "1321057633579786242",
      "fullText" : "Finished my Allianz Research Award presentation! I was very nervous but I also enjoyed showing my research so much! They had really interesting questions and it was great to talk about all the potential of my model. Also congrats to the other contestants for their great work! :) https://t.co/VRNgR3ypZH",
      "expandedUrl" : "https://twitter.com/i/web/status/1321057633579786242"
    }
  },
  {
    "like" : {
      "tweetId" : "1320692624970448898",
      "fullText" : "Idea: Let’s use our papers’ rejection history to promote them. \n\n“The research that was too daring for Nature!”\n\n“Here’s the paper that Science didn’t want you to read!”",
      "expandedUrl" : "https://twitter.com/i/web/status/1320692624970448898"
    }
  },
  {
    "like" : {
      "tweetId" : "1320788972138831872",
      "fullText" : "I just learned that, upon moving to my faculty position a few months ago, my health insurance didn’t carry over &amp; I’m now effectively without one (pending appeal)\n\nNow reevaluating my life choices🤔 Skydive in Chicago last month feels like an unnecessary risky gamble worth it tho https://t.co/vHLmBx1TST",
      "expandedUrl" : "https://twitter.com/i/web/status/1320788972138831872"
    }
  },
  {
    "like" : {
      "tweetId" : "1320752752134393867",
      "fullText" : "After a few years in academia, I realised I’ve developed a very particular form of selective vision. \n\n#AcademicChatter #phdlife #AcademicTwitter @PhDVoice #phdchat #PhD #ResearchMatters https://t.co/P4vncZB72x",
      "expandedUrl" : "https://twitter.com/i/web/status/1320752752134393867"
    }
  },
  {
    "like" : {
      "tweetId" : "1320730918814973960",
      "fullText" : "You’re unable to view this Post because this account owner limits who can view their Posts. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1320730918814973960"
    }
  },
  {
    "like" : {
      "tweetId" : "1320731279445340160",
      "fullText" : "Very flattered to have both myself and Money on the Mind nominated for the very first Habit Weekly Awards! Thanks for the recognition @SamuelSalzer !\n\nAlways grateful for the massive support the people in #behavioralscience have given me :D\n\nhttps://t.co/Hy9hjoY0JJ https://t.co/UaYT1CsZZB",
      "expandedUrl" : "https://twitter.com/i/web/status/1320731279445340160"
    }
  },
  {
    "like" : {
      "tweetId" : "1320729377861226496",
      "fullText" : "Eer van mijn werk! https://t.co/ltkOnn2cIy",
      "expandedUrl" : "https://twitter.com/i/web/status/1320729377861226496"
    }
  },
  {
    "like" : {
      "tweetId" : "1320644058491080704",
      "fullText" : "Yesterday I was cleaning up my room. Quite surprisingly I found that my passport was stuck between desk and the wall. It must have been there for at least a couple of months. I smiled to myself and thought \"Won't need you for a long time\".\n\nI stuck it back to where I found it 🤷",
      "expandedUrl" : "https://twitter.com/i/web/status/1320644058491080704"
    }
  },
  {
    "like" : {
      "tweetId" : "1320101515042918400",
      "fullText" : "10/10 debugging partner https://t.co/atm4Gw4PwQ",
      "expandedUrl" : "https://twitter.com/i/web/status/1320101515042918400"
    }
  },
  {
    "like" : {
      "tweetId" : "1320018992879357952",
      "fullText" : "I know I might look like a hurricane researcher on the outside ..\n\nBut on the inside I'm an asphalt hooligan🤟 \n\n(Haha just kidding, I joined my bf to a test site today. Way more fun than grading math exams! And I even got to ride along in the steamroller😎 Today was a good day) https://t.co/b9Hhm5nuWU",
      "expandedUrl" : "https://twitter.com/i/web/status/1320018992879357952"
    }
  },
  {
    "like" : {
      "tweetId" : "1319636031986159619",
      "fullText" : "@JantsjeMol this is my fav. so far.",
      "expandedUrl" : "https://twitter.com/i/web/status/1319636031986159619"
    }
  },
  {
    "like" : {
      "tweetId" : "1319622790639738880",
      "fullText" : "Oh hello there https://t.co/rvfCDSVdVB",
      "expandedUrl" : "https://twitter.com/i/web/status/1319622790639738880"
    }
  },
  {
    "like" : {
      "tweetId" : "1319608981325742082",
      "fullText" : "Me after my first day of grading math exams. I don't even know how to caption my feelings, but I am sure fellow teachers can relate.🙈\n\n10 exams down, 91 to go. https://t.co/V2J0rD0jji",
      "expandedUrl" : "https://twitter.com/i/web/status/1319608981325742082"
    }
  },
  {
    "like" : {
      "tweetId" : "1319582521512939520",
      "fullText" : "@JantsjeMol Liselotte saying \"oh they are cooking the same thing in the oven\" when entering the VR neighbour's house haha",
      "expandedUrl" : "https://twitter.com/i/web/status/1319582521512939520"
    }
  },
  {
    "like" : {
      "tweetId" : "1319561042423414784",
      "fullText" : "It took a handful of rejections, but my first first author paper is finally published! https://t.co/ULuobzV2JL https://t.co/eiS2HbvcC1",
      "expandedUrl" : "https://twitter.com/i/web/status/1319561042423414784"
    }
  },
  {
    "like" : {
      "tweetId" : "1319270538875863042",
      "fullText" : "It's practice job market talk season for grad students! A little known fact about job talks is they should be aimed at second year undergraduates, because that is how smart the average faculty member is when they are sitting in a comfortable chair with a phone in their pocket.",
      "expandedUrl" : "https://twitter.com/i/web/status/1319270538875863042"
    }
  },
  {
    "like" : {
      "tweetId" : "1319516176347791360",
      "fullText" : "so begins day two. Which direction will I move in, I do not know. You shall likely judge how successful I am by how active I am on Twitter.",
      "expandedUrl" : "https://twitter.com/i/web/status/1319516176347791360"
    }
  },
  {
    "like" : {
      "tweetId" : "1319368650214854657",
      "expandedUrl" : "https://twitter.com/i/web/status/1319368650214854657"
    }
  },
  {
    "like" : {
      "tweetId" : "1319349417363857412",
      "fullText" : "@JantsjeMol @UvA_Amsterdam @UvA_EB @Shaul_Shalvi Congrats, Jantsje, that's awesome! Hope I can visit you sometime!",
      "expandedUrl" : "https://twitter.com/i/web/status/1319349417363857412"
    }
  },
  {
    "like" : {
      "tweetId" : "1319235388414754820",
      "fullText" : "I started this morning needing to cut 300 words off a paper...now I need to cut 1200. I think I made a mistake somewhere in this process.",
      "expandedUrl" : "https://twitter.com/i/web/status/1319235388414754820"
    }
  },
  {
    "like" : {
      "tweetId" : "1141435813529554945",
      "fullText" : "Finally met my Doppelgänger at #ESEE2019 https://t.co/6tXobmeTT1",
      "expandedUrl" : "https://twitter.com/i/web/status/1141435813529554945"
    }
  },
  {
    "like" : {
      "tweetId" : "1319245391662108672",
      "fullText" : "Ook aan @TilburgU - een universiteit zonder geschiedenisopleiding - zien we dit jaar een grote toename van studenten met belangstelling voor geschiedenis en cultuur! In Tilburg University College: @BA_LiberalArts https://t.co/k9wKfpZcdP",
      "expandedUrl" : "https://twitter.com/i/web/status/1319245391662108672"
    }
  },
  {
    "like" : {
      "tweetId" : "1319252155396743170",
      "fullText" : "It really meant a lot seeing all those messages! Over the next few weeks, I will tweet out short summaries for some of my papers. In the meantime, my website with CV and further info is: https://t.co/IJgl3nXJP6.",
      "expandedUrl" : "https://twitter.com/i/web/status/1319252155396743170"
    }
  },
  {
    "like" : {
      "tweetId" : "1319218430726311936",
      "fullText" : "My 89 yo grandma beat me in playing Halma with a perfect score and I wanted to share a picture of her winner mood 💜 https://t.co/REs1fbybZf",
      "expandedUrl" : "https://twitter.com/i/web/status/1319218430726311936"
    }
  },
  {
    "like" : {
      "tweetId" : "1319180870780129280",
      "fullText" : "I hit 60 #interviews, so it's summary article time!\n\nHere, 60 famous people in #behavioralscience tell you about their proudest achievement in either #behavioraleconomics, #academia, #industry, or waaay beyond!\n\nhttps://t.co/JhOwrT5H1K https://t.co/7q9jRVU8Dk",
      "expandedUrl" : "https://twitter.com/i/web/status/1319180870780129280"
    }
  },
  {
    "like" : {
      "tweetId" : "1318927637578977286",
      "fullText" : "And some dare to say that open science provides no personal benefits... @Bibliothecaris @OSCGroningen #tastyscience https://t.co/sakLzi5IlG",
      "expandedUrl" : "https://twitter.com/i/web/status/1318927637578977286"
    }
  },
  {
    "like" : {
      "tweetId" : "1318881243107414019",
      "expandedUrl" : "https://twitter.com/i/web/status/1318881243107414019"
    }
  },
  {
    "like" : {
      "tweetId" : "1318710414633553921",
      "fullText" : "Do you constantly check to see if the status of your paper changed from 'under review' to 'final decision being made', or are you normal?\n\n@OpenAcademics @AcademicChatter #AcademicTwitter https://t.co/F8EDTzb748",
      "expandedUrl" : "https://twitter.com/i/web/status/1318710414633553921"
    }
  },
  {
    "like" : {
      "tweetId" : "1309922480040050688",
      "fullText" : "Papers in 2020: \"We are the very first in the galaxy deriving the following algorithm, which has been proof of having a 0.0001 increment in accuracy over all the rest procedures known by humankind\"\n\nPapers in 1955: \"No originality is claimed for the tests discussed in this paper\" https://t.co/67ogwsOpx4",
      "expandedUrl" : "https://twitter.com/i/web/status/1309922480040050688"
    }
  },
  {
    "like" : {
      "tweetId" : "1294798589688860672",
      "fullText" : "Finishing my econometrics prep. Gonna make a hard sell for my vtable package in your class if you're using R.\n\n- Easily explore variable characteristics and values with vtable\n- Super easy summary tables with sumtable\n- Balance tables with sumtable\n\nhttps://t.co/3vvRufRhJM",
      "expandedUrl" : "https://twitter.com/i/web/status/1294798589688860672"
    }
  },
  {
    "like" : {
      "tweetId" : "1296440493577064448",
      "fullText" : "Just had an incoming student email me with a request for an RA position, link to his GitHub profile included. Can #EconTwitter please spread the word that a GitHub profile with previous work (ie written code) is at least as important as a nicely latexed CV? Thanks.",
      "expandedUrl" : "https://twitter.com/i/web/status/1296440493577064448"
    }
  },
  {
    "like" : {
      "tweetId" : "1318484350942531585",
      "fullText" : "PhD defense of my great friend @esther_schuch on the role of uncertainty in management @MARmaEDnetwork ! Wish I would be there 😍 https://t.co/OWAnLQLmMZ",
      "expandedUrl" : "https://twitter.com/i/web/status/1318484350942531585"
    }
  },
  {
    "like" : {
      "tweetId" : "1317001849669586946",
      "fullText" : "#EconTwitter how do you help your students form groups and do online group work if they don't know each other much?\n\nAny good or bad experiences here? \n\nMerci 💛",
      "expandedUrl" : "https://twitter.com/i/web/status/1317001849669586946"
    }
  },
  {
    "like" : {
      "tweetId" : "1318195012346220544",
      "fullText" : "Did you know that the tmap package has its own website?\n\nIt contains examples for each tmap function and a few articles.\n\nVisit it at https://t.co/ZaMUkjxy7j\n\n#tmap #rstats #rspatial https://t.co/wsqdcsmRnc",
      "expandedUrl" : "https://twitter.com/i/web/status/1318195012346220544"
    }
  },
  {
    "like" : {
      "tweetId" : "1318173805769068546",
      "fullText" : "‘Eigenlijk zou bij elk persbericht van zo’n belangengroep moeten staan: hier is onze verantwoording, dit geldt alleen voor onze achterban.’ raadt hoogleraar politieke communicatie @claesdevreese aan. @volkskrant @FMG_UvA\nhttps://t.co/kXuS9u9gUq",
      "expandedUrl" : "https://twitter.com/i/web/status/1318173805769068546"
    }
  },
  {
    "like" : {
      "tweetId" : "1318119517025947648",
      "fullText" : "We have many openings for Assistant Professor and Associate Professor (tenured) positions at University of Bologna: https://t.co/OfWZx4QDpm and https://t.co/B1Myx9f9dw. \n\nAny field, including environmental economics; deadline is November 15. Please share!\n\n#economics #university",
      "expandedUrl" : "https://twitter.com/i/web/status/1318119517025947648"
    }
  },
  {
    "like" : {
      "tweetId" : "1318117352068833280",
      "fullText" : "Uitermate vereerd met deze prijs als #OpenScienceChampion van @TilburgU!\n\nSpeciale dank aan al mijn vrienden in het @C19RedTeam! Vooral aan @edwinveldhuizen, met wie ik al maanden de data, code, en cijfers openlijk deel en publiceer :-) https://t.co/ekgdV9l43O",
      "expandedUrl" : "https://twitter.com/i/web/status/1318117352068833280"
    }
  },
  {
    "like" : {
      "tweetId" : "1317459076754726912",
      "fullText" : "The presentations of the ESA World Meetings are now available online!Want to watch the latest research in #experimentaleconomics according to your tastes? You’re in luck!\n \nVideos of the parallel sessions from the conference are on the ESA YouTube channel:\nhttps://t.co/uU6Wzo3j7d",
      "expandedUrl" : "https://twitter.com/i/web/status/1317459076754726912"
    }
  },
  {
    "like" : {
      "tweetId" : "1317524534338224130",
      "fullText" : "I have been thinking about this all day and concluded experimental economics should get more adventurous. https://t.co/v7IHCvSQtq",
      "expandedUrl" : "https://twitter.com/i/web/status/1317524534338224130"
    }
  },
  {
    "like" : {
      "tweetId" : "1317446796403245056",
      "fullText" : "... but this was really helpful.\n\nAll of this is to say, if there's anything you'd like to ask me about my research, blog posts, or teaching, I'd love to hear about it 😁\n3/3 https://t.co/KrUPdITYGv",
      "expandedUrl" : "https://twitter.com/i/web/status/1317446796403245056"
    }
  },
  {
    "like" : {
      "tweetId" : "1317038591034490880",
      "fullText" : "Dear All, I will be on the job market this year. My main research areas are auctions, public procurement, and recently behavioral research on the pandemic: https://t.co/BeaQsySckk Please let me know about interesting job postings at your faculty. #econjobmarket #EconTwitter https://t.co/ciztQ9L3L7",
      "expandedUrl" : "https://twitter.com/i/web/status/1317038591034490880"
    }
  },
  {
    "like" : {
      "tweetId" : "1316643913948635137",
      "fullText" : "Calling all science/health journalists, press officers and those trying to communicate health research:\n\nDelighted to announce the launch of RealRisk, @d_spiegel and the Winton Centre's tool to help you get your numbers across clearly and accurately.\n\nhttps://t.co/C84a6zW3kd https://t.co/6f9aQoR0Lf",
      "expandedUrl" : "https://twitter.com/i/web/status/1316643913948635137"
    }
  },
  {
    "like" : {
      "tweetId" : "1316051074080440320",
      "fullText" : "PERSONAL ANNOUNCEMENT: I am on the job market this year! My personal website with CV is: https://t.co/IJgl3nXJP6.\n\nAs it's not the best time to be on the market, a thread on who I am and why your department should invite me for a skype-out and not miss the opportunity to hire me! https://t.co/Z8Xbfly4oA",
      "expandedUrl" : "https://twitter.com/i/web/status/1316051074080440320"
    }
  },
  {
    "like" : {
      "tweetId" : "1316735405954412545",
      "fullText" : "@StefanLipman defending his  PhD thesis at @ESHPM_EUR 💪🏻 https://t.co/wHxSQYp44y",
      "expandedUrl" : "https://twitter.com/i/web/status/1316735405954412545"
    }
  },
  {
    "like" : {
      "tweetId" : "1316721423021375488",
      "fullText" : "A useful distinction between #reproducibility and #replicability by @MicheleNuijten at #NSRI2020 symposium on #researchintegrity https://t.co/Q07uGbeuAa",
      "expandedUrl" : "https://twitter.com/i/web/status/1316721423021375488"
    }
  },
  {
    "like" : {
      "tweetId" : "1316695845757218817",
      "fullText" : "@JantsjeMol @UvA_Amsterdam @UvA_EB @Shaul_Shalvi https://t.co/5PqxELy8vS",
      "expandedUrl" : "https://twitter.com/i/web/status/1316695845757218817"
    }
  },
  {
    "like" : {
      "tweetId" : "1316709645088628736",
      "fullText" : "Could not be happier about this!!!\nWhen you are not sure whether your correlation maps are telling the truth, here a way to rule (at least some hypotheses) out! https://t.co/jzO3flJDQ8",
      "expandedUrl" : "https://twitter.com/i/web/status/1316709645088628736"
    }
  },
  {
    "like" : {
      "tweetId" : "1316687766588194816",
      "fullText" : "@JantsjeMol @UvA_Amsterdam @UvA_EB @Shaul_Shalvi Congratulations 🎉🎉🎉 https://t.co/KJ5wxaMo7u",
      "expandedUrl" : "https://twitter.com/i/web/status/1316687766588194816"
    }
  },
  {
    "like" : {
      "tweetId" : "1316674211889532928",
      "fullText" : "@JantsjeMol @UvA_EB @Shaul_Shalvi Well done, Jantsje! Good luck with this exciting adventure! ^LG",
      "expandedUrl" : "https://twitter.com/i/web/status/1316674211889532928"
    }
  },
  {
    "like" : {
      "tweetId" : "1316479481289175040",
      "fullText" : "Do you have room for one more follower? Drop a comment or a GIF below if you have an academic-related account and I will* follow the 1st 100 people**😍  #AcademicTwitter #phdchat \n\n*if you're a kind person\n**currently following 7761 accounts https://t.co/QFNFyIuZFb",
      "expandedUrl" : "https://twitter.com/i/web/status/1316479481289175040"
    }
  },
  {
    "like" : {
      "tweetId" : "1316475654213455873",
      "fullText" : "Bij Nieuwsuur mocht ik samen met @BDDataplan vertellen over mobiliteit, rioolwater en snelle + accurate data, die kunnen helpen bij het bestrijden van het coronavirus. En mooi om te zien dat de #hamstercurve in het item zat :) https://t.co/2t455vrFtn",
      "expandedUrl" : "https://twitter.com/i/web/status/1316475654213455873"
    }
  },
  {
    "like" : {
      "tweetId" : "1316395958083543041",
      "fullText" : "I haven't known how to share this story, but I do want to get it off my chest, so here goes.\n\nIt's a story of discrimination. I'm sure everyone has one. Thread:",
      "expandedUrl" : "https://twitter.com/i/web/status/1316395958083543041"
    }
  },
  {
    "like" : {
      "tweetId" : "1316394660869427203",
      "fullText" : "@ClemensFiedler https://t.co/hiRv8YcSCV",
      "expandedUrl" : "https://twitter.com/i/web/status/1316394660869427203"
    }
  },
  {
    "like" : {
      "tweetId" : "1316314344611885057",
      "fullText" : "Today I defend my Doctoral Thesis: Innovation in the Digital Age: Competition, Cooperation, and Standardization in the Aula of Tilburg University.\n\nYou can follow the ceremony starting at 16:30 here https://t.co/JuIP2NPMsN or https://t.co/ncRDcgAJ8N.",
      "expandedUrl" : "https://twitter.com/i/web/status/1316314344611885057"
    }
  },
  {
    "like" : {
      "tweetId" : "1316359765442916353",
      "fullText" : "Vanavond zijn @BDDataplan en ik samen te zien in Nieuwsuur. We leggen uit hoe je de effecten van de maatregelen terug kunt zien in 'de cijfers': positieve tests, rioolwater, mobiliteit en meer. Stay tuned :) https://t.co/cMts5NcbTS",
      "expandedUrl" : "https://twitter.com/i/web/status/1316359765442916353"
    }
  },
  {
    "like" : {
      "tweetId" : "1316321059587731456",
      "fullText" : "Upon asking my sister what a good image would be for a catastrophe model (commonly abbreviated to cat model), she replied with 👇\n\nOk sis, you win 😉 https://t.co/DPlgzVVl0F",
      "expandedUrl" : "https://twitter.com/i/web/status/1316321059587731456"
    }
  },
  {
    "like" : {
      "tweetId" : "1577997527802167300",
      "fullText" : "This morning.\n\n-Me: Why'd you take out Mostly Harmless Econometrics?\n-Daughter (8): I was using it to draw straight lines\n-That book talks about doing that with math\n-Why?\n-Let's say you are trying to predict behavior from feelings\n-Why would an economist want to do that?",
      "expandedUrl" : "https://twitter.com/i/web/status/1577997527802167300"
    }
  },
  {
    "like" : {
      "tweetId" : "1577726767992868864",
      "fullText" : "It's raining and all Bergen cats are (sensibly) indoors, so here are two lovely fluffballs from one of our followers in Athens to make your evening🥰\n\n#CatsOnTwitter #cats #CatsOfTwitter https://t.co/e8dD3vNEY4",
      "expandedUrl" : "https://twitter.com/i/web/status/1577726767992868864"
    }
  },
  {
    "like" : {
      "tweetId" : "1577645632893894659",
      "fullText" : "Two weeks left to apply for my PhD vacancy on assessing infrastructure failure due to climate extremes and how this will affect our economy. https://t.co/2R2YedMJu5.",
      "expandedUrl" : "https://twitter.com/i/web/status/1577645632893894659"
    }
  },
  {
    "like" : {
      "tweetId" : "1577529726096269312",
      "fullText" : "Proud 🇸🇮 🏳️‍🌈 ! Slovenia becomes first East European country to legalise same-sex marriage and adoption https://t.co/d2QIdkzun5",
      "expandedUrl" : "https://twitter.com/i/web/status/1577529726096269312"
    }
  },
  {
    "like" : {
      "tweetId" : "1577271963751325698",
      "fullText" : "@JantsjeMol @eckelcc @danilaserra_eco @KhoaVuUmn @erezyoeli @alexoimas @otree Fantastic, thanks! 🙌🏻",
      "expandedUrl" : "https://twitter.com/i/web/status/1577271963751325698"
    }
  },
  {
    "like" : {
      "tweetId" : "1577267393247776769",
      "fullText" : "Werk! Wil jij internationaal klimaatbeleid effectiever maken door onderzoek naar lagere emissies wereldwijd? Het PBL zoekt een junior onderzoeker om beleid van landen met de grootste uitstoot te analyseren met het invloedrijke IMAGE model.  #vacature https://t.co/gA45mdGi30 https://t.co/uSbsRFXRsW",
      "expandedUrl" : "https://twitter.com/i/web/status/1577267393247776769"
    }
  },
  {
    "like" : {
      "tweetId" : "1576899539763884032",
      "fullText" : "We are not very good at randomising.\n👉 They are actually strategies more likely to win at Rock-Paper-Scissors.\nhttps://t.co/8sBekGrpnM https://t.co/rvhlQLy0cq",
      "expandedUrl" : "https://twitter.com/i/web/status/1576899539763884032"
    }
  },
  {
    "like" : {
      "tweetId" : "1577189936901500928",
      "fullText" : "Do farmers cooperate as much as farmers predict?\n\nIn this German case study, we compare farmers' contributions in a public goods game setting to experts' predictions of the respective farmer behaviour\n\nOpen access link⬇️\n\nhttps://t.co/8UUM5QnUVJ\n#agecon https://t.co/NkAd5fw9RR",
      "expandedUrl" : "https://twitter.com/i/web/status/1577189936901500928"
    }
  },
  {
    "like" : {
      "tweetId" : "1576448270930305025",
      "fullText" : "Gonna tag some more awesome colleagues right here: @MuisSanne @JohannaKoehler @JantsjeMol @ElcoKoks  @pieterbeuk @PhilipWard_ @Marleen_Ruiter @Hans_deMoel and all the others I likely have forgotten to mention. I truly appreciate your kind words and messages!!❤️",
      "expandedUrl" : "https://twitter.com/i/web/status/1576448270930305025"
    }
  },
  {
    "like" : {
      "tweetId" : "1576448268346671106",
      "fullText" : "Feeling so uplifted right now 😊 Having my friends, family, colleagues and professors (even if the only word they understand is orkaan 😉) cheer for you and your tv appearance makes me feel amazing!!\n\nThank you all at @VU_IVM and @LamontEarth, you are the absolute best!! https://t.co/1Hml3BMw9z",
      "expandedUrl" : "https://twitter.com/i/web/status/1576448268346671106"
    }
  },
  {
    "like" : {
      "tweetId" : "1575787480443297792",
      "fullText" : "not long now https://t.co/WiZUBtoCcv",
      "expandedUrl" : "https://twitter.com/i/web/status/1575787480443297792"
    }
  },
  {
    "like" : {
      "tweetId" : "1575772693794017280",
      "fullText" : "Today we launch the Journal of Global environmental psychology. GEP has been co-developed by researchers in our field. It's free for authors &amp; readers. We look forward to theoretical &amp; applied work on the relationship between people &amp; their environment\nhttps://t.co/vku0uyqX3y 🌏 https://t.co/0U8fwNpXPS",
      "expandedUrl" : "https://twitter.com/i/web/status/1575772693794017280"
    }
  },
  {
    "like" : {
      "tweetId" : "1575711673012277249",
      "fullText" : "My dear friend @jondequidt’s son always hears people refer to me as “your Hannes”, so he calls me “my Hannes”. Here’s the best birthday present https://t.co/G3OtTED6Za",
      "expandedUrl" : "https://twitter.com/i/web/status/1575711673012277249"
    }
  },
  {
    "like" : {
      "tweetId" : "1575501734931095557",
      "fullText" : "Important new paper shows that \"gamified\" inoculation approaches may not help people detect fake news - rather, they simply increase overall skepticism: https://t.co/Nu0jUDeEPA\n\nSince true content is usually more common than false, this means that the intervention may backfire... https://t.co/gKITuD8ufP",
      "expandedUrl" : "https://twitter.com/i/web/status/1575501734931095557"
    }
  },
  {
    "like" : {
      "tweetId" : "1575523150279884803",
      "fullText" : "I am pleased to announce the \n\n3rd Winter Workshop in the Behavioral and Experimental Economics of food consumption\n\nMarch 15-17 in the French Alps. \n\nJoin us for an immersive atmosphere, engaging talks, discussion, snow &amp; fondue. \n\nInfo &amp; submission here:\nhttps://t.co/kwoh3GdOH9 https://t.co/gvZRcVUtaT",
      "expandedUrl" : "https://twitter.com/i/web/status/1575523150279884803"
    }
  },
  {
    "like" : {
      "tweetId" : "1575368251395145728",
      "fullText" : "Gisteravond kreeg ik de kans om (voor het eerst!) op nationale radio ons onderzoek naar de gevolgen van klimaatverandering op Bonaire toe te lichten. Live vanuit een NOS auto voor de deur! Je kunt het hier terugluisteren: https://t.co/ln6M3c6qSn https://t.co/1m68VxmQlV",
      "expandedUrl" : "https://twitter.com/i/web/status/1575368251395145728"
    }
  },
  {
    "like" : {
      "tweetId" : "1575199584233701385",
      "fullText" : "Wat is een oorkaan en waarom moet Nederland er ook rekening mee houden? @Bloemendaal_N vertelt erover in #atlastv  @VU_IVM  @LamontEarth https://t.co/10GvnQBIUi",
      "expandedUrl" : "https://twitter.com/i/web/status/1575199584233701385"
    }
  },
  {
    "like" : {
      "tweetId" : "1575068962173652992",
      "fullText" : "Vanavond zit ik in het programma Atlas om te praten over het huidige orkaanseizoen (met natuurlijk speciale aandacht voor orkaan Ian👇), het effect van klimaatverandering, en hoe mijn onderzoek bijdraagt aan het inzichtelijk maken van risico's. NPO2, 20:25u! @VU_IVM @VU_Science https://t.co/5VcVR13P1h",
      "expandedUrl" : "https://twitter.com/i/web/status/1575068962173652992"
    }
  },
  {
    "like" : {
      "tweetId" : "1574465696070762496",
      "fullText" : "What do you mean, Monday? We don't do that here.\n- Oliver 🐾🥰\n\nMuch love from Bergen!\n#CatsOfTwitter #cats #CatsOnTwitter https://t.co/OpE7fUCvRJ",
      "expandedUrl" : "https://twitter.com/i/web/status/1574465696070762496"
    }
  },
  {
    "like" : {
      "tweetId" : "1574425125671342085",
      "fullText" : "Celebrating our permanent contract with cake! 🍰🥂🎉😊 @Marleen_Ruiter https://t.co/FHXAhHsiGv https://t.co/oplvERLlGc",
      "expandedUrl" : "https://twitter.com/i/web/status/1574425125671342085"
    }
  },
  {
    "like" : {
      "tweetId" : "1574324741720215555",
      "fullText" : "What is the role of Honesty-Humility (HH) in crime?\nIn our new paper, we found that HH broadly distinguished those who engaged in crime leading to imprisonment from those who did not. However, HH did not predict the more specific aspects of criminal behavior. \nSee thread: https://t.co/x9Aew0TsFw",
      "expandedUrl" : "https://twitter.com/i/web/status/1574324741720215555"
    }
  },
  {
    "like" : {
      "tweetId" : "1574054321871900679",
      "fullText" : "Ignorance,\nBad Policy,\nDiscrimination,\nMarket Inefficiency, \nand Other Bad Things That Happen When You Don't Run Experiments.\n\nThat's the title of my new book.\n\nActually, that's the whole book.",
      "expandedUrl" : "https://twitter.com/i/web/status/1574054321871900679"
    }
  },
  {
    "like" : {
      "tweetId" : "1573312109127016450",
      "fullText" : "🥳🥳🥳 PNN turned 35 today! https://t.co/r8TVyE7fLq",
      "expandedUrl" : "https://twitter.com/i/web/status/1573312109127016450"
    }
  },
  {
    "like" : {
      "tweetId" : "1573347523128868864",
      "fullText" : "Do you know academic staff at Amsterdam universities @UvA_Amsterdam or @VUamsterdam who provide exceptional contributions in teaching, societal impact, or academic community support (mentoring), nominate them for this award! Great to see these important efforts recognised! https://t.co/Dobvl02O8w",
      "expandedUrl" : "https://twitter.com/i/web/status/1573347523128868864"
    }
  },
  {
    "like" : {
      "tweetId" : "1573354127836549122",
      "fullText" : "A beautiful evening in Bergen, and a beautiful fluffball to go with that😻\n\n#cats #CatsOfTwitter https://t.co/hrQy6YFLuV",
      "expandedUrl" : "https://twitter.com/i/web/status/1573354127836549122"
    }
  },
  {
    "like" : {
      "tweetId" : "1315710526350077953",
      "fullText" : "Paper accepted! 🥳\nGreat way to the start the week! Soon I'll have proof that I got something done during my #postdoc 😂\n#AcademicChatter #phdchat #MondayMotivation #MondayMood #ECRchat #postdoclife https://t.co/9Ify89yzaV",
      "expandedUrl" : "https://twitter.com/i/web/status/1315710526350077953"
    }
  },
  {
    "like" : {
      "tweetId" : "1315445454398726147",
      "fullText" : "You’re unable to view this Post because this account owner limits who can view their Posts. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1315445454398726147"
    }
  },
  {
    "like" : {
      "tweetId" : "1315058517238321154",
      "fullText" : "Niece asked for science kit, but disappointed with pre-made kits. Compiled my own. \n\n28 experiments. Each has: a goal, materials, methods,what’s happening explanation, what kind of scientist uses this in real life, &amp; example of woman scientist\n\nDM me if you would like a copy https://t.co/S1Vd9icNGS",
      "expandedUrl" : "https://twitter.com/i/web/status/1315058517238321154"
    }
  },
  {
    "like" : {
      "tweetId" : "1314851874521088000",
      "fullText" : "#datumfetisj : 10-10-2020. De vorige keer dat 2*ddmm=jjjj (09-09-1818) bestond @statistiekcbs nog niet, wel wat weetjes: in 1818 telde NL 2,4 miljoen inwoners,  heette Fryslân nog Vriesland en schreven we Braband in plaats van Brabant. https://t.co/BzdodQVwOE https://t.co/WLacRyRlSW",
      "expandedUrl" : "https://twitter.com/i/web/status/1314851874521088000"
    }
  },
  {
    "like" : {
      "tweetId" : "1314695096265142272",
      "fullText" : "This is wonderful. [I fact-checked it and it's legit.] https://t.co/OnZ1JS51Y9",
      "expandedUrl" : "https://twitter.com/i/web/status/1314695096265142272"
    }
  },
  {
    "like" : {
      "tweetId" : "1314684624912576512",
      "fullText" : "Prediction https://t.co/1x9OKG6VOQ https://t.co/UVepdKDBWD https://t.co/0yZzdasRg9",
      "expandedUrl" : "https://twitter.com/i/web/status/1314684624912576512"
    }
  },
  {
    "like" : {
      "tweetId" : "1314544921869783040",
      "fullText" : "Honored to witness my friend and colleague become a Doctor today! https://t.co/JNbxaSQwwH",
      "expandedUrl" : "https://twitter.com/i/web/status/1314544921869783040"
    }
  },
  {
    "like" : {
      "tweetId" : "1314522334766813187",
      "fullText" : "What a great honor is to work at @WFP! Congratulations to all staff members, no matter what your role is! 😃 https://t.co/6fCZoCiEH1",
      "expandedUrl" : "https://twitter.com/i/web/status/1314522334766813187"
    }
  },
  {
    "like" : {
      "tweetId" : "1314532021323132928",
      "fullText" : "Congrats to the new Dr. Sanderink! A successful social distance PhD defence on the topic of the #climate #energy nexus @l_sanderink https://t.co/itAHbDVtDP",
      "expandedUrl" : "https://twitter.com/i/web/status/1314532021323132928"
    }
  },
  {
    "like" : {
      "tweetId" : "1314225757389033473",
      "fullText" : "Ok, listen up, everyone, Esther Duflo just said \"Referees need to be more positive. This is just a paper in the AER , it's not some divine piece coming down! I am limited by the number of positive reports I get not by space available in the journal\"",
      "expandedUrl" : "https://twitter.com/i/web/status/1314225757389033473"
    }
  },
  {
    "like" : {
      "tweetId" : "1314181207198924800",
      "fullText" : "Yesterday:\n\nPossible client: We want you to improve the graphics in our big paper report\nMe: Mmmmm, okaaaaay...\nClient: After that we might have some time to play with our AI extracted historical map dat...\nMe: DEAL! DEAL! DEAL!",
      "expandedUrl" : "https://twitter.com/i/web/status/1314181207198924800"
    }
  },
  {
    "like" : {
      "tweetId" : "1314011741286694912",
      "fullText" : "Running lab experiments 'virtually' in Australia while in the UK. It's nice to be able to do that while wearing PJ bottoms. 🤔\nHeaps of coffee needed. https://t.co/gkyj1VgRmA",
      "expandedUrl" : "https://twitter.com/i/web/status/1314011741286694912"
    }
  },
  {
    "like" : {
      "tweetId" : "1313681556335194112",
      "fullText" : "Accidentally sent pug photos to a random person and it turned into the most wholesome interaction of 2020: https://t.co/5WCOOqeI51",
      "expandedUrl" : "https://twitter.com/i/web/status/1313681556335194112"
    }
  },
  {
    "like" : {
      "tweetId" : "1313939371498844162",
      "expandedUrl" : "https://twitter.com/i/web/status/1313939371498844162"
    }
  },
  {
    "like" : {
      "tweetId" : "1313785534125309954",
      "fullText" : "Lenka Fiala (@FialaLenka) will lead today's #Wednesdayworkshop. She will present her (JM) paper \"Statistical Role Models\" https://t.co/ql5FT27s3b #statisticalinformation #rolemodels #highpaying #mathematicaltask #genderdifferences #stereotypes #mathematicalperformance #research https://t.co/JdcgxQiSH1",
      "expandedUrl" : "https://twitter.com/i/web/status/1313785534125309954"
    }
  },
  {
    "like" : {
      "tweetId" : "1313719648005877762",
      "fullText" : "Looking forward to present my job market paper tomorrow at 5pm CET!\n@PhdEvs has weekly presentations by JM candidates from all over the world and working on various fields. Be sure to check it out! https://t.co/CLeWnXHUnP",
      "expandedUrl" : "https://twitter.com/i/web/status/1313719648005877762"
    }
  },
  {
    "like" : {
      "tweetId" : "1311328534200188929",
      "fullText" : "A bit of publicity for the Science Journal for Kids. It has been some time now, but I really enjoyed the editing process and  it's a great way to communicate peer-reviewed scientific work to a younger audience.    https://t.co/OJPI8tY03P",
      "expandedUrl" : "https://twitter.com/i/web/status/1311328534200188929"
    }
  },
  {
    "like" : {
      "tweetId" : "1313477155611906049",
      "fullText" : "I feel like I’m having this conversation over and over again https://t.co/sFzKInnSYE",
      "expandedUrl" : "https://twitter.com/i/web/status/1313477155611906049"
    }
  },
  {
    "like" : {
      "tweetId" : "1313147118606069762",
      "fullText" : "I am really really really really (like screaming) happy to tell you that I just got the news that I am one of the 4 finalists of the Allianz Climate Risk Research Award!! I will present my work for the Allianz company on Oct 27th, which I'm honestly really looking forward to 😊 https://t.co/0sih1BTQCC",
      "expandedUrl" : "https://twitter.com/i/web/status/1313147118606069762"
    }
  },
  {
    "like" : {
      "tweetId" : "1313133792312336384",
      "fullText" : "Excited I've been appointed by @APA President to serve on the new APA Task Force on Climate Change (with brilliant colleagues incl @TacianoMilfont @ezramarkowitz). Look forward to furthering the role of psychology in tackling #climatechange! @CambPsych @ChurchillCol https://t.co/Hyxt8icdT3",
      "expandedUrl" : "https://twitter.com/i/web/status/1313133792312336384"
    }
  },
  {
    "like" : {
      "tweetId" : "1261212987144142850",
      "fullText" : "Proud to tell the world about our awesome research! @ivanhaigh @VU_IVM https://t.co/WNVNpDGXF8",
      "expandedUrl" : "https://twitter.com/i/web/status/1261212987144142850"
    }
  },
  {
    "like" : {
      "tweetId" : "1311666408363704329",
      "fullText" : "\"When data is coming from interviews, the situation of Raw, Processed and Analyzed data is very different from the what a lot of #OpenScience initiatives started with\"  #vudatacon\n\nYou can now look back at the inspiring presentation by \n@renebekkers📽️\nhttps://t.co/L8J8WvJWmS https://t.co/qCxf6oiDsr https://t.co/9ZihxaR67A",
      "expandedUrl" : "https://twitter.com/i/web/status/1311666408363704329"
    }
  },
  {
    "like" : {
      "tweetId" : "1311682725229756422",
      "fullText" : "Today Rhoda Odongo @rhodaodongo and Ileen Streefkerk joined @VU_IVM as PhDs in the DOWN2EARTH project @D2E_Project! Happy to virtually welcome them to the team!! 🥳 https://t.co/OBBLemro6G",
      "expandedUrl" : "https://twitter.com/i/web/status/1311682725229756422"
    }
  },
  {
    "like" : {
      "tweetId" : "1311630671354433544",
      "fullText" : "A beautiful and trustworthy face can open doors. While those same doors slam in the face of the one we call unattractive or untrustworthy. #TilburgU https://t.co/AQmNvJ6fEC https://t.co/4X4PpZBZb3",
      "expandedUrl" : "https://twitter.com/i/web/status/1311630671354433544"
    }
  },
  {
    "like" : {
      "tweetId" : "1261734260244914178",
      "fullText" : "Very useful advice for how to do research in #VR... https://t.co/YR7BGrexme",
      "expandedUrl" : "https://twitter.com/i/web/status/1261734260244914178"
    }
  },
  {
    "like" : {
      "tweetId" : "1311253043523080193",
      "fullText" : "@JantsjeMol @networkinstvu @VU_Science Wow looks very impressive!!! https://t.co/1KCXpQ4lcW",
      "expandedUrl" : "https://twitter.com/i/web/status/1311253043523080193"
    }
  },
  {
    "like" : {
      "tweetId" : "1311229343318896646",
      "fullText" : "Tell your students—doctors *do* want you to know that trick! And maybe also tell them to reinvest the time saved into preregistering their hypotheses 😇 (6/6)",
      "expandedUrl" : "https://twitter.com/i/web/status/1311229343318896646"
    }
  },
  {
    "like" : {
      "tweetId" : "1311248645161914368",
      "fullText" : "Last Monday, I got the amazing news that I am one of the 10 finalists for the #Allianz climate risk research award! The winners will be announced next week but I am already really honored that my essay on my work on tropical cyclone risk will be featured in the compendium😊",
      "expandedUrl" : "https://twitter.com/i/web/status/1311248645161914368"
    }
  },
  {
    "like" : {
      "tweetId" : "1311229750518702082",
      "fullText" : "I took a little while, but I finally have my first map on the wall 😃 (Iceland from 1963, such an amazing design! I printed it in 50x40cm)\n\nThank you very much to everybody that helped me find a HQ version of this particular print. Especially 🙏 to @borgar and @cba https://t.co/2hiaxJweS9",
      "expandedUrl" : "https://twitter.com/i/web/status/1311229750518702082"
    }
  },
  {
    "like" : {
      "tweetId" : "1311182392778993664",
      "fullText" : "New paper open for discussion on the creation of event-specific vulnerability curves using Bayesian statistics and a case study of Hurricane Dorian, by our @jens_debruijn @Marleen_Ruiter @Bloemendaal_N and colleagues from @GFDRR &amp; @ResearchTI. https://t.co/R4dGYLIE5h",
      "expandedUrl" : "https://twitter.com/i/web/status/1311182392778993664"
    }
  },
  {
    "like" : {
      "tweetId" : "1310930516141420545",
      "fullText" : "My research with on evacuations during COVID-19 times.  The Hurricane Laura and Sally project includes Mark Welford, Amy Polen, and ELizabeth Dunn\nhttps://t.co/bAN5xefvN4",
      "expandedUrl" : "https://twitter.com/i/web/status/1310930516141420545"
    }
  },
  {
    "like" : {
      "tweetId" : "1310838672099602433",
      "fullText" : "First day of remote teaching went surprisingly well. Live ‘chat’ during a prerecorded lecture was great - lots of fab questions, and much more interactive than a lecture theatre. An unexpected positive was I learnt a lot about what I had/hadn’t explained well in the lecture.",
      "expandedUrl" : "https://twitter.com/i/web/status/1310838672099602433"
    }
  },
  {
    "like" : {
      "tweetId" : "1309039298264600579",
      "fullText" : "We hebben een lekkage en dus heb ik net allemaal dakdekkerswebsites vergeleken. Nu moet ik zelf een bio maken en ben ik geneigd dingen te schrijven als\n\nOddens is dé EXPERT voor al uw Bataafse SPOEDklussen! Vraag nu een offerte aan en ontvang BINNEN 24 UUR historische duiding!",
      "expandedUrl" : "https://twitter.com/i/web/status/1309039298264600579"
    }
  },
  {
    "like" : {
      "tweetId" : "1309056859844812800",
      "fullText" : "Update on https://t.co/6PZ4sCrvJQ: Going strong &amp; doing a cool business incubator by @TUEinnovation! Very useful. And thanks for the card!\n\nNext up: smoke testing of our idea/solution. https://t.co/y8HnuOHiMh",
      "expandedUrl" : "https://twitter.com/i/web/status/1309056859844812800"
    }
  },
  {
    "like" : {
      "tweetId" : "1308824473836171270",
      "expandedUrl" : "https://twitter.com/i/web/status/1308824473836171270"
    }
  },
  {
    "like" : {
      "tweetId" : "1308777940168118273",
      "fullText" : "Perfection! Don't we all love a good Fibonacci sequence? \n\nPs this is former-hurricane and now extratropical cyclone Teddy :) https://t.co/IcE1BTipnl",
      "expandedUrl" : "https://twitter.com/i/web/status/1308777940168118273"
    }
  },
  {
    "like" : {
      "tweetId" : "1308742800696135680",
      "fullText" : "Happy to share our new #openaccess paper on mapping global patterns of land use decision-making @IVM_VU @VU_science @acwfs_VU @ELSenviron  https://t.co/he1DZFQYJv\n\nTogether with @peterverburg11 we studied how contextual conditions can explain why and how we change land use. 1/9 https://t.co/fPWTLkTUWl",
      "expandedUrl" : "https://twitter.com/i/web/status/1308742800696135680"
    }
  },
  {
    "like" : {
      "tweetId" : "1308734522356367361",
      "fullText" : "This morning I felt a bit down,\nthe world seemed depressing and brown.\nSo I threw on some glitter\nand posted on Twitter\nand have now no reason to frown.\n#lunchlimerick",
      "expandedUrl" : "https://twitter.com/i/web/status/1308734522356367361"
    }
  },
  {
    "like" : {
      "tweetId" : "1308718171927523328",
      "fullText" : "You’re unable to view this Post because this account owner limits who can view their Posts. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1308718171927523328"
    }
  },
  {
    "like" : {
      "tweetId" : "1308522020632694789",
      "fullText" : "My mom made me a mask. #psychtwitter #iopsych #measurement https://t.co/Q2UVjSPBdw",
      "expandedUrl" : "https://twitter.com/i/web/status/1308522020632694789"
    }
  },
  {
    "like" : {
      "tweetId" : "1308620737859784705",
      "fullText" : "It finally happened #lifegoals https://t.co/AcNvxKrAO9",
      "expandedUrl" : "https://twitter.com/i/web/status/1308620737859784705"
    }
  },
  {
    "like" : {
      "tweetId" : "1308377551635705856",
      "fullText" : "My paper spent 18 hours at the QJE yesterday.  Sigh.  Well, at least they are fast.",
      "expandedUrl" : "https://twitter.com/i/web/status/1308377551635705856"
    }
  },
  {
    "like" : {
      "tweetId" : "1308312859932332034",
      "fullText" : "Ah, Reference list time. The time to double check that no paper has been given a new issue/page/collection/year number that now seems to invalidate the previous reference. I am curious why we do this, given that I would guess papers are rarely read in their paper version today.",
      "expandedUrl" : "https://twitter.com/i/web/status/1308312859932332034"
    }
  },
  {
    "like" : {
      "tweetId" : "1307028337123045377",
      "fullText" : "Ok wait what just happened?\n\nSubtropical storm Alpha (! Yes we ran out of hurricane names today with Wilfred forming just a few hours earlier. We're now at the Greek alphabet) formed near Portugal (! Not your typical genesis location) today! \n\nI am confused. https://t.co/HviP0OUOcv",
      "expandedUrl" : "https://twitter.com/i/web/status/1307028337123045377"
    }
  },
  {
    "like" : {
      "tweetId" : "1307646411295596551",
      "fullText" : "In mijn hoofd hoor ik de kleine Oriana nog een keer zeggen: “omdat ik teveel van haar hou”. Na een half jaar strijd in mijn hoofd leer ik te accepteren: De wetenschapper is niet vertrokken, maar de wetenschapper is een mens.\n\nEen blog over mijn worsteling. https://t.co/9uVQILYCpy",
      "expandedUrl" : "https://twitter.com/i/web/status/1307646411295596551"
    }
  },
  {
    "like" : {
      "tweetId" : "1307758398134456320",
      "fullText" : "Can people distinguish human-written from #AI-generated text, when they are incentivized to do so?\n\nWhat if human editors select the best outputs?\n\nDo people like AI poetry? \n\nJust out in Computers in Human Behavior\nhttps://t.co/NOq6QbJ04X\nJoint work: @UvA_Amsterdam &amp; @DNB_NL https://t.co/FVBLTIfzKt",
      "expandedUrl" : "https://twitter.com/i/web/status/1307758398134456320"
    }
  },
  {
    "like" : {
      "tweetId" : "1307765979909369857",
      "fullText" : "I've been going through a rough patch lately, so a reminder for everyone who needs it: be kind to yourself and take a break if you need one. We are still in a pandemic and your mental health is important! ♥️ https://t.co/KCZMiOzP2g",
      "expandedUrl" : "https://twitter.com/i/web/status/1307765979909369857"
    }
  },
  {
    "like" : {
      "tweetId" : "1307784493831524356",
      "expandedUrl" : "https://twitter.com/i/web/status/1307784493831524356"
    }
  },
  {
    "like" : {
      "tweetId" : "1306840207350693889",
      "fullText" : "Ha! No way. I enjoy watching you squirm. https://t.co/NsEWphFUsp",
      "expandedUrl" : "https://twitter.com/i/web/status/1306840207350693889"
    }
  },
  {
    "like" : {
      "tweetId" : "1306660469596450818",
      "fullText" : "After last night’s tweet, I’ve realized a lot about #EconTwitter \n\n1. It is the most wholesome network \n2. I’ve received guidance about opportunities/experiences \n3. I’ve connected w/ SO many amazing people\n4. I am so happy to be here\n5. Can’t wait to pay this forward one day😭",
      "expandedUrl" : "https://twitter.com/i/web/status/1306660469596450818"
    }
  },
  {
    "like" : {
      "tweetId" : "1306765397262295041",
      "fullText" : "@MN_Econ https://t.co/lc1Eq8LYWy",
      "expandedUrl" : "https://twitter.com/i/web/status/1306765397262295041"
    }
  },
  {
    "like" : {
      "tweetId" : "1306621759052017664",
      "fullText" : "Vanavond om 19:30 ben ik in RTL Nieuws te zien over het dashboard en regionale maatregelen. Met een beetje uitleg over de 'escalatieladder' (lees: kleurcodes) en hoe de 'instrumentenkist' (lees: maatregelen) op het dashboard moeten staan.",
      "expandedUrl" : "https://twitter.com/i/web/status/1306621759052017664"
    }
  },
  {
    "like" : {
      "tweetId" : "1306549731204706305",
      "fullText" : "Congratulations Dr. @Marleen_Ruiter ! https://t.co/5JhYpCqb0N",
      "expandedUrl" : "https://twitter.com/i/web/status/1306549731204706305"
    }
  },
  {
    "like" : {
      "tweetId" : "1306531043390914562",
      "fullText" : "@Marleen_Ruiter is currently defending her thesis! https://t.co/26VYflai9k",
      "expandedUrl" : "https://twitter.com/i/web/status/1306531043390914562"
    }
  },
  {
    "like" : {
      "tweetId" : "1306508959348649984",
      "fullText" : "At 11.45, my dear friend and colleague will defend her PhD thesis ! The more, the merrier, please join us at https://t.co/C7A7zsTrAp\nI can already tell that it will be a good one!! https://t.co/o9LylLA9Q1",
      "expandedUrl" : "https://twitter.com/i/web/status/1306508959348649984"
    }
  },
  {
    "like" : {
      "tweetId" : "1306313376654659587",
      "fullText" : "@paulhudson028 @seatsixtyone We should just call it Britishstar and the 'Get back control tunnel'",
      "expandedUrl" : "https://twitter.com/i/web/status/1306313376654659587"
    }
  },
  {
    "like" : {
      "tweetId" : "1305964364667793410",
      "fullText" : "Working on a revise &amp; resubmit\n\nRef 1: \"I would like to emphasize that I strongly feel that this paper is suitable for publication in X (as well as frankly higher-ranked journals)\" Then 2 paras of praise for our work\n\nNever happened to me ever before, thanks for making my day R1 https://t.co/umdAEQwB7k",
      "expandedUrl" : "https://twitter.com/i/web/status/1305964364667793410"
    }
  },
  {
    "like" : {
      "tweetId" : "1306216675210002432",
      "fullText" : "#AcademicTwitter #phdchat @OpenAcademics \n\nIs anyone here addicted to specific font when they write?\n\nI absolutely refuse to read or write if it is not Times New Roman🤓\n\nI have a collaborator who is Calibri person, every draft I change to Times and he reverts to Calibri🤣🧬",
      "expandedUrl" : "https://twitter.com/i/web/status/1306216675210002432"
    }
  },
  {
    "like" : {
      "tweetId" : "1306215442365788161",
      "fullText" : "Getting ready for physical experiments while still improving the interface of my online experiments. Curious which research line will turn out more promising https://t.co/QDI4VNH7Rw",
      "expandedUrl" : "https://twitter.com/i/web/status/1306215442365788161"
    }
  },
  {
    "like" : {
      "tweetId" : "1305795198207705088",
      "fullText" : "We are pleased to welcome @cnvanderwal in the managing team of this twitter account!\nThanks for helping us (@Milad_Haghani and @r_lovreglio) https://t.co/PAtTJHSL52",
      "expandedUrl" : "https://twitter.com/i/web/status/1305795198207705088"
    }
  },
  {
    "like" : {
      "tweetId" : "1305937218255626240",
      "fullText" : "The best recommendation of the day from one student: drink wine instead of coffee to reduce your environmental #footprint :) joke aside, we all should be better informed of how we impact the environment in our every day lives!",
      "expandedUrl" : "https://twitter.com/i/web/status/1305937218255626240"
    }
  },
  {
    "like" : {
      "tweetId" : "1306099030888452096",
      "fullText" : "Someone is having a good time at NHC 😆🐻 https://t.co/eElQZPzumf",
      "expandedUrl" : "https://twitter.com/i/web/status/1306099030888452096"
    }
  },
  {
    "like" : {
      "tweetId" : "1305589209248468993",
      "fullText" : "Check out our new VR video depicting #Hull at the time of the 1646 flood. We (@RenRuins @FloodSkinner @BetaJesterLtd and others) had so much fun making it happen! 👇👇👇 https://t.co/RAMI7ehlzL",
      "expandedUrl" : "https://twitter.com/i/web/status/1305589209248468993"
    }
  },
  {
    "like" : {
      "tweetId" : "1305667539922550784",
      "fullText" : "In video meetings it's a hassle to unmute just to say one word especially if someone else is speaking. I created a video lens that uses hand gestures to show comic-book style messages instead. So far it's been pretty fun! https://t.co/wp6XO5QDQc",
      "expandedUrl" : "https://twitter.com/i/web/status/1305667539922550784"
    }
  },
  {
    "like" : {
      "tweetId" : "1305765874746392576",
      "fullText" : "First day of school...ehm postdoc here at @GATE_LSE ! Looks amazing, I'm very excited!! It also seems like I will still be able to play table tennis in the breaks! Hurray :D https://t.co/w9kVrAsNEH",
      "expandedUrl" : "https://twitter.com/i/web/status/1305765874746392576"
    }
  },
  {
    "like" : {
      "tweetId" : "1305430832904101895",
      "fullText" : "Back to #teaching? \n\nFeel free to use (at your own risk 😉) my @oTree \"classic\" #experiments with your students.\n\nYou find the code and the description in my @GitHub repository\nhttps://t.co/PFb8IUzfBU\n\nI keep updating it and new apps are coming soon.",
      "expandedUrl" : "https://twitter.com/i/web/status/1305430832904101895"
    }
  },
  {
    "like" : {
      "tweetId" : "1305390106862399488",
      "fullText" : "Hot off the press our new paper in #LandscapeEcology led by Miguel Cebrian looking into how local and scientific #knowledge are related to #perceptions of #ecosystemservices and #human-nature relationships in @PNGuadarrama @YESS_Network @Envision2050. https://t.co/oVFjx3S0X1",
      "expandedUrl" : "https://twitter.com/i/web/status/1305390106862399488"
    }
  },
  {
    "like" : {
      "tweetId" : "1276289979887599617",
      "fullText" : "I presented for the first time at a conference today. No one said anything during the talk or the Q&amp;A segment, but I have received encouraging emails and messages after.\n#phdlife",
      "expandedUrl" : "https://twitter.com/i/web/status/1276289979887599617"
    }
  },
  {
    "like" : {
      "tweetId" : "1304794628080762883",
      "fullText" : "I bought my 1st NatGeo in a thrift shop back in 2007 when I was 15. My English wasn't sufficient enough to fully understand everything, but I was intrigued by the photos of hurricane damages.\n\nLittle did I know I'll be finishing my PhD on tropical cyclone risk 8 months from now😊 https://t.co/Svj7c5Cx8T",
      "expandedUrl" : "https://twitter.com/i/web/status/1304794628080762883"
    }
  },
  {
    "like" : {
      "tweetId" : "1304796622438662145",
      "fullText" : "And DONE. 55 hours of #2020ESAGlobal conference are over. Big thanks go to all organizers, graduate student helpers, and Walter and his @MobLab team for putting this together. And thank you of course to our ~600 participants and presenters for sharing your research with us! https://t.co/Ink7mZHIyk",
      "expandedUrl" : "https://twitter.com/i/web/status/1304796622438662145"
    }
  },
  {
    "like" : {
      "tweetId" : "1304351536613666816",
      "fullText" : "Productivity tip: Make sure there's one thing on your to-do list you absolutely dread. Nothing like a task your REALLY don't want to do to get the other stuff done. #proflife #AcademicChatter https://t.co/5ODptGCeYp",
      "expandedUrl" : "https://twitter.com/i/web/status/1304351536613666816"
    }
  },
  {
    "like" : {
      "tweetId" : "1304351397350174720",
      "fullText" : "Holding a pre-registration reveal party, announcing which set of hypotheses will be reported\n\n#academictwitter #AcademicChatter #phdchat #psychtwitter https://t.co/OObX8KKyVf",
      "expandedUrl" : "https://twitter.com/i/web/status/1304351397350174720"
    }
  },
  {
    "like" : {
      "tweetId" : "1304322672118108160",
      "fullText" : "Today I will present a paper on how observability affects lying decisions at #2020ESAGlobal. If you are interested tune in at 12:00 CET, 3 am LA. https://t.co/bjLDgRtAda",
      "expandedUrl" : "https://twitter.com/i/web/status/1304322672118108160"
    }
  },
  {
    "like" : {
      "tweetId" : "1304163503381643264",
      "expandedUrl" : "https://twitter.com/i/web/status/1304163503381643264"
    }
  },
  {
    "like" : {
      "tweetId" : "1304293813310107650",
      "fullText" : "Toddler wisdom: social distancing is easier when you add some garlic to the laundry",
      "expandedUrl" : "https://twitter.com/i/web/status/1304293813310107650"
    }
  },
  {
    "like" : {
      "tweetId" : "1303970784755494912",
      "fullText" : "Mail van de Centrale Bank van Nigeria. Toch triest dat je als inwoner van Nederland meer contact hebt met de nationale bank van een West-Afrikaans land dan met je eigen DNB.",
      "expandedUrl" : "https://twitter.com/i/web/status/1303970784755494912"
    }
  },
  {
    "like" : {
      "tweetId" : "1303975279505924098",
      "expandedUrl" : "https://twitter.com/i/web/status/1303975279505924098"
    }
  },
  {
    "like" : {
      "tweetId" : "1303828483534196738",
      "fullText" : "Whoa! :-) @R_Thaler @CassSunstein @ideas42 @UofT_BEAR https://t.co/xgL6Wzbjmi",
      "expandedUrl" : "https://twitter.com/i/web/status/1303828483534196738"
    }
  },
  {
    "like" : {
      "tweetId" : "1303809131351027716",
      "expandedUrl" : "https://twitter.com/i/web/status/1303809131351027716"
    }
  },
  {
    "like" : {
      "tweetId" : "1301814233190068224",
      "fullText" : "We need better-informed decision-making to adapt in a changing climate.\n\nJoin our workshop with @CmccClimate &amp; learn how climate adaptation modelling can be a key tool in building climate resilience. 🌍🌱\n\n📅 Date: 8-10 September\n\n👉🏼https://t.co/HkGi5j7B6H\n#EUAdaptationStrategy https://t.co/1kzPqPf1tj",
      "expandedUrl" : "https://twitter.com/i/web/status/1301814233190068224"
    }
  },
  {
    "like" : {
      "tweetId" : "1303641211165642752",
      "fullText" : "👏🏽Congrats, Nickolas Gagnon! 👏🏽We had today a successful Cum Laude PhD dissertation at Maastricht University. \nIf you are interested in discrimination in the labor market, this excellent piece of work is more than recommended. #EconTwitter https://t.co/fYrtXcWhia",
      "expandedUrl" : "https://twitter.com/i/web/status/1303641211165642752"
    }
  },
  {
    "like" : {
      "tweetId" : "1303587939306405888",
      "fullText" : "I am strangely excited about this conference. Been to ESA meetings since 2003 (Erfurt!) and this is the first online meeting. From the cat memes, I am sure it will be as cool as the real meetings. Though I will miss seeing all of you in person... https://t.co/34NPl5r8wB",
      "expandedUrl" : "https://twitter.com/i/web/status/1303587939306405888"
    }
  },
  {
    "like" : {
      "tweetId" : "1303598128193568768",
      "expandedUrl" : "https://twitter.com/i/web/status/1303598128193568768"
    }
  },
  {
    "like" : {
      "tweetId" : "1303481816586874883",
      "fullText" : "Here is the link to a potentially useful Excel template for planning your very own virtual ESA program: https://t.co/jAN0KJN1hK  Like the colors? https://t.co/a67lFcENUw",
      "expandedUrl" : "https://twitter.com/i/web/status/1303481816586874883"
    }
  },
  {
    "like" : {
      "tweetId" : "1303252424468189184",
      "fullText" : "Erg geestig dit kunstproject. Met een serieuze ondertoon. \"In je eigen tuin demonstreren op het Malieveld? Willem maakt het mogelijk\" https://t.co/aQlPUNe7PE",
      "expandedUrl" : "https://twitter.com/i/web/status/1303252424468189184"
    }
  },
  {
    "like" : {
      "tweetId" : "1302878793305149442",
      "expandedUrl" : "https://twitter.com/i/web/status/1302878793305149442"
    }
  },
  {
    "like" : {
      "tweetId" : "1242157200488964097",
      "fullText" : "We want to share our resources as widely as possible, especially for those of you teaching your own children at home. Today's post shows you how to try our Flash Flood! activity at home. Please share widely.\n\nhttps://t.co/4kChjd6YAx https://t.co/ySIw8giOmL",
      "expandedUrl" : "https://twitter.com/i/web/status/1242157200488964097"
    }
  },
  {
    "like" : {
      "tweetId" : "1301856717525995520",
      "fullText" : "That's him, what a nice croc. https://t.co/plK8GF5TKX",
      "expandedUrl" : "https://twitter.com/i/web/status/1301856717525995520"
    }
  },
  {
    "like" : {
      "tweetId" : "1301483656536625152",
      "fullText" : "@JoelvdWeele @Max_Planck_CHM @mpib_berlin https://t.co/kyPrASuBdW",
      "expandedUrl" : "https://twitter.com/i/web/status/1301483656536625152"
    }
  },
  {
    "like" : {
      "tweetId" : "1295532829707628546",
      "fullText" : "It struck me today that the title of my job market paper is so clunky that anytime I have to enter it into some form I have to open the pdf to double-check.\n\nOne-word titles from now on I think.",
      "expandedUrl" : "https://twitter.com/i/web/status/1295532829707628546"
    }
  },
  {
    "like" : {
      "tweetId" : "1301128526649872384",
      "fullText" : "If you’re more a fan of the video format, the main points of the paper are summarized in this recorded talk I gave for @riotscienceNL: https://t.co/lLCTHKUlfV",
      "expandedUrl" : "https://twitter.com/i/web/status/1301128526649872384"
    }
  },
  {
    "like" : {
      "tweetId" : "1301088544845377536",
      "fullText" : "Working from home :) works like a charm, I just have to figure out how to drink coffee. Hot with a straw or cold? #homeoffice #workingdad https://t.co/HkvATdIJA2",
      "expandedUrl" : "https://twitter.com/i/web/status/1301088544845377536"
    }
  },
  {
    "like" : {
      "tweetId" : "1301090061811884032",
      "fullText" : "Of course, he's also here #businesscat https://t.co/Kzuym53kGZ",
      "expandedUrl" : "https://twitter.com/i/web/status/1301090061811884032"
    }
  },
  {
    "like" : {
      "tweetId" : "1300867617641492481",
      "fullText" : "Hello #EconTwitter and other friends--I'm back. For now.  And without a clear sense of what my mission is.",
      "expandedUrl" : "https://twitter.com/i/web/status/1300867617641492481"
    }
  },
  {
    "like" : {
      "tweetId" : "1300903321587388417",
      "fullText" : "First day of lectures on sustainability and environmental change! Around 80 students from all around the world took part in today's lecture. Zoom worked great, and I actually had more interactions and questions than usually :) https://t.co/WcNM60ABbG",
      "expandedUrl" : "https://twitter.com/i/web/status/1300903321587388417"
    }
  },
  {
    "like" : {
      "tweetId" : "1301039980563828736",
      "fullText" : "Logging into twitter and discover that many people liked your freshly completed working paper is a great way to start the day!\n\nThanks @DurRobert for sharing it! https://t.co/kYqnA48k4J",
      "expandedUrl" : "https://twitter.com/i/web/status/1301039980563828736"
    }
  },
  {
    "like" : {
      "tweetId" : "1298694326776664064",
      "fullText" : "In this job-hunting, i worry about skill loss. Also, It is hard to focus on other things when you have to go through this frustrating process. Leaves you with limited energy. Somedays I am not that optimistic, and today is that day.",
      "expandedUrl" : "https://twitter.com/i/web/status/1298694326776664064"
    }
  },
  {
    "like" : {
      "tweetId" : "1298973179034112001",
      "fullText" : "Science works. https://t.co/OKiHSdAqsF",
      "expandedUrl" : "https://twitter.com/i/web/status/1298973179034112001"
    }
  },
  {
    "like" : {
      "tweetId" : "1298806668063657984",
      "fullText" : "Following tradition (?), @nicolerogersc sends her second submission of wines that are appropriate for a statistician https://t.co/VAF6cGF451",
      "expandedUrl" : "https://twitter.com/i/web/status/1298806668063657984"
    }
  },
  {
    "like" : {
      "tweetId" : "1298940006187311105",
      "fullText" : "This Post is from a suspended account. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1298940006187311105"
    }
  },
  {
    "like" : {
      "tweetId" : "1298661267310247936",
      "fullText" : "Can we nudge people towards more sustainable food options? Maybe, but it's messy. In two field studies we examined whether sustainable menu labels prompt more sustainable dining choices in a university cafe, now out in Appetite. 1/x\n\nhttps://t.co/vlzDFnBAbB https://t.co/PU4pJuZgIU",
      "expandedUrl" : "https://twitter.com/i/web/status/1298661267310247936"
    }
  },
  {
    "like" : {
      "tweetId" : "1298882223614169097",
      "fullText" : "3. Together with @JantsjeMol @amynpolen @Jennife80870085 we designed a new scale to categorize tropical cyclones, also taking rainfall and storm surge into account. Laura would be categorized as a Cat 5 due to its 20ft storm surge (forecast). Paper is currently under revision.",
      "expandedUrl" : "https://twitter.com/i/web/status/1298882223614169097"
    }
  },
  {
    "like" : {
      "tweetId" : "1298848716594589696",
      "fullText" : "Meanwhile, here’s to this NOAA crew who flew a P-3 through a hurricane for 8 hours to gather data to improve forecasts. https://t.co/8Rm0LsfkD4",
      "expandedUrl" : "https://twitter.com/i/web/status/1298848716594589696"
    }
  },
  {
    "like" : {
      "tweetId" : "1298270079960748036",
      "fullText" : "🚨Special Issue on ‘Social #Norms &amp; Behavior Change’ in JEBO🚨\n\nSend us your experimental/empirical/theoretical work at the intersection of norms &amp; behavior change, including #nudging. \n\nSubmissions open *Sept 1*, more details👇🏻\n\n@mhallsworth @BrendanNyhan @CassSunstein @R_Thaler https://t.co/d03Njoa845",
      "expandedUrl" : "https://twitter.com/i/web/status/1298270079960748036"
    }
  },
  {
    "like" : {
      "tweetId" : "1298132576213831680",
      "fullText" : "@Leefomgeving That #energyefficient #renovations do generally not pay off is not the kind of message you want to spread as policy maker facing a huge #energytransition. The @Leefomgeving study illustrates the challenge ahead and calls for stronger support measures",
      "expandedUrl" : "https://twitter.com/i/web/status/1298132576213831680"
    }
  },
  {
    "like" : {
      "tweetId" : "1293643608269062144",
      "fullText" : "In February, a journal sent my manuscript back, asking for revisions. Then my mom died. Then the pandemic hit. Then my dad died. Today, I resubmitted. Can I get a WHAT, WHAT!",
      "expandedUrl" : "https://twitter.com/i/web/status/1293643608269062144"
    }
  },
  {
    "like" : {
      "tweetId" : "1293520448492318728",
      "fullText" : "You’re unable to view this Post because this account owner limits who can view their Posts. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1293520448492318728"
    }
  },
  {
    "like" : {
      "tweetId" : "1293523829659246596",
      "fullText" : "Second version of my Lissajous curve exploration with ellipses + a colored line.\n\nA4 Bristol 250gsm paper with a Red Promarker &amp; Black Pilot G-TEC-C4 pen.\n\n#plottertwitter #axidraw https://t.co/8MMcYP1dGY",
      "expandedUrl" : "https://twitter.com/i/web/status/1293523829659246596"
    }
  },
  {
    "like" : {
      "tweetId" : "1289249577246236672",
      "fullText" : "For now, I get to stay at @ESHPM_EUR and continue my research and teaching. I'm not sure what the future will bring, if I'll ever feel like an 'economist' and where I'll work in a couple of years, but I look forward to finding out! Sorry for the #rambling! #Phdlife #EconTwitter",
      "expandedUrl" : "https://twitter.com/i/web/status/1289249577246236672"
    }
  },
  {
    "like" : {
      "tweetId" : "1291289586518245377",
      "fullText" : "Working from home!\n\n#AcademicTwitter @AcademicChatter #WFH #WorkFromHome https://t.co/IAt5OBVsAS",
      "expandedUrl" : "https://twitter.com/i/web/status/1291289586518245377"
    }
  },
  {
    "like" : {
      "tweetId" : "1290963191137280002",
      "fullText" : "We thank Nisa et al. for making data available so we could do our own analyses &amp; arrive at our own conclusions about the impact of behavior change interventions. We learned a lot from this process &amp; we hope the authors did too. Science as it should be: a fruitful exchange.\n\nEND",
      "expandedUrl" : "https://twitter.com/i/web/status/1290963191137280002"
    }
  },
  {
    "like" : {
      "tweetId" : "1290978384777011200",
      "fullText" : "I’m so disheartened by the competitiveness of science today. Been reviewing applications for tenure-track positions, PhD projects &amp; nominations for awards in the past days/weeks. So many amazing people… Please let the the end of the rainbow exist! Any research on this? 😨 https://t.co/zJVii6bfr8",
      "expandedUrl" : "https://twitter.com/i/web/status/1290978384777011200"
    }
  },
  {
    "like" : {
      "tweetId" : "1241459089844076550",
      "fullText" : "Prevention is still the best approach to crisis management. Here follows my humble contribution to the DRR community : https://t.co/4DwdC0yOLw  @EarthsFutureEiC",
      "expandedUrl" : "https://twitter.com/i/web/status/1241459089844076550"
    }
  },
  {
    "like" : {
      "tweetId" : "1290375288342315015",
      "fullText" : "for stage 15 of our #biketour #amsterdam to #venice our two-cyclists+monkey team was reinforced by Stefi’s cousin Andrea, to do the heavy front riding&amp;take the peloton to #Trento. Then the rain hit us on the last steep climb and unfortunately never left... -w/ @JoelvdWeele ❤️🇪🇺☔️ https://t.co/YeELpIH210",
      "expandedUrl" : "https://twitter.com/i/web/status/1290375288342315015"
    }
  },
  {
    "like" : {
      "tweetId" : "1290393457991864324",
      "fullText" : "Elissa Kranzler, Risk Center Research Fellow, and colleagues, have recently published research on risk communication strategies. Read \"Identifying Promising Messages to Increase Hurricane Mitigation Among Coastal Homeowners in the United States\" here: https://t.co/TvQFQaGBEI",
      "expandedUrl" : "https://twitter.com/i/web/status/1290393457991864324"
    }
  },
  {
    "like" : {
      "tweetId" : "1273710146506629120",
      "expandedUrl" : "https://twitter.com/i/web/status/1273710146506629120"
    }
  },
  {
    "like" : {
      "tweetId" : "1237518566598963200",
      "fullText" : "As promised, here is some base #rstats code to generate a specification chart.\n\nI'm including a reproducible example so you can understand the possibilities and how to customize the chart. \n\nFeel free to share. Let's make appendices shorter!\n\nhttps://t.co/FwIEoCOdaq https://t.co/rPOwo7xJO9",
      "expandedUrl" : "https://twitter.com/i/web/status/1237518566598963200"
    }
  },
  {
    "like" : {
      "tweetId" : "1289095680578002945",
      "fullText" : "Dat zeg ik ook altijd tegen mezelf. En ben er nog tevreden mee ook. https://t.co/RNqzdgw7yS",
      "expandedUrl" : "https://twitter.com/i/web/status/1289095680578002945"
    }
  },
  {
    "like" : {
      "tweetId" : "1288783827289202693",
      "fullText" : "Wie had dat gedacht: Van rekenen in je vrije tijd, naar invloed op het beleid.\n\nErg blij om te zien dat we op deze manier ook ons steentje kunnen bijdragen aan het leerproces in deze crisis. Hopelijk helpt onze bijdrage in het verbeteren van het dashboard! https://t.co/FLsSve6mWM",
      "expandedUrl" : "https://twitter.com/i/web/status/1288783827289202693"
    }
  },
  {
    "like" : {
      "tweetId" : "1288799904534540294",
      "fullText" : "Together with @the_IDB, we are looking at how future global change might impact the forest cover in the #Amazon region. Red is cropland, yellow is pasture. Stay tuned for more updates! https://t.co/wWZs7serxg",
      "expandedUrl" : "https://twitter.com/i/web/status/1288799904534540294"
    }
  },
  {
    "like" : {
      "tweetId" : "1288490035029970944",
      "fullText" : "me trying to not have bad posture from coding all day https://t.co/l4GnlewdtB",
      "expandedUrl" : "https://twitter.com/i/web/status/1288490035029970944"
    }
  },
  {
    "like" : {
      "tweetId" : "1288492840264314880",
      "fullText" : "Here's some great news.  Anya Samek receives the Vernon Smith Ascending Scholar award! Congratulations @AnyaSamek !!\n\nhttps://t.co/KxthxwOqvp",
      "expandedUrl" : "https://twitter.com/i/web/status/1288492840264314880"
    }
  },
  {
    "like" : {
      "tweetId" : "1288303036012457984",
      "fullText" : "Don't know what people think of when they think of #HongKong, but here's a bit from a morning #hike ... https://t.co/w9vPelCLCw",
      "expandedUrl" : "https://twitter.com/i/web/status/1288303036012457984"
    }
  },
  {
    "like" : {
      "tweetId" : "1287935733274218504",
      "fullText" : "Introduction to R for Social and Behavioral Sciences  {https://t.co/m4OY6LhL5n} #rstats #DataScience",
      "expandedUrl" : "https://twitter.com/i/web/status/1287935733274218504"
    }
  },
  {
    "like" : {
      "tweetId" : "1286325387069448192",
      "fullText" : "Happy news during otherwise gloomy times: my H-1B has been approved &amp; I can finally start my new position @Penn! Feeling relieved to reduce my existential angst of having to leave everything behind\n\nHoping the best for those who have been anxiously waiting for theirs (@jonj💪🏻) https://t.co/gEJBFoJsZB",
      "expandedUrl" : "https://twitter.com/i/web/status/1286325387069448192"
    }
  },
  {
    "like" : {
      "tweetId" : "1287729032281366529",
      "fullText" : "One day I'll understand git, but today is not that day\n\nhttps://t.co/zyiqpW1bu0 https://t.co/XFuv0mb6r3",
      "expandedUrl" : "https://twitter.com/i/web/status/1287729032281366529"
    }
  },
  {
    "like" : {
      "tweetId" : "1287743696486752258",
      "fullText" : "Important new paper out today from @ElizabethLinos &amp; @sdellavi. Looks at all the data from @BITAmericas &amp; @OESgov to ask: what impact do nudges have in the real world? \n\nConclusion: 8% improvement (1.4 % points) in outcomes across 165 trials. \n\nPaper: https://t.co/qdHClmeSC6 1/6 https://t.co/kUqCoQDlaF",
      "expandedUrl" : "https://twitter.com/i/web/status/1287743696486752258"
    }
  },
  {
    "like" : {
      "tweetId" : "1287653295453089792",
      "fullText" : "Good start of the week. It's great to see editors and reviewers appreciating such projects. Hoping to see this paper in print soon... https://t.co/vX5eojuWDl",
      "expandedUrl" : "https://twitter.com/i/web/status/1287653295453089792"
    }
  },
  {
    "like" : {
      "tweetId" : "1286624865349443584",
      "fullText" : "The only work I'm doing today is a one hour call for a project with a friend (academic work) and an essay length email to a UG who had questions about the #PhD.\n\nIt's my #mentalhealthday. Don't even try judging me.\n\nHere's Angela Lansbury in all her fabulousness ;) https://t.co/Prtw4giRiQ",
      "expandedUrl" : "https://twitter.com/i/web/status/1286624865349443584"
    }
  },
  {
    "like" : {
      "tweetId" : "1286561645267955712",
      "fullText" : "Eindnoot 3: Ik dank @statistiekcbs voor het publiceren van een R package, waardoor dit compleet geautomatiseerd kan :) En dank aan alle andere corona-dataverwerkers! Rutte geparafraseerd: 'Alleen samen krijgen we corona-data onder controle.'",
      "expandedUrl" : "https://twitter.com/i/web/status/1286561645267955712"
    }
  },
  {
    "like" : {
      "tweetId" : "1286242237647593472",
      "fullText" : "@JantsjeMol @sabeconomics https://t.co/q7myVlmrur",
      "expandedUrl" : "https://twitter.com/i/web/status/1286242237647593472"
    }
  },
  {
    "like" : {
      "tweetId" : "1286030219598422016",
      "fullText" : "I only just recently realized that you can rename variables within dplyr::select().😳 It's a very small thing, but I'll be using this more often now. #rstats https://t.co/msbuTArX77",
      "expandedUrl" : "https://twitter.com/i/web/status/1286030219598422016"
    }
  },
  {
    "like" : {
      "tweetId" : "1285934650200907777",
      "fullText" : "SABE 2020 Conference in Moscow has started this morning: https://t.co/Taiqkp6CHW\nIt will last until this Sunday, July 26, with 124 talks by researchers in Behavioral Economics, and 3 keynote speakers - Marie Claire Villeval (Herbert Simon lecture), Simon Gaechter, Martin Kocher.",
      "expandedUrl" : "https://twitter.com/i/web/status/1285934650200907777"
    }
  },
  {
    "like" : {
      "tweetId" : "1285857603130662912",
      "fullText" : "Happy to announce my upcoming public PhD defence (15/10). Don't know if it'll (also) be digital. The dissertation will be published some time beforehand. Let me know if you'd like a (digital) copy! #PhD #PhDone #EconTwitter\nhttps://t.co/jwAljNciLi",
      "expandedUrl" : "https://twitter.com/i/web/status/1285857603130662912"
    }
  },
  {
    "like" : {
      "tweetId" : "1285854495826739200",
      "fullText" : "@JantsjeMol @VUamsterdam That's so kind! Thank you, @JantsjeMol I sent you an email, hopefully to the right address 😇",
      "expandedUrl" : "https://twitter.com/i/web/status/1285854495826739200"
    }
  },
  {
    "like" : {
      "tweetId" : "1285832789137465344",
      "fullText" : "Waarvan akte https://t.co/Dnd92Dpd5g",
      "expandedUrl" : "https://twitter.com/i/web/status/1285832789137465344"
    }
  },
  {
    "like" : {
      "tweetId" : "1285845008755630081",
      "fullText" : "Iets wat ik elke maand, week en dag doe is een overzicht maken van de openstaande taken. Dit schrijf ik op in mijn versie van een bullet journal. Hier een korte video waarin je kunt zien wat er zo al in staat. https://t.co/jKAJ8aGoCv",
      "expandedUrl" : "https://twitter.com/i/web/status/1285845008755630081"
    }
  },
  {
    "like" : {
      "tweetId" : "1285667838347350018",
      "fullText" : "@JantsjeMol perhaps we should include a video in our reviewer response of how we're collecting data from hundreds of tropical cyclone reports, and how that makes us feel 😅 https://t.co/G3tiwkNEeK",
      "expandedUrl" : "https://twitter.com/i/web/status/1285667838347350018"
    }
  },
  {
    "like" : {
      "tweetId" : "1285471013229268994",
      "fullText" : "11 Days ago we submitted this video to https://t.co/u4dHUPxpJ1. They will fund selected companies with 3 million usd, for 20% of shares. Yesterday we heard the results will come in next Wednesday!\n\nhttps://t.co/GKBSvKaO23",
      "expandedUrl" : "https://twitter.com/i/web/status/1285471013229268994"
    }
  },
  {
    "like" : {
      "tweetId" : "1285434498662817797",
      "fullText" : "*opens prestigious journal ToC*\n\n*clicks on interesting looking article*\n\n“We conducted a 2x2 ANOVA, n = 50”\n\n*closes tab*",
      "expandedUrl" : "https://twitter.com/i/web/status/1285434498662817797"
    }
  },
  {
    "like" : {
      "tweetId" : "1284973898669461512",
      "fullText" : "To clarify: I’ll be reading the intro chapter and actual professional audiobook narrator @GabraZackman is reading the rest of the book because she is great and also has a home recording studio that is not just bedclothes on lamps. #EndOfEverythingBook",
      "expandedUrl" : "https://twitter.com/i/web/status/1284973898669461512"
    }
  },
  {
    "like" : {
      "tweetId" : "1284034742812368896",
      "fullText" : "Marthe Wens @Ted1388 &amp; others @VU_IVM \"Simulating Small-Scale Agricultural Adaptation Decisions in Response to Drought Risk: An Empirical Agent-Based Model for Semi-Arid Kenya\" &gt; ignoring household characteristics leads to underestimation of food-aid needs https://t.co/8rS8UauQLe",
      "expandedUrl" : "https://twitter.com/i/web/status/1284034742812368896"
    }
  },
  {
    "like" : {
      "tweetId" : "1282613663791226880",
      "fullText" : "All the way up! ↗️🆙📈Quick visit at the office after 4 months.. #nudgeseverywhere #behavioralscience #goodtobeback #physicaldistancing https://t.co/suF6VPVrQr",
      "expandedUrl" : "https://twitter.com/i/web/status/1282613663791226880"
    }
  },
  {
    "like" : {
      "tweetId" : "1276144837004275713",
      "fullText" : "De VU had zomaar in Epe kunnen staan. En het verhuisde hoofdgebouw zou eigenlijk een glazen gevel krijgen. Een park zou de campus worden... Mooie ontdekkingen van universiteitshistoricus @FlipseAb @VUamsterdam @advalvas_vu https://t.co/duz7YUR2Ko https://t.co/lchPMi4U7j",
      "expandedUrl" : "https://twitter.com/i/web/status/1276144837004275713"
    }
  },
  {
    "like" : {
      "tweetId" : "1276465238108524544",
      "fullText" : "Mmh, not sure whether I should feel flattered or offended: Mendeley suggests that I read my own paper... https://t.co/LGnPM2O9c8",
      "expandedUrl" : "https://twitter.com/i/web/status/1276465238108524544"
    }
  },
  {
    "like" : {
      "tweetId" : "1276427941229051906",
      "fullText" : "@VU_IVM @JantsjeMol @Marleen_Ruiter ...its been that long already! Best of luck to him.",
      "expandedUrl" : "https://twitter.com/i/web/status/1276427941229051906"
    }
  },
  {
    "like" : {
      "tweetId" : "1276426281547190274",
      "fullText" : "Our colleague Pete Robinson is defending his PhD. \n\nYou can attend the defence here: https://t.co/edysCnltXX https://t.co/l4dA33Y720",
      "expandedUrl" : "https://twitter.com/i/web/status/1276426281547190274"
    }
  },
  {
    "like" : {
      "tweetId" : "1276158535127248901",
      "fullText" : "@JantsjeMol @MinIenW @AnneValkengoed Snel! Dankjewel 😀",
      "expandedUrl" : "https://twitter.com/i/web/status/1276158535127248901"
    }
  },
  {
    "like" : {
      "tweetId" : "1276098344520224768",
      "fullText" : "@JantsjeMol @MinIenW @AnneValkengoed Ergens terug te zien?:)))",
      "expandedUrl" : "https://twitter.com/i/web/status/1276098344520224768"
    }
  },
  {
    "like" : {
      "tweetId" : "1276085754171719687",
      "fullText" : "Must see! Tentoonstelling Lucas Gassel in @MuseumHelmond Verrassende en gedetailleerde schilderijen, vooral mooi van landschappen en architectuur. Omdat je er met je neus bovenop kunt staan, echt een genot https://t.co/dvYYKWT8qo",
      "expandedUrl" : "https://twitter.com/i/web/status/1276085754171719687"
    }
  },
  {
    "like" : {
      "tweetId" : "1275838256517693440",
      "fullText" : "Even though it didn’t happen in a normal setting, this day is a Ph. antastic D. ay! I am Ph. inally D. one! \nYou treated me well @VTAgEcon! Now let’s go find new adventures at the @WPCareySchool and @ASU as an Assistant Professor. https://t.co/yREbLwUmXx",
      "expandedUrl" : "https://twitter.com/i/web/status/1275838256517693440"
    }
  },
  {
    "like" : {
      "tweetId" : "1275968754023833600",
      "fullText" : "There are at least 5 recent #EconTwitter topics that this could apply to. https://t.co/YvFslPlL57",
      "expandedUrl" : "https://twitter.com/i/web/status/1275968754023833600"
    }
  },
  {
    "like" : {
      "tweetId" : "1276002388097167361",
      "fullText" : "Now we just need an #rstats #ggplot geom_disco. https://t.co/JQ8oqPqFuV",
      "expandedUrl" : "https://twitter.com/i/web/status/1276002388097167361"
    }
  },
  {
    "like" : {
      "tweetId" : "1276022657377538050",
      "fullText" : "600 applications for 2 PhD positions for @D2E_Project!! Wish I had 100 positions instead of 2... If you're looking for me I'm evaluating applications. w/ @Marleen_Ruiter @GabrielaGNobre @DimCoumou @Molei_HS https://t.co/OtD0dOKsYv",
      "expandedUrl" : "https://twitter.com/i/web/status/1276022657377538050"
    }
  },
  {
    "like" : {
      "tweetId" : "1275732072838172672",
      "fullText" : "Shoutout to #VUmc #AmsterdamUMC for this creative way of \"enforcing\" #socialdistancing in the waiting areas! 👏 This way, people in the high-risk group (like myself) can still get their medical testing done in a safe manner. https://t.co/9PhYtaldTA",
      "expandedUrl" : "https://twitter.com/i/web/status/1275732072838172672"
    }
  },
  {
    "like" : {
      "tweetId" : "1275705023809413125",
      "fullText" : "I'm not yet published academically, but I am being referenced!!! 🤩\n\nWell, at least the interview with @CFCamerer is ;)\n\n(Author has given permission to screenshot and share) https://t.co/ULlMuhcBuk",
      "expandedUrl" : "https://twitter.com/i/web/status/1275705023809413125"
    }
  },
  {
    "like" : {
      "tweetId" : "1275384482615513089",
      "fullText" : "Hey hey! We're back online and will return to our normal weekly posting schedule. Hope you're all safe and happy!\n\nStay tuned for updates about #environment #psychology and #climatechange",
      "expandedUrl" : "https://twitter.com/i/web/status/1275384482615513089"
    }
  },
  {
    "like" : {
      "tweetId" : "1275371860981698560",
      "fullText" : "Step forward for Open Science! https://t.co/xnnyQKup3x",
      "expandedUrl" : "https://twitter.com/i/web/status/1275371860981698560"
    }
  },
  {
    "like" : {
      "tweetId" : "1275020507746795520",
      "fullText" : "One size fits all? Designing financial incentives tailored to individual economic preferences. \n\nIn this paper, just published in @BPPjournal, I studied the incentives individuals would select for themselves (e.g. deposit contract, lottery). \n@ESHPM_EUR \nhttps://t.co/Dx6kW9HJaU",
      "expandedUrl" : "https://twitter.com/i/web/status/1275020507746795520"
    }
  },
  {
    "like" : {
      "tweetId" : "1258289874500804617",
      "fullText" : "\"Rejection is not refutation. Plenty of rejections must be only tentative.\" Hacking, 1965, Logic of Statistical Inference",
      "expandedUrl" : "https://twitter.com/i/web/status/1258289874500804617"
    }
  },
  {
    "like" : {
      "tweetId" : "1273555359005884418",
      "fullText" : "Franziska Komossa is currently defending her PhD thesis \"Outdoor Recreationists and where to find them\" You can follow online here: https://t.co/5vHBHM2gQa https://t.co/AFEWJIKo24",
      "expandedUrl" : "https://twitter.com/i/web/status/1273555359005884418"
    }
  },
  {
    "like" : {
      "tweetId" : "1273212600986341377",
      "fullText" : "Not going to lie, I do love the honesty of the title. Though I have not read the rest of the paper yet. https://t.co/cST8evPl24",
      "expandedUrl" : "https://twitter.com/i/web/status/1273212600986341377"
    }
  },
  {
    "like" : {
      "tweetId" : "1273042829191688192",
      "fullText" : "Curious about #Neuroeconomics? In 2020 the conference is virtual, free for members, heavily discounted for non-members, and the society offers fee waivers due to COVID and to undergraduate students. \nFor more details: https://t.co/L1qgUdArVI",
      "expandedUrl" : "https://twitter.com/i/web/status/1273042829191688192"
    }
  },
  {
    "like" : {
      "tweetId" : "1272823756919054336",
      "fullText" : "\"Vaccinated individuals showed lower levels of generosity toward nonvaccinated others regardless of their group membership. \n\nWe interpret this finding as an indicator of an unconditional moral principle.\"\n\nPlus, results replicated best in situation closest to reality. https://t.co/fqJhGBOsVc",
      "expandedUrl" : "https://twitter.com/i/web/status/1272823756919054336"
    }
  },
  {
    "like" : {
      "tweetId" : "1272823837483302914",
      "fullText" : "I made a pivot table I AM A GOD OF EXCEL",
      "expandedUrl" : "https://twitter.com/i/web/status/1272823837483302914"
    }
  },
  {
    "like" : {
      "tweetId" : "1271353904035479553",
      "fullText" : "Wat doen jullie? #teamzwaaien https://t.co/7sTpTlLhmn",
      "expandedUrl" : "https://twitter.com/i/web/status/1271353904035479553"
    }
  },
  {
    "like" : {
      "tweetId" : "1271364316453842945",
      "fullText" : "Geweldig paper. Eerst was er geen correlatie tussen suikerconsumptie en BMI, toen begonnen gezondere mensen suiker te mijden waardoor er wél een correlatie ontstond. Zo kan voedingsadvies via selectiebias vanzelf waar worden. @mkeulemans @stanvanpelt https://t.co/3U8Lu1tHMz",
      "expandedUrl" : "https://twitter.com/i/web/status/1271364316453842945"
    }
  },
  {
    "like" : {
      "tweetId" : "1270673564493021184",
      "fullText" : "Shaul Shalvi has been appointed professor of Behavioural Ethics at the UvA. He will focus on the scientific study of ethical questions. Many congratulations @Shaul_Shalvi! https://t.co/u7yQ3FCYI3",
      "expandedUrl" : "https://twitter.com/i/web/status/1270673564493021184"
    }
  },
  {
    "like" : {
      "tweetId" : "1270507355273261056",
      "fullText" : "My degree has arrived! Next step is getting my dissertation books, which are currently being held hostage at a Canadian book binding company. \n\nGraduating during a pandemic is weird. https://t.co/VPxmj1ACfZ",
      "expandedUrl" : "https://twitter.com/i/web/status/1270507355273261056"
    }
  },
  {
    "like" : {
      "tweetId" : "1269934781615177729",
      "fullText" : "Uit onderzoek van VU-promovendus Michelle Eykelenboom blijkt dat meerderheid van ondervraagde Nederlanders voor een extra #belasting is op #frisdrank, mits de opbrengst wordt ingezet voor publieke gezondheid. Lees meer: https://t.co/COTdrkzJIT \n#NationaleSuikerChallenge #diabetes https://t.co/8Tt4UF1Wlf",
      "expandedUrl" : "https://twitter.com/i/web/status/1269934781615177729"
    }
  },
  {
    "like" : {
      "tweetId" : "1268880795109908481",
      "fullText" : "📢📢VACANCY ALERT!! 2 PhD positions available at @VU_IVM within the @D2E_Project. On data-based analysis &amp; modelling of drought risk and adaptation of rural communities in East Africa. Please RT.\nhttps://t.co/pWqBTNVG10 #Down2EarthAfrica #drought #PhDposition https://t.co/ywtFdgB7GJ",
      "expandedUrl" : "https://twitter.com/i/web/status/1268880795109908481"
    }
  },
  {
    "like" : {
      "tweetId" : "1268833940703494144",
      "fullText" : "Conragtulations to @DSchindlerEcon and coauthor @Mark_Westcott_  on their forthcoming paper at @RevEconStud! https://t.co/6zznvzBIPR",
      "expandedUrl" : "https://twitter.com/i/web/status/1268833940703494144"
    }
  },
  {
    "like" : {
      "tweetId" : "1267785046762696704",
      "fullText" : "I know I'm late to the party but I just used `here::here()` for the first time. I use to have my Rmarkdown files the the project root dir but my colleague has it is a subfolder which messed up relative file paths. `here::here()` to the rescue ❤️\n#RStats",
      "expandedUrl" : "https://twitter.com/i/web/status/1267785046762696704"
    }
  },
  {
    "like" : {
      "tweetId" : "1265988952986660880",
      "fullText" : "Fabulous work by the picture editor here. https://t.co/raOwPSmAjS",
      "expandedUrl" : "https://twitter.com/i/web/status/1265988952986660880"
    }
  },
  {
    "like" : {
      "tweetId" : "1265559577149538306",
      "fullText" : "We often talk about visualising uncertainty in the field. I think I've found the perfect specimen... https://t.co/J3GGHupS1W",
      "expandedUrl" : "https://twitter.com/i/web/status/1265559577149538306"
    }
  },
  {
    "like" : {
      "tweetId" : "1265562121997357056",
      "fullText" : "@UniofExeter #PHD #student @joaomineiro07 won a competition to use the @UniofBath VSimulator @BathArchandCivE and went on to secure funding to research the effects of #virtualreality on chronic pain. To find out more, check out our latest news story at https://t.co/VEYKSzaOFz https://t.co/7eIZCtDPX5",
      "expandedUrl" : "https://twitter.com/i/web/status/1265562121997357056"
    }
  },
  {
    "like" : {
      "tweetId" : "1265294078104817664",
      "expandedUrl" : "https://twitter.com/i/web/status/1265294078104817664"
    }
  },
  {
    "like" : {
      "tweetId" : "1265341717600964613",
      "fullText" : "@NuclearPuentes I made some progress on mine before g school but now it lies dormant until I apply for jobs. I’ve been updating the cv tho. I like the github host option https://t.co/gk6oVbhlNL",
      "expandedUrl" : "https://twitter.com/i/web/status/1265341717600964613"
    }
  },
  {
    "like" : {
      "tweetId" : "1264610154630090753",
      "fullText" : "Actually it is perfectly rational #behavioraleconomics https://t.co/K3vPrOcpYD",
      "expandedUrl" : "https://twitter.com/i/web/status/1264610154630090753"
    }
  },
  {
    "like" : {
      "tweetId" : "1264841100637896704",
      "fullText" : "Weather literacy &amp; #ClimateChange :\nThe German public does not seem well equipped to anticipate weather risks &amp; may fail to fully grasp what climate change implies, a @n_fleischhut @stefanmherzog R Hertwig @mpib_berlin survey study reveals (WCAS).\nhttps://t.co/DPO1odVPhr\nUngated. https://t.co/Ih5a0YWS3y",
      "expandedUrl" : "https://twitter.com/i/web/status/1264841100637896704"
    }
  },
  {
    "like" : {
      "tweetId" : "1262400156667973638",
      "fullText" : "Same as it ever was: Our 19-country, 4,000 participant attempt at replicating the original Prospect Theory leaves no doubt. As robust today as it was in 1979.\n\nhttps://t.co/IEESJ2mUL9",
      "expandedUrl" : "https://twitter.com/i/web/status/1262400156667973638"
    }
  },
  {
    "like" : {
      "tweetId" : "1261222468993286145",
      "fullText" : "Over half a million of you, yes, over 500,000, have now watched our Inundation Street 360 flood awareness video! Amazing! Thank you all for watching and subscribing.\n\nhttps://t.co/RllfDLw0x6 https://t.co/LzNjM5uckV",
      "expandedUrl" : "https://twitter.com/i/web/status/1261222468993286145"
    }
  },
  {
    "like" : {
      "tweetId" : "1261233862866358272",
      "fullText" : "@JantsjeMol My only desk rejection (so far has become my mist cited paper...",
      "expandedUrl" : "https://twitter.com/i/web/status/1261233862866358272"
    }
  },
  {
    "like" : {
      "tweetId" : "1261060659229278208",
      "fullText" : "So, I’m officially transitioning to #rstats from SPSS after several failed transitions over the last two years, which has been eased by the fact that the data I now work w comes from SQL or excel files. \n\nToday I figured out how to get all the data imported to R and run ANOVAS. https://t.co/ZlLDYIFAim",
      "expandedUrl" : "https://twitter.com/i/web/status/1261060659229278208"
    }
  },
  {
    "like" : {
      "tweetId" : "1260936941534507009",
      "fullText" : "I wrote this as a joke. Less than 12 hours ago. \n\nA woman saw this, went to my profile, saw my pinned tweet, started my course, then DMed me to say she now sees coding is not rocket science and to count her in as one of the 1,908.\n\nI may have a new mission. https://t.co/PuMQdZ8ChD",
      "expandedUrl" : "https://twitter.com/i/web/status/1260936941534507009"
    }
  },
  {
    "like" : {
      "tweetId" : "1260111985968119808",
      "fullText" : "Ever wanted to comment out a single step in your #dplyr chains but introduced an error due to a trailing `%&gt;%`? Here are two ways to mitigate this issue. I am a big fan of the last one. How about you?\n#RStats #programming https://t.co/h2PQCcL2fC",
      "expandedUrl" : "https://twitter.com/i/web/status/1260111985968119808"
    }
  },
  {
    "like" : {
      "tweetId" : "1259832685926678528",
      "fullText" : "Watching a live presentation on a VR conference, as the speaker suggested, from my bed",
      "expandedUrl" : "https://twitter.com/i/web/status/1259832685926678528"
    }
  },
  {
    "like" : {
      "tweetId" : "1258692718454345731",
      "fullText" : "@ZigaMalek I knew peer view was harsh, but this is a new level.",
      "expandedUrl" : "https://twitter.com/i/web/status/1258692718454345731"
    }
  },
  {
    "like" : {
      "tweetId" : "1257866519574450178",
      "expandedUrl" : "https://twitter.com/i/web/status/1257866519574450178"
    }
  },
  {
    "like" : {
      "tweetId" : "1257831464739106817",
      "fullText" : "Gorgeous structures and terrific for awareness raising on #marineplastic  - so much potential for #SciArt @WashedAshoreArt  https://t.co/o5PxdsbnBV",
      "expandedUrl" : "https://twitter.com/i/web/status/1257831464739106817"
    }
  },
  {
    "like" : {
      "tweetId" : "1257312054957858820",
      "fullText" : "I'm TA in a cog-neuro class. This week we're covering attention. To illustrate \"change blindness\" I am slowly cutting my beard between each presentation slide. I also record the slides from last to first so it will look like my beard is growing out. This is pedagogy, right? https://t.co/V06uQsk3Nh",
      "expandedUrl" : "https://twitter.com/i/web/status/1257312054957858820"
    }
  },
  {
    "like" : {
      "tweetId" : "1255790560897642503",
      "fullText" : "You explain to subjects the uniform distribution. You quiz them: they pass. \n\nThen you ask them where do they believe the draw would land. \n\nAnd you get this.\n\nWhy? \n\nNew paper on Jo Eco Psy with @FilippinAntonio Peter Katuščák &amp; John Smith: https://t.co/ccRgz7dDx4 \n\nThread 👇 https://t.co/cuwZZmkhFY",
      "expandedUrl" : "https://twitter.com/i/web/status/1255790560897642503"
    }
  },
  {
    "like" : {
      "tweetId" : "1245367618783059968",
      "fullText" : "Ik verzamel voor onderzoek (en delen best practices)📸foto’s van visuele aanpassingen die mensen helpen om 1,5m afstand te houden (bv. lijnen, vlakken op de vloer)\n\nhttps://t.co/e18nDXA13h\n\n#Nudge #SocialDistance #anderhalvemeter #Supermarkt #coronanl #Covid19NL https://t.co/okluA6sulh",
      "expandedUrl" : "https://twitter.com/i/web/status/1245367618783059968"
    }
  },
  {
    "like" : {
      "tweetId" : "1253428459063218176",
      "fullText" : "https://t.co/y2sgtzlZxN https://t.co/1OQB89YtRc",
      "expandedUrl" : "https://twitter.com/i/web/status/1253428459063218176"
    }
  },
  {
    "like" : {
      "tweetId" : "1253309769550565376",
      "fullText" : "📢#Bsap20 wordt een online evenement! \nDe kern van Bessensap – wetenschap ontmoet pers – blijft centraal staan en het programma op 12 juni wordt omgevormd tot een online programma met ruimte voor onderzoekspresentaties, workshops en een plenair programma: https://t.co/SnA1awHAtR https://t.co/WuyeUznRtK",
      "expandedUrl" : "https://twitter.com/i/web/status/1253309769550565376"
    }
  },
  {
    "like" : {
      "tweetId" : "1253060264183959554",
      "fullText" : "#Rstats: You can't compare correlation magnitudes by eyeballing them &amp; stating one is bigger than the other - you need to test for differences statistically! If you need to do this the cocor package in R has you covered. \n\nEven has a GUI webapp: https://t.co/NrB0LdOu3Q\n\n#phdchat https://t.co/eGIplRoWRC",
      "expandedUrl" : "https://twitter.com/i/web/status/1253060264183959554"
    }
  },
  {
    "like" : {
      "tweetId" : "1253239305478250497",
      "fullText" : "So happy! A little dream comes true... \n\nOur publication in Nature is out! \n\nGreat teamwork with @a_gerster, Ken Gillingham &amp; @MarcoHorvath! \n\nPlease read &amp; comment it! \n\nIt is concise, an easy read, &amp; very important! \n\n#econtwitter\n#Mobility \n#cars \n#Sustainability \n@RWI_Leibniz https://t.co/QLt5HFVzMi",
      "expandedUrl" : "https://twitter.com/i/web/status/1253239305478250497"
    }
  },
  {
    "like" : {
      "tweetId" : "1252948512272154624",
      "fullText" : "Covid-study-study: I asked 200 people on Turk about the COVID19 studies they've done. \n\nFirst, by their own estimation, how many COVID19 studies have they done?\n\n(notice the logarithmic x axis) https://t.co/juzBtTtTO8",
      "expandedUrl" : "https://twitter.com/i/web/status/1252948512272154624"
    }
  },
  {
    "like" : {
      "tweetId" : "1252952612074209280",
      "fullText" : "On this day five years ago, my favorite co-author (@AmandaCook_Econ) and I decided that it would be utility-maximizing for us to enter into a joint legal arrangement. I am delighted to report that it continues to be utility-maximizing.",
      "expandedUrl" : "https://twitter.com/i/web/status/1252952612074209280"
    }
  },
  {
    "like" : {
      "tweetId" : "1252960211393851394",
      "fullText" : "Happy #EarthDay to my beautiful new Utah home 🌎 https://t.co/UfgU0d3WSQ",
      "expandedUrl" : "https://twitter.com/i/web/status/1252960211393851394"
    }
  },
  {
    "like" : {
      "tweetId" : "1252906175823314944",
      "fullText" : "Mirthe Boomsma (@BoomsmaMirthe) lead today’s #WednesdayWorkshop. She will present her work \"What do my neighbours do? Leveraging social learning to stimulate organic waste sorting\" https://t.co/ql5FT27s3b\n#Economics #Research #organicwastesorting #environmental #recycling https://t.co/n2RZD1qD0O",
      "expandedUrl" : "https://twitter.com/i/web/status/1252906175823314944"
    }
  },
  {
    "like" : {
      "tweetId" : "1242124212623388673",
      "fullText" : "In non-corona news, my first paper was recently published! #Opensource available on Journal of Cleaner Production, it is a literature review on #sustainable #plastic #businessmodels  @VU_IVM https://t.co/mYKcCEJmxn https://t.co/3V6veL4vQ0",
      "expandedUrl" : "https://twitter.com/i/web/status/1242124212623388673"
    }
  },
  {
    "like" : {
      "tweetId" : "1252853149750067204",
      "fullText" : "Kleine vermelding van onze essaybundel in @trouw. https://t.co/9QRtS3X3S4",
      "expandedUrl" : "https://twitter.com/i/web/status/1252853149750067204"
    }
  },
  {
    "like" : {
      "tweetId" : "1252687747065798659",
      "expandedUrl" : "https://twitter.com/i/web/status/1252687747065798659"
    }
  },
  {
    "like" : {
      "tweetId" : "1252653700780306438",
      "fullText" : "#EconCookingTwitter. The secret to making a pavlova is that you should actually make two. https://t.co/4TMCtPZ5HY",
      "expandedUrl" : "https://twitter.com/i/web/status/1252653700780306438"
    }
  },
  {
    "like" : {
      "tweetId" : "1252822309913546753",
      "fullText" : "@JantsjeMol @Marleen_Ruiter @ZigaMalek @anaiscouasnon @DirkEilander @jens_debruijn @giodc3 @GabrielaGNobre @FialaLenka @zoelinder @prindt @AJBijsterveld @SimoneHaeckl Love the wind-up bird chronicles!",
      "expandedUrl" : "https://twitter.com/i/web/status/1252822309913546753"
    }
  },
  {
    "like" : {
      "tweetId" : "1252546298210856965",
      "fullText" : "We are looking for a PhD candidate who is excited to develop a simulation environment using #CognitiveScience, #DataScience, #SeriousGames in close collaboration with @PortOfRotterdam, @Brightcape1,@Mindlabs2 and @TilburgU! With @klincewiczm &amp; myself. 👇👇👇 https://t.co/n6XwsY42FY",
      "expandedUrl" : "https://twitter.com/i/web/status/1252546298210856965"
    }
  },
  {
    "like" : {
      "tweetId" : "1250047656950403072",
      "fullText" : "🤔 What would Elsevier or Wiley do if I come up I with a sign that says: \n\nI NEED \nMORE \nACCEPTED \nPAPERS!! https://t.co/EvV75WWZ9V",
      "expandedUrl" : "https://twitter.com/i/web/status/1250047656950403072"
    }
  },
  {
    "like" : {
      "tweetId" : "1250055354014195717",
      "fullText" : "Sylvia, one of our interns, is working on a page for when a payment goes wrong.\n\nThis is a graphic she made https://t.co/ppvYRkORFz",
      "expandedUrl" : "https://twitter.com/i/web/status/1250055354014195717"
    }
  },
  {
    "like" : {
      "tweetId" : "1247897592777674755",
      "fullText" : "Wanneer we het vandaag de dag hebben over de #Watersnoodramp, dan wordt eigenlijk altijd verwezen naar de ramp van 1953. Er waren er echter veel meer. In de #16eEeuw kende een stormvloed zelfs nóg hogere vloedgolven en mogelijk meer slachtoffers dan de ramp van 1953. Lees meer.",
      "expandedUrl" : "https://twitter.com/i/web/status/1247897592777674755"
    }
  },
  {
    "like" : {
      "tweetId" : "1248151491405393920",
      "fullText" : "Interesting ... ‘ggplot for tables ...’ https://t.co/l654UxRyUZ",
      "expandedUrl" : "https://twitter.com/i/web/status/1248151491405393920"
    }
  },
  {
    "like" : {
      "tweetId" : "1247643014295502849",
      "fullText" : "Sometimes a paper is made by a great figure.  This one might take the cake.  Great new work on by @sreal_lab, https://t.co/Gj3DYnXV71 https://t.co/7i5ZC0wp6g",
      "expandedUrl" : "https://twitter.com/i/web/status/1247643014295502849"
    }
  },
  {
    "like" : {
      "tweetId" : "1247054354781278209",
      "fullText" : "How to measure infiltration rates at home? Our Hans de Moel demonstrates this to the hydrology master students in his garden using a can of green beans.\n\n@Molei_HS @VU_Science @VUamsterdam https://t.co/mU3eRLec4V",
      "expandedUrl" : "https://twitter.com/i/web/status/1247054354781278209"
    }
  },
  {
    "like" : {
      "tweetId" : "1247065840303955971",
      "fullText" : "Happy Monday! In today's #interview we are talking to @CFCamerer ! \n\nWe talk about getting into #BehavioralScience, but also about the #research in #Neuroeconomics.\n\nIt's a beast of an interview (length wise at least), so make sure you start early!\n\nhttps://t.co/bPSstVz7th https://t.co/g55mqlhOQS",
      "expandedUrl" : "https://twitter.com/i/web/status/1247065840303955971"
    }
  },
  {
    "like" : {
      "tweetId" : "1246025156151123968",
      "fullText" : "How to measure saturated hydraulic conductivity when you cannot do it in the field?\n\nHere is our @anaiscouasnon with her home-build set up to demonstrate this to our Hydrology Master students!\n\n#tinkering @VU_Science @VUamsterdam https://t.co/JWvoRexKoz",
      "expandedUrl" : "https://twitter.com/i/web/status/1246025156151123968"
    }
  },
  {
    "like" : {
      "tweetId" : "1245685049548247040",
      "fullText" : "Finally created my website using R! https://t.co/8kw9Ki6gDo\n\nMy first step towards open science, thanks to @dsquintana's brilliant tutorial and helpful people here on Twitter (thanks @helenahhartmann!). New to R, so this took me several days to complete - but worth it!\n\n#phdchat https://t.co/GqvRXvfDu4",
      "expandedUrl" : "https://twitter.com/i/web/status/1245685049548247040"
    }
  },
  {
    "like" : {
      "tweetId" : "1240890948831281152",
      "fullText" : "Latest #OA paper in @IJDRS from #ResilNam (through the @grp_resilience and @zfoundation water window) on #Disaster #Risk #Science on the interaction between #SocialCapital and improvements in #Flood #ProtectiveMotivtion #factors overall.  See here for the https://t.co/rYIX1Q6iCP https://t.co/tCa5HqH6lD",
      "expandedUrl" : "https://twitter.com/i/web/status/1240890948831281152"
    }
  },
  {
    "like" : {
      "tweetId" : "1240754984389611524",
      "fullText" : "@JantsjeMol I always wanted to make an art fair with research posters curated purely on the basis of aesthetics.",
      "expandedUrl" : "https://twitter.com/i/web/status/1240754984389611524"
    }
  },
  {
    "like" : {
      "tweetId" : "1240670205661110273",
      "expandedUrl" : "https://twitter.com/i/web/status/1240670205661110273"
    }
  },
  {
    "like" : {
      "tweetId" : "1240657174247936007",
      "fullText" : "@Marleen_Ruiter He loves maps! @kschulze123 https://t.co/3cG6VeNd0S",
      "expandedUrl" : "https://twitter.com/i/web/status/1240657174247936007"
    }
  },
  {
    "like" : {
      "tweetId" : "1240265653564723201",
      "fullText" : "@Marleen_Ruiter I think I will get used to this, and I will have to take the cat to work once home isolation is over.",
      "expandedUrl" : "https://twitter.com/i/web/status/1240265653564723201"
    }
  },
  {
    "like" : {
      "tweetId" : "1234038301142724611",
      "fullText" : "goeie nudge les van ⁦@texdewit⁩ https://t.co/O8NbfSS8xN",
      "expandedUrl" : "https://twitter.com/i/web/status/1234038301142724611"
    }
  },
  {
    "like" : {
      "tweetId" : "1239568790360334338",
      "fullText" : "So this happened. To encourage my ⁦@WUR⁩ students to engage in our virtual classroom I promised to lecture as a banana if we got 20 good comments or questions. And so they did. And so I did.  #OnlineTeaching #AcademicChatter #trynewthings ⁦@wyoungacademy⁩ https://t.co/QJpHPrmydB",
      "expandedUrl" : "https://twitter.com/i/web/status/1239568790360334338"
    }
  },
  {
    "like" : {
      "tweetId" : "1239335098052489216",
      "fullText" : "A reason for me to leave #academia is because I'm afraid my research would be buried under non-published manuscripts, rot in rejected versions and otherwise be represented in non-accessible journals. \n\nBut this is impact too, and it makes me happy @AcademicChatter https://t.co/un08vIKBd6",
      "expandedUrl" : "https://twitter.com/i/web/status/1239335098052489216"
    }
  },
  {
    "like" : {
      "tweetId" : "1238480456087109633",
      "fullText" : "@JantsjeMol @JohnHolbein1 @mhallsworth @CassSunstein @Shaul_Shalvi Thanks! In this case, shoutout goes to the reviewers and the editor who were very supportive and constructive. Why can’t it always be this way 🤷🏻‍♂️😄",
      "expandedUrl" : "https://twitter.com/i/web/status/1238480456087109633"
    }
  },
  {
    "like" : {
      "tweetId" : "1238459096233320448",
      "fullText" : "Krijgen we het Italiaanse coronascenario? Pas op voor dubieuze grafieken, waarschuwt @caal https://t.co/3DXns2xXGc via @volkskrant",
      "expandedUrl" : "https://twitter.com/i/web/status/1238459096233320448"
    }
  },
  {
    "like" : {
      "tweetId" : "1237739000020054020",
      "fullText" : "Yay,I got asked to refree for JEBO,its one of my favorite outlets &lt;:)",
      "expandedUrl" : "https://twitter.com/i/web/status/1237739000020054020"
    }
  },
  {
    "like" : {
      "tweetId" : "1237467924916580354",
      "fullText" : "Me [gives sister the dates I will be visiting]\nSister: That's a great time to be coming here! You'll probably get to see everything except the aurora\nAurora: hold my beer ... https://t.co/qLfEplm40D",
      "expandedUrl" : "https://twitter.com/i/web/status/1237467924916580354"
    }
  },
  {
    "like" : {
      "tweetId" : "1236998855633362951",
      "fullText" : "After four years of hard work, it's great to finally hold this in my hand. An electronic version of my dissertation is available here: https://t.co/DROnyShyFN.\n\nHere's a summary... https://t.co/t9hbBhny89",
      "expandedUrl" : "https://twitter.com/i/web/status/1236998855633362951"
    }
  },
  {
    "like" : {
      "tweetId" : "1235992360271507456",
      "fullText" : "@EmilyNix100 Grad students are the Marco Polos of academia. \"I've been to a faraway land, and bring news of amazing things. In the Far East, a great new website has been made, which allows LaTeX to be compiled online...\". &lt;crowd ooohhhs&gt;",
      "expandedUrl" : "https://twitter.com/i/web/status/1235992360271507456"
    }
  },
  {
    "like" : {
      "tweetId" : "1236347513059319809",
      "fullText" : "Uitstekende, indrukwekkende uitzending van @EenVandaag over #mh17 proces. Verhelderend. Mijn gedachten gaan terug naar onze betreurde collega WiIlem Witteveen en zijn gezin... @TilburgU @BA_LiberalArts",
      "expandedUrl" : "https://twitter.com/i/web/status/1236347513059319809"
    }
  },
  {
    "like" : {
      "tweetId" : "1236306943096041474",
      "fullText" : "Hello @AcademicChatter ! Friends of mine have started a great initiative: BrainyTab!\n\nIt's a browser extension that shows you #BehavioralScience concepts explained every time you open a new tab. It's free, fun and educating!\n\nhttps://t.co/nJjjAJeB2Z",
      "expandedUrl" : "https://twitter.com/i/web/status/1236306943096041474"
    }
  },
  {
    "like" : {
      "tweetId" : "1235919658777300993",
      "fullText" : "Spring break: time for a trip to the beach https://t.co/sf7TvYP2Qc",
      "expandedUrl" : "https://twitter.com/i/web/status/1235919658777300993"
    }
  },
  {
    "like" : {
      "tweetId" : "1235578357980557312",
      "fullText" : "Of ik in een gekke bui #dataviz-inspired stickers heb laten maken? 😀 https://t.co/T3CxkU4cPv",
      "expandedUrl" : "https://twitter.com/i/web/status/1235578357980557312"
    }
  },
  {
    "like" : {
      "tweetId" : "1235782892262916096",
      "fullText" : "When my ggplot look ggreat on the first try. https://t.co/XaaQBmfQ1V",
      "expandedUrl" : "https://twitter.com/i/web/status/1235782892262916096"
    }
  },
  {
    "like" : {
      "tweetId" : "1235516124823015424",
      "fullText" : "I ❤️ this paper https://t.co/N9c9zTb2ba",
      "expandedUrl" : "https://twitter.com/i/web/status/1235516124823015424"
    }
  },
  {
    "like" : {
      "tweetId" : "1234859066398257154",
      "fullText" : "@NL_Wetenschap Misschien weet je het na het lezen van dit paper: https://t.co/RoUomzQqQ6",
      "expandedUrl" : "https://twitter.com/i/web/status/1234859066398257154"
    }
  },
  {
    "like" : {
      "tweetId" : "1234840727911387137",
      "fullText" : "De tweede aanvraag betreft een Comenius teaching-fellow onderwijsinnovatiebeurs. Hopelijk 1 mei groen licht voor mijn voorgestelde Virtual Reality leeromgeving waarin aankomende basisschoolleerkrachten op realistische en veilige wijze met klassensituaties kunnen oefenen. https://t.co/GyCAM01Om0",
      "expandedUrl" : "https://twitter.com/i/web/status/1234840727911387137"
    }
  },
  {
    "like" : {
      "tweetId" : "1234813558329835522",
      "fullText" : "a new approach to open access - https://t.co/9bN28T5KyS",
      "expandedUrl" : "https://twitter.com/i/web/status/1234813558329835522"
    }
  },
  {
    "like" : {
      "tweetId" : "1234813382009729024",
      "fullText" : "@JantsjeMol @raedyping @rstatstweet Replace \"jitter\" with \"noise\" or \"horizontal offset\"",
      "expandedUrl" : "https://twitter.com/i/web/status/1234813382009729024"
    }
  },
  {
    "like" : {
      "tweetId" : "1234808512452100096",
      "fullText" : "Deze week op @SALTOamsterdam spreken Aafke en Mathijs met @jens_debruijn en @nadiabloemendaal VAN @VU_IVM over twitterdata en algoritmes om tropische stormen te voorspellen en monitoren. Verder vertelt Bart Verheggen @klimaatVeranda over klimaatontkenning.\nhttps://t.co/NRGYcN9KFH",
      "expandedUrl" : "https://twitter.com/i/web/status/1234808512452100096"
    }
  },
  {
    "like" : {
      "tweetId" : "1234050065829855232",
      "fullText" : "Tune in to @RadioSwammerdam at 11h this morning to hear our Nadia Bloemendaal and @jens_debruijn talk about their respective research (the STORM model and the use of twitter to detect floods).",
      "expandedUrl" : "https://twitter.com/i/web/status/1234050065829855232"
    }
  },
  {
    "like" : {
      "tweetId" : "1234075446192590848",
      "fullText" : "In “Why We Can No Longer Ignore #Consecutive #Disasters”  @Marleen_Ruiter et al argue that the number of consecutive disasters and their impacts are increasing around the world. \n\nhttps://t.co/AcR2egf5p4\n\n@theAGU #AGUpubs #naturalhazards https://t.co/Ya3d0lADmw",
      "expandedUrl" : "https://twitter.com/i/web/status/1234075446192590848"
    }
  },
  {
    "like" : {
      "tweetId" : "1234133872352296961",
      "fullText" : "Cadastre for climate! \n\nDr. Hans Mol from @FryskeAkademy @LeidenHum and Thomas Vermaut from @KNAWHuC presented the historical GIS and it’s possibilities for long-term spatial and ecological analyses at the @VU_IVM colloquium. \n\n@VU_Science https://t.co/Tf9ZR2Xwho",
      "expandedUrl" : "https://twitter.com/i/web/status/1234133872352296961"
    }
  },
  {
    "like" : {
      "tweetId" : "1233326447462404096",
      "fullText" : "Our latest open access paper on the compound flood potential from river discharge and storm surge extremes at the global scale is out,👇!  https://t.co/6J0zTkUWEl\n\nWe analysed the timing and correlation between the two in deltas and estuaries: key findings in this thread! https://t.co/JYONk4ccRz",
      "expandedUrl" : "https://twitter.com/i/web/status/1233326447462404096"
    }
  },
  {
    "like" : {
      "tweetId" : "1233101399141109760",
      "fullText" : "Excited to present my poster on how people send gossip in groups to determine how receivers of gossip behave towards the target of the gossip at the intragroup processes pre conference #SPSP2020 https://t.co/HIU62Cmcdi",
      "expandedUrl" : "https://twitter.com/i/web/status/1233101399141109760"
    }
  },
  {
    "like" : {
      "tweetId" : "1232945710015881216",
      "fullText" : "Latest #OpenAccess  paper in @SocRiskAnalysis #RiskAnalysis journal. About one aspect of the #SocialJustice implication of property-level adaptation against #flooding through #Fairness and #affordability. Here is the link: https://t.co/k3SnRPJ6tA https://t.co/UPYq7glbdC",
      "expandedUrl" : "https://twitter.com/i/web/status/1232945710015881216"
    }
  },
  {
    "like" : {
      "tweetId" : "1232556402775863296",
      "fullText" : "My first day of teaching today. This course inspired me to do research in JDM (I sat in the same room exactly 3 years ago). I’ll be talking about the impact of emotions and emotion regulation on decision making. Very excited, but can’t seem to regulate my fear &amp; anxiety #phdchat",
      "expandedUrl" : "https://twitter.com/i/web/status/1232556402775863296"
    }
  },
  {
    "like" : {
      "tweetId" : "1232705851179225094",
      "fullText" : "I am currently doing MLE with bootstrapped standard errors for an R&amp;R because the editor doesn't think Bayesian techniques are appropriate for their journal. 10 bootstraps takes about as long as my entire Bayesian implementation to run. https://t.co/l34A6bW2Ww",
      "expandedUrl" : "https://twitter.com/i/web/status/1232705851179225094"
    }
  },
  {
    "like" : {
      "tweetId" : "1232693947337707526",
      "fullText" : "Who needs in-flight entertainment of you got the Arctic passing by below you #SPSP2020 https://t.co/2c7RbhYlO6",
      "expandedUrl" : "https://twitter.com/i/web/status/1232693947337707526"
    }
  },
  {
    "like" : {
      "tweetId" : "1572601697905610754",
      "fullText" : "It turned out that I could visit CREED @UvA_Amsterdam in October😀\n\nVery much looking forward to coming to the Netherlands again and meeting people there☺️ https://t.co/3kM9hZu7vl",
      "expandedUrl" : "https://twitter.com/i/web/status/1572601697905610754"
    }
  },
  {
    "like" : {
      "tweetId" : "1572113923498721280",
      "fullText" : "Thanks to Christoph Merkle, Alexander Koch, Nicola Maaser, Julia Nafziger, @ClaesBackman, Nickolas Gagnon&amp;everyone else at @Aarhus_BSS for hosting me yesterday in the MOB Seminar (https://t.co/MR8v3XWaNu)!I had a fantastic time. And don't miss  next week's MOB with @EgonTripodi! https://t.co/8wyhnERu2b",
      "expandedUrl" : "https://twitter.com/i/web/status/1572113923498721280"
    }
  },
  {
    "like" : {
      "tweetId" : "1571823147216932868",
      "expandedUrl" : "https://twitter.com/i/web/status/1571823147216932868"
    }
  },
  {
    "like" : {
      "tweetId" : "1570325874163191809",
      "fullText" : "#QuickVR is a library for #VR virtual embodiment in #unity3d  but also useful as a fast way to build new applications. It is available on GitHub and described in this @FrontVR paper\nhttps://t.co/HyHt2338GP  @ERC_Research #MoTIVE",
      "expandedUrl" : "https://twitter.com/i/web/status/1570325874163191809"
    }
  },
  {
    "like" : {
      "tweetId" : "1570301562152689665",
      "fullText" : "Yesterday Shaul Shalvi gave his oratie (inaugural lecture), \"Bursting the selfishness bubble\". Very interesting talk and I'm happy to have been able to be there! \n\nCongratulations! https://t.co/7WdiZcLCMX",
      "expandedUrl" : "https://twitter.com/i/web/status/1570301562152689665"
    }
  },
  {
    "like" : {
      "tweetId" : "1568572329873084418",
      "fullText" : "*Slowly peaking outside*\nAm I... Am I finished now?\n\nHanded in my thesis after some intense weeks! On my way to Asia on Monday 🌴 https://t.co/w4CYVeFCo7",
      "expandedUrl" : "https://twitter.com/i/web/status/1568572329873084418"
    }
  },
  {
    "like" : {
      "tweetId" : "1569401190798204928",
      "fullText" : "Walking into the Monday like... 🐈😠\n\n#cats #CatsOfTwitter #academicswithcats https://t.co/t70w3wzFX5",
      "expandedUrl" : "https://twitter.com/i/web/status/1569401190798204928"
    }
  },
  {
    "like" : {
      "tweetId" : "1568999038917251073",
      "fullText" : "Oliver🐈 wishes you a great start of the week: put your right paw forward!🐾\n\n#CatsOfTwitter #cats #academicswithcats https://t.co/FrIPltUqYJ",
      "expandedUrl" : "https://twitter.com/i/web/status/1568999038917251073"
    }
  },
  {
    "like" : {
      "tweetId" : "1559855523389997056",
      "fullText" : "Iets te dicht bij de werkelijkheid, deze 😬 https://t.co/fUeCg6hvow",
      "expandedUrl" : "https://twitter.com/i/web/status/1559855523389997056"
    }
  },
  {
    "like" : {
      "tweetId" : "1560222540202663937",
      "fullText" : "🍔 Further update of the environmental impacts of food explorer on @OurWorldInData\n\nAs per request, this morning I added faceted views, so you can:\n\n- see different env impacts at once\n- or look at different nutritional units per environmental impact 👇\n\nhttps://t.co/8lS7ZjI2G6 https://t.co/U6zIKlMkDB",
      "expandedUrl" : "https://twitter.com/i/web/status/1560222540202663937"
    }
  },
  {
    "like" : {
      "tweetId" : "1560266175065763841",
      "fullText" : "Excited to announce a workshop on 'morals and repugnance in markets' for the inauguration of the Amsterdam Center for Behavioral Change (ACBC) at @UvA_Amsterdam! In-person workshop in Amsterdam on September 5.\n\nRegister here:\nhttps://t.co/m41aWKw7Sx https://t.co/MAoYbi0YJ4",
      "expandedUrl" : "https://twitter.com/i/web/status/1560266175065763841"
    }
  },
  {
    "like" : {
      "tweetId" : "1559920361986211842",
      "expandedUrl" : "https://twitter.com/i/web/status/1559920361986211842"
    }
  },
  {
    "like" : {
      "tweetId" : "1559856733794844672",
      "fullText" : "🆕 New data on the environmental impacts of food.\n\nFor a long time we've had environmental footprints of food commodities on @OurWorldInData: beef, wheat, rice, etc.\n\nI've added lots of new data on specific food products: bread, burgers, pasta, etc.\n\nhttps://t.co/yQYDIi9pVu\n\n🧵 https://t.co/YI3ojoCPIm",
      "expandedUrl" : "https://twitter.com/i/web/status/1559856733794844672"
    }
  },
  {
    "like" : {
      "tweetId" : "1559219606467772416",
      "expandedUrl" : "https://twitter.com/i/web/status/1559219606467772416"
    }
  },
  {
    "like" : {
      "tweetId" : "1559091746230902785",
      "expandedUrl" : "https://twitter.com/i/web/status/1559091746230902785"
    }
  },
  {
    "like" : {
      "tweetId" : "1556903887117877248",
      "expandedUrl" : "https://twitter.com/i/web/status/1556903887117877248"
    }
  },
  {
    "like" : {
      "tweetId" : "1557305467185266690",
      "fullText" : "When your ex PhD supervisor (ex because I graduated) who you are still in frequent contact with casually mentions getting married next week.\n\nHe'd been engaged for a year and just forgot to mention it 🤣",
      "expandedUrl" : "https://twitter.com/i/web/status/1557305467185266690"
    }
  },
  {
    "like" : {
      "tweetId" : "1556993701381111808",
      "fullText" : "Field experiment finds that restaurant items \"were 24% more likely to sell when they were marketed as vegetarian/vegan than when they were marketed as plant-based\" @D_L_Rosenfeld \n\nhttps://t.co/6DNESrI7J6",
      "expandedUrl" : "https://twitter.com/i/web/status/1556993701381111808"
    }
  },
  {
    "like" : {
      "tweetId" : "1556604761864118273",
      "fullText" : "Zojuist kwam ik de eerste versie van het boekvoorstel tegen, uit januari 2020. \n\nDe titel, ondertitel en voorkant zijn veranderd, maar de hoofdboodschap is hetzelfde. 😉\n\n👉 https://t.co/HVNDUSrs12 https://t.co/MRJ4NBSMNy",
      "expandedUrl" : "https://twitter.com/i/web/status/1556604761864118273"
    }
  },
  {
    "like" : {
      "tweetId" : "1550495309607981056",
      "fullText" : "@j2bryson Thanks for the shout out 🙏\nThe working paper is available here:\nhttps://t.co/TsigWk8WTt\nJoint work with the great colleagues Alicia von Schenk and Victor Klockmann from @Max_Planck_CHM",
      "expandedUrl" : "https://twitter.com/i/web/status/1550495309607981056"
    }
  },
  {
    "like" : {
      "tweetId" : "1550542463160688645",
      "fullText" : "cyclist sleeping set-up during the Tour de France #TDF2022 - with @JoelvdWeele https://t.co/l72W0JiKJ1",
      "expandedUrl" : "https://twitter.com/i/web/status/1550542463160688645"
    }
  },
  {
    "like" : {
      "tweetId" : "1550490438871703556",
      "fullText" : "This was a great ICSD. Thanks to all of you for making this such a great conference. We are tired now and need some sleep. https://t.co/XSgtCY8Rac",
      "expandedUrl" : "https://twitter.com/i/web/status/1550490438871703556"
    }
  },
  {
    "like" : {
      "tweetId" : "1550499783042899968",
      "fullText" : "@JantsjeMol @simoncolumbus @ICSD_Conference Jantsje in een bootsje: kan niet missen!",
      "expandedUrl" : "https://twitter.com/i/web/status/1550499783042899968"
    }
  },
  {
    "like" : {
      "tweetId" : "1549123212600016898",
      "fullText" : "Grateful we're getting to host so many friends and colleagues in Copenhagen this week. Looking forward to four days of #ICSDCPH https://t.co/Hyr95m300h",
      "expandedUrl" : "https://twitter.com/i/web/status/1549123212600016898"
    }
  },
  {
    "like" : {
      "tweetId" : "1547625352003870720",
      "fullText" : "Tips on sabbatical-ing, especially if during pandemic:\n\n1. Minimum 6-months\n2. Prioritize new connections\n3. Leave time for reflection and joy\n\nA short thread.",
      "expandedUrl" : "https://twitter.com/i/web/status/1547625352003870720"
    }
  },
  {
    "like" : {
      "tweetId" : "1231965373228101632",
      "fullText" : "Thrilled that our RCT on grading schemes w/ @MvP_VanPraag @sanderonderstal &amp; Randolph Sloof - that went through enough rounds of rejections &amp; revisions to acquire the affectionate nickname \"our ugly duckling project\" - finally turned into a swan 🐣--&gt;🦢1/5\nhttps://t.co/uTbs5QPmJ3",
      "expandedUrl" : "https://twitter.com/i/web/status/1231965373228101632"
    }
  },
  {
    "like" : {
      "tweetId" : "1231953507122466818",
      "fullText" : "This is getting out of hand. https://t.co/erMB2O9CcT",
      "expandedUrl" : "https://twitter.com/i/web/status/1231953507122466818"
    }
  },
  {
    "like" : {
      "tweetId" : "1231950958554312704",
      "fullText" : "I've heard this as well-- if you haven't found a job yet, hang in there! https://t.co/hLwrkS9qfX",
      "expandedUrl" : "https://twitter.com/i/web/status/1231950958554312704"
    }
  },
  {
    "like" : {
      "tweetId" : "1231895348790153222",
      "fullText" : "On my way to @amsterdamumc to give a seminar on my work on tailoring financial incentives. Last time I was invited for a seminar it was cancelled last minute, so here's to better luck #phdlife #slightlynervous",
      "expandedUrl" : "https://twitter.com/i/web/status/1231895348790153222"
    }
  },
  {
    "like" : {
      "tweetId" : "1231630169686802432",
      "fullText" : "Let's see what they say! https://t.co/dEyz9aGTV9 https://t.co/4yIE7zDM0c",
      "expandedUrl" : "https://twitter.com/i/web/status/1231630169686802432"
    }
  },
  {
    "like" : {
      "tweetId" : "1231617331824152583",
      "fullText" : "We're looking rising stars in #behavioralscience. Join us for a 2-year post-doctoral research professional appointment. Learn more and apply by March 15 https://t.co/W1h9v7DpHZ https://t.co/UIFCXBWlxH",
      "expandedUrl" : "https://twitter.com/i/web/status/1231617331824152583"
    }
  },
  {
    "like" : {
      "tweetId" : "1230882611804942337",
      "fullText" : "Wat kan data toch mooi zijn! Nederland verdeeld in 10 vlakken met een gelijk aantal inwoners. Fijn weekend! 🌍🌍 https://t.co/b2FSfEmoQ4",
      "expandedUrl" : "https://twitter.com/i/web/status/1230882611804942337"
    }
  },
  {
    "like" : {
      "tweetId" : "1230802805067321345",
      "fullText" : "Cyclone Idai &amp; Hurricane Harvey revealed the devastating consequences of the co-occurrence of coastal &amp; river floods.\n@anaiscouasnon identified regions w/ a high compound flooding potential from river discharge and river mouth storm surge extremes globally:https://t.co/Jl3hup18sN https://t.co/69RjzSQpbA",
      "expandedUrl" : "https://twitter.com/i/web/status/1230802805067321345"
    }
  },
  {
    "like" : {
      "tweetId" : "1230794420271841280",
      "fullText" : "Well that was the nicest comment I got for a presentation: normally I glaze over economic presentations, but yours was interesting enough to actually listen too.",
      "expandedUrl" : "https://twitter.com/i/web/status/1230794420271841280"
    }
  },
  {
    "like" : {
      "tweetId" : "1230806445303746560",
      "expandedUrl" : "https://twitter.com/i/web/status/1230806445303746560"
    }
  },
  {
    "like" : {
      "tweetId" : "1230401730321494018",
      "fullText" : "‘Minibiebs? Die gebruikt toch niemand?' Tja de kastjes met weggeefboeken lijken er soms wat eenzaam bij te staan, verloren in het niemandsland tussen goede bedoelingen en nutteloosheid. Dat beeld is niet correct, zegt promovenda Anouk Schippers https://t.co/fqgruYi3xs #economie https://t.co/sAqHiJ6Drf",
      "expandedUrl" : "https://twitter.com/i/web/status/1230401730321494018"
    }
  },
  {
    "like" : {
      "tweetId" : "1230524238739623936",
      "fullText" : "Having a morning of good news about teaching:\n 1/2) My advisee in the 2-year masters program, having proposed his own research question, collected his own awesome data, and only needed me to debug 2 lines of code in order to get synth to work https://t.co/d9BxCvsoO8",
      "expandedUrl" : "https://twitter.com/i/web/status/1230524238739623936"
    }
  },
  {
    "like" : {
      "tweetId" : "1230524249477005313",
      "fullText" : "2/2) IRB exemption approved for a project I will be doing with my econometrics students https://t.co/E3dm2MfjFU",
      "expandedUrl" : "https://twitter.com/i/web/status/1230524249477005313"
    }
  },
  {
    "like" : {
      "tweetId" : "1230451239617429510",
      "fullText" : "👌: Designer wants to buy subscription to public transport, doesn't trust the payment page because the use of comic sans, and breaks off transaction process https://t.co/jR84mRtjko",
      "expandedUrl" : "https://twitter.com/i/web/status/1230451239617429510"
    }
  },
  {
    "like" : {
      "tweetId" : "1230238187953512449",
      "fullText" : "Op 9 mei is er in Leiden een VR-dag: programma en meer info is te vinden op https://t.co/FDjcv54vAt .",
      "expandedUrl" : "https://twitter.com/i/web/status/1230238187953512449"
    }
  },
  {
    "like" : {
      "tweetId" : "1230228846676496385",
      "fullText" : "Many of your colleagues are probably checking this out ... https://t.co/M5cBd87RGg",
      "expandedUrl" : "https://twitter.com/i/web/status/1230228846676496385"
    }
  },
  {
    "like" : {
      "tweetId" : "1230059637090799618",
      "fullText" : "Very true! https://t.co/lVIia8XQj1",
      "expandedUrl" : "https://twitter.com/i/web/status/1230059637090799618"
    }
  },
  {
    "like" : {
      "tweetId" : "1229867185188720640",
      "fullText" : "At #OceanSciences meeting in San Diego and just had a great plenary session with @ErikvanSebille promising to find the missing 99% of #oceanplastic - a noble endeavour! #OSM2020 https://t.co/kRjnZRXjkI",
      "expandedUrl" : "https://twitter.com/i/web/status/1229867185188720640"
    }
  },
  {
    "like" : {
      "tweetId" : "1229867946710749184",
      "fullText" : "IVM PhD Tadzio Holtrop will be presenting at #OceanSciences today at 15:15 on work done in collaboration with colleague Hans van der Woerd #python #opensource #satellite #hyperspectral #OSM2020 https://t.co/NExNBWAxGs",
      "expandedUrl" : "https://twitter.com/i/web/status/1229867946710749184"
    }
  },
  {
    "like" : {
      "tweetId" : "1229839146539200512",
      "fullText" : "We are looking for a new colleague, an Assistant Professor in Economics! Leiden University its Department of Economics is a great place to work. See here for more information:\nhttps://t.co/v5TU1rMQNh",
      "expandedUrl" : "https://twitter.com/i/web/status/1229839146539200512"
    }
  },
  {
    "like" : {
      "tweetId" : "1229772624449998850",
      "expandedUrl" : "https://twitter.com/i/web/status/1229772624449998850"
    }
  },
  {
    "like" : {
      "tweetId" : "1229721491668979713",
      "fullText" : "I am stoked! Two of my own papers made it into the top 10 publications of the @wupperinst. https://t.co/2GQo7cxde4",
      "expandedUrl" : "https://twitter.com/i/web/status/1229721491668979713"
    }
  },
  {
    "like" : {
      "tweetId" : "1229429048478175233",
      "fullText" : "It is 2020 - It is Volume 4 - It is out today. You won't want to miss out. Read it here &gt;&gt; https://t.co/CMwAfMp3bZ &lt;&lt;#Nudge https://t.co/kz4V5KTwcq",
      "expandedUrl" : "https://twitter.com/i/web/status/1229429048478175233"
    }
  },
  {
    "like" : {
      "tweetId" : "1229465128795504641",
      "fullText" : "@DrGBuckingham what has helped me tremendously here was advice from Stephen King's \"On writing\": always take seriously when others tell you that some section does not work (they are usually right), but do not NOT take seriously their advice on how to fix it (they are usually wrong).",
      "expandedUrl" : "https://twitter.com/i/web/status/1229465128795504641"
    }
  },
  {
    "like" : {
      "tweetId" : "1228004585337499650",
      "fullText" : "In our paper \"Gender and Willingness to Compete for High Stakes\", we show that men and women's willingness to compete depends on the gender of their opponent. Women avoid competing against men, and men exploit this in strategic interactions. Download link: https://t.co/JSrZb1IaQ4 https://t.co/RIgoy28DBU",
      "expandedUrl" : "https://twitter.com/i/web/status/1228004585337499650"
    }
  },
  {
    "like" : {
      "tweetId" : "1227669742158319622",
      "fullText" : "I’ve been keeping a secret 🤫 and today I’m finally allowed to share the news!...\n\nI’m beyond excited to have been chosen as a finalist for the Entrepreneur of the year category in the https://t.co/d9IeT0Idol Tech Playmaker… https://t.co/RlJtzIxMOl",
      "expandedUrl" : "https://twitter.com/i/web/status/1227669742158319622"
    }
  },
  {
    "like" : {
      "tweetId" : "1226934011534225411",
      "fullText" : "It’s almost time for #academicvalentine 2020 💖 starting with retweets of my last years’ doodles! \n@ your academic valentine! #phdchat #sciart #academicvalentines https://t.co/BG4XQ7owxt",
      "expandedUrl" : "https://twitter.com/i/web/status/1226934011534225411"
    }
  },
  {
    "like" : {
      "tweetId" : "1227740578588372993",
      "fullText" : "Roses are red\nViolets are blue\nH0: my tweets are still this good 👇\np = 0.02\n#academicvalentine https://t.co/0wDZEzimet",
      "expandedUrl" : "https://twitter.com/i/web/status/1227740578588372993"
    }
  },
  {
    "like" : {
      "tweetId" : "1227330831858982914",
      "fullText" : "Yay paper accepted!",
      "expandedUrl" : "https://twitter.com/i/web/status/1227330831858982914"
    }
  },
  {
    "like" : {
      "tweetId" : "1227240811672285184",
      "fullText" : "I’ve received 4 rejections in the last 3 months. But yesterday I got some good news about a paper in my inbox. \n\nThis is just a reminder that when it feels like the rejections are pouring down, you could be just around the corner from an acceptance. One day at a time, my friends.",
      "expandedUrl" : "https://twitter.com/i/web/status/1227240811672285184"
    }
  },
  {
    "like" : {
      "tweetId" : "1226888791027257344",
      "fullText" : "Bèta studenten in Nederland, wat denken jullie ervan om in het kader van ‘een keer iets anders’, een jaartje dat robotvoetbal en die zonnewagenrace over te slaan en je eens een jaar lang hier op te richten als (universitaire) competitie? Dit is leuker dan simuleren @RolfHut https://t.co/3NENSurGHA",
      "expandedUrl" : "https://twitter.com/i/web/status/1226888791027257344"
    }
  },
  {
    "like" : {
      "tweetId" : "1226796656047333376",
      "fullText" : "Can survey measures of expectations predict actual future outcomes?\n\nInteresting paper on a research collaboration between psychologists and economists shows how it can be done, suggesting both fields can contribute to each other under certain conditions.\n\nhttps://t.co/va3QRlk9Tx https://t.co/nZVYfGqTsY",
      "expandedUrl" : "https://twitter.com/i/web/status/1226796656047333376"
    }
  },
  {
    "like" : {
      "tweetId" : "1226892268172279809",
      "fullText" : "I've submitted to journals in several disciplines/fields. Each has their own quirks.\n\nPolitical science: \"I don't like the framing!!!!\"\nPublic administration: \"cite more PA articles!!!!\"\nPsychology: \"Your paper isn't in APA format!!!!\"\nEconomics: \"MOAR ROBUSTNESS ✔️✔️✔️!!!!!\"",
      "expandedUrl" : "https://twitter.com/i/web/status/1226892268172279809"
    }
  },
  {
    "like" : {
      "tweetId" : "1226548488089034755",
      "fullText" : "I always mention panoramic paintings when I talk about the history of VR. But I'm ashamed to say I had never been to Panorama Mesdag, which is right in my home town. \n\nThis weekend I took my daughter! \n\nTOUCH this image: Panorama Mesdag https://t.co/T1gOo62735",
      "expandedUrl" : "https://twitter.com/i/web/status/1226548488089034755"
    }
  },
  {
    "like" : {
      "tweetId" : "1226829752155230208",
      "fullText" : "Also, all of the reviews I have done were either completed on time or declined within 24 hours.",
      "expandedUrl" : "https://twitter.com/i/web/status/1226829752155230208"
    }
  },
  {
    "like" : {
      "tweetId" : "1225169778391896066",
      "fullText" : "A new outlet for (behavioral) VR research... https://t.co/7WHvOo89PB",
      "expandedUrl" : "https://twitter.com/i/web/status/1225169778391896066"
    }
  },
  {
    "like" : {
      "tweetId" : "1225099899777306626",
      "fullText" : "Zoë Linder-Baptie, a project Manager at the Risk Center, is excited to be in Charleston, SC at #SocialCoast20 to present on the topic of equitable federal disaster aid policy! https://t.co/cJvfcMVEvU",
      "expandedUrl" : "https://twitter.com/i/web/status/1225099899777306626"
    }
  },
  {
    "like" : {
      "tweetId" : "1224840502719107072",
      "fullText" : "I'm sorry in advance but I'm teaching serial correlation tomorrow and I'm going to put in a slide that says \"Cereal Correlation\" and has pictures of boxes of Capt Crunch, Crunch Berries, Oops all the Berries, and Peanut Butter Crunch.",
      "expandedUrl" : "https://twitter.com/i/web/status/1224840502719107072"
    }
  },
  {
    "like" : {
      "tweetId" : "1225069183966248961",
      "fullText" : "Ik heb de slides van mijn lezing (Een lans voor digitale luiheid) van gister online gezet. Hier en daar wat tekst toegevoegd zodat de lijn in principe digitaal redelijk te volgen moet zijn, indien men niet te lui is. https://t.co/SVn9nNhxdY",
      "expandedUrl" : "https://twitter.com/i/web/status/1225069183966248961"
    }
  },
  {
    "like" : {
      "tweetId" : "1224775369783435264",
      "fullText" : "Been getting a lot of emails from this predatory journal lately, so I decided to submit this manuscript. Stay tuned. 🤞🤞🤞 https://t.co/nv1f2PausF https://t.co/BxklvDsZHR",
      "expandedUrl" : "https://twitter.com/i/web/status/1224775369783435264"
    }
  },
  {
    "like" : {
      "tweetId" : "1225049698366623745",
      "fullText" : "This time of year, thousands of students are considering a PhD.\n\nI loved doing my PhD. But the fact is that it's not for everyone, or even necessary for many career fields.\n\nBefore you make the commitment, I highly recommend working your way through this flow chart. https://t.co/11Pf48nr4V",
      "expandedUrl" : "https://twitter.com/i/web/status/1225049698366623745"
    }
  },
  {
    "like" : {
      "tweetId" : "1224561764659908608",
      "fullText" : "I think it's time to post this @xkcd comic again... https://t.co/d00M8slASN",
      "expandedUrl" : "https://twitter.com/i/web/status/1224561764659908608"
    }
  },
  {
    "like" : {
      "tweetId" : "1224667281441067009",
      "fullText" : "Me: Don't feel too badly, I'm a behavioral economist, so it's behavior like this that puts food on the table.\n\nWorking with/around smart &amp; interesting people @utoledo is awesome 😀😀😀😀😀\n\nThis also initiated a conversation w an undergrad about #TeachBE\n\n2/2",
      "expandedUrl" : "https://twitter.com/i/web/status/1224667281441067009"
    }
  },
  {
    "like" : {
      "tweetId" : "1224607437652664320",
      "fullText" : "I'm at #BlueInvest in Brussels today sharing some @CLAIM_H2020 information and interviewing some experts, entrepreneurs and others interested in #marinelitter @VU_IVM https://t.co/O45KkfkzoF",
      "expandedUrl" : "https://twitter.com/i/web/status/1224607437652664320"
    }
  },
  {
    "like" : {
      "tweetId" : "1224399189255147524",
      "fullText" : "💥Refurbished @CESifoGroup paper w/ Bolton &amp; Schmidt on when &amp; why #nudge interventions hoping to achieve behavior change can backfire &amp; what to do about it (key: leverage #norms properly). Details in thread👇🏻\n\nLink to paper: https://t.co/u5tO88ZdE2\n#EconTwitter #SocSciResearch https://t.co/G0edEk0MK8 https://t.co/4ivJVvzVTO",
      "expandedUrl" : "https://twitter.com/i/web/status/1224399189255147524"
    }
  },
  {
    "like" : {
      "tweetId" : "1224382275422507009",
      "fullText" : "Come work with us! https://t.co/VPV8orGYvq",
      "expandedUrl" : "https://twitter.com/i/web/status/1224382275422507009"
    }
  },
  {
    "like" : {
      "tweetId" : "1223393452374863873",
      "fullText" : "This is genius! https://t.co/KI18M3RRxq",
      "expandedUrl" : "https://twitter.com/i/web/status/1223393452374863873"
    }
  },
  {
    "like" : {
      "tweetId" : "1222899282581180420",
      "fullText" : "My favorite step of the article submission process is waiting for the single PDF I uploaded to be converted to a PDF",
      "expandedUrl" : "https://twitter.com/i/web/status/1222899282581180420"
    }
  },
  {
    "like" : {
      "tweetId" : "1222072851852877825",
      "fullText" : "Maar gisteravond wel verschrikkelijk fijn college gegeven aan een eagere groep honors studenten! 👨‍🎓",
      "expandedUrl" : "https://twitter.com/i/web/status/1222072851852877825"
    }
  },
  {
    "like" : {
      "tweetId" : "1222080308293644289",
      "fullText" : "Here is an exclusive peak review for the March 2020 issue of Experimental Economics. Methods, markets, morals, inequality, conflict,  voting, auctions, matching, domestic production, circuit breakers, and how CEOs differ ... you name it - we are on it! https://t.co/pst3NuqWkH",
      "expandedUrl" : "https://twitter.com/i/web/status/1222080308293644289"
    }
  },
  {
    "like" : {
      "tweetId" : "1220710377169747968",
      "fullText" : "What's H, the probability they are mocking you for not saying hello?\n\nWhat's E, the probability they just answered a call with earbuds in?\n\nSuppose the date is today and location is NYC\n\n#EverydayCausalInference\n\n2/2",
      "expandedUrl" : "https://twitter.com/i/web/status/1220710377169747968"
    }
  },
  {
    "like" : {
      "tweetId" : "1220375045425573894",
      "fullText" : "We are proud to share the great news that our 2019-ERM student (and now colleague) Sem Duijndam, won the @VUamsterdam master thesis award.\n\nHe was the second ERM winner and third ERM nominee in the last three years.\n\nMore onur ERM MSc program: https://t.co/AwJSetOCwB\n@VU_Science https://t.co/QEweh80H7z",
      "expandedUrl" : "https://twitter.com/i/web/status/1220375045425573894"
    }
  },
  {
    "like" : {
      "tweetId" : "1220515089901662215",
      "fullText" : "The daily dose of heart attack... receiving this email ~2 weeks after submission and expecting it’s a desk rejection based on the title, but it’s just a confirmation that paper has been sent out. Don’t play us like that journals/editors 😏 \n#EconTwitter https://t.co/AfH6DVpBh0",
      "expandedUrl" : "https://twitter.com/i/web/status/1220515089901662215"
    }
  },
  {
    "like" : {
      "tweetId" : "1219776997821317121",
      "fullText" : "Found some new behavioral/experimental texts while browsing the book exhibition at #ASSA2020.  Anyone has experience using any of those in their courses? #EconTwitter https://t.co/QhqxGJowt0",
      "expandedUrl" : "https://twitter.com/i/web/status/1219776997821317121"
    }
  },
  {
    "like" : {
      "tweetId" : "1219648390209904640",
      "fullText" : "Hey @lonelywhale &amp; @Dell I see a link to the 4D Cry Out experience on your website (https://t.co/4PTXz6NZBp) but the link goes nowhere! Got a working link for me? Curious about how you used  #virtualreality to raise awareness on #marineplastic and #oceanconservation",
      "expandedUrl" : "https://twitter.com/i/web/status/1219648390209904640"
    }
  },
  {
    "like" : {
      "tweetId" : "1218151500482072576",
      "fullText" : "Next week I will discuss how to use Behavioral Science in Public Policy at the Dutch Ministry of Social Affairs and Employment. \n\nBased on among else the @PAReview article \"Public Policy and Behavior Change\".\n\n#impact #scienceforsociety\n\nhttps://t.co/cQG698RtF1",
      "expandedUrl" : "https://twitter.com/i/web/status/1218151500482072576"
    }
  },
  {
    "like" : {
      "tweetId" : "1218159580871634949",
      "fullText" : "\"But will it replicate?\" \n@FialaLenka discusses her successful #replication forecasting in the @ReplicationMkts project. Read her interview here: https://t.co/YqEmqis1dA\n\n#OpenScience #Research #AcademicTwitter #ButWillItReplicate",
      "expandedUrl" : "https://twitter.com/i/web/status/1218159580871634949"
    }
  },
  {
    "like" : {
      "tweetId" : "1218058944918278144",
      "fullText" : "Leidt een duwtje in de gezonde richting echt tot gewenst gedrag? Vandaag promoveert Tina Venema op dit onderwerp https://t.co/IOrA0DwToh via @volkskrant",
      "expandedUrl" : "https://twitter.com/i/web/status/1218058944918278144"
    }
  },
  {
    "like" : {
      "tweetId" : "1217180208727576578",
      "fullText" : "This picture is becoming a tradition in our Bogotá Experimental Economics Conference #BEEC2020 https://t.co/ZcBdJBqm5F",
      "expandedUrl" : "https://twitter.com/i/web/status/1217180208727576578"
    }
  },
  {
    "like" : {
      "tweetId" : "1216765171139600388",
      "fullText" : "@eugen_dimant @KickbackGAP @robgillanders @causalinf @JohnHolbein1 I figured -- just wanted the world to know you weren't dissing experimental papers.",
      "expandedUrl" : "https://twitter.com/i/web/status/1216765171139600388"
    }
  },
  {
    "like" : {
      "tweetId" : "1212620967727550465",
      "fullText" : "Passport control: \n- Are you a doctor?\n- Yes\n- What kind, medical?\n- No, economics \n- Ah, money doctor",
      "expandedUrl" : "https://twitter.com/i/web/status/1212620967727550465"
    }
  },
  {
    "like" : {
      "tweetId" : "1209214847809916928",
      "fullText" : "Once again a blowback for simple nudging. Failure to achieve behavioral change with norm-#nudges (providing information) is in line with recent surge in findings. \n\n@JohnHolbein1 will simultaneously appreciate publication of #NullEffectsMatter &amp; be disappointed in the findings :) https://t.co/PDsSOrrqbS",
      "expandedUrl" : "https://twitter.com/i/web/status/1209214847809916928"
    }
  },
  {
    "like" : {
      "tweetId" : "1208027503056560133",
      "fullText" : "Highlight from this grading season: \"the firm buys a low quality technology and produce less, but it's OK because it can only sell at a not-amazing shitty price\"",
      "expandedUrl" : "https://twitter.com/i/web/status/1208027503056560133"
    }
  },
  {
    "like" : {
      "tweetId" : "1208038106949210112",
      "fullText" : "5/9 We asked ourselves: \"Does #normnudging also work as a vehicle for #anticorruption in the field? \" https://t.co/RyVXZBKfOQ",
      "expandedUrl" : "https://twitter.com/i/web/status/1208038106949210112"
    }
  },
  {
    "like" : {
      "tweetId" : "1208038083406508032",
      "fullText" : "1/9 Our new paper is out in @BPPjournal \n\nIn short: \nLab-in-the-field study showing that Informing people about decreasing bribery levels in their community changes beliefs and willingness to bribe in an incentivized corruption game. \n\nFull story 👇\n\nhttps://t.co/aCQqDm164c",
      "expandedUrl" : "https://twitter.com/i/web/status/1208038083406508032"
    }
  },
  {
    "like" : {
      "tweetId" : "1208000990592610304",
      "fullText" : "I won the award for the Best Research Master Course for my course on Programming in R 🤩 A big thank you to all my students, you guys are the best! https://t.co/AS6cfB0fav",
      "expandedUrl" : "https://twitter.com/i/web/status/1208000990592610304"
    }
  },
  {
    "like" : {
      "tweetId" : "1207790546179084288",
      "fullText" : "My paper \"Measuring and Comparing Two Kinds of Rationalizable Opportunity Cost in Mixture Models\" is now published in Games in the special issue on \"The Empirics of Behaviour\nunder Risk and Ambiguity\"\n\nhttps://t.co/jRL9gi7t3d",
      "expandedUrl" : "https://twitter.com/i/web/status/1207790546179084288"
    }
  },
  {
    "like" : {
      "tweetId" : "1207326289524342787",
      "fullText" : "We love this! https://t.co/Ib9WNf0RiZ",
      "expandedUrl" : "https://twitter.com/i/web/status/1207326289524342787"
    }
  },
  {
    "like" : {
      "tweetId" : "1206688737914163200",
      "fullText" : "We found Dr. Eugen Dimant to be a terrific guest. Energetic, passionate, and #insightful! His observations on #nudges and #socialnorms are terrific. https://t.co/H2jwjKfoFh",
      "expandedUrl" : "https://twitter.com/i/web/status/1206688737914163200"
    }
  },
  {
    "like" : {
      "tweetId" : "1207214522592829440",
      "fullText" : "Despite the growth of web/field experiments in Grenoble we still believe in old brick-and-mortar labs. Thanks to a grant by @IdexFormation, feedback from @EcScienceAssoc colleagues, support from @GrenobleINP and hard work by @aurelevel we renovated the lab. Isn't it beautiful? https://t.co/2lIF37L7Wv",
      "expandedUrl" : "https://twitter.com/i/web/status/1207214522592829440"
    }
  },
  {
    "like" : {
      "tweetId" : "1206477699780399104",
      "fullText" : "Look how cool this looks 😎 (let alone the fact that it is actually really cool)! https://t.co/S77yW9oLOJ",
      "expandedUrl" : "https://twitter.com/i/web/status/1206477699780399104"
    }
  },
  {
    "like" : {
      "tweetId" : "1205115032851435522",
      "fullText" : "Where others call set.seed(), the Dutch call set.Hagelslag()\n\ncc @HernanBruno1975 @andre_quentin https://t.co/OFOuLtkKIM",
      "expandedUrl" : "https://twitter.com/i/web/status/1205115032851435522"
    }
  },
  {
    "like" : {
      "tweetId" : "1205068726242103297",
      "fullText" : "VU-onderzoekers @jens_debruijn, @Marleen_Ruiter, Hans de Moel en Jeroen Aerts van @VU_IVM, ontwikkelden samen met @jurjenwagemaker (@FloodTags) en @BrendenJongman (Wereldbank) een algoritme voor real-time opsporen en volgen van overstromingen dmv tweets https://t.co/xq64I0Cl7S https://t.co/ho07Ukdykz",
      "expandedUrl" : "https://twitter.com/i/web/status/1205068726242103297"
    }
  },
  {
    "like" : {
      "tweetId" : "1199062699025600512",
      "fullText" : "#girlthings https://t.co/haRHQJJgK1",
      "expandedUrl" : "https://twitter.com/i/web/status/1199062699025600512"
    }
  },
  {
    "like" : {
      "tweetId" : "1197470716976869376",
      "fullText" : "How can governments, businesses and research collaborate to speed up the rate of energy-efficient renovations? Come join our discussion with @ebespaarders and @MarikeKnoef at this year's #Dvhg19 in The Hague! Next Thu, 28 Nov, Fokker terminal.  https://t.co/QNiRwYRdH8 https://t.co/TRSKbEzqiu",
      "expandedUrl" : "https://twitter.com/i/web/status/1197470716976869376"
    }
  },
  {
    "like" : {
      "tweetId" : "1204114005658345473",
      "fullText" : "By automatically analysing ~88 million tweets posted over four years in 11 languages we find over 10.000 flood events of which up to 90% is correctly detected. Check out the new paper at https://t.co/zkpVBPEC5M\n\nReal-time results are also available at https://t.co/3UUBBbYc1r https://t.co/Ve9cDZfEl0",
      "expandedUrl" : "https://twitter.com/i/web/status/1204114005658345473"
    }
  },
  {
    "like" : {
      "tweetId" : "1204857341914468352",
      "fullText" : "Jantsje Mol spent about a month at the Risk Center this fall as a part of this research, so we are excited to share this paper that she and that our partners at @VU_IVM have published. Read it here: https://t.co/ydRnMgzhL7 https://t.co/COF2z5gCR3",
      "expandedUrl" : "https://twitter.com/i/web/status/1204857341914468352"
    }
  },
  {
    "like" : {
      "tweetId" : "1204921409132101632",
      "fullText" : "Congrats Jeroen!\n\n#AGU2019 https://t.co/51yIftiuSJ",
      "expandedUrl" : "https://twitter.com/i/web/status/1204921409132101632"
    }
  },
  {
    "like" : {
      "tweetId" : "1204766551926300674",
      "fullText" : "Well, this is neat — You can scribble whatever you want into Google's AI tool, called AutoDraw, and it'll convert it into clipart that you can download for free. Seems useful for slides &amp; stimuli. https://t.co/wXhtrRqctO https://t.co/MJlB0U6KcP",
      "expandedUrl" : "https://twitter.com/i/web/status/1204766551926300674"
    }
  },
  {
    "like" : {
      "tweetId" : "1204760672497786881",
      "expandedUrl" : "https://twitter.com/i/web/status/1204760672497786881"
    }
  },
  {
    "like" : {
      "tweetId" : "1204705911044005889",
      "fullText" : "#Rstats: Be more productive in R Studio with multiple cursors.\n\nDo this:\nHold down Alt -&gt; click -&gt; drag the cursor across multiple lines.\n\nNow edit multiple lines of code simultaneously.\n\n#phdchat #rstudio https://t.co/1TZpxIU0GB",
      "expandedUrl" : "https://twitter.com/i/web/status/1204705911044005889"
    }
  },
  {
    "like" : {
      "tweetId" : "1204513904765759488",
      "fullText" : "Check out the poster that Elissa Kranzler, one of our Risk Center Post-Doctoral Fellows, is presenting on about Hurricane risk perceptions at the Society for Risk Analysis Conference in Arlington, VA.  #SRA2019 @SocRiskAnalysis https://t.co/0n9XIwpHJj",
      "expandedUrl" : "https://twitter.com/i/web/status/1204513904765759488"
    }
  },
  {
    "like" : {
      "tweetId" : "1204431311030685696",
      "fullText" : "Almost there ... https://t.co/ozW7M7JTfr",
      "expandedUrl" : "https://twitter.com/i/web/status/1204431311030685696"
    }
  },
  {
    "like" : {
      "tweetId" : "1204241009678389248",
      "fullText" : "SOME PEOPLE WAIT A LIFETIME FOR A MOMENT LIKE THIS\n\n#Econtwitter karaoke signup is here! Friday night at ASSA in San Diego, 9pm pacific\n\nFill out form below if you want to attend (everyone has to sing!)\n\nco-organized by @florianederer and @anne_m_burton \n\nhttps://t.co/fXdqrz2JnH",
      "expandedUrl" : "https://twitter.com/i/web/status/1204241009678389248"
    }
  },
  {
    "like" : {
      "tweetId" : "1204162648864112642",
      "fullText" : "@odedgurantz @JantsjeMol I will compile all these ideas in my website!",
      "expandedUrl" : "https://twitter.com/i/web/status/1204162648864112642"
    }
  },
  {
    "like" : {
      "tweetId" : "1204084457503940610",
      "fullText" : "@JantsjeMol Awesome! I will follow up on this!",
      "expandedUrl" : "https://twitter.com/i/web/status/1204084457503940610"
    }
  },
  {
    "like" : {
      "tweetId" : "1204065093601808384",
      "fullText" : "Interested in technology, data visualization and applied science? I will present “Awash in Data: Virtual Flooding with Virtual Reality Technology” in NH12A: Using Earth Observations and Imagery Analysis for Risk and Resilience this morning Moscone West; 2016, L2 @theAGU #AGU19 https://t.co/BB3uFsizo3",
      "expandedUrl" : "https://twitter.com/i/web/status/1204065093601808384"
    }
  },
  {
    "like" : {
      "tweetId" : "1204058281272066050",
      "fullText" : "Writing https://t.co/xyMP2NqVah",
      "expandedUrl" : "https://twitter.com/i/web/status/1204058281272066050"
    }
  },
  {
    "like" : {
      "tweetId" : "1202992495862398976",
      "fullText" : "More bridge-burning so that I don't recycle exam questions. Here is the computational exam I gave my econometrics students yesterday. Open book, open internet (except email, etc). https://t.co/O5tWBtz1i0",
      "expandedUrl" : "https://twitter.com/i/web/status/1202992495862398976"
    }
  },
  {
    "like" : {
      "tweetId" : "1037251510927863810",
      "fullText" : "Sympathy cards for scientists. Created by @TomGauld https://t.co/jAQ09uqlWf",
      "expandedUrl" : "https://twitter.com/i/web/status/1037251510927863810"
    }
  },
  {
    "like" : {
      "tweetId" : "1202336507853492227",
      "expandedUrl" : "https://twitter.com/i/web/status/1202336507853492227"
    }
  },
  {
    "like" : {
      "tweetId" : "1202560182024331273",
      "fullText" : "Lekker dan. Net uur zitten schaven aan een stuk tekst tot het nét binnen de 400 woorden past (dat is een essentiële skill voor een wetenschappers trouwens) ... blijkt dat er 𝗺𝗶𝗻𝗶𝗺𝗮𝗮𝗹 400 woorden staat 😞",
      "expandedUrl" : "https://twitter.com/i/web/status/1202560182024331273"
    }
  },
  {
    "like" : {
      "tweetId" : "1202596450967990274",
      "fullText" : "Someone realized my dream, a mobile VR lab, awesome! @michagaebler https://t.co/j3BTXY6fET",
      "expandedUrl" : "https://twitter.com/i/web/status/1202596450967990274"
    }
  },
  {
    "like" : {
      "tweetId" : "1202597521484386306",
      "fullText" : "I am a proud member of #TeamAbsoluteRisk https://t.co/qgJIHqAUCK",
      "expandedUrl" : "https://twitter.com/i/web/status/1202597521484386306"
    }
  },
  {
    "like" : {
      "tweetId" : "1202566751680155648",
      "fullText" : "Lecturing in Eindhoven today, taking to data science students about eye tracking data in social decision making. Let the lecture begin! https://t.co/lZE3gvi2HX",
      "expandedUrl" : "https://twitter.com/i/web/status/1202566751680155648"
    }
  },
  {
    "like" : {
      "tweetId" : "1202259586897588226",
      "fullText" : "Today I visited the the ⁦@univgroningen⁩ faculty of law ⁦@rechten050⁩. Extremely inspiring meetings with students and young staff. I even visited the court room with a virtual reality 👓 https://t.co/FoIH9sTZnm",
      "expandedUrl" : "https://twitter.com/i/web/status/1202259586897588226"
    }
  },
  {
    "like" : {
      "tweetId" : "1202496049413267456",
      "fullText" : "Extra optie stuurt keuze bij schadeverzekeringen\nArtikel in @ESBtweets samen met Nina Peters.\n\nUitkomsten in een plaatje (niet in stuk door ruimtegebrek)\nhttps://t.co/jPgf8NwCyn https://t.co/FDxNSYNdFi",
      "expandedUrl" : "https://twitter.com/i/web/status/1202496049413267456"
    }
  },
  {
    "like" : {
      "tweetId" : "1202496193219219456",
      "fullText" : "Job market candidates: @TiUEconomics will send out the bulk of interview invitations today or tomorrow. If you haven't heard by then, there's still a chance you'll hear in the days after!",
      "expandedUrl" : "https://twitter.com/i/web/status/1202496193219219456"
    }
  },
  {
    "like" : {
      "tweetId" : "1202351211833376770",
      "fullText" : "Leuke collega’s heb ik toch op @TilburgU : students’ research Symposium vandaag. Prachtig om onze studenten zo enthousiast te horen praten over eigen sociologisch onderzoek. Mooie dag! https://t.co/xxnkRgUdQ3",
      "expandedUrl" : "https://twitter.com/i/web/status/1202351211833376770"
    }
  },
  {
    "like" : {
      "tweetId" : "1201902268288847873",
      "fullText" : "After hours of coaxing half a sentence at time into my document, I decide it's getting late, I should wrap it up for today and go home. Then my brain goes, \"No, let's write this thing!\" Does this happen to anyone else?\n#AcademicChatter #phdchat #phdlife #AcWri https://t.co/eNY1CbYAOR",
      "expandedUrl" : "https://twitter.com/i/web/status/1201902268288847873"
    }
  },
  {
    "like" : {
      "tweetId" : "1201497631161225216",
      "expandedUrl" : "https://twitter.com/i/web/status/1201497631161225216"
    }
  },
  {
    "like" : {
      "tweetId" : "1200917769774141442",
      "fullText" : "You’re unable to view this Post because this account owner limits who can view their Posts. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1200917769774141442"
    }
  },
  {
    "like" : {
      "tweetId" : "1201146055204704257",
      "fullText" : "Good to see that the number of outlets for high quality short papers in economics is increasing! There are cases where length has merit, but all too often it seems that our field puts a premium on length as a signal of thoroughness, leading to excessively long articles. https://t.co/TPFLI7bC90",
      "expandedUrl" : "https://twitter.com/i/web/status/1201146055204704257"
    }
  },
  {
    "like" : {
      "tweetId" : "1200415970906574849",
      "fullText" : "At the SFB Seminar, we had a lively discussion with @PaulSmeets5 about his paper Investor Memory where he analyses memory bias in an experiment. Depending on participants' choice between an investment in bonds or stocks, participants memorized the market outcome differently. https://t.co/WemCW4o6jK",
      "expandedUrl" : "https://twitter.com/i/web/status/1200415970906574849"
    }
  },
  {
    "like" : {
      "tweetId" : "1200379031050498050",
      "fullText" : "Communicating uncertainties is super important to the #wx and #climate communities. We do it well but can we do even better? We had a great colloquium @KNMI by @SanneJWWillems about verbal vs numeric expressions of uncertainty (research w co-authors @ionicasmeets and @CaAl) https://t.co/EJzgV75pFQ",
      "expandedUrl" : "https://twitter.com/i/web/status/1200379031050498050"
    }
  },
  {
    "like" : {
      "tweetId" : "1200279684212113408",
      "fullText" : "How can we apply #BehavioralScience in work of the @UN ?  Make it💡easy 💡attractive 💡social 💡timely . @UN Bangkok \n@UNESCAP @UN_Innovation hosted Luke Ravenscroft @B_I_Tweets today. https://t.co/x5VaXAxBnA",
      "expandedUrl" : "https://twitter.com/i/web/status/1200279684212113408"
    }
  },
  {
    "like" : {
      "tweetId" : "1200355151237783552",
      "fullText" : "Ontwerpers hebben het altijd over 'de vraag achter de vraag'. Su-per-belangrijk Maar die vraag wordt dus altijd groter, nooit kleiner. Nooit eens een strategic design consultant die zegt: 'Nee hoor, je wil geen communicatiestrategie, doe eerst maar eens gewoon een goeie website.'",
      "expandedUrl" : "https://twitter.com/i/web/status/1200355151237783552"
    }
  },
  {
    "like" : {
      "tweetId" : "1200041455005376512",
      "fullText" : "New in this revision: norm-#nudge interventions can be ineffective because they are not *actually* shifting #norms (at least not in an environment where existing norms are clear) @RDMetcalfe @c_a_gravert @fiorin_econ\n\nPrevious🧵summarizing the key results:\nhttps://t.co/E6xma2VyiT https://t.co/hsDvOpMOvp https://t.co/NvPtSkYBRG",
      "expandedUrl" : "https://twitter.com/i/web/status/1200041455005376512"
    }
  },
  {
    "like" : {
      "tweetId" : "1200022374210514945",
      "fullText" : "I’m very happy of presenting today my work with Ernesto Reuben as a guest at the Brown Bag Seminar in NYU Abu Dhabi. First time presenting this one 🙋🏽‍♀️👩🏽‍🏫. In this study we use laboratory measurements to test whether there is a pure Preference for Competititon. https://t.co/CLgNaB3qsr",
      "expandedUrl" : "https://twitter.com/i/web/status/1200022374210514945"
    }
  },
  {
    "like" : {
      "tweetId" : "1199985259946893312",
      "expandedUrl" : "https://twitter.com/i/web/status/1199985259946893312"
    }
  },
  {
    "like" : {
      "tweetId" : "1199714226459332608",
      "fullText" : "8yo is playing this with brutal strategic sophistication. He is a good Bayesian and an okay bluffer. https://t.co/YtYN5sdTlc",
      "expandedUrl" : "https://twitter.com/i/web/status/1199714226459332608"
    }
  },
  {
    "like" : {
      "tweetId" : "1199725158094778368",
      "fullText" : "Breaking news...I have actually booked up my Christmas holiday, its still using days from 2018 but I am getting better at this holiday thing! in 2019 I might use them all.",
      "expandedUrl" : "https://twitter.com/i/web/status/1199725158094778368"
    }
  },
  {
    "like" : {
      "tweetId" : "1199332905220227072",
      "fullText" : "Ons onderzoek naar effecten van de online keuzeomgeving op leengedrag staat online!\n\nWe vinden effecten op aangevraagd leenbedrag, aflosbedrag en looptijd. Soms in onverwachte richting...\n\nLees meer in het rapport en de infographic! https://t.co/V4xrFpF2sX",
      "expandedUrl" : "https://twitter.com/i/web/status/1199332905220227072"
    }
  },
  {
    "like" : {
      "tweetId" : "1198983795225104384",
      "fullText" : "\"Steun het nadenken, onze wereld rust erop\" Hear, hear! https://t.co/qGqe3BAIla",
      "expandedUrl" : "https://twitter.com/i/web/status/1198983795225104384"
    }
  },
  {
    "like" : {
      "tweetId" : "1198972600124350469",
      "fullText" : "Holy shit, interieur van de nieuwe slaaptreinen van de ÖBB. Ik weet niet waar ze heen gaan, maar ik ga erheen.\n(via @noordwestexpres) https://t.co/zDXlRBvWCB",
      "expandedUrl" : "https://twitter.com/i/web/status/1198972600124350469"
    }
  },
  {
    "like" : {
      "tweetId" : "1198871514721980421",
      "fullText" : "Job market candidates: I will be posting @TiUEconomics hiring committee's process as we move along the job market season. I offer this in the hope that others join in and unreliable sources like econjobrumors get consulted less.",
      "expandedUrl" : "https://twitter.com/i/web/status/1198871514721980421"
    }
  },
  {
    "like" : {
      "tweetId" : "1198034957576409088",
      "fullText" : "While @indycashew is at SEA, we are having a weekend of \"don't tell mum\" time. 4yo managed to sneak these on me while watching a movie tonight. I was aware of the pink one, but the green one came as a surprise when I looked in the mirror. https://t.co/n6wctSzTXm",
      "expandedUrl" : "https://twitter.com/i/web/status/1198034957576409088"
    }
  },
  {
    "like" : {
      "tweetId" : "1197901415252840448",
      "fullText" : "New coding example on my website \"For loops in Stata: foreach (and a bit of esttab)\"\n\nThis is one of the tricks @DeNewJohn showed me that has greatly improved my productivity. I showed it to my class yesterday.\n\nhttps://t.co/RRIDQFamUr",
      "expandedUrl" : "https://twitter.com/i/web/status/1197901415252840448"
    }
  },
  {
    "like" : {
      "tweetId" : "1197847267828535299",
      "fullText" : "Archaeology is a subset of predatory spam journals that are targeting me today. I guess digging up roman flood insurance contracts must be more common than I thought.",
      "expandedUrl" : "https://twitter.com/i/web/status/1197847267828535299"
    }
  },
  {
    "like" : {
      "tweetId" : "1197188997950259200",
      "fullText" : "Last week during the Q&amp;A session Duflo answered, \"That was more of a comment than a question,\" and I cannot stop thinking about it",
      "expandedUrl" : "https://twitter.com/i/web/status/1197188997950259200"
    }
  },
  {
    "like" : {
      "tweetId" : "1197256984694861827",
      "fullText" : "Virtual and augmented reality enhanced by touch https://t.co/tjSjv0oMSb",
      "expandedUrl" : "https://twitter.com/i/web/status/1197256984694861827"
    }
  },
  {
    "like" : {
      "tweetId" : "1197163193585590274",
      "fullText" : "Our paper is published in @Nutrients_MDPI: Served portion sizes affect later food intake\nthrough social consumption norms: https://t.co/BhfFJXbv5Q This makes my research visit to the University of Liverpool complete! @AshleighHaynes @eric_robinson_ @EllenvanKleef  @Emely_de_Vet",
      "expandedUrl" : "https://twitter.com/i/web/status/1197163193585590274"
    }
  },
  {
    "like" : {
      "tweetId" : "1197123266009280515",
      "fullText" : "Werken als gedragsonderzoeker voor een onafhankelijk instituut?  https://t.co/d2RPzhn8RR",
      "expandedUrl" : "https://twitter.com/i/web/status/1197123266009280515"
    }
  },
  {
    "like" : {
      "tweetId" : "1196559508425695232",
      "fullText" : "Working on human behaviour &amp; energy/climate change/environmental issues? We're really interested to hear more🌱 https://t.co/VsMsrcVa9a",
      "expandedUrl" : "https://twitter.com/i/web/status/1196559508425695232"
    }
  },
  {
    "like" : {
      "tweetId" : "1196108176476782595",
      "fullText" : "Hey #EconTwitter, please give a warm welcome to @EvaRye\n\nShe's an Econ Ph.D. student at Aarhus but she's visiting @CornellEcon for the semester\n\nShe does really amazing work on econ of risky health behaviors, a lot of which uses Danish register data (so cool!!)",
      "expandedUrl" : "https://twitter.com/i/web/status/1196108176476782595"
    }
  },
  {
    "like" : {
      "tweetId" : "1196467383629733894",
      "fullText" : "Gave a seminar today in Paris (U. Paris 8) on a joint project with @TheBrouwer and @mc_villeval. Very nice people and a lot of questions! Thanks for the invitation.",
      "expandedUrl" : "https://twitter.com/i/web/status/1196467383629733894"
    }
  },
  {
    "like" : {
      "tweetId" : "1196407721089753097",
      "fullText" : "WE HEBBEN GEWONNEN!!\n\nOp... https://t.co/CVbYOYRAxg",
      "expandedUrl" : "https://twitter.com/i/web/status/1196407721089753097"
    }
  },
  {
    "like" : {
      "tweetId" : "1196251873772093440",
      "fullText" : "Update: She’s officially a programmer. I just heard from the kitchen “Ugh!!! C’mon!!!” followed by a few minutes of silence, followed by gleeful squeals of satisfaction. Yup... been there more times than I can count. https://t.co/Z2ArfV7OHI",
      "expandedUrl" : "https://twitter.com/i/web/status/1196251873772093440"
    }
  },
  {
    "like" : {
      "tweetId" : "1194350062341697537",
      "fullText" : "We are looking to admit a new PhD student in Economics to study the economics of risky health behaviors at @ErasmusESE as part of @ErasmusSCBH. Student will be supervised by me and Hans van Kippersluis. Deadline Jan 8 2020. Please distribute widely! https://t.co/55BkidpJ8y",
      "expandedUrl" : "https://twitter.com/i/web/status/1194350062341697537"
    }
  },
  {
    "like" : {
      "tweetId" : "1165083259614715904",
      "fullText" : "Finally got to visit Philadelphia. What an amazing view from City Hall Tower! https://t.co/LAnI2gypbp",
      "expandedUrl" : "https://twitter.com/i/web/status/1165083259614715904"
    }
  },
  {
    "like" : {
      "tweetId" : "1195623648469622784",
      "fullText" : "Extremely happy to announce that yesterday I successfully defended my PhD thesis. https://t.co/CFNUCgMbeD",
      "expandedUrl" : "https://twitter.com/i/web/status/1195623648469622784"
    }
  },
  {
    "like" : {
      "tweetId" : "1194974515085922305",
      "fullText" : "@paulhudson028 you might already know this one, but still: https://t.co/wLHlOBHVkn",
      "expandedUrl" : "https://twitter.com/i/web/status/1194974515085922305"
    }
  },
  {
    "like" : {
      "tweetId" : "1194642086320132099",
      "fullText" : "ok #poliscitwitter, i know there's *something* happening on TV right now, but i need your attention for a MINUTE.\n\nA thread on the latest fallout from the #Dominguez scandal at Harvard:",
      "expandedUrl" : "https://twitter.com/i/web/status/1194642086320132099"
    }
  },
  {
    "like" : {
      "tweetId" : "1194610350458580992",
      "fullText" : "Looks like a great issue!  Experimental methods are being used well in many different subfields of economics to explore important questions that you can't get at any other way. https://t.co/X0sEzqufJW",
      "expandedUrl" : "https://twitter.com/i/web/status/1194610350458580992"
    }
  },
  {
    "like" : {
      "tweetId" : "1194591674292428800",
      "fullText" : "Final week to apply for the position of Assistant Professor of Economics at Leiden University! #vacancy \nhttps://t.co/kDXpqyoWa4 https://t.co/jQxfSaAP44",
      "expandedUrl" : "https://twitter.com/i/web/status/1194591674292428800"
    }
  },
  {
    "like" : {
      "tweetId" : "1194523712453828608",
      "fullText" : "Onze eigen @CaAl @univgroningen is één van de deelnemers van de Nationale Wetenschapsquiz 2019! 💪https://t.co/DjVHKg3b5p",
      "expandedUrl" : "https://twitter.com/i/web/status/1194523712453828608"
    }
  },
  {
    "like" : {
      "tweetId" : "1194300566253559810",
      "expandedUrl" : "https://twitter.com/i/web/status/1194300566253559810"
    }
  },
  {
    "like" : {
      "tweetId" : "1194088151557582848",
      "fullText" : "#EconTwitter We are hiring postdocs! \nhttps://t.co/JccKA5hcSM\n\n#JILAEE is a center recently started by John List (@UChi_Economics) and Julio Elias (@UCEMA_edu). We partner with large firms &amp; gov't orgs around Latin America to do experiments w/ an impact. Join us (or pls RT)! 1/N",
      "expandedUrl" : "https://twitter.com/i/web/status/1194088151557582848"
    }
  },
  {
    "like" : {
      "tweetId" : "1193958560356610049",
      "fullText" : "Hi all! The Library of Statistical Techniques has a new home! https://t.co/PQEnQsf9UO is much nicer looking, has better search, and subcategories. Check it out and consider contributing! See the Contributing page for more info. https://t.co/KXAAFY3B0g",
      "expandedUrl" : "https://twitter.com/i/web/status/1193958560356610049"
    }
  },
  {
    "like" : {
      "tweetId" : "1193906224711888896",
      "fullText" : "I think I have found a global max for my @MATLAB coding utility function!\n#EconTwitter #AcademicChatter @uniinnsbruck https://t.co/6cRMOiHFjO",
      "expandedUrl" : "https://twitter.com/i/web/status/1193906224711888896"
    }
  },
  {
    "like" : {
      "tweetId" : "1192825730872356865",
      "fullText" : "We congratulate professor @PhilipWard_ who today gave his oration entitled “Bending the trend: Towards sustainable flood and drought risk solutions through understanding global disaster risk”. https://t.co/wtKZH9pkja",
      "expandedUrl" : "https://twitter.com/i/web/status/1192825730872356865"
    }
  },
  {
    "like" : {
      "tweetId" : "1192753443963854854",
      "expandedUrl" : "https://twitter.com/i/web/status/1192753443963854854"
    }
  },
  {
    "like" : {
      "tweetId" : "1192979206352842752",
      "fullText" : "The celebrations in academia can be few and far between, but this week @Indycashew and I both had papers accepted, so we'll call this one a win. https://t.co/MNvAJhi5Nd",
      "expandedUrl" : "https://twitter.com/i/web/status/1192979206352842752"
    }
  },
  {
    "like" : {
      "tweetId" : "1192462813010255875",
      "fullText" : "Who did say studying abroad is not for PhD students? \nI am thankful for the partnership between @VTAgEcon and @uniinnsbruck that gives PhD students the opportunity to conduct research and take courses abroad! #EconTwitter #AcademicChatter https://t.co/T4VcBEjG5w",
      "expandedUrl" : "https://twitter.com/i/web/status/1192462813010255875"
    }
  },
  {
    "like" : {
      "tweetId" : "1192308032887111680",
      "fullText" : "This is going to be my illustration of choice overload next semester https://t.co/U39h3ifrGF",
      "expandedUrl" : "https://twitter.com/i/web/status/1192308032887111680"
    }
  },
  {
    "like" : {
      "tweetId" : "1192008147336122368",
      "fullText" : "Today, we are hosting Agne Kajackaite. She is Head of the Research Group \"Ethics and Behavioral Economics\" at the WZB Berlin Social Science Center. She will spend the whole day at @GATE_LSE. Great to have you around, @agnekaj!",
      "expandedUrl" : "https://twitter.com/i/web/status/1192008147336122368"
    }
  },
  {
    "like" : {
      "tweetId" : "1191257509815734275",
      "fullText" : "How to make an appendix look pretty\n(and easy to understand) https://t.co/GEVQdXwrbf",
      "expandedUrl" : "https://twitter.com/i/web/status/1191257509815734275"
    }
  },
  {
    "like" : {
      "tweetId" : "1191668887445749760",
      "fullText" : "Alternative title: \"Any Amount of Running Associated with Other Behaviors which Decrease Risk of Premature Death.\"  \n\n\"IT'S SELECTION!\", she yelled into the void. https://t.co/VljohtrJ0y",
      "expandedUrl" : "https://twitter.com/i/web/status/1191668887445749760"
    }
  },
  {
    "like" : {
      "tweetId" : "1191376060283273216",
      "fullText" : "‼️ BREAKING NEWS: De Keuringsdienst komt met een nieuwe webserie: KVWeetjes. Nieuwe onderwerpen en nieuwe verslaggevers: Nathan en Rens. Elke woensdag 15:00 op Facebook en YouTube! #kvw #keuringsdienstvanwaarde #KVWeetjes https://t.co/V7hFxFZUqo",
      "expandedUrl" : "https://twitter.com/i/web/status/1191376060283273216"
    }
  },
  {
    "like" : {
      "tweetId" : "1191358387612790784",
      "fullText" : "I woke up to some good news this morning: my paper \"Measuring and Comparing Two Kinds of Rationalizable Opportunity Cost in Mixture Models\" has been accepted by Games for their special issue titled \"The Empirics of Behaviour under Risk and Ambiguity\" https://t.co/6B9TUdI4EQ",
      "expandedUrl" : "https://twitter.com/i/web/status/1191358387612790784"
    }
  },
  {
    "like" : {
      "tweetId" : "1190288863157276673",
      "fullText" : "Onderweg terug van weer een inspirerend video-interview met hoogleraar economie en ex-senator Henriette Prast van @TilburgU. Willen we meer of minder veldexperimenten? Wat zijn ethische aspecten vd gedragseconomie en hoe is het vakgebied gedragseconomie in Nederland ontstaan?",
      "expandedUrl" : "https://twitter.com/i/web/status/1190288863157276673"
    }
  },
  {
    "like" : {
      "tweetId" : "1190011888521887747",
      "fullText" : "My lab is made of: voodoo correlation, the dead salmon study, p hacking, bunferonni correction, bold signal, Freudian slip, Dana Big and climate change. https://t.co/o6GkeRDZ2S",
      "expandedUrl" : "https://twitter.com/i/web/status/1190011888521887747"
    }
  },
  {
    "like" : {
      "tweetId" : "1190232348618559489",
      "fullText" : "Ik ben bezig met het maken van een vragenlijst voor mijn onderzoek en hiervoor wil ik een aantal vragen testen. Het zou top zijn als je me daarbij kan helpen! Het kost je een paar minuutjes. Link: https://t.co/htIuVFm0uu\nRT'en wordt erg gewaardeerd!",
      "expandedUrl" : "https://twitter.com/i/web/status/1190232348618559489"
    }
  },
  {
    "like" : {
      "tweetId" : "1190239469330485249",
      "fullText" : "@erinhengel I have a paper conditionally accepted, which is just me. So...I guess that will help?",
      "expandedUrl" : "https://twitter.com/i/web/status/1190239469330485249"
    }
  },
  {
    "like" : {
      "tweetId" : "1190231851073523712",
      "fullText" : "@B_I_Tweets We have the same goal in the Netherlands. We’re currently developing a database with effective safety measures and also testing interventions with field experiments ourselves!",
      "expandedUrl" : "https://twitter.com/i/web/status/1190231851073523712"
    }
  },
  {
    "like" : {
      "tweetId" : "1189919685980098561",
      "fullText" : "This afternoon @StefanLipman and I organised a small symposium @ESHPM_EUR where the students from our Minor presented posters of their clever interventions to improve health behaviour. It was a big success with lots of discussion! #behaviouraleconomics #Nudge",
      "expandedUrl" : "https://twitter.com/i/web/status/1189919685980098561"
    }
  },
  {
    "like" : {
      "tweetId" : "1189896588799496195",
      "fullText" : "Where my other estimators at? #HappyHalloween #EconTwitter https://t.co/s2utnNMTvj",
      "expandedUrl" : "https://twitter.com/i/web/status/1189896588799496195"
    }
  },
  {
    "like" : {
      "tweetId" : "1189920065275269123",
      "fullText" : "At the doctors office. Wie anders dan Alfred red je in nood? dé communicatiebox die Paul gebruikt tijdens lezingen met mij was even kapot. Daarmee kan hij als een drummer accenten geven aan mijn verbale gedeelte. Made by @UTwenteCreate studenten ❤️#arduinos #snoertjes #ledjes https://t.co/aZTeF08GCE",
      "expandedUrl" : "https://twitter.com/i/web/status/1189920065275269123"
    }
  },
  {
    "like" : {
      "tweetId" : "1189772411501043713",
      "fullText" : "Check out our proposal on @sciencemagazine. Ask experts (&amp; non-experts) to predict research results. Clarifies how much updating/surprise with a study, can reduce incidence of null results, and helps in experimental design. Ongoing work w/ @Devin_G_Pope @evavivalt @deankarlan https://t.co/rQHo6FhIIc",
      "expandedUrl" : "https://twitter.com/i/web/status/1189772411501043713"
    }
  },
  {
    "like" : {
      "tweetId" : "1189682976197615617",
      "fullText" : "During Energy Week, we had the opportunity to check out the @AnnenbergPenn exhibit exploring blockchain in Iceland. Did you miss it? You can still visit the exhibit through May 2020. #EnergyAtPenn https://t.co/1cnnNJuVEG",
      "expandedUrl" : "https://twitter.com/i/web/status/1189682976197615617"
    }
  },
  {
    "like" : {
      "tweetId" : "1189544559468040193",
      "fullText" : "Super important note on null results here: \"Duflo has tested and published the results of many experiments that have improved the desired outcomes, but she has also published a wide range of experiments that either didn’t work or didn’t work as expected.\" https://t.co/jFcz8EfjPr",
      "expandedUrl" : "https://twitter.com/i/web/status/1189544559468040193"
    }
  },
  {
    "like" : {
      "tweetId" : "1189527119300190211",
      "fullText" : "Dr. Carolyn Kousky, Executive Director of the @WhartonRiskCtr, spoke with the @WSJ about the 'disaster gap' and how insurers and homeowners are looking for more ways to cover expenses as natural disasters increase https://t.co/QOGMS52QJO",
      "expandedUrl" : "https://twitter.com/i/web/status/1189527119300190211"
    }
  },
  {
    "like" : {
      "tweetId" : "1189270488511590400",
      "fullText" : "Receiving physical mail is so under-appreciated these days! \n\nHuge thanks to @motivationguru &amp; @THoulihan from @behavioralgroov for interviewing some of the #NoBeC2019 speakers for their new podcast episodes. Frankly, I’m looking forward to those more than to hearing myself 😬😄 https://t.co/hW4m8A7xla https://t.co/Y67v8EaWMc",
      "expandedUrl" : "https://twitter.com/i/web/status/1189270488511590400"
    }
  },
  {
    "like" : {
      "tweetId" : "1189135146999603200",
      "fullText" : "In haar proefschrift introduceert VU-milieuwetenschapper van de @VU_Science Gabriela Guimarães Nobre nieuwe methoden om natuurlijke gevaren te vertalen naar verwachte sociaaleconomische effecten die gebruikt kunnen worden voor rampenpreventie. Lees meer: https://t.co/Ruz0x3iPwn https://t.co/q3N5CV8wrf",
      "expandedUrl" : "https://twitter.com/i/web/status/1189135146999603200"
    }
  },
  {
    "like" : {
      "tweetId" : "1189166399899475970",
      "fullText" : "🇲🇽🌽 Nacho's en tortilla's verschillen van naam, prijs en vorm. Maar qua smaak lijken ze precies hetzelfde. Dus wat is het verschil? Donderdag 20:25 op NPO 3. #kvw #keuringsdienst #nacho #tortilla https://t.co/yMwNUzhCSQ",
      "expandedUrl" : "https://twitter.com/i/web/status/1189166399899475970"
    }
  },
  {
    "like" : {
      "tweetId" : "1189074333932625920",
      "fullText" : "Is er eigenlijk wel eens onderzocht wat er van de outreach-beloftes in reguliere voorstellen terecht is gekomen @NWONieuws en @ionicasmeets? https://t.co/lOuz49mHUx",
      "expandedUrl" : "https://twitter.com/i/web/status/1189074333932625920"
    }
  },
  {
    "like" : {
      "tweetId" : "1189091413465686018",
      "fullText" : "The final week of the minor (with deadlines and exam next week)! Today we discuss economic evaluation and measurement (by @jobvanexel) and presenting skills (yours truly). Thursday our students will present the interventions they developed!",
      "expandedUrl" : "https://twitter.com/i/web/status/1189091413465686018"
    }
  },
  {
    "like" : {
      "tweetId" : "1188843928822435840",
      "fullText" : "Tekening gemaakt. Het is een tweeluik van een zwerm.\n\n‘De eerste dans | De laatste dans’\n\nBas Geeraets\nInkt op papier\n100 x 130 cm\n\nRetweet is lief. https://t.co/FcPACzLYTE",
      "expandedUrl" : "https://twitter.com/i/web/status/1188843928822435840"
    }
  },
  {
    "like" : {
      "tweetId" : "1188912481919492096",
      "fullText" : "@thomas_mock @R4DScommunity Hi there, I am one of the @SquirrelCensus founding members. R is my second language (first: Italian, third: English). I used R to perform the count analyses. I am very happy that you are going to use R to make cool stuff. Excited to see thye final product/s.",
      "expandedUrl" : "https://twitter.com/i/web/status/1188912481919492096"
    }
  },
  {
    "like" : {
      "tweetId" : "1188911287666913281",
      "fullText" : "We are hiring a postdoc in Computational Social Science at Microsoft Research-New York City. Application deadline December 8, 2019. RTs appreciated.\n\nhttps://t.co/PxM5gGiVNM",
      "expandedUrl" : "https://twitter.com/i/web/status/1188911287666913281"
    }
  },
  {
    "like" : {
      "tweetId" : "1188887495284531201",
      "fullText" : "If I would live in the US, I would make this map for myself.\nNow that think about it: same map for EU regions is a good candidate for #30DayMapChallenge https://t.co/gVzsIgksOG",
      "expandedUrl" : "https://twitter.com/i/web/status/1188887495284531201"
    }
  },
  {
    "like" : {
      "tweetId" : "1188727852935581697",
      "fullText" : "\"Are we all behavioural economists now?\" The @econmethodology debate continues, next in San Diego #ASSA2020 with @CFCamerer @cherfeld @ErikAngner @Undercoverhist @MKL4ES https://t.co/gtCM7tGgOG",
      "expandedUrl" : "https://twitter.com/i/web/status/1188727852935581697"
    }
  },
  {
    "like" : {
      "tweetId" : "1188703251149066241",
      "fullText" : "\"Let the dataset change your mindset\" - Hans Rosling\n\n#statistics #data #rstats\n\n#ArtificialStupidity no.54 https://t.co/KvEmdphxJp",
      "expandedUrl" : "https://twitter.com/i/web/status/1188703251149066241"
    }
  },
  {
    "like" : {
      "tweetId" : "1188561506746716160",
      "fullText" : "Job market candidates: We are hiring! @TiUEconomics is looking for two new colleagues (all fields) to join us @TilburgU! https://t.co/fJhf5LW9e9 If you're doing great research in economics, are a good teacher and nice person, apply today, the deadline is soon! Some useful info:",
      "expandedUrl" : "https://twitter.com/i/web/status/1188561506746716160"
    }
  },
  {
    "like" : {
      "tweetId" : "1188802975084490752",
      "fullText" : "Weet je wélk vak íedereen op school zou moeten krijgen? \n\nHet vak 'dat ik iets door mijn expertise of persoonlijke ervaring heel belangrijk vind wil nog niet zeggen dat álle kinderen dit moeten leren en zeg maar ook maar eens wat er dan uit het curriculum moet.' \n\nDat vak.",
      "expandedUrl" : "https://twitter.com/i/web/status/1188802975084490752"
    }
  },
  {
    "like" : {
      "tweetId" : "1188662087293247490",
      "fullText" : "You’re unable to view this Post because this account owner limits who can view their Posts. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1188662087293247490"
    }
  },
  {
    "like" : {
      "tweetId" : "1188784998821838848",
      "fullText" : "Dit was wat je noemt een enerverende ochtend! 🎉 Eerst vertellen over onze gedragsonderzoeken bij de aftrap van de actieagenda (zie bijv het onderzoek voor @Flanderijn: https://t.co/6yOCzRDmv9) en daarna plotseling aan mogen sluiten bij.. [1/2] https://t.co/jr4Copt3qg",
      "expandedUrl" : "https://twitter.com/i/web/status/1188784998821838848"
    }
  },
  {
    "like" : {
      "tweetId" : "1187980503565123584",
      "fullText" : "Fijn om nog eens op de homepagina van een krant te staan 😎 https://t.co/TUF6e0nm8z (🔒) https://t.co/OUksfHJUDl",
      "expandedUrl" : "https://twitter.com/i/web/status/1187980503565123584"
    }
  },
  {
    "like" : {
      "tweetId" : "1187842692778201088",
      "fullText" : "Love this perspective. I feel we need more #northisnotup maps https://t.co/xbQ63bUfzE",
      "expandedUrl" : "https://twitter.com/i/web/status/1187842692778201088"
    }
  },
  {
    "like" : {
      "tweetId" : "1187947140028305408",
      "fullText" : "Our “Malleable Lies” paper is in the current issue of Management Science. 🤘 For a summary of our simple theory and high stakes empirical analysis on the relation between free-form pre-play communication and cooperation, see 👇 https://t.co/hAUYNrFwPP",
      "expandedUrl" : "https://twitter.com/i/web/status/1187947140028305408"
    }
  },
  {
    "like" : {
      "tweetId" : "1187468397828702209",
      "fullText" : "Know someone who's Dutch? Why not share this with them &gt;&gt;&gt; https://t.co/VNHM48cAUe",
      "expandedUrl" : "https://twitter.com/i/web/status/1187468397828702209"
    }
  },
  {
    "like" : {
      "tweetId" : "1187705870521688064",
      "fullText" : "This is what I do :) https://t.co/9cvMJNyTtz",
      "expandedUrl" : "https://twitter.com/i/web/status/1187705870521688064"
    }
  },
  {
    "like" : {
      "tweetId" : "1187511734409449475",
      "fullText" : "Lots of good ideas won't work and that's OK!\n\neffective #behaviourchange programs need to be Easy, Attractive, Social, and Timely\n\nSo, we need to think about how, when and where we deliver our messages, but not be disheartened when it doesntwork out #ChangeConf2019 @B_I_Tweets",
      "expandedUrl" : "https://twitter.com/i/web/status/1187511734409449475"
    }
  },
  {
    "like" : {
      "tweetId" : "1187644740931600384",
      "fullText" : "We vergelijken leren van een plattegrond met leren in een virtuele weergave van het terrein - het #goffertpark in Nijmegen. Een student @LeidenPsy bekijkt de navigatieprestatie van de groepen voor haar scriptie neuropsychologie. Leuk om zo onderzoek en onderwijs te combineren 3/3",
      "expandedUrl" : "https://twitter.com/i/web/status/1187644740931600384"
    }
  },
  {
    "like" : {
      "tweetId" : "1187451730654482432",
      "fullText" : "And a probability question for the undergrads that tripped me up when I tried to do it in my head first #TeachBE https://t.co/uXjzN1TGke",
      "expandedUrl" : "https://twitter.com/i/web/status/1187451730654482432"
    }
  },
  {
    "like" : {
      "tweetId" : "1187616309326106624",
      "expandedUrl" : "https://twitter.com/i/web/status/1187616309326106624"
    }
  },
  {
    "like" : {
      "tweetId" : "1187295726113624064",
      "fullText" : "I would be grateful for examples of clear and simple communications of #food carbon footprints. We potentially can test those! @klimafakten @k3klima @FCRN @Carbon_Literacy @CAST_Centre @dr_anneowen @FCRNetwork @Risk_Literacy @mpib_berlin https://t.co/NqRkSaKXji",
      "expandedUrl" : "https://twitter.com/i/web/status/1187295726113624064"
    }
  },
  {
    "like" : {
      "tweetId" : "1187358394505748480",
      "fullText" : "Our piece on scaling up climate cooperation, based on a large review of the theoretical and empirical literature, is out. #ClimateChange #cooperation @voxeu @UniboMagazine @GRI_LSE https://t.co/QAsa8LoHXz",
      "expandedUrl" : "https://twitter.com/i/web/status/1187358394505748480"
    }
  },
  {
    "like" : {
      "tweetId" : "1187380429726330880",
      "fullText" : "@JantsjeMol @JamesBland_Econ @eugen_dimant @BorisLeeuwen @DAycinena @atavoni Also simply different parameters in repeated PDs like https://t.co/fcV7J6G3D8",
      "expandedUrl" : "https://twitter.com/i/web/status/1187380429726330880"
    }
  },
  {
    "like" : {
      "tweetId" : "1187379247159136258",
      "fullText" : "@JantsjeMol @JamesBland_Econ @eugen_dimant @BorisLeeuwen @DAycinena Threshold PGG with and without inequality? Like the PNAS paper by @atavoni and others? The PD games on PNAS with uncertainty by Barrett and Danneberg also on PNAS seem implementable.",
      "expandedUrl" : "https://twitter.com/i/web/status/1187379247159136258"
    }
  },
  {
    "like" : {
      "tweetId" : "1187069692348755968",
      "fullText" : "@JantsjeMol @eugen_dimant @rghidoni86 @BorisLeeuwen @DAycinena Also, common pool resource experiments are very applicable for environmental",
      "expandedUrl" : "https://twitter.com/i/web/status/1187069692348755968"
    }
  },
  {
    "like" : {
      "tweetId" : "1187069544419868673",
      "fullText" : "@JantsjeMol @eugen_dimant @rghidoni86 @BorisLeeuwen @DAycinena What you've got there is a continuous Prisoner's Dilemma! Do the same with Stag Hunt and Volunteer's Dilemma (i.e. minimum effort &amp; threshold public good).",
      "expandedUrl" : "https://twitter.com/i/web/status/1187069544419868673"
    }
  },
  {
    "like" : {
      "tweetId" : "1187290170967646213",
      "fullText" : "Consumers struggle identifying effective rules of thumb for reducing food carbon footprints. We need better communications informing both their individual and policy decisions related to food and climate @PriestleyCentre @SRILeeds @LeedsUniBSchool @sfiscience #carbonliteracy https://t.co/I7oxglMTgM",
      "expandedUrl" : "https://twitter.com/i/web/status/1187290170967646213"
    }
  },
  {
    "like" : {
      "tweetId" : "1187150042139975681",
      "fullText" : "Want to hear some of your #EconTwitter favorites spin haikus and limericks about their econ research? Support @ProbCausation via Patreon, and you can do just that. Our first bonus episode here: https://t.co/det2Ku13Jx",
      "expandedUrl" : "https://twitter.com/i/web/status/1187150042139975681"
    }
  },
  {
    "like" : {
      "tweetId" : "1187097486156095489",
      "fullText" : "We are ending the day back at the Kleinman Center. Penny Liao of @WhartonRiskCtr is presenting on sea level rise and the social cost of flood insurance subsidies. #EnergyAtPenn https://t.co/tzUYAomIZp",
      "expandedUrl" : "https://twitter.com/i/web/status/1187097486156095489"
    }
  },
  {
    "like" : {
      "tweetId" : "1187069771382247424",
      "fullText" : "That moment you are travelling to teach #dataviz, and this is your Airbnb host's bookshelf https://t.co/WqbEw0LTHi",
      "expandedUrl" : "https://twitter.com/i/web/status/1187069771382247424"
    }
  },
  {
    "like" : {
      "tweetId" : "1187012797525352448",
      "fullText" : "*Event reminder!* Today at 4pm in @KleinmanEnergy's Classroom. https://t.co/FWEQ7ZsyjH",
      "expandedUrl" : "https://twitter.com/i/web/status/1187012797525352448"
    }
  },
  {
    "like" : {
      "tweetId" : "1186755432435482625",
      "fullText" : "[Postdoc job advert] Please spread widely. We have 3 postdoc positions (&amp; more coming) at the newly-established Max-Planck Center for Humans &amp; Machines @Max_Planck_CHM @mpib_berlin \n\nLooking for highly motivated, adventurous, interdisciplinary scientists.\n\nDetails below. https://t.co/8jSrPtY07j",
      "expandedUrl" : "https://twitter.com/i/web/status/1186755432435482625"
    }
  },
  {
    "like" : {
      "tweetId" : "1186991298147946498",
      "fullText" : "Filmpjes kijken en vroegen hoe lang die duurden. De tijd leek vooral sneller te gaan bij filmpjes die emotie opwekten, zowel voor de echte en virtuele filmpjes. Het lijkt dus belangrijk om goed te kijken naar wat mensen te zien krijgen, niet hoe. 2/2",
      "expandedUrl" : "https://twitter.com/i/web/status/1186991298147946498"
    }
  },
  {
    "like" : {
      "tweetId" : "1186971247260950528",
      "fullText" : "@causalinf me and you right now: https://t.co/rjudvZSXiM",
      "expandedUrl" : "https://twitter.com/i/web/status/1186971247260950528"
    }
  },
  {
    "like" : {
      "tweetId" : "1186927228006862848",
      "fullText" : "#virtualreality wordt steeds belangrijker in de psychologie, dat vraagt om onderzoek naar hoe we VR verwerken. Anne Cuperus promoveert 10 december bij @AndreaEvers en mij op dit onderwerp @UniLeiden: VR helpt o.a. bij traumaverwerking.",
      "expandedUrl" : "https://twitter.com/i/web/status/1186927228006862848"
    }
  },
  {
    "like" : {
      "tweetId" : "1186882745521397760",
      "fullText" : "Registered Reports Remove Pressure on Researchers to Get the “Right” Results - Behavioral Scientist ⁦@behscientist⁩ #EconTwitter #socsciresearch https://t.co/aBbEvC7In7",
      "expandedUrl" : "https://twitter.com/i/web/status/1186882745521397760"
    }
  },
  {
    "like" : {
      "tweetId" : "1186675735492087808",
      "fullText" : "Hey #EconTwitter graduate students: are you on the market this year? Send me your JMP. \n\nAt a minimum, I'll give some comments. If it's good / interesting / funny, I'll talk it up! \n\nAnd as an added bonus, it'll make the meetings more fun to \"know\" more people.",
      "expandedUrl" : "https://twitter.com/i/web/status/1186675735492087808"
    }
  },
  {
    "like" : {
      "tweetId" : "1186725805918838784",
      "fullText" : "More official pictures to come! #NoBeC2019 https://t.co/zJooIB1YOQ",
      "expandedUrl" : "https://twitter.com/i/web/status/1186725805918838784"
    }
  },
  {
    "like" : {
      "tweetId" : "1186733756616343552",
      "fullText" : "Parametric insurance is sometimes seen as an add-on for traditional homeowners insurance; payouts might be small, but there is no deductible - via @WSJ at https://t.co/xeDar3j9sw Read more to hear from Executive Director, Carolyn Kousky and Research Fellow, Benjamin Collier.",
      "expandedUrl" : "https://twitter.com/i/web/status/1186733756616343552"
    }
  },
  {
    "like" : {
      "tweetId" : "1186536562714206209",
      "fullText" : "@ionicasmeets Ik kreeg die vraag al een keer een twee maanden na mijn promotie. Dat voelde dan weer als wodka aangeboden krijgen voor je eerste groeispurt",
      "expandedUrl" : "https://twitter.com/i/web/status/1186536562714206209"
    }
  },
  {
    "like" : {
      "tweetId" : "1186451148871475204",
      "fullText" : "#TeachBE\nhttps://t.co/ALNjOE2nZ5",
      "expandedUrl" : "https://twitter.com/i/web/status/1186451148871475204"
    }
  },
  {
    "like" : {
      "tweetId" : "1186285400748412929",
      "fullText" : "Yes, session proposal accepted by @NH_EGU !  \n\nWant to show some nice work on multi-hazard w.r.t. disaster/impact risk assessments, climate change adaptation? \n\nSubmit an abstract to our session!  https://t.co/6bDPsq6l7d  \n\n@Marleen_Ruiter @Ste_rzi @annalojacomo https://t.co/UdncEDtcHY",
      "expandedUrl" : "https://twitter.com/i/web/status/1186285400748412929"
    }
  },
  {
    "like" : {
      "tweetId" : "1186256238729936896",
      "fullText" : "Wil je weten hoe goed je de weg kunt vinden en tips om dit te verbeteren? Doe onze test op https://t.co/cjViNRN3kg \nHier vind je een kort voorbeeld van de experimenten die wij zoal doen om navigatievermogen te meten. Gedurende deze week zal ik onze bevindingen hier delen.",
      "expandedUrl" : "https://twitter.com/i/web/status/1186256238729936896"
    }
  },
  {
    "like" : {
      "tweetId" : "1185995754336161793",
      "fullText" : "So looking forward to these episodes...they were some of the best we've ever done!  Thank you Eugen and everyone else at UPenn and #NoBeC2019!!! https://t.co/dgkGHWEury",
      "expandedUrl" : "https://twitter.com/i/web/status/1185995754336161793"
    }
  },
  {
    "like" : {
      "tweetId" : "1186237435514109952",
      "fullText" : "Rugby for Beginners https://t.co/zkWYR5Si7l",
      "expandedUrl" : "https://twitter.com/i/web/status/1186237435514109952"
    }
  },
  {
    "like" : {
      "tweetId" : "1186199312667164674",
      "fullText" : "@JantsjeMol Ja 😅 family dagje met de haagse branche",
      "expandedUrl" : "https://twitter.com/i/web/status/1186199312667164674"
    }
  },
  {
    "like" : {
      "tweetId" : "1184912517447012352",
      "fullText" : "Really great comments and presentations at #NoBeC2019\nThanks for having me! https://t.co/nSasov3nCE",
      "expandedUrl" : "https://twitter.com/i/web/status/1184912517447012352"
    }
  },
  {
    "like" : {
      "tweetId" : "1186021703425712133",
      "fullText" : "Excited to present our project tomorrow on the role of vmPFC during exploration/exploitation at #SfN19 nanosymposium of decision-making  @matthewrushworth @mkwittmann  @JacquieScholl @MKFlugge @EFouragnan @lev_tank https://t.co/XGoKZ3uj49",
      "expandedUrl" : "https://twitter.com/i/web/status/1186021703425712133"
    }
  },
  {
    "like" : {
      "tweetId" : "1185483488801316864",
      "expandedUrl" : "https://twitter.com/i/web/status/1185483488801316864"
    }
  },
  {
    "like" : {
      "tweetId" : "1185549424782561280",
      "fullText" : "We are looking for new colleagues! Assistant and associate professors. See our ad on SSRN for more info: https://t.co/ju3uvfSEaT",
      "expandedUrl" : "https://twitter.com/i/web/status/1185549424782561280"
    }
  },
  {
    "like" : {
      "tweetId" : "1185380678466179072",
      "fullText" : "#NoBeC2019 @Penn was a real success - I learned a ton from this accomplished and interdisciplinary crowd. Thanks so much for joining us! Spread the word and hopefully we’ll see ya next year for #NoBeC2020 💪🏻 https://t.co/qOGJEJRiBh",
      "expandedUrl" : "https://twitter.com/i/web/status/1185380678466179072"
    }
  },
  {
    "like" : {
      "tweetId" : "1185296976415318017",
      "fullText" : "Two of my favorite experimentalists explain interdisciplinary research!  Elke Weber and Rosemarie Nagel at #NoBeC2019 https://t.co/VzdHcYShem",
      "expandedUrl" : "https://twitter.com/i/web/status/1185296976415318017"
    }
  },
  {
    "like" : {
      "tweetId" : "1185097037240553477",
      "fullText" : "Thanks to the folks at CREED- Univ Amsterdam for the great hospitality! The number of bottles here indicates they are leading in the post-seminar beer hour competition on my European tour. https://t.co/sq7SOpAnDa",
      "expandedUrl" : "https://twitter.com/i/web/status/1185097037240553477"
    }
  },
  {
    "like" : {
      "tweetId" : "1184987612106416128",
      "fullText" : "Thrilled to be able to attend @behavioralgroov ‘s 100th episode with a stellar panel: Michael Hallsworth (@mhallsworth), Annie Duke (@AnnieDuke) and Jeff Kreisler (@jeffkreisler) Thanks to @PennMBDS ! https://t.co/H04nA54lVg",
      "expandedUrl" : "https://twitter.com/i/web/status/1184987612106416128"
    }
  },
  {
    "like" : {
      "tweetId" : "1184973527692271617",
      "fullText" : "Here we go! 🎉 \n\n#BG100 #behavioralscience #BehavioralEconomics https://t.co/kOqv8TfTrQ",
      "expandedUrl" : "https://twitter.com/i/web/status/1184973527692271617"
    }
  },
  {
    "like" : {
      "tweetId" : "1184752161458135040",
      "fullText" : "Today, we’re proud to announce a new collaboration @Wharton, part of @Penn. Together with our Geostrategic Business Group, we’re launching the Wharton Political Risk Lab. Find out what this means for your business: https://t.co/RJNn3NgW6A #geopolitics #BetterWorkingWorld https://t.co/kPCyMzsk4G",
      "expandedUrl" : "https://twitter.com/i/web/status/1184752161458135040"
    }
  },
  {
    "like" : {
      "tweetId" : "1184822046032683008",
      "fullText" : "The great @NicoLacetera is kicking off our #Norms and Behavioral Change Workshop @Penn with his talk on repugnant transactions.\n\nDay 1 program is stacked and we (@CBicchieri @EnriqueFatas @PennMBDS) are looking forward to hosting ~80 scholars from various disciplines #NoBeC2019 https://t.co/bw7VIP3nqT",
      "expandedUrl" : "https://twitter.com/i/web/status/1184822046032683008"
    }
  },
  {
    "like" : {
      "tweetId" : "1184602341456130051",
      "fullText" : "+1 https://t.co/QzYRyVq3zR",
      "expandedUrl" : "https://twitter.com/i/web/status/1184602341456130051"
    }
  },
  {
    "like" : {
      "tweetId" : "1184620021022167043",
      "fullText" : "My student Deepak Saraswat is presenting his paper on Impact of Goal Setting Student Effort and Learning- an at scale RCT in Zanzibar at the #NoBeC2019 conference at @Penn on October 17-18! Joint work with @AsadIslamBD, @shwetlena, Eema, and Sungoh. Please see his poster! https://t.co/0d5qmyJTlE",
      "expandedUrl" : "https://twitter.com/i/web/status/1184620021022167043"
    }
  },
  {
    "like" : {
      "tweetId" : "1184553035927830529",
      "fullText" : "#NoBec2019 keynote speaker, Deborah Prentice, provost &amp; Professor of Psychology &amp; Public Affairs, will talk about how #socialnorms serve as a catalyst for change and how to use norm interventions to change behaviors. Full agenda: https://t.co/4kj5xwTL8a\n #behavioralscience @Penn https://t.co/wNBkwylLTM",
      "expandedUrl" : "https://twitter.com/i/web/status/1184553035927830529"
    }
  },
  {
    "like" : {
      "tweetId" : "1183837516706799616",
      "expandedUrl" : "https://twitter.com/i/web/status/1183837516706799616"
    }
  },
  {
    "like" : {
      "tweetId" : "1183765153642405889",
      "fullText" : "Thanks so much @OkstateCAS for featuring my research in October's \"Faculty Scholar Spotlight.\" I'm so excited to build on this line of research in the coming years at @OKstatePoliSci !\n\nhttps://t.co/S8KJ0VOP5x https://t.co/pAWYQ9rDqB",
      "expandedUrl" : "https://twitter.com/i/web/status/1183765153642405889"
    }
  },
  {
    "like" : {
      "tweetId" : "1183074923993976832",
      "fullText" : "Our ESA contest winner - Xueting predicted that economists are level-5 thinkers. Here she is with her professor Rosemarie Nagel. https://t.co/uVBZ80bV6S",
      "expandedUrl" : "https://twitter.com/i/web/status/1183074923993976832"
    }
  },
  {
    "like" : {
      "tweetId" : "1183061938093342721",
      "fullText" : "A little more dramatic a few minutes later https://t.co/Ekyeu1wIB8",
      "expandedUrl" : "https://twitter.com/i/web/status/1183061938093342721"
    }
  },
  {
    "like" : {
      "tweetId" : "1182684549953683467",
      "fullText" : "Oct 17 KEYNOTE Speaker @NicoLacetera, whose research focuses on the ethical constraints to markets will discuss: \"What is Repugnant? The Empirics of Contested Transactions\" #NoBeC2019  https://t.co/MUU5Lfgi6G\n@penn #behavioralscience #economics https://t.co/0ab8C3vJZh",
      "expandedUrl" : "https://twitter.com/i/web/status/1182684549953683467"
    }
  },
  {
    "like" : {
      "tweetId" : "1182682627272302592",
      "fullText" : "Super excited to present my PhD project today at 2pm @Princeton, looking at the role of vmPFC during exploration/exploitation. Really grateful to be here!  @nathanieldaw @garrett_neil @cjahn_neuro https://t.co/eT1vMQwzAO",
      "expandedUrl" : "https://twitter.com/i/web/status/1182682627272302592"
    }
  },
  {
    "like" : {
      "tweetId" : "1182611040321921025",
      "fullText" : "this predatory journal email sure gives you all possible response options. What about adding \"5. Never write me again\" #AcademicTwitter https://t.co/9PXKy1DAIJ",
      "expandedUrl" : "https://twitter.com/i/web/status/1182611040321921025"
    }
  },
  {
    "like" : {
      "tweetId" : "1055568534498095104",
      "fullText" : "A map of every European City https://t.co/AMtSF8rhYJ",
      "expandedUrl" : "https://twitter.com/i/web/status/1055568534498095104"
    }
  },
  {
    "like" : {
      "tweetId" : "1182306496698150912",
      "fullText" : "A bit of fun with ggplot while my simulation does its thing. https://t.co/Xx5JOdShRy",
      "expandedUrl" : "https://twitter.com/i/web/status/1182306496698150912"
    }
  },
  {
    "like" : {
      "tweetId" : "1181969777931296773",
      "fullText" : "For an Economics of Sustainability class, I want to spend 15-30 minutes each week on a topic that is less commonly known (e.g., sustainable brewing) or an unexpected trade-off in sustainability initiatives. Looking for topic suggestions!! #EconTwitter @cwae_aaea @env_aaea",
      "expandedUrl" : "https://twitter.com/i/web/status/1181969777931296773"
    }
  },
  {
    "like" : {
      "tweetId" : "1181953546645843968",
      "fullText" : "If you're a doctoral student research #VR / #XR, please consider submitting your work to the @IEEEVR 2020 Doctoral Consortium!\n\nDeadline: November 23, 2019. https://t.co/WUyuI5NzbF",
      "expandedUrl" : "https://twitter.com/i/web/status/1181953546645843968"
    }
  },
  {
    "like" : {
      "tweetId" : "1181949698896224258",
      "fullText" : "Used this game in my behavioral science class @PennMBDS, students had a blast!\n\nGoal: test knowledge in small groups to avoid hindsight, then investigate which studies have been (un)successfully replicated since release of the game. Sounds like your kind of exercise @_alice_evans https://t.co/wxHcSNKwbs",
      "expandedUrl" : "https://twitter.com/i/web/status/1181949698896224258"
    }
  },
  {
    "like" : {
      "tweetId" : "1181945784784375808",
      "fullText" : "Evidence suggests that we are least happy when we are at work. \n\n@B_I_Tweets sought to change that today by organising a Walk and Talk in St James' Park for #MentalHealthAwarenessWeek  😎🌳🦆\n\nFind out how to make work a happier place on our blog https://t.co/zFJ3axcs38 https://t.co/2XwXpXf96N",
      "expandedUrl" : "https://twitter.com/i/web/status/1181945784784375808"
    }
  },
  {
    "like" : {
      "tweetId" : "1181912951365787648",
      "fullText" : "Wij van het promovendigroepje adviseren een promovendigroepje! https://t.co/qS5OC5GFMp",
      "expandedUrl" : "https://twitter.com/i/web/status/1181912951365787648"
    }
  },
  {
    "like" : {
      "tweetId" : "1181899982422630402",
      "fullText" : "@unipotsdam @VU_IVM Now, back to working on paper revisions, gotta great feelings of success when they come #AcademicTwitter",
      "expandedUrl" : "https://twitter.com/i/web/status/1181899982422630402"
    }
  },
  {
    "like" : {
      "tweetId" : "1181895987612266496",
      "fullText" : "Echt mijn buik vol van mensen die op socialmedia-cursus zijn geweest en daar hebben geleerd dat je vragen moet stellen om de interactie te vergroten.\n\nEn, waar ben jij helemaal klaar mee?",
      "expandedUrl" : "https://twitter.com/i/web/status/1181895987612266496"
    }
  },
  {
    "like" : {
      "tweetId" : "1181602157050650624",
      "fullText" : "Opportunity Alert: @behscientist contributors @AnnieDuke, @jeffkreisler, &amp; @mhallsworth will be helping the podcast @behavioralgroov celebrate its 100th episode w/ a live event on Oct 17 at the Pennsylvania Academy for Performing Arts at 7:00pm. Info here: https://t.co/j9r9ZXAyd2",
      "expandedUrl" : "https://twitter.com/i/web/status/1181602157050650624"
    }
  },
  {
    "like" : {
      "tweetId" : "1181864531380834309",
      "fullText" : "We have a tenure-track position in Neuroeconomics at CREED. Would be grateful if you share with talented researchers. https://t.co/67VjYqOiRM",
      "expandedUrl" : "https://twitter.com/i/web/status/1181864531380834309"
    }
  },
  {
    "like" : {
      "tweetId" : "1181584086537781249",
      "fullText" : "To whoever thought up the \"Reject and Resubmit\" journal status - What is wrong with you???\nJust say \"Major revisions.\" \n#PeerReview #AcademicChatter #AcWri #phdchat https://t.co/uMD9djewZ4",
      "expandedUrl" : "https://twitter.com/i/web/status/1181584086537781249"
    }
  },
  {
    "like" : {
      "tweetId" : "1181281371127463938",
      "fullText" : "Successfully defended my PhD dissertation today! In the spirit of acknowledging &amp; normalizing failure in the process, I defended in a skirt made of rejection letters from the course of my PhD. #AcademicTwitter #AcademicChatter #PhDone \nTHANK YOU to everyone involved in my journey https://t.co/FQbXYQ1Oov",
      "expandedUrl" : "https://twitter.com/i/web/status/1181281371127463938"
    }
  },
  {
    "like" : {
      "tweetId" : "1181582881677705217",
      "fullText" : "Today I noticed that the #norm-#nudge paper 👇🏻 with @CBicchieri was being mistakenly cited as published in the AER. I appreciate this case of wishful thinking 😄 \n\n#EconTwitter #SocSciResearch @_alice_evans https://t.co/aa6yoMWJte https://t.co/WqyfOmxk37",
      "expandedUrl" : "https://twitter.com/i/web/status/1181582881677705217"
    }
  },
  {
    "like" : {
      "tweetId" : "1181372911556411392",
      "fullText" : "You’re unable to view this Post because this account owner limits who can view their Posts. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1181372911556411392"
    }
  },
  {
    "like" : {
      "tweetId" : "1181314294065094657",
      "fullText" : "There is never a good reason to wear a suit with exactly matching pants, jacket, and shirt but WITHOUT a tie. \n\nWho are these barbarians? https://t.co/RbanyKREov",
      "expandedUrl" : "https://twitter.com/i/web/status/1181314294065094657"
    }
  },
  {
    "like" : {
      "tweetId" : "1180963256732717056",
      "fullText" : "political scientists: so we're all agreed? graphs are much easier to interpret than tables? \n\npsychologists: ...\n\npolitical scientists: ... \n\npsychologists: we (n=255) tried but (b =.33) we (SE =.03) can't (df =802.26) help (t =12.36, p=.001, 95% CI [.28, .39]) it https://t.co/quFs0AXBMm",
      "expandedUrl" : "https://twitter.com/i/web/status/1180963256732717056"
    }
  },
  {
    "like" : {
      "tweetId" : "1547695959575969794",
      "fullText" : "Very excited and grateful for this @NWO_SSH grant, which will allow Daan van Soest, Till Wicker and me to test light-touch interventions to help refugees in Uganda take back control of their lives. Stay tuned! Congrats to @BartBronnenberg and @proflog for winning one grant each! https://t.co/oHqr2nFo5y",
      "expandedUrl" : "https://twitter.com/i/web/status/1547695959575969794"
    }
  },
  {
    "like" : {
      "tweetId" : "1546396146326724609",
      "fullText" : "Hier 👇👇heb ik de afgelopen anderhalf jaar vooral aan gewerkt. \n\nHeel blij dat we met steun van de universiteiten, de rijksoverheid, de FD Mediagroep, DNB, AFM, de bankensector, VNO-NCW &amp; MKB Nederland, de FNV en de SER aan de slag kunnen. https://t.co/mmqSqV89oc",
      "expandedUrl" : "https://twitter.com/i/web/status/1546396146326724609"
    }
  },
  {
    "like" : {
      "tweetId" : "1546511498679402499",
      "fullText" : "People of all incomes &amp; backgrounds prefer immediate rewards over larger, delayed ones. 170-author, 61-country study in @NatureHumBehav shows econ. inequality, inflation, &amp; instability disrupt financial many decisions. Multiple, major policy implications.\n\nhttps://t.co/A0c8gjiohZ https://t.co/nLU0voG2Lr",
      "expandedUrl" : "https://twitter.com/i/web/status/1546511498679402499"
    }
  },
  {
    "like" : {
      "tweetId" : "1546423247792652289",
      "fullText" : "A really interesting, open-access(!) book on improving weather warnings &amp; communication just launched! https://t.co/6GLSFslQxG",
      "expandedUrl" : "https://twitter.com/i/web/status/1546423247792652289"
    }
  },
  {
    "like" : {
      "tweetId" : "1545046566620188675",
      "fullText" : "In their infinite kindness and wisdom, @UvA_Amsterdam promoted me to full professor of business &amp; sustainability. Thank you to family, friends, mentors, colleagues, collaborators, students for standing (by) me. The expectations seem to be high so will be sure to disappoint then… https://t.co/rrrj3Tbxqv",
      "expandedUrl" : "https://twitter.com/i/web/status/1545046566620188675"
    }
  },
  {
    "like" : {
      "tweetId" : "1544682389661794306",
      "fullText" : "Last week Amsterdam #Neuroeconomics hosted the 40th #EgProc meeting @UvA_EB. The conference was great fun and featured many excellent talks on process tracing, including key notes by @GioCoricelli, Johanna Lahey and Vojtech Bartos. Many thanks to our sponsors (see pic). https://t.co/5Cb65SOTHO",
      "expandedUrl" : "https://twitter.com/i/web/status/1544682389661794306"
    }
  },
  {
    "like" : {
      "tweetId" : "1544722746160160770",
      "fullText" : "Yay, @BetMarloes (and @AniekAntvelink in spirit) won the best @networkinstvu presentation prize! Excited to share our findings on interdisciplinary and translational research communication in due time :-) https://t.co/wH5StyERIV",
      "expandedUrl" : "https://twitter.com/i/web/status/1544722746160160770"
    }
  },
  {
    "like" : {
      "tweetId" : "1543953617362747392",
      "fullText" : "Today I handed in the final version of my thesis, which will stay in the library. Now I just have to wait for my diploma to officially become Dr. Parra :) https://t.co/ybvYjHi0kA",
      "expandedUrl" : "https://twitter.com/i/web/status/1543953617362747392"
    }
  },
  {
    "like" : {
      "tweetId" : "1542904371075321857",
      "fullText" : "Marthe Wens @VU_IVM just have me her \"boekje\" (physical PhD thesis, yes, this is what they look like in the Netherlands, another nice reason to be back) and it is soooo beautiful! Well done, Marthe!  #SuperProudSupervisor together with @JeroenAerts4 @Ted1388 https://t.co/kYYtYgvKtq",
      "expandedUrl" : "https://twitter.com/i/web/status/1542904371075321857"
    }
  },
  {
    "like" : {
      "tweetId" : "1542801559494459397",
      "fullText" : "Die dag dat het experimenteerprogramma van @minlnv   over True Pricing en gedrag niet 1, maar 2 landelijke dagbladen haalt  @janpaulvansoest @true_price https://t.co/pQmLhratS5",
      "expandedUrl" : "https://twitter.com/i/web/status/1542801559494459397"
    }
  },
  {
    "like" : {
      "tweetId" : "1542416921127182337",
      "fullText" : "Excited to announce that our CHANCE (Climate cHange impActs on extreme sea levels iN Coastal watErs) proposal got granted! This means that in the coming 4 years we can continue to work on improving extreme sea level projections 🥳 Together with José Antolínez  @TUDelft_CT @VU_IVM https://t.co/O2DzPZ1HCo",
      "expandedUrl" : "https://twitter.com/i/web/status/1542416921127182337"
    }
  },
  {
    "like" : {
      "tweetId" : "1542210431913172993",
      "fullText" : "Take some environmental economists sitting by the canal.. #EAERE2022 #Rimini @EAERE_envecon https://t.co/0oqGBGTXXY",
      "expandedUrl" : "https://twitter.com/i/web/status/1542210431913172993"
    }
  },
  {
    "like" : {
      "tweetId" : "1541799393812176896",
      "fullText" : "This storm chase trip was a dream come true (ok not the covid bit). Ever since I was 10 and saw the movie Twister, I knew I wanted to go stormchasing. Last year, I got this trip as my PhD graduation gift. And I saw the supercells 10-yr old me dreamed about 20 years ago!",
      "expandedUrl" : "https://twitter.com/i/web/status/1541799393812176896"
    }
  },
  {
    "like" : {
      "tweetId" : "1541797766774624257",
      "fullText" : "Almost 4 weeks ago we went on the storm chase trip of our life. We saw amazing supercells, of which this monster (Belle Fourche, SD, 12 June 2022) is the one that will stay with me forever. Tennisball-size hail was reported! And yes;these colors were the actual colors of the cell https://t.co/fsaSn17coy",
      "expandedUrl" : "https://twitter.com/i/web/status/1541797766774624257"
    }
  },
  {
    "like" : {
      "tweetId" : "1541727262990647297",
      "fullText" : "We are ready to start! ⚡️\n#EAERE2022 #team #bestteam #EnvEcon https://t.co/XR1oOmMxFi",
      "expandedUrl" : "https://twitter.com/i/web/status/1541727262990647297"
    }
  },
  {
    "like" : {
      "tweetId" : "1541705211449860096",
      "fullText" : "This is the scientific publishing industry for you. \n\nMDPI milks you for money. Nature milks you for money. Elsevier, Wiley, Frontiers... you name it. \n\nThey do little and reap large benefits. \n\nThe game is rigged, and they always win. \n\nWe ought to stop playing. \n\nHow? A thread. https://t.co/QaJ4ThZiww",
      "expandedUrl" : "https://twitter.com/i/web/status/1541705211449860096"
    }
  },
  {
    "like" : {
      "tweetId" : "1539904429176020992",
      "fullText" : "Very happy to be featured by @WomEvoBehSci! https://t.co/WwcycnFvPz",
      "expandedUrl" : "https://twitter.com/i/web/status/1539904429176020992"
    }
  },
  {
    "like" : {
      "tweetId" : "1539746678475046912",
      "expandedUrl" : "https://twitter.com/i/web/status/1539746678475046912"
    }
  },
  {
    "like" : {
      "tweetId" : "1539144688158097409",
      "fullText" : "Naast de bekende #klimaatstreepjescode voor temperatuur hebben wij ze ook  voor neerslag en zonneschijn gemaakt. Gemiddeld is Nederland nu warmer, natter en zonniger dan in 1900. Download de klimaatstreepjescode van NL hier: https://t.co/q1blW2KaLr #ShowYourStripes https://t.co/W5kxLiaAQ6",
      "expandedUrl" : "https://twitter.com/i/web/status/1539144688158097409"
    }
  },
  {
    "like" : {
      "tweetId" : "1537078484832505859",
      "fullText" : "We are organising a symposium about the psychology of #climatechange #adaptation next week! 🎉\nAlways wanted to know what adaptation is all about? Come join us (in-person or online) to catch up on the latest research! 😎\n\n👉Follow it online via https://t.co/0zjUEWpbZV https://t.co/S8EXMTlWnf",
      "expandedUrl" : "https://twitter.com/i/web/status/1537078484832505859"
    }
  },
  {
    "like" : {
      "tweetId" : "1536723734060572674",
      "expandedUrl" : "https://twitter.com/i/web/status/1536723734060572674"
    }
  },
  {
    "like" : {
      "tweetId" : "1536022882634960896",
      "fullText" : "The winners of predicting the outcome of Keynes’ beauty contest @ Advances with Field Experiments conference. \n\n#afe2022 #voltageeffect @Econ_4_Everyone @UChi_Economics https://t.co/iaFX0lrMw5",
      "expandedUrl" : "https://twitter.com/i/web/status/1536022882634960896"
    }
  },
  {
    "like" : {
      "tweetId" : "1535758477536141312",
      "expandedUrl" : "https://twitter.com/i/web/status/1535758477536141312"
    }
  },
  {
    "like" : {
      "tweetId" : "1534571214219358209",
      "expandedUrl" : "https://twitter.com/i/web/status/1534571214219358209"
    }
  },
  {
    "like" : {
      "tweetId" : "1534599002812952576",
      "fullText" : "Don’t cite my work! I don’t want to lose my hair!\n\nRecent highly scientific study, “Elevated h-index causes hair graying and/or loss in academics” https://t.co/hQonvCqp0S",
      "expandedUrl" : "https://twitter.com/i/web/status/1534599002812952576"
    }
  },
  {
    "like" : {
      "tweetId" : "1181254905018761216",
      "fullText" : "Building a data-driven CV in R. New blog post detailing how I built my CV/Resume using {{pagedown}}, {{glue}}, and spreadsheets; and how you can too! #rstats \n\nhttps://t.co/OGWZnMOFw3 https://t.co/xazFcV1Xv5",
      "expandedUrl" : "https://twitter.com/i/web/status/1181254905018761216"
    }
  },
  {
    "like" : {
      "tweetId" : "1181222397858287616",
      "fullText" : "I received an R&amp;R over the weekend with two of the most thoughtful and helpful reviewer reports I have ever received. \n\nWhatever happens, the paper will be better because of it.\n\nRunning a new model now. https://t.co/Y2fy0Ny0AM",
      "expandedUrl" : "https://twitter.com/i/web/status/1181222397858287616"
    }
  },
  {
    "like" : {
      "tweetId" : "1181220974147952640",
      "fullText" : "Just handed back my first exam in Intermediate Micro.  I love watching students' eyes get bigger and bigger as they realize they did way better than they thought.  Can I change my title from \"instructor\" to \"prior-updater?\"",
      "expandedUrl" : "https://twitter.com/i/web/status/1181220974147952640"
    }
  },
  {
    "like" : {
      "tweetId" : "1180612241974087680",
      "fullText" : "Bryggen in Trondheim. Slightly less famous than their Bergen counterparts, but this exceptional sunshine makes up the small difference. https://t.co/1JH6UJurXq",
      "expandedUrl" : "https://twitter.com/i/web/status/1180612241974087680"
    }
  },
  {
    "like" : {
      "tweetId" : "1180127883135799297",
      "fullText" : "Nicest reviewer comment I've gotten in ages &amp; made my day! Reviewers, remember you can praise as well as criticize:  \"This is one of those papers I wish I had written (in fact I thought at one point about trying to run this experiment) and I think this is going to be well cited.\"",
      "expandedUrl" : "https://twitter.com/i/web/status/1180127883135799297"
    }
  },
  {
    "like" : {
      "tweetId" : "1180160591715033088",
      "expandedUrl" : "https://twitter.com/i/web/status/1180160591715033088"
    }
  },
  {
    "like" : {
      "tweetId" : "1179767447093682177",
      "fullText" : "BLOG - Rosalie leert over vriendelijkheid in het Brooklyn Bridge Park  #studereninhetbuitenland  https://t.co/XHriU0Surz https://t.co/jrzRk9wVtX",
      "expandedUrl" : "https://twitter.com/i/web/status/1179767447093682177"
    }
  },
  {
    "like" : {
      "tweetId" : "1179716512199905280",
      "fullText" : "You’re unable to view this Post because this account owner limits who can view their Posts. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1179716512199905280"
    }
  },
  {
    "like" : {
      "tweetId" : "1179490906107469824",
      "fullText" : "Who can't help but fix the random italics, the 3 different fonts, the mixed line heights and shifting alignments in supplier forms and invoice templates? 🙋",
      "expandedUrl" : "https://twitter.com/i/web/status/1179490906107469824"
    }
  },
  {
    "like" : {
      "tweetId" : "1179420979350687746",
      "fullText" : "Well, that is next week Paul's problem as its now long-weekend time.",
      "expandedUrl" : "https://twitter.com/i/web/status/1179420979350687746"
    }
  },
  {
    "like" : {
      "tweetId" : "1178734277413896192",
      "fullText" : "I am taking a new paper on the road the next two weekends (Behavioral and Experimental Economists of the Mid-Atlantic, then N American Economic Science Association). \n\n\"Group and Treatment Heterogeneity in Quantal Response Equilibrium: A Bayesian Approach\" https://t.co/DABDbPaYp0",
      "expandedUrl" : "https://twitter.com/i/web/status/1178734277413896192"
    }
  },
  {
    "like" : {
      "tweetId" : "1179163966582472705",
      "fullText" : "I'm an RA for a prof and he asked me to compile abstracts from 2016-now for top psych journals on topics related to diversity/intergroup relations. It was an extremely useful exercise in general but helped me see trends in the journals. Here are my (unsolicited)insights: 1/4",
      "expandedUrl" : "https://twitter.com/i/web/status/1179163966582472705"
    }
  },
  {
    "like" : {
      "tweetId" : "1179189536884236288",
      "fullText" : "Hey #econtwitter and #econcookingtwitter, suppose you wanted to teach economics of food to 10-year olds. How would you do it? You have a couple hours per week for a few weeks. Any advice appreciated.",
      "expandedUrl" : "https://twitter.com/i/web/status/1179189536884236288"
    }
  },
  {
    "like" : {
      "tweetId" : "1179125072302350336",
      "fullText" : "Dat zo'n consultant figuur in je coupe zegt \"ik ben een regelaartje, ik ga gewoon een beetje shinen met mijn skills\" @NS_online #treinleven",
      "expandedUrl" : "https://twitter.com/i/web/status/1179125072302350336"
    }
  },
  {
    "like" : {
      "tweetId" : "1179083796047679488",
      "fullText" : "Unpopular opinion. There's a science bubble. The return on investment in science is lower than we would like to admit. We don't spend the resources needed to verify our claims. People skate by on luck. The many replication crises are signs of the science bubble finally popping.",
      "expandedUrl" : "https://twitter.com/i/web/status/1179083796047679488"
    }
  },
  {
    "like" : {
      "tweetId" : "1178968826697932800",
      "fullText" : "Submit dissertation: ✅\n\n4 years\n23 studies\n12,297 participants\n82,512 words\n\nEnjoyed every bit of it thanks to my awesome supervisors @tony_m_evans, Ilja van Beest, and Mariëlle Stel! Starting my new position as an Assistant Professor @TilburgU today. https://t.co/y8x7mrsIGB",
      "expandedUrl" : "https://twitter.com/i/web/status/1178968826697932800"
    }
  },
  {
    "like" : {
      "tweetId" : "1178729085637296128",
      "fullText" : "What's a photobooth without Mas-Colell? https://t.co/l1HW6HiYOn",
      "expandedUrl" : "https://twitter.com/i/web/status/1178729085637296128"
    }
  },
  {
    "like" : {
      "tweetId" : "1178758503994990597",
      "fullText" : "Eiko needs to write grant: \ncleans up, cooks crazy dinner, goes to the gym 2 times / day. Hello social media.\n\nEiko needs to make figure for grant: \n36 hours focus work without sleep &amp; food, still excited.\n\nI need to switch job. Someone want to hire a \"figure maker\"?",
      "expandedUrl" : "https://twitter.com/i/web/status/1178758503994990597"
    }
  },
  {
    "like" : {
      "tweetId" : "1178410877873250304",
      "fullText" : "#Rstats: I'm writing a `bookdown` book on how to perform power analysis in R. I'm going to attempt to cover most common designs in psychological science, but it will be applicable to all sorts of data sets. Watch this space. \n\n#phdchat https://t.co/fChdnZQivk",
      "expandedUrl" : "https://twitter.com/i/web/status/1178410877873250304"
    }
  },
  {
    "like" : {
      "tweetId" : "1178674731584614400",
      "fullText" : "Proctoring an exam rn. Saw a student muttering under his breath and kind of...dancing?  Got a little closer and y’all...this student is reciting what appears to be a rap he made up to remember what I’m almost certain is the formula for price elasticity if demand. What a hero. A+.",
      "expandedUrl" : "https://twitter.com/i/web/status/1178674731584614400"
    }
  },
  {
    "like" : {
      "tweetId" : "1178685971119915008",
      "fullText" : "Collega Sander werd over zijn proefschrift geïnterviewd door ⁦@nrc⁩ https://t.co/AeaENzZl42",
      "expandedUrl" : "https://twitter.com/i/web/status/1178685971119915008"
    }
  },
  {
    "like" : {
      "tweetId" : "1178580378732421120",
      "fullText" : "Running a study in the economics lab today @Radboud_Uni \n\n#MissionControl #LifeOfAnAcademic https://t.co/MC1OkB4pur",
      "expandedUrl" : "https://twitter.com/i/web/status/1178580378732421120"
    }
  },
  {
    "like" : {
      "tweetId" : "1178221886746120192",
      "fullText" : "Flood warning in the U.K. today. 🤔 perhaps there is room to  improve risk communication...? ⁦@MarieJuanchich⁩ ⁦@aFrenchparadox⁩ ⁦@ellenpetersjdm⁩ https://t.co/HdbLXJRtuZ",
      "expandedUrl" : "https://twitter.com/i/web/status/1178221886746120192"
    }
  },
  {
    "like" : {
      "tweetId" : "1178006882990149632",
      "fullText" : "Hey #EconTwitter @EcScienceAssoc @voxlacea @IFREEweb there's still time, but the submission deadline for the 2020 Bogotá Experimental Economics Conference is close (October 1st). \nSubmissions here https://t.co/INaFnAPxpW\nConference: Jan 9-11 https://t.co/V0QGfk0e6U",
      "expandedUrl" : "https://twitter.com/i/web/status/1178006882990149632"
    }
  },
  {
    "like" : {
      "tweetId" : "1177861197791715328",
      "fullText" : "Did an interactive poll at the National Pension Forum 2019. Result: 82% of pension fund executives indicate that pension funds should also invest in a sustainable manner if that reduces the financial return. https://t.co/njnCM1e8Xw",
      "expandedUrl" : "https://twitter.com/i/web/status/1177861197791715328"
    }
  },
  {
    "like" : {
      "tweetId" : "1177651537494958080",
      "fullText" : "I've been using this terminal app called thefuck for years and it still cracks me up because I'm 12. It corrects errors in previous console commands. So if you type the wrong thing, you just say 'fuck' and it gives you what you probably meant.\n\nhttps://t.co/OZSIc3zm1V https://t.co/j5h4uZhF5z",
      "expandedUrl" : "https://twitter.com/i/web/status/1177651537494958080"
    }
  },
  {
    "like" : {
      "tweetId" : "1177681614681395201",
      "fullText" : "Please join us next Wednesday 10/2 when we host \n@GilbertGaul1 at @Wharton's Huntsman Hall for a discussion with Prof. Orton and Dr. Kunreuther about his new book, The Geography of Risk. \n3 copies of the book will be given out at the event! \nTo RSVP: https://t.co/1GebTSQibV https://t.co/HCVClPw3t9",
      "expandedUrl" : "https://twitter.com/i/web/status/1177681614681395201"
    }
  },
  {
    "like" : {
      "tweetId" : "1177628814081499139",
      "fullText" : "We are at the #klimaatstaking in den Haag and we are not happy.\n\nTime to act! #ClimateStrike #FridaysForFuture #ClimateBreakdown https://t.co/xCCtk17oJR",
      "expandedUrl" : "https://twitter.com/i/web/status/1177628814081499139"
    }
  },
  {
    "like" : {
      "tweetId" : "1177504905256259584",
      "fullText" : "Making ~2 kg tiramisù for a student's graduation 🎓 party definitely counts as work, yes? https://t.co/KVKCHYFuRX",
      "expandedUrl" : "https://twitter.com/i/web/status/1177504905256259584"
    }
  },
  {
    "like" : {
      "tweetId" : "1177555762522001408",
      "fullText" : "#klimaatstaking https://t.co/XSHJQ6LL1V",
      "expandedUrl" : "https://twitter.com/i/web/status/1177555762522001408"
    }
  },
  {
    "like" : {
      "tweetId" : "1177293075082874880",
      "expandedUrl" : "https://twitter.com/i/web/status/1177293075082874880"
    }
  },
  {
    "like" : {
      "tweetId" : "1177237123554000897",
      "fullText" : "You’re unable to view this Post because this account owner limits who can view their Posts. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1177237123554000897"
    }
  },
  {
    "like" : {
      "tweetId" : "1177215968763883521",
      "fullText" : "Deze foto gebruiken 2 mede-wetenschappers en ik om het verschil uit te leggen tussen een correlatie en causaliteit met betrekking tot lichaamslengte en baardgroei. https://t.co/cmOhOyWR67",
      "expandedUrl" : "https://twitter.com/i/web/status/1177215968763883521"
    }
  },
  {
    "like" : {
      "tweetId" : "1177211305406717953",
      "fullText" : "@TiUEconomics is joining this group. We will only interview in Rotterdam this year, not in San Diego. @EEANews @LSEEcon @briq_institute @Unibocconi @BristolUni @Cambridge_Uni @UniofOxford @sciencespo https://t.co/3TMB9gqwBP",
      "expandedUrl" : "https://twitter.com/i/web/status/1177211305406717953"
    }
  },
  {
    "like" : {
      "tweetId" : "1176981903611744256",
      "fullText" : "#EconTwitter what are good small grants (under ~$25K) that are good “first grants” for grad students to apply for? Hoping to compile a good list.\n\nEx: @RussellSageFdn Small Prizes in Behavioral Econ ($7500 max)\n\nQuestion motivated by a great workshop with @cbb2cornell today!",
      "expandedUrl" : "https://twitter.com/i/web/status/1176981903611744256"
    }
  },
  {
    "like" : {
      "tweetId" : "1170116555704635393",
      "fullText" : "The Wharton Risk Center is excited to now be on Twitter to share our news and events with you!",
      "expandedUrl" : "https://twitter.com/i/web/status/1170116555704635393"
    }
  },
  {
    "like" : {
      "tweetId" : "1176573180095422472",
      "fullText" : "Looking foward to this truly interdisciplinary conference on #trust and #cooperation. Scientists working on experimental #economics, #psychology, and #climate change get together! https://t.co/Qxpu2aDbzo",
      "expandedUrl" : "https://twitter.com/i/web/status/1176573180095422472"
    }
  },
  {
    "like" : {
      "tweetId" : "1176556077850267649",
      "fullText" : "How might we make Behavioural Insights more interdisciplinary? Very pleased with the publication today of this paper in the @BPPjournal, and many thanks to @Markiewhitehead for the great collaboration in this! #behaviouralinsights #nudge See\nhttps://t.co/y8pgGt0GXA https://t.co/bsUqPRFC1e",
      "expandedUrl" : "https://twitter.com/i/web/status/1176556077850267649"
    }
  },
  {
    "like" : {
      "tweetId" : "1176528176811520000",
      "fullText" : "Enthusiastic nods from my freshmen as I explain \"false positives\" as \"feeling your phone go off, checking it, and seeing zero notifications\"",
      "expandedUrl" : "https://twitter.com/i/web/status/1176528176811520000"
    }
  },
  {
    "like" : {
      "tweetId" : "1176516844632584194",
      "fullText" : "@JantsjeMol You might regret saying that :D",
      "expandedUrl" : "https://twitter.com/i/web/status/1176516844632584194"
    }
  },
  {
    "like" : {
      "tweetId" : "1176397134918311936",
      "fullText" : "My friend @willemsleegers made an awesome tool to automatically insert stat results into your paper: #tidystats. Interested? Try out the first version &amp; help him improve it! :) See below. https://t.co/7nsGdBN8ap",
      "expandedUrl" : "https://twitter.com/i/web/status/1176397134918311936"
    }
  },
  {
    "like" : {
      "tweetId" : "1176492103972675585",
      "fullText" : "First sign of a predatory journal asking for submissions: comic sans #AcademicTwitter https://t.co/Kb6hCCAJ6A",
      "expandedUrl" : "https://twitter.com/i/web/status/1176492103972675585"
    }
  },
  {
    "like" : {
      "tweetId" : "1165162090312753152",
      "fullText" : "Back to personal Twitter. #TIBER2019 (@tibertilburg) was a great success, thanks everyone for contributing to this! Organizer-mode: off. https://t.co/ZNeXUNJgh5",
      "expandedUrl" : "https://twitter.com/i/web/status/1165162090312753152"
    }
  },
  {
    "like" : {
      "tweetId" : "1165005974899503112",
      "expandedUrl" : "https://twitter.com/i/web/status/1165005974899503112"
    }
  },
  {
    "like" : {
      "tweetId" : "1164154011248971776",
      "fullText" : "Check out the amazing poster by @SchildChristoph at #spudm2019! Monitoring and Honesty statements reduce cheating; ethical reminders don't #betterposter https://t.co/DWWPReKWov",
      "expandedUrl" : "https://twitter.com/i/web/status/1164154011248971776"
    }
  },
  {
    "like" : {
      "tweetId" : "1164768469792915459",
      "fullText" : "Today is T-day! #TIBER2019 wil start in just two hours, kicked off by @GretchenChapman's keynote lecture on Changing Health Behavior without Changing Beliefs. See you soon!",
      "expandedUrl" : "https://twitter.com/i/web/status/1164768469792915459"
    }
  },
  {
    "like" : {
      "tweetId" : "1164057519955828736",
      "fullText" : "I’m happy to share that I am officially starting my new mission as president-elect for the European Association for Decision-Making. Thank you to all those who voted me in. I look forward to contributing to this excellent organisation! https://t.co/tfvxGG0L2f #spudm2019",
      "expandedUrl" : "https://twitter.com/i/web/status/1164057519955828736"
    }
  },
  {
    "like" : {
      "tweetId" : "1164422311782604800",
      "fullText" : "Waking up with the announcement that our paper has been accepted for publication is the best way to start my day #phdlife #iwokeuplikethis https://t.co/3rqMjeUW5i",
      "expandedUrl" : "https://twitter.com/i/web/status/1164422311782604800"
    }
  },
  {
    "like" : {
      "tweetId" : "1164147619578470401",
      "fullText" : "I want to take a second to point out how convenient it is that pretty much everyone at #SPUDM2019 is tweeting about ongoing talks and topics, as with five parallel sessions FOMO is strong! #scicomm #behavioraleconomics #cognitivescience #psychology",
      "expandedUrl" : "https://twitter.com/i/web/status/1164147619578470401"
    }
  },
  {
    "like" : {
      "tweetId" : "1164180967554203648",
      "fullText" : "@JantsjeMol @roeterseiland @ReadTheSyllabus I happen to know a Symposium where landscape is the standard... ;) #TIBER2019",
      "expandedUrl" : "https://twitter.com/i/web/status/1164180967554203648"
    }
  },
  {
    "like" : {
      "tweetId" : "1164178735895121923",
      "fullText" : "@JantsjeMol @roeterseiland Landscape posters rock",
      "expandedUrl" : "https://twitter.com/i/web/status/1164178735895121923"
    }
  },
  {
    "like" : {
      "tweetId" : "1163932995159564288",
      "expandedUrl" : "https://twitter.com/i/web/status/1163932995159564288"
    }
  },
  {
    "like" : {
      "tweetId" : "1163844062883000321",
      "fullText" : "I will be starting my lab at Penn State in January, we will be doing some really exciting nutrition work using fMRI, EMA, and VR with awesome collaborators at Penn State, Dartmouth, and UMBC. I've got a fully-funded PhD position available and one 2-year post-doc position.",
      "expandedUrl" : "https://twitter.com/i/web/status/1163844062883000321"
    }
  },
  {
    "like" : {
      "tweetId" : "1163381013436870656",
      "fullText" : "#SPUDM2016 held at @UvA_Amsterdam: \n\nToday, @CBicchieri is giving the first keynote of the conference on our paper 👇🏻”It’s Not A Lie If You Believe It” (new WP just released, same link) - joint work with S. Sonderegger @UoNCeDEx #SocSciResearch\n\nhttps://t.co/Io2XUs2FEA https://t.co/E9k2FlUiD0",
      "expandedUrl" : "https://twitter.com/i/web/status/1163381013436870656"
    }
  },
  {
    "like" : {
      "tweetId" : "1163395584516087808",
      "fullText" : "#SPUDM2019 Keynote by @CBicchieri presenting work inspired by Seinfeld!😀 \n\"It's Not A Lie If You Believe It: Lying and Belief Distortion Under Norm-Uncertainty\" with @eugen_dimant &amp; Silvia Sonderegger  #socialnorms @UvA_Amsterdam https://t.co/nydh67eXO0",
      "expandedUrl" : "https://twitter.com/i/web/status/1163395584516087808"
    }
  },
  {
    "like" : {
      "tweetId" : "1162841109040680960",
      "fullText" : "@JantsjeMol Nice Jants! Brilliant url 😂!\n\nAlso I raise u mine: https://t.co/t2bEIaNDEH",
      "expandedUrl" : "https://twitter.com/i/web/status/1162841109040680960"
    }
  },
  {
    "like" : {
      "tweetId" : "1162460752508325888",
      "fullText" : "@JantsjeMol Nice! #luckilyyouhaveaneasylastname",
      "expandedUrl" : "https://twitter.com/i/web/status/1162460752508325888"
    }
  },
  {
    "like" : {
      "tweetId" : "1162365955663650818",
      "fullText" : "@RWI_Leibniz @LorenzGoette @a_gerster @MarcoHorvath @stevepuller @praveenkopalle @alecia_cassidy @MWerthschulte The day ended with proper old-school German cuisine at #GasthausZumBrenner. Almost all workshop participants were present. A wonderful first evening😊\n\n#RWI_EEEW https://t.co/16fQzMGMI4",
      "expandedUrl" : "https://twitter.com/i/web/status/1162365955663650818"
    }
  },
  {
    "like" : {
      "tweetId" : "1161984740838313984",
      "fullText" : "@JantsjeMol @ValerioCapraro Nice, feel free to report back. For K&amp;W and us the descriptive norm focus nudge worked well, for Valerio seemingly also the injunctive norm focus nudge, even in settings that are quite different. Would be interesting to see what you find in your setting",
      "expandedUrl" : "https://twitter.com/i/web/status/1161984740838313984"
    }
  },
  {
    "like" : {
      "tweetId" : "1161211818305642496",
      "fullText" : "@Claudia_Sahm @TrevonDLogan I've had a student who is not at my university ask to meet me in office hours because she said she just wanted to see a female economist in person once. She had a full econ degree from another university but never had a female econ prof.",
      "expandedUrl" : "https://twitter.com/i/web/status/1161211818305642496"
    }
  },
  {
    "like" : {
      "tweetId" : "1161209350863708160",
      "fullText" : "We studied if geoscientist are better at recognizing real landscapes from video game landscapes, for which we used the @NintendoEurope #Zelda game #BreathoftheWild. My new paper with @CaAl, @samillingworth and @FloodSkinner is now #openaccess available in @EGU_GC #scicomm https://t.co/uVfPQAzA9D",
      "expandedUrl" : "https://twitter.com/i/web/status/1161209350863708160"
    }
  },
  {
    "like" : {
      "tweetId" : "1160822340529401857",
      "fullText" : "and done. Time for a coffee",
      "expandedUrl" : "https://twitter.com/i/web/status/1160822340529401857"
    }
  },
  {
    "like" : {
      "tweetId" : "1158819011276263427",
      "fullText" : "Probably a shot in the dark. Does anyone know work that has been done as fiction but is built with #dataviz? An example is maps made for fantasy novels like Eragon. But these maps seem peripheral. Im looking for charts, graphs, as the central support for the stories.",
      "expandedUrl" : "https://twitter.com/i/web/status/1158819011276263427"
    }
  },
  {
    "like" : {
      "tweetId" : "1158705184912158720",
      "fullText" : "Exciting news: the @IGLglobal by @nesta_uk Winter Research Meeting will take place 21 Nov 2019 @VU_Amsterdam, hosted by @ResearchTI. Join us to discuss field experiments on entrepreneurship, innovation, science &amp; technology or business support policies https://t.co/7ksbqSlrUF 1/6",
      "expandedUrl" : "https://twitter.com/i/web/status/1158705184912158720"
    }
  },
  {
    "like" : {
      "tweetId" : "1157668864232177674",
      "fullText" : "@RWI_Leibniz_en @LorenzGoette @stevepuller @mondpanther @RDMetcalfe @andreasloeschel @itonomics @haucap @CassSunstein @brittanyrstreet @jrgptrs @fawolak @LarsGrotewold @ArthurvBenthem @a_gerster @alecia_cassidy @BostonMunich @t_staake @MWerthschulte @MarcoHorvath @NEWCOMERS_H2020 Day 2: Wednesday\n\"From Nudging in Qatar to Meaty Arguments and Fishy Associations!\"\n\nIt will be inspiring, I am sure. I am so much looking forward! \n\n#RWI_EEEW #conservation #foodconsumption #ClimateCrisis \nAlso some scientific input for\n#FridaysForFuture #fff @Sommerkongress https://t.co/iRkhKbnJZH",
      "expandedUrl" : "https://twitter.com/i/web/status/1157668864232177674"
    }
  },
  {
    "like" : {
      "tweetId" : "1157418694475038720",
      "fullText" : "That's all for now. Enjoy the job market, it's pretty awesome to spend a few months flying around the country talking to dozens of people who, like, actually read your paper and want to get to know you.",
      "expandedUrl" : "https://twitter.com/i/web/status/1157418694475038720"
    }
  },
  {
    "like" : {
      "tweetId" : "1155867427277869056",
      "fullText" : "Cool experiments about prospect theory.  This kind of work requires lab experiments.  https://t.co/a4Gelf4Us5 https://t.co/K7IQCyI1pm",
      "expandedUrl" : "https://twitter.com/i/web/status/1155867427277869056"
    }
  },
  {
    "like" : {
      "tweetId" : "1154838399565672448",
      "fullText" : "Getting the posters ready for our #Norms &amp; behavioral change #NoBeC2019 workshop @Penn. See 👇🏻 for list of amazing speakers.\n\nWant to attend without presenting, or present a poster? Email nobec-workshop@sas.upenn.edu\n\nFor more information check the website https://t.co/QWvf7ZTm5o https://t.co/3ZTSosqQSS https://t.co/qtM7t9gB0q",
      "expandedUrl" : "https://twitter.com/i/web/status/1154838399565672448"
    }
  },
  {
    "like" : {
      "tweetId" : "1154725740518268928",
      "fullText" : "[NEW]: A look back and a look forwards: what I've been up to in the past half year, and a glimpse of what is to come https://t.co/l0EU1OltnF https://t.co/M7m0rkP60q",
      "expandedUrl" : "https://twitter.com/i/web/status/1154725740518268928"
    }
  },
  {
    "like" : {
      "tweetId" : "1154665671139254273",
      "fullText" : "New working paper out: Culture and Prevalence of Sanctioning Institutions, with @mhmtygtgrdl https://t.co/JaiTXuTpue https://t.co/0tYzUAixTJ",
      "expandedUrl" : "https://twitter.com/i/web/status/1154665671139254273"
    }
  },
  {
    "like" : {
      "tweetId" : "1154678911709667328",
      "fullText" : "I have just told the scam caller that I can't help them because i am currently robbing the place. They then hung up. So either they are going to leave me alone or the police will come.",
      "expandedUrl" : "https://twitter.com/i/web/status/1154678911709667328"
    }
  },
  {
    "like" : {
      "tweetId" : "1154004298860302336",
      "fullText" : "I'm excited to unveil the first round of data from a new project: the demographic composition (% women and %URM) of econ seminar speakers, from schools across the country.\n\nhttps://t.co/0Z0Uz3PuGs https://t.co/rahhhRTK6G",
      "expandedUrl" : "https://twitter.com/i/web/status/1154004298860302336"
    }
  },
  {
    "like" : {
      "tweetId" : "1154198439657447425",
      "fullText" : "I started my current job in Data Design 2 yrs ago. I remember the day I got interviewed. In early August, I will leave my job to build my freelance career. I learned a lot. I have grown significantly. And I am ready to move on. A thread on what I learned and why I am leaving 👇",
      "expandedUrl" : "https://twitter.com/i/web/status/1154198439657447425"
    }
  },
  {
    "like" : {
      "tweetId" : "1153933868996726784",
      "expandedUrl" : "https://twitter.com/i/web/status/1153933868996726784"
    }
  },
  {
    "like" : {
      "tweetId" : "1152715681353404416",
      "fullText" : "ABSTRACT\nThe effect of Y on X is real.\n\nMETHOD\nQuestionable proxies for Y and X.\n\nRESULTS\nFancy stuff involving tables, covariates.\n\nDISCUSSION\nLimitations: this study cannot in principle prove that Y affects X. \n\nCONCLUSION\nTotally does tho.",
      "expandedUrl" : "https://twitter.com/i/web/status/1152715681353404416"
    }
  },
  {
    "like" : {
      "tweetId" : "1153038004711317504",
      "expandedUrl" : "https://twitter.com/i/web/status/1153038004711317504"
    }
  },
  {
    "like" : {
      "tweetId" : "1152574943097311232",
      "fullText" : "A very nice review... https://t.co/DNVbVRB4oW",
      "expandedUrl" : "https://twitter.com/i/web/status/1152574943097311232"
    }
  },
  {
    "like" : {
      "tweetId" : "1152239054496419841",
      "fullText" : "Leaving the office now for a holiday. This is the last picture I'll post of my time as a PhD :)\n.\nSee you in 3 weeks! https://t.co/JeE4zGCiPA",
      "expandedUrl" : "https://twitter.com/i/web/status/1152239054496419841"
    }
  },
  {
    "like" : {
      "tweetId" : "1152103860455919617",
      "fullText" : "We won the second place award 🥈! Such an inspiring experience. So many insights from neuroscience and psychology for future research. It’s impossible to deny the need of interdisciplinarity in the future research agenda. #Neuroeconomics Summer School, NYU Shanghai 2019 https://t.co/2IF8gTClpK",
      "expandedUrl" : "https://twitter.com/i/web/status/1152103860455919617"
    }
  },
  {
    "like" : {
      "tweetId" : "1151957735413600256",
      "fullText" : "TheyDrawIt: create line charts that ask users to sketch their beliefs before viewing data, and then optionally visualize other users’ beliefs https://t.co/o9DbHX0BYM By @vis_research https://t.co/y9Mk7sUu1t",
      "expandedUrl" : "https://twitter.com/i/web/status/1151957735413600256"
    }
  },
  {
    "like" : {
      "tweetId" : "1151799215271686144",
      "fullText" : "#ExperimentalEcon meets epidemiology:\n\n1. we ran an experiment comparing the impact of nutritional labels (data here: https://t.co/BpH80nP3SC)\n\n2. epidemiologists simulated based on our data the number of avoided deaths\n\nresults are now out (open access): https://t.co/nkR6SFVm9B",
      "expandedUrl" : "https://twitter.com/i/web/status/1151799215271686144"
    }
  },
  {
    "like" : {
      "tweetId" : "1150987178660552704",
      "fullText" : "This is very good news: “Given the largely positive experiences so far, the JDE has decided to make pre-results review a permanent track for article submission at the journal.” https://t.co/1GMtd5IE10",
      "expandedUrl" : "https://twitter.com/i/web/status/1150987178660552704"
    }
  },
  {
    "like" : {
      "tweetId" : "1151012618821361664",
      "fullText" : "Getting the 'this person has cited your work' alerts, always cheers me up. #AcademicTwitter",
      "expandedUrl" : "https://twitter.com/i/web/status/1151012618821361664"
    }
  },
  {
    "like" : {
      "tweetId" : "1149661169344376838",
      "expandedUrl" : "https://twitter.com/i/web/status/1149661169344376838"
    }
  },
  {
    "like" : {
      "tweetId" : "1149589610462208002",
      "fullText" : "Before programming #VR experiments yourself: practice saying \"that's NOT possible\" 1000 times",
      "expandedUrl" : "https://twitter.com/i/web/status/1149589610462208002"
    }
  },
  {
    "like" : {
      "tweetId" : "1149304440622592001",
      "fullText" : "We are looking for a postdoctoral researcher at the Winton Centre for Risk and Evidence Communication as part of the European RISE project to help communicate seismic risk across Europe. It's a great team, do apply!\nhttps://t.co/u634kKrlFd @SocRiskAnalysis @JofRiskResearch",
      "expandedUrl" : "https://twitter.com/i/web/status/1149304440622592001"
    }
  },
  {
    "like" : {
      "tweetId" : "1148961851901919232",
      "fullText" : "Last month I received a one-line referee report that I enjoyed passing on to the authors: \n\n\"This is a nice paper. You should be proud of it\"\n\n[This was after a major revision, so a full report was certainly not necessary; if I got this, I'd print it out &amp; tape it to my monitor]",
      "expandedUrl" : "https://twitter.com/i/web/status/1148961851901919232"
    }
  },
  {
    "like" : {
      "tweetId" : "1148855244207640577",
      "fullText" : "I am very honored to become the new President Elect of the Economic Science Association (ESA). Thank you for your votes!",
      "expandedUrl" : "https://twitter.com/i/web/status/1148855244207640577"
    }
  },
  {
    "like" : {
      "tweetId" : "1148575125576585216",
      "expandedUrl" : "https://twitter.com/i/web/status/1148575125576585216"
    }
  },
  {
    "like" : {
      "tweetId" : "1148217219802906624",
      "fullText" : "NEW @BPPjournal. Why don't more ppl in earthquake prone areas demand policy action to counteract disaster? Our work (w/ @AdullROHR) shows that actual hazard shapes policy support, but only for those who accurately perceive it. [THREAD] #scipol #scicomm\n\nhttps://t.co/ynWJuctZWy https://t.co/JHw9mK3hMm",
      "expandedUrl" : "https://twitter.com/i/web/status/1148217219802906624"
    }
  },
  {
    "like" : {
      "tweetId" : "1148317281149181952",
      "fullText" : "🚨High powered &amp; pre-registered study on #nudges&amp; #norms🚨\n(w/ G.v. Kleef &amp; @Shaul_Shalvi)\n\nRQ: does framing of nudges affect dishonesty when subjective &amp; objective risk are ruled out?\nA: nada (but interesting secondary results👇)\nPaper: https://t.co/V5J5VqYFpd\n\n1/9 \n#EconTwitter https://t.co/Gi7YKOK4C6",
      "expandedUrl" : "https://twitter.com/i/web/status/1148317281149181952"
    }
  },
  {
    "like" : {
      "tweetId" : "1147177066095185920",
      "fullText" : "Sigrid Suetens @SSuetens @TilburgU kicks off #ESA2019 at Vancouver with a keynote on discrimination. https://t.co/Ugj4oJnqEY",
      "expandedUrl" : "https://twitter.com/i/web/status/1147177066095185920"
    }
  },
  {
    "like" : {
      "tweetId" : "1147577401578156032",
      "fullText" : "The Economic Science Association (ESA) @EcScienceAssoc is on Twitter. \n\nLet’s make sure people know about it! #ExperimentalEcon https://t.co/5ecxRlOjQL",
      "expandedUrl" : "https://twitter.com/i/web/status/1147577401578156032"
    }
  },
  {
    "like" : {
      "tweetId" : "1147309816177709056",
      "fullText" : "⁦@eckelcc⁩ Advice for promoting ⁦@ExcenGsu⁩ #ESA2019 https://t.co/mzscOczra6",
      "expandedUrl" : "https://twitter.com/i/web/status/1147309816177709056"
    }
  },
  {
    "like" : {
      "tweetId" : "1147370187332567040",
      "fullText" : "#meega https://t.co/IfiJ0WYLag",
      "expandedUrl" : "https://twitter.com/i/web/status/1147370187332567040"
    }
  },
  {
    "like" : {
      "tweetId" : "1146862095981514752",
      "fullText" : "After noticing that many of its $3,000 bikes were getting damaged during shipping, a Dutch company redesigned the packaging so it no longer resembles ordinary bike packaging. It reduced shipping damage by 80%. https://t.co/IoSpTcABWq via @demilked #Nudge @R_Thaler @CassSunstein https://t.co/FA2MNJ24rq",
      "expandedUrl" : "https://twitter.com/i/web/status/1146862095981514752"
    }
  },
  {
    "like" : {
      "tweetId" : "1146464686201872385",
      "fullText" : "Excited to announce our amazing speakers at #NoBeC2019 including @eckelcc @varungauri @_alice_evans @saadgulzar @janagallus @rustamromaniuc @danilaserra_eco et al. with keynotes from @NicoLacetera &amp; D. Prentice\n\nWant to attend without presenting?Email nobec-workshop@sas.upenn.edu https://t.co/ddDtthmvGY https://t.co/k2uzsprb08",
      "expandedUrl" : "https://twitter.com/i/web/status/1146464686201872385"
    }
  },
  {
    "like" : {
      "tweetId" : "1146253818914582528",
      "fullText" : "Got an email today asking if I have any plans to publish a current working paper. I think I’ll reply with a link to this tweet, as an example of the econ publishing timeline. https://t.co/MMJS7AMvC4",
      "expandedUrl" : "https://twitter.com/i/web/status/1146253818914582528"
    }
  },
  {
    "like" : {
      "tweetId" : "1146351330551828481",
      "fullText" : "Happy to report that I made it! Alive, on time, and still sane (I think).\n\nDoctor! https://t.co/KInE0uiMUV",
      "expandedUrl" : "https://twitter.com/i/web/status/1146351330551828481"
    }
  },
  {
    "like" : {
      "tweetId" : "1145599299801235456",
      "fullText" : "Nice plot and lovely write up https://t.co/hk4Gz5q6hq",
      "expandedUrl" : "https://twitter.com/i/web/status/1145599299801235456"
    }
  },
  {
    "like" : {
      "tweetId" : "1145097025370939398",
      "fullText" : "Here's the line-up for the preconference workshop of #ispgr2019 on #MixedReality for posture and gait research. Sunday 30/6 at 8.30AM (yes, indeed, that's early...), Moorefoot room (level 0). https://t.co/GXix2yCuHK",
      "expandedUrl" : "https://twitter.com/i/web/status/1145097025370939398"
    }
  },
  {
    "like" : {
      "tweetId" : "1144297616986873857",
      "fullText" : "Ill be doing all sorts of demos about tube maps at #EsriUC including animated versions https://t.co/BLJLu4ZO1f",
      "expandedUrl" : "https://twitter.com/i/web/status/1144297616986873857"
    }
  },
  {
    "like" : {
      "tweetId" : "1144519053614243840",
      "expandedUrl" : "https://twitter.com/i/web/status/1144519053614243840"
    }
  },
  {
    "like" : {
      "tweetId" : "1144236982438023169",
      "fullText" : "After the plagiarism row over the first @Tokyo2020 logo, and the rather weak official one, this concept is a wonderful piece of design. https://t.co/qQDMES9jjY",
      "expandedUrl" : "https://twitter.com/i/web/status/1144236982438023169"
    }
  },
  {
    "like" : {
      "tweetId" : "1144259033160978438",
      "fullText" : "#chartoon https://t.co/wDK3I35hNl",
      "expandedUrl" : "https://twitter.com/i/web/status/1144259033160978438"
    }
  },
  {
    "like" : {
      "tweetId" : "1144230901015908352",
      "fullText" : "Vacation vs. Stress https://t.co/FI7PZXiXCQ",
      "expandedUrl" : "https://twitter.com/i/web/status/1144230901015908352"
    }
  },
  {
    "like" : {
      "tweetId" : "1143889384795791360",
      "fullText" : "I wrote a book!\n.\nMessage me if you want to check it out! https://t.co/WODAt0ZmPo",
      "expandedUrl" : "https://twitter.com/i/web/status/1143889384795791360"
    }
  },
  {
    "like" : {
      "tweetId" : "1143881743511904256",
      "fullText" : "I have a new, very concise tutorial out!\n\n## How to collaborate on GitHub on train wifi\n\nDon't. Read a book or go to sleep.\n\nThe end.",
      "expandedUrl" : "https://twitter.com/i/web/status/1143881743511904256"
    }
  },
  {
    "like" : {
      "tweetId" : "1143489705482313729",
      "fullText" : "Hold that thought. https://t.co/2ZcQUR9GEi",
      "expandedUrl" : "https://twitter.com/i/web/status/1143489705482313729"
    }
  },
  {
    "like" : {
      "tweetId" : "1071138625415458817",
      "fullText" : "How is it possible that this widely used quote from Andrew Vickers from 2005 is cited only twice? https://t.co/MbaWOWJvnQ https://t.co/HORvyxjOYW",
      "expandedUrl" : "https://twitter.com/i/web/status/1071138625415458817"
    }
  },
  {
    "like" : {
      "tweetId" : "1143029920186216449",
      "fullText" : "@NEWCOMERS_H2020 pre-kickoff @euenergyweek #EUSEW2019: Julia Blasch @VU_IVM and @MojcaDrevensek @ConsensusLj networking w @eu_h2020 #H2020 #energycommunity #energyefficiency projects like @REScoopEU @RescoopPlus @EnableNetworkEU @enCompassH2020 @START2ACT etc. Very inspiring! https://t.co/eQ3X5VtTfm",
      "expandedUrl" : "https://twitter.com/i/web/status/1143029920186216449"
    }
  },
  {
    "like" : {
      "tweetId" : "1142376238939549696",
      "fullText" : "Today marks the end of my stay at @GATE_LSE. Thanks to everyone there, in particular @mc_villeval, for the warm welcome and for making me feel right at home; I had an amazing time! https://t.co/Pbd3eCbBFp",
      "expandedUrl" : "https://twitter.com/i/web/status/1142376238939549696"
    }
  },
  {
    "like" : {
      "tweetId" : "1142039706143735808",
      "expandedUrl" : "https://twitter.com/i/web/status/1142039706143735808"
    }
  },
  {
    "like" : {
      "tweetId" : "1141725104084344832",
      "fullText" : "** Attention junior women in economics **\n\nApply for this program! I've now participated as both a mentee and a mentor, and it was an amazing experience both times. I learned so much from the other women in those rooms. There's nothing else like it. @AEACSWEP #ASSA2020 https://t.co/ynHGXJfvzc",
      "expandedUrl" : "https://twitter.com/i/web/status/1141725104084344832"
    }
  },
  {
    "like" : {
      "tweetId" : "1141993568443281411",
      "fullText" : "#postdoc year 9 milestone: in 💕 with the simplicity of my latest paper https://t.co/gjrRRZGY0Q",
      "expandedUrl" : "https://twitter.com/i/web/status/1141993568443281411"
    }
  },
  {
    "like" : {
      "tweetId" : "1141948877186260993",
      "fullText" : "Vandaag is het zover, Bessensap 2019!  Zo’n 400 journalisten, persvoorlichters en onderzoekers ontmoeten elkaar in @DeRodeHoed om te netwerken en kennis over wetenschapscommunicatie uit te wisselen. Gedurende dag zullen wij hierover twitteren, volg #Bsap19 voor alle updates. https://t.co/H3lDa4nua1",
      "expandedUrl" : "https://twitter.com/i/web/status/1141948877186260993"
    }
  },
  {
    "like" : {
      "tweetId" : "1141668959449702404",
      "fullText" : "Keynote lecture - Beyond effectiveness: The value(s) of nudging by Barbara Prainsack @BPrainsack - Professor of Comparative Policy Analysis University of Vienna and King’s College London at #wink2019 https://t.co/2J9qylkrp8",
      "expandedUrl" : "https://twitter.com/i/web/status/1141668959449702404"
    }
  },
  {
    "like" : {
      "tweetId" : "1141647618172510208",
      "fullText" : "First plenary lecture at #ASFEE2019 by Arno Riedl on neuroeconomics, reward and punishment. @TSEinfo https://t.co/mJnPwBd4Bq",
      "expandedUrl" : "https://twitter.com/i/web/status/1141647618172510208"
    }
  },
  {
    "like" : {
      "tweetId" : "1141606648236118016",
      "expandedUrl" : "https://twitter.com/i/web/status/1141606648236118016"
    }
  },
  {
    "like" : {
      "tweetId" : "1140926796424200193",
      "fullText" : "Training for the Future: VR Hitting Game - Testday @VU_FGB https://t.co/HW0G3UtPUO",
      "expandedUrl" : "https://twitter.com/i/web/status/1140926796424200193"
    }
  },
  {
    "like" : {
      "tweetId" : "1141264948099784708",
      "fullText" : "And we thought MTurk bots were contaminating our participant pool.. https://t.co/mraqTszNSn",
      "expandedUrl" : "https://twitter.com/i/web/status/1141264948099784708"
    }
  },
  {
    "like" : {
      "tweetId" : "1141281558260793344",
      "fullText" : "@SanneRaghoebar presenting her research at #WINK2019: A given portion size can alter descriptive and jnjuctive social norms that guide future consumption https://t.co/88hQP8BUcN",
      "expandedUrl" : "https://twitter.com/i/web/status/1141281558260793344"
    }
  },
  {
    "like" : {
      "tweetId" : "1141414022430035968",
      "fullText" : "@KarenHitters https://t.co/o7tnHvT4BF",
      "expandedUrl" : "https://twitter.com/i/web/status/1141414022430035968"
    }
  },
  {
    "like" : {
      "tweetId" : "1141242486242926592",
      "fullText" : "#WINK2019 is about to begin! https://t.co/ANQYkMGbXr",
      "expandedUrl" : "https://twitter.com/i/web/status/1141242486242926592"
    }
  },
  {
    "like" : {
      "tweetId" : "1141342669446291456",
      "fullText" : "Motto of the conference spotted at the University hall in Utrecht #WINK2019 #nudgeconference 📸 Credits to @Emely_de_Vet https://t.co/sCER5vWd9u",
      "expandedUrl" : "https://twitter.com/i/web/status/1141342669446291456"
    }
  },
  {
    "like" : {
      "tweetId" : "1141339932738428928",
      "fullText" : "Interesting conference on #nudging in a beautiful setting in #Utrecht. #wink great discussion on policy and #ethics with policymakers and experts. https://t.co/1oOJ6FDmOX",
      "expandedUrl" : "https://twitter.com/i/web/status/1141339932738428928"
    }
  },
  {
    "like" : {
      "tweetId" : "1140926082633388032",
      "fullText" : "Thesis is finished... so more time for social media:P\nVisiting Frascati, Rome, to attend the liquid metal experiments on the Frascati Tokamak Upgrade! https://t.co/bXILvGcBuH",
      "expandedUrl" : "https://twitter.com/i/web/status/1140926082633388032"
    }
  },
  {
    "like" : {
      "tweetId" : "1140610539267198976",
      "fullText" : "It's a wrap.. my PhD thesis \"Floods, droughts and climate variability : from early warning to early action\" is finally submitted to the reading committee! #phdlife https://t.co/542S44M39e",
      "expandedUrl" : "https://twitter.com/i/web/status/1140610539267198976"
    }
  },
  {
    "like" : {
      "tweetId" : "1138957379050049537",
      "fullText" : "👨: \"... and that's why daddy got punched in the face at the data viz conference.\"\n🧒: \"All because you brought 3D bar charts to R?\"\n👨: \"ESPECIALLY because I brought 3D bar charts to R.\"\n\nsorry everyone, with the good comes the bad 🙃 #rstats #rayshader https://t.co/piieSRrkBZ",
      "expandedUrl" : "https://twitter.com/i/web/status/1138957379050049537"
    }
  },
  {
    "like" : {
      "tweetId" : "1139174917671399425",
      "fullText" : "Anaïs Couasnon @anaiscouasnon from the Institute for Environmental Studies of the Vrije Universiteit Amsterdam @VU_IVM is visiting us as part of her PhD project \"Assessing the likelihood and impacts of compound coastal and river floods at the global scale\" https://t.co/pfqAkQexHd https://t.co/gXP5I6JiQf",
      "expandedUrl" : "https://twitter.com/i/web/status/1139174917671399425"
    }
  },
  {
    "like" : {
      "tweetId" : "1138711557481873408",
      "fullText" : "Was discussing how to outline a PhD project again this morning, so going to retweet this short outline I use with my own students. Structure and practical, and the bad science jokes are free. https://t.co/XNLhlVKYfE",
      "expandedUrl" : "https://twitter.com/i/web/status/1138711557481873408"
    }
  },
  {
    "like" : {
      "tweetId" : "1138384116032921601",
      "fullText" : "Genius idea from @ginjabookchick - the Rules of #OpenAccess Biscuits https://t.co/WrboE3uEBa",
      "expandedUrl" : "https://twitter.com/i/web/status/1138384116032921601"
    }
  },
  {
    "like" : {
      "tweetId" : "1138492581526925313",
      "fullText" : "I mean, seriously, just look at these slides. #rstats #EconTwitter https://t.co/e2n9fBUkTE",
      "expandedUrl" : "https://twitter.com/i/web/status/1138492581526925313"
    }
  },
  {
    "like" : {
      "tweetId" : "1136727814948950018",
      "fullText" : "FEMA will release 50M records from the NFIP. Will include “data on every individual flood ins claim going back to 1978 and every policy sold going back a decade.” The dataset should be available by mid-June on the OpenFEMA website:   https://t.co/cSNXLoQgCg via @nrdc",
      "expandedUrl" : "https://twitter.com/i/web/status/1136727814948950018"
    }
  },
  {
    "like" : {
      "tweetId" : "1136574988276965376",
      "fullText" : "Finaly a nice way to keep all the go's charged and mobile! https://t.co/n0PYxxqUuN",
      "expandedUrl" : "https://twitter.com/i/web/status/1136574988276965376"
    }
  },
  {
    "like" : {
      "tweetId" : "1136158325828141057",
      "fullText" : "Ik zat in de jury van de olympiade,  deze 3 meiden staken er met kop en schouders bovenuit. Check de video voor 💯data storytelling https://t.co/e4AX7CcJdB",
      "expandedUrl" : "https://twitter.com/i/web/status/1136158325828141057"
    }
  },
  {
    "like" : {
      "tweetId" : "1136062095370440704",
      "fullText" : "GREAT news that Experimental Economics is having a 5-7 paper trial with registered reports (paper acceptance before results). Following lead of JDevEcon. Other journals should jump in (and I know why they wont, but zipped lips for now) https://t.co/H9BTJJfcrN",
      "expandedUrl" : "https://twitter.com/i/web/status/1136062095370440704"
    }
  },
  {
    "like" : {
      "tweetId" : "1135944405477724160",
      "fullText" : "20 #dataviz books reviewed and organised in \"Jump-starts\", \"Foundations\", \"Specialty\" and \"Not recommended\", by @elsabirch https://t.co/L8ZrYdktk8 https://t.co/buGRo1HCrd",
      "expandedUrl" : "https://twitter.com/i/web/status/1135944405477724160"
    }
  },
  {
    "like" : {
      "tweetId" : "1131833212517400577",
      "fullText" : "Vidi grant @NWONieuws for @Shaul_Shalvi @ABS_UvA  @UvA_ASE. He will be doing research on sharing responsibly in the on-demand economy. Many congrats Shaul!",
      "expandedUrl" : "https://twitter.com/i/web/status/1131833212517400577"
    }
  },
  {
    "like" : {
      "tweetId" : "1135574313392889856",
      "fullText" : "Fantastic to meet the great \n@CassSunstein.  A very inspiring talk about behavioral science and climate change at the National Institute for Public Health &amp; the Environment @rivm. https://t.co/Cr3xpRXa2l",
      "expandedUrl" : "https://twitter.com/i/web/status/1135574313392889856"
    }
  },
  {
    "like" : {
      "tweetId" : "1135591994301067264",
      "fullText" : "Docent Liberal Arts and Sciences (0,7 fte) https://t.co/TUrvgMgx2V @UniUtrecht",
      "expandedUrl" : "https://twitter.com/i/web/status/1135591994301067264"
    }
  },
  {
    "like" : {
      "tweetId" : "1135606595075936257",
      "fullText" : "Interesting talk today on a theory of factors behind seemingly sudden social movements by @CassSunstein at the Dutch Central Bank. https://t.co/cp2hmtkQMq https://t.co/ZVp09m7HoS",
      "expandedUrl" : "https://twitter.com/i/web/status/1135606595075936257"
    }
  },
  {
    "like" : {
      "tweetId" : "1135722436375273472",
      "expandedUrl" : "https://twitter.com/i/web/status/1135722436375273472"
    }
  },
  {
    "like" : {
      "tweetId" : "1135533859460845568",
      "fullText" : "'Can we not nudge/avoid choice architecture? No. Every website has a design, and it involves choice. A office has a way it is set up, influencing choice. There is always a choice architecture in place, people will be nudged.' @CassSunstein #hearhear",
      "expandedUrl" : "https://twitter.com/i/web/status/1135533859460845568"
    }
  },
  {
    "like" : {
      "tweetId" : "1135198767110656000",
      "fullText" : "Thanks to @NiklasJohannes and @bmwiernik for pointing out this great example comparing the effect size distributions of pre-registered and non pre-registered studies https://t.co/PXJYI7ZUXS https://t.co/CmUkP1t31s",
      "expandedUrl" : "https://twitter.com/i/web/status/1135198767110656000"
    }
  },
  {
    "like" : {
      "tweetId" : "1135454206905724928",
      "fullText" : "Our Julia Blasch is one of the H2020 PENNY project collaborators and will be attending Thursday's symposium on energy efficiency in Brussels. https://t.co/j8Rwn4t4jj",
      "expandedUrl" : "https://twitter.com/i/web/status/1135454206905724928"
    }
  },
  {
    "like" : {
      "tweetId" : "1127486487333941249",
      "fullText" : "A bit of self-promotion: my paper “Perfect and imperfect strangers in social dilemmas” with Sigrid Suetens and Blair Cleave is out on the last issue of the European Economic Review!\n\nYou can read it here: https://t.co/21Xa7yVHXT\n\n#Cooperation #EconTwitter 1/4",
      "expandedUrl" : "https://twitter.com/i/web/status/1127486487333941249"
    }
  },
  {
    "like" : {
      "tweetId" : "1134110108215009282",
      "fullText" : "Availability bias: Take a look at this chart to see a striking representation of how news coverage bias our judgment of probability of different causes of death. https://t.co/CeDXwSVQyz",
      "expandedUrl" : "https://twitter.com/i/web/status/1134110108215009282"
    }
  },
  {
    "like" : {
      "tweetId" : "1133838254569086977",
      "fullText" : "When I joined Twitter a few months ago, I started looking for inspiring female economists to follow. One of the first I found was @dynarski. Today I got my fan girl moment after her talk at @ChicagoBooth #SelfieWithSue https://t.co/j8RaQgDWtf",
      "expandedUrl" : "https://twitter.com/i/web/status/1133838254569086977"
    }
  },
  {
    "like" : {
      "tweetId" : "1132922402084728832",
      "fullText" : "EU election results 2019: across Europe https://t.co/VtQPwg1q4i https://t.co/cOn0h07wCq",
      "expandedUrl" : "https://twitter.com/i/web/status/1132922402084728832"
    }
  },
  {
    "like" : {
      "tweetId" : "1132716057175744513",
      "fullText" : "This is the only dataviz I've done of this election sorry (so far) https://t.co/HH2jPSiF3X",
      "expandedUrl" : "https://twitter.com/i/web/status/1132716057175744513"
    }
  },
  {
    "like" : {
      "tweetId" : "1132799901782274048",
      "fullText" : "What is the best cycling city in the Netherlands? An analysis of bicycle accessibility in nine #Dutch cities https://t.co/O8Tlv1KKFk #MapPorn https://t.co/DkDur982Fp",
      "expandedUrl" : "https://twitter.com/i/web/status/1132799901782274048"
    }
  },
  {
    "like" : {
      "tweetId" : "1132218302208647168",
      "fullText" : "Don't forget to submit your abstract for the @tibertilburg symposium. It is a great event for everyone doing research on the intersection between Economics and Psychology! https://t.co/shL98qQSmO",
      "expandedUrl" : "https://twitter.com/i/web/status/1132218302208647168"
    }
  },
  {
    "like" : {
      "tweetId" : "1131905993409990656",
      "fullText" : "If you don't have time to read our 60+ page NBER working paper (I don't blame you... :)), you might want to take a look at this brief summary in @voxeu! https://t.co/gKE7bTwGUc",
      "expandedUrl" : "https://twitter.com/i/web/status/1131905993409990656"
    }
  },
  {
    "like" : {
      "tweetId" : "1131758020885590017",
      "fullText" : "220 world metro systems https://t.co/9TaQRkLadt #MapPorn https://t.co/8wiclstr3H",
      "expandedUrl" : "https://twitter.com/i/web/status/1131758020885590017"
    }
  },
  {
    "like" : {
      "tweetId" : "1131558380647190528",
      "fullText" : "21 June is the big day: the 2019 edition of Bessensap! Journalists, press officers and researchers will meet in Amsterdam to network with colleagues and exchange knowledge on the latest developments in science and its communication. Register now: https://t.co/pNLI1h2XD3 #Bsap19 https://t.co/awuSsMCtXh",
      "expandedUrl" : "https://twitter.com/i/web/status/1131558380647190528"
    }
  },
  {
    "like" : {
      "tweetId" : "1131572971385098240",
      "fullText" : "You won't want to miss our partner @B_I_Tweets at this year's #CfASummit! Gain practical insights on how your city can use behavioral science &amp; evaluation to improve outcomes for residents. Register today! https://t.co/wyOcDUosMK\n\nGet a taste ⤵️ https://t.co/y4Lsm0PqfP",
      "expandedUrl" : "https://twitter.com/i/web/status/1131572971385098240"
    }
  },
  {
    "like" : {
      "tweetId" : "1130967355868274689",
      "fullText" : "A scientific study examining the ability to search for LEGO pieces. The story of my life at the moment! #VSS2019 https://t.co/gsiOiPQ6E5",
      "expandedUrl" : "https://twitter.com/i/web/status/1130967355868274689"
    }
  },
  {
    "like" : {
      "tweetId" : "1130717244969893889",
      "fullText" : "hahah, Got to love EU forms. Here is this lovely online system for you to fill in. Great, done that? Now print it all off and post it to us via snail mail.",
      "expandedUrl" : "https://twitter.com/i/web/status/1130717244969893889"
    }
  },
  {
    "like" : {
      "tweetId" : "1130107171251871744",
      "fullText" : "Who needs a lab for physical models? @wrmtudelft https://t.co/ijpfmi4Yvx",
      "expandedUrl" : "https://twitter.com/i/web/status/1130107171251871744"
    }
  },
  {
    "like" : {
      "tweetId" : "1129420527158931457",
      "fullText" : "Is there a term for time spent making graphs look pretty instead of working on actual analyses? Procrastigraphing? #epitwitter #sciencetwitter https://t.co/vcUrstdBiy",
      "expandedUrl" : "https://twitter.com/i/web/status/1129420527158931457"
    }
  },
  {
    "like" : {
      "tweetId" : "1129295933013975041",
      "fullText" : "Cool paper! Great job @alesaiatw and @dominic_rohner! https://t.co/mUUIv3Ykjf",
      "expandedUrl" : "https://twitter.com/i/web/status/1129295933013975041"
    }
  },
  {
    "like" : {
      "tweetId" : "1128997500361347073",
      "fullText" : "Pieter van Beukering ( @pieterbeuk )  is benoemd tot hoogleraar milieueconomie met als leeropdracht ‘Economics of Natural Capital’. De leerstoel is ingebed bij het Instituut voor Milieuvraagstukken ( @VU_IVM ) van de Faculteit der Bètawetenschappen. https://t.co/It4Sh8bp7d https://t.co/yh0vTYm3eR",
      "expandedUrl" : "https://twitter.com/i/web/status/1128997500361347073"
    }
  },
  {
    "like" : {
      "tweetId" : "1129055998143082497",
      "fullText" : "The Future of #cleanoceans is Female ! @CLAIM_H2020 @aqua_lit #EMD2019 #marinelitter and #innovation https://t.co/jm9ZruRGTN",
      "expandedUrl" : "https://twitter.com/i/web/status/1129055998143082497"
    }
  },
  {
    "like" : {
      "tweetId" : "1129013040605736960",
      "fullText" : "Vandaag is de officiële opening van het Amsterdam Sustainability Institute (ASI) van Vrije Universiteit Amsterdam. Dit is een samenwerkingsplatform op het gebied van duurzaamheid en de Sustainable Development Goals (SDGs). #sustainability #SDGs #ASI https://t.co/k8gt1FWltD",
      "expandedUrl" : "https://twitter.com/i/web/status/1129013040605736960"
    }
  },
  {
    "like" : {
      "tweetId" : "1128673351969464322",
      "fullText" : "How can having a pair of eyes looking at you, yours or someone else's, affect your decisions? Zvonimir Bašić presents his experimental work on self and social image. #EEG https://t.co/s40QbUFt6Q",
      "expandedUrl" : "https://twitter.com/i/web/status/1128673351969464322"
    }
  },
  {
    "like" : {
      "tweetId" : "1128957482628538368",
      "expandedUrl" : "https://twitter.com/i/web/status/1128957482628538368"
    }
  },
  {
    "like" : {
      "tweetId" : "1128965858179584011",
      "fullText" : "Registration for this year's TIBER Symposium is now open! \n@tibertilburg #TIBER2019 #Economics #Psychology\n\nhttps://t.co/YLRYuf3pLX",
      "expandedUrl" : "https://twitter.com/i/web/status/1128965858179584011"
    }
  },
  {
    "like" : {
      "tweetId" : "1128564955006021632",
      "fullText" : "Welcome to the MPI Workshop on Behavioral and Experimental Economics! https://t.co/z57wi1xHRe",
      "expandedUrl" : "https://twitter.com/i/web/status/1128564955006021632"
    }
  },
  {
    "like" : {
      "tweetId" : "1128590856804548608",
      "fullText" : "Getting ready to head to Lisbon for #EMD2019 to learn, share and present a workshop on #marinelitter and #innovation. Looking forward to an interesting couple of days (and lots of pastel de nata :) ! @CLAIM_H2020 @aqua_lit",
      "expandedUrl" : "https://twitter.com/i/web/status/1128590856804548608"
    }
  },
  {
    "like" : {
      "tweetId" : "1128609933199597568",
      "fullText" : "A nice paper on social interaction in #AugmentedReality in #PLOSONE: https://t.co/OP9UivskZI",
      "expandedUrl" : "https://twitter.com/i/web/status/1128609933199597568"
    }
  },
  {
    "like" : {
      "tweetId" : "1128267631033823233",
      "expandedUrl" : "https://twitter.com/i/web/status/1128267631033823233"
    }
  },
  {
    "like" : {
      "tweetId" : "1126856342713638912",
      "fullText" : "Asymmetric feedback about others' trustworthiness makes people cynical, but they often trust nonetheless because they think it's the morally right thing to do. @daviddunning6 https://t.co/dFjTqwiBLs https://t.co/2Jtp4XKu3Y",
      "expandedUrl" : "https://twitter.com/i/web/status/1126856342713638912"
    }
  },
  {
    "like" : {
      "tweetId" : "1126854914951528448",
      "fullText" : "Reminder: The deadline for our vacancy for a PhD position for the project \"How the adoption of research practices can cause or cure bad science\" is May 31: https://t.co/xf1P95Mqgy",
      "expandedUrl" : "https://twitter.com/i/web/status/1126854914951528448"
    }
  },
  {
    "like" : {
      "tweetId" : "1126550446070480898",
      "fullText" : "With a bit of delay: abstract submission for TIBER 2019 has opened! Submit your abstract now (max. 250 words) at our website (https://t.co/NsdeiPHbEj). Note that the submission deadline will be extended to June 9! https://t.co/ZqqzPHAbeW",
      "expandedUrl" : "https://twitter.com/i/web/status/1126550446070480898"
    }
  },
  {
    "like" : {
      "tweetId" : "1125989495743176704",
      "fullText" : "#AcademicTwitter got to say. I have been really nervous about reaching out on Twitter professionally. Especially as a master's student. But everyone has shown me nothing but kindness. ❤❤❤",
      "expandedUrl" : "https://twitter.com/i/web/status/1125989495743176704"
    }
  },
  {
    "like" : {
      "tweetId" : "1126094478626971649",
      "fullText" : "@MartenvdMeulen @ionicasmeets Dat lijkt me zeker een rol spelen!\n\nEen eigen onderzoeksinteresse: VR gebruiken om dmv embodied interaction intuïties te creëren voor exotische fysische systemen die we nu vaak 'alleen' wiskundig begrijpen",
      "expandedUrl" : "https://twitter.com/i/web/status/1126094478626971649"
    }
  },
  {
    "like" : {
      "tweetId" : "1126048599828307968",
      "fullText" : "Today we welcome Russell Golman from @CarnegieMellon  to our #Wednesdayseminar.\nHe will present his work \"The Demand for, and Avoidance of, Information.\nhttps://t.co/ql5FT27s3b\n#Economics #Research #experimentallytest #informationseeking #avoidance https://t.co/W70qjdhcDM",
      "expandedUrl" : "https://twitter.com/i/web/status/1126048599828307968"
    }
  },
  {
    "like" : {
      "tweetId" : "1126032761649815552",
      "fullText" : "Ons volgende boek heet 'Hoe gaan we dit uitleggen' en gaat over klimaatverandering. Een goed moment om antwoord te zoeken op de voor een uitgeverij existentiële vraag: kunnen we het nog wel uitleggen dat we papieren boeken drukken? https://t.co/x48Jry9O6r",
      "expandedUrl" : "https://twitter.com/i/web/status/1126032761649815552"
    }
  },
  {
    "like" : {
      "tweetId" : "1125742828372447232",
      "fullText" : "Newton's laws of motion distill 3 fundamental truths about the physical world; these 3 laws do so for human behavior\n\nArticle by @alineholzwarth (me!) in @behavecondotcom #behavioralscience #behavioraleconomics\n@ptrnhealth @danariely\n@advncdhindsight\n\nhttps://t.co/Ta1Lb7U968 https://t.co/JH7EkG89FC",
      "expandedUrl" : "https://twitter.com/i/web/status/1125742828372447232"
    }
  },
  {
    "like" : {
      "tweetId" : "1125711510398013441",
      "fullText" : "Op 16 mei opent de @VUamsterdam het Amsterdam Sustainability Institute (ASI), een nieuw platform voor samenwerking op het gebied van duurzaamheid: https://t.co/CfH1Ne5drn @SDGNederland https://t.co/LOPdJ46xBt",
      "expandedUrl" : "https://twitter.com/i/web/status/1125711510398013441"
    }
  },
  {
    "like" : {
      "tweetId" : "1125426274640510981",
      "fullText" : "no such a thing as a free lunch eh https://t.co/QiVgUw2Uen",
      "expandedUrl" : "https://twitter.com/i/web/status/1125426274640510981"
    }
  },
  {
    "like" : {
      "tweetId" : "1125446793674801153",
      "fullText" : "You’re unable to view this Post because this account owner limits who can view their Posts. {learnmore}",
      "expandedUrl" : "https://twitter.com/i/web/status/1125446793674801153"
    }
  },
  {
    "like" : {
      "tweetId" : "1124502328994824192",
      "fullText" : "I've created a single-item measure of pro-sociality:\n\nIt is simply whether you press the elevator \"door open\" or \"door closed\" button when someone else is racing to the elevator. https://t.co/QHaMJFQTtl",
      "expandedUrl" : "https://twitter.com/i/web/status/1124502328994824192"
    }
  },
  {
    "like" : {
      "tweetId" : "1123957542961471489",
      "fullText" : "Earlier today Yasar Mehmet Kutluay successfully defended his thesis titled 'The Value of (Avoiding) Malaria'. Congratulations Dr. Kutluay! https://t.co/exicGFNdsx",
      "expandedUrl" : "https://twitter.com/i/web/status/1123957542961471489"
    }
  },
  {
    "like" : {
      "tweetId" : "1124236289954414593",
      "fullText" : "Reading another PNAS paper, and I just can't get over this. WHY put the methods section at the END of a paper??? https://t.co/Mkrv31ci7k",
      "expandedUrl" : "https://twitter.com/i/web/status/1124236289954414593"
    }
  },
  {
    "like" : {
      "tweetId" : "1121329617636347906",
      "fullText" : "Everybody is always surprised that my husband @FBRAK also has a PhD, not just a pretty face, hehe 😉 @manwhohasitall #manwhohasitall https://t.co/sTeIf6OxVI",
      "expandedUrl" : "https://twitter.com/i/web/status/1121329617636347906"
    }
  },
  {
    "like" : {
      "tweetId" : "1121663358019629056",
      "fullText" : "Good to share this! We all have our rejections of grant proposals and papers...! Part of the job, and takes perseverance to continue..! Well done @CarlaHaelermans https://t.co/7hS8QIuB42",
      "expandedUrl" : "https://twitter.com/i/web/status/1121663358019629056"
    }
  },
  {
    "like" : {
      "tweetId" : "1120978739431641089",
      "fullText" : "Interested in psychology, ecomomics, and decision-making? Come visit Tilburg in the summer for this year's #tiber2019 conference! https://t.co/LpSZj9yoY1",
      "expandedUrl" : "https://twitter.com/i/web/status/1120978739431641089"
    }
  },
  {
    "like" : {
      "tweetId" : "1120744100091838467",
      "fullText" : "Finalizing my presentation on local land-use decision-making of emerging global demands on the 🚆 to the #glposm in Bern. Interested in seeing more nice maps🌍? Check out my full talk on Thursday🙂 @GlobalLandP #flyingless https://t.co/oNPhhW5UXJ",
      "expandedUrl" : "https://twitter.com/i/web/status/1120744100091838467"
    }
  },
  {
    "like" : {
      "tweetId" : "1119332448200949761",
      "fullText" : "Extreem weer en klimaatverandering: Een stuk van mij en @gjvoldenborgh in @NUnl \nhttps://t.co/GIHkaWCXgh",
      "expandedUrl" : "https://twitter.com/i/web/status/1119332448200949761"
    }
  },
  {
    "like" : {
      "tweetId" : "1120373152859791363",
      "fullText" : "🔥Full update of 👇paper on backfiring of #nudges🔥\nLink: https://t.co/azGVnceUEb\n\nMain finding: nudges can backfire \nA solution: proper #norm interventions\n\nBut wait, there is more! \nWe now study the mechanism of *why* the nudge backfires \nThread ⬇️\n\n#EconTwitter #SocSciResearch https://t.co/AuTtU2lyod",
      "expandedUrl" : "https://twitter.com/i/web/status/1120373152859791363"
    }
  },
  {
    "like" : {
      "tweetId" : "1120382540651606021",
      "fullText" : "Nog even rustig aan op m’n Berlijnse balkon. \n\nMorgen gaan we het over de analyse van gezondheidsdata hebben! \n\nHans Rosling kon dit als geen ander. Ik adviseer iedereen dan ook om het boek ‘Feitenkennis’ (EN: Factfulness) te lezen, ter lering en vermaak. https://t.co/Yp5R4AMoc7",
      "expandedUrl" : "https://twitter.com/i/web/status/1120382540651606021"
    }
  },
  {
    "like" : {
      "tweetId" : "1119572558800674816",
      "fullText" : "Norm-nudges can be powerful interventions, but they can easily fail to be effective and can even backfire unless they are designed with care, argue @CBicchieri and @eugen_dimant: https://t.co/ALs8Zq3VVn",
      "expandedUrl" : "https://twitter.com/i/web/status/1119572558800674816"
    }
  },
  {
    "like" : {
      "tweetId" : "1118810257558519808",
      "fullText" : "Some of you pointed out the irony of having an article about open science behind a paywall, so @mackeithpress decided to make this article free access :) https://t.co/8rJyZG53v6",
      "expandedUrl" : "https://twitter.com/i/web/status/1118810257558519808"
    }
  },
  {
    "like" : {
      "tweetId" : "1116812783138627585",
      "fullText" : "Can VR make climate change “real”? https://t.co/WscI4hZEHH",
      "expandedUrl" : "https://twitter.com/i/web/status/1116812783138627585"
    }
  },
  {
    "like" : {
      "tweetId" : "1116608154429603842",
      "fullText" : "\"interdisciplinarity allowed us to design a successful earthquake and fire preparedness intervention that drew on multiple sets of expertise.\" Read more of the behind the paper post by Helene Joffe here: https://t.co/tYsNWoDwIL",
      "expandedUrl" : "https://twitter.com/i/web/status/1116608154429603842"
    }
  },
  {
    "like" : {
      "tweetId" : "1116319324917071872",
      "fullText" : "Blij met het winnen van de proefshriftprijs! #NCVGZ2019 https://t.co/6gZmyu5uir",
      "expandedUrl" : "https://twitter.com/i/web/status/1116319324917071872"
    }
  },
  {
    "like" : {
      "tweetId" : "1116301678804860934",
      "fullText" : "Het is volop genieten met de @Emerce top 100. Bedrijf: 'We staan op gedeelde 3e plek!' Klopt, maar die 3e plek is ook gelijk de laatste plek... https://t.co/6U7Kqp5pfe https://t.co/GSrvjCwg00",
      "expandedUrl" : "https://twitter.com/i/web/status/1116301678804860934"
    }
  },
  {
    "like" : {
      "tweetId" : "1116284905749659648",
      "fullText" : "Now in room N1: @jens_debruijn on his global flood monitor that uses twitter to detect floods. This is work done in a collaboration between @VU_IVM and @FloodTags. https://t.co/DqRU6gtnuI",
      "expandedUrl" : "https://twitter.com/i/web/status/1116284905749659648"
    }
  },
  {
    "like" : {
      "tweetId" : "1115923557958213633",
      "fullText" : ".@anaiscouasnon of @VU_IVM gives a #SpoilerWarning because she uses the famous(ly bad) movie Dante’s Peak as an example for her research on the impact of “compound hazards”, ie disasters never come alone: earthquakes followed by floods, etc. Brilliant #scicomm &amp; #science. #egu19 https://t.co/INtjhF9jzS",
      "expandedUrl" : "https://twitter.com/i/web/status/1115923557958213633"
    }
  },
  {
    "like" : {
      "tweetId" : "1115648625017749504",
      "fullText" : "https://t.co/psng1WVVBG",
      "expandedUrl" : "https://twitter.com/i/web/status/1115648625017749504"
    }
  },
  {
    "like" : {
      "tweetId" : "1114956341913645058",
      "fullText" : "I'm excited to show off something I've been working on for a few months now: the materials from a new class that I pinpoints a very different, and I think very promising way of teaching undergrad econometrics (thread)",
      "expandedUrl" : "https://twitter.com/i/web/status/1114956341913645058"
    }
  },
  {
    "like" : {
      "tweetId" : "1113442215857139723",
      "fullText" : "Natuurkundige @RHDijkgraaf vertelde gisteren in #deafspraak dat hij niet begrijpt hoe politici de zwakte van de wetenschap, het feit dat men nooit 100% zekerheid kan bieden, zo durven uit te buiten.\n\nHerbekijk de volledige aflevering hier: https://t.co/SMJkuNORHn https://t.co/ozJZx54fl8",
      "expandedUrl" : "https://twitter.com/i/web/status/1113442215857139723"
    }
  },
  {
    "like" : {
      "tweetId" : "1113861320695209984",
      "fullText" : "Free beta of oTree Studio (graphical editor) is available, sign up on https://t.co/vLDtlDd8a1 and click the “Studio” link in the upper right.",
      "expandedUrl" : "https://twitter.com/i/web/status/1113861320695209984"
    }
  },
  {
    "like" : {
      "tweetId" : "1113725713897668608",
      "fullText" : "We're very excited to welcome everyone to the #ENTERJamboree! Volunteers are available at the registration desk, or look for the yellow name tags or dark blue Tilburg hats. https://t.co/Iy5SCZDKEL",
      "expandedUrl" : "https://twitter.com/i/web/status/1113725713897668608"
    }
  },
  {
    "like" : {
      "tweetId" : "1112770182919938051",
      "fullText" : "The new month brings a big change that we're dying to share! The Journal of Human Resources is now the Journal of Huge Raccoons. We're excited to swap our focus in microeconomics for full color pictures of these paunchy procyons. Catch a sneak peek here: https://t.co/Y6Fi6yTlwu https://t.co/Ng4aFSIZoU",
      "expandedUrl" : "https://twitter.com/i/web/status/1112770182919938051"
    }
  },
  {
    "like" : {
      "tweetId" : "1113308058355154950",
      "fullText" : "Check out the 14th Nordic Conference on #BehaviouralEconomics! Great keynote speakers in the lovely city of Kiel, Germany. https://t.co/SDJjhN0NrV",
      "expandedUrl" : "https://twitter.com/i/web/status/1113308058355154950"
    }
  },
  {
    "like" : {
      "tweetId" : "1107618823975383046",
      "fullText" : "@Land4Flood The Paris conference on Risk Perception went quite well for local organizers... What do you think? Looking forward to the conference report! https://t.co/q68hDCG6E8",
      "expandedUrl" : "https://twitter.com/i/web/status/1107618823975383046"
    }
  },
  {
    "like" : {
      "tweetId" : "1109094998333636608",
      "fullText" : "Whoop #paper with accept with minor revisions. Time to go home, I can't top this. #AcademicTwitter",
      "expandedUrl" : "https://twitter.com/i/web/status/1109094998333636608"
    }
  },
  {
    "like" : {
      "tweetId" : "1108679952591933440",
      "fullText" : "Call for Replication Proposals! Grants of €150,000 for replication projects, and €75,000 for reanalysis projects. Deadline: June 6. For details, see: https://t.co/Kq1nTn5TEp https://t.co/hvGj0LYL2P",
      "expandedUrl" : "https://twitter.com/i/web/status/1108679952591933440"
    }
  },
  {
    "like" : {
      "tweetId" : "1107634172489859073",
      "fullText" : "If you're in Amsterdam &amp; want to hear about #virtualreality research, come to my talk at @VUamsterdam next Monday! #VR https://t.co/wLxjoxZtMM",
      "expandedUrl" : "https://twitter.com/i/web/status/1107634172489859073"
    }
  },
  {
    "like" : {
      "tweetId" : "1106557896177922049",
      "fullText" : "Sparren over duurzaamheid met gedragswetenschappers? Meld je aan voor onze Werkplaats Gedrag op 4 april: https://t.co/mxFFfyuShx https://t.co/uR8GJD2rM1",
      "expandedUrl" : "https://twitter.com/i/web/status/1106557896177922049"
    }
  },
  {
    "like" : {
      "tweetId" : "1105814852667392001",
      "fullText" : "Academics and practitioners from 14 different countries at the\nEuropean Conference on Risk Perception: Behaviour, Management and Response\nLT #RiskPerception\n@UniversiteCergy\n@Land4Flood https://t.co/ppYFlB08Tv",
      "expandedUrl" : "https://twitter.com/i/web/status/1105814852667392001"
    }
  },
  {
    "like" : {
      "tweetId" : "1105494419116048385",
      "fullText" : "#NerdAlert ! Collega @jessefrederik kwam ineens met dit bríljante speeltje aanzetten, het 'Galton Board'. In mijn nieuwsbrief vertel ik er meer over: https://t.co/bAHYwCrozN https://t.co/0J3wvOlM0d",
      "expandedUrl" : "https://twitter.com/i/web/status/1105494419116048385"
    }
  },
  {
    "like" : {
      "tweetId" : "1105423399810224128",
      "fullText" : "As part of #BrainAwarenessWeek2019, I wrote an article about our research @OxfordWIN @OxExpPsy about how we make decisions when faced with uncertainty, check it out :-) \nhttps://t.co/annP1Tu5QB https://t.co/qqNrOhIyYF",
      "expandedUrl" : "https://twitter.com/i/web/status/1105423399810224128"
    }
  },
  {
    "like" : {
      "tweetId" : "1105222067866099714",
      "fullText" : "We have developed a visual oTree editor that allows you to build oTree projects in a hybrid point-and-click interface. If you’d like to try the beta and provide weekly written feedback, contact me chris@otree.org.",
      "expandedUrl" : "https://twitter.com/i/web/status/1105222067866099714"
    }
  },
  {
    "like" : {
      "tweetId" : "1103969254842478592",
      "fullText" : "As today is #InternationalWomensDay, Helena Fornwagner wrote a blog post about #BalanceforBetter for the The Nature Research Behavioural &amp; Social Sciences Community. You can find it at https://t.co/aTVgjSjDN0",
      "expandedUrl" : "https://twitter.com/i/web/status/1103969254842478592"
    }
  },
  {
    "like" : {
      "tweetId" : "1103980744785842177",
      "fullText" : "Is it a duck or a rabbit?\n\nGoogle Cloud Vision’s algorithm has the same optical illusion than you and me. It sees one or the other, depending on how the image is rotated.\n\nht @minimaxir\nhttps://t.co/BSzaMWOWcu",
      "expandedUrl" : "https://twitter.com/i/web/status/1103980744785842177"
    }
  },
  {
    "like" : {
      "tweetId" : "1103086162606874624",
      "fullText" : "Useful primer it seems. https://t.co/mx8nUzjWsS",
      "expandedUrl" : "https://twitter.com/i/web/status/1103086162606874624"
    }
  },
  {
    "like" : {
      "tweetId" : "1102966951498956800",
      "fullText" : "Just came across a figure in a published academic paper in Comic Sans and I may have to quit work for now and possibly eternity. https://t.co/SIbdXbyGsn",
      "expandedUrl" : "https://twitter.com/i/web/status/1102966951498956800"
    }
  },
  {
    "like" : {
      "tweetId" : "1102938910865412096",
      "fullText" : "This nice review shows how #VR experiments can benefit econ research, and discusses some challenges of VR experiments, too. #behavioraleconomics https://t.co/yzkFqjL7JN",
      "expandedUrl" : "https://twitter.com/i/web/status/1102938910865412096"
    }
  },
  {
    "like" : {
      "tweetId" : "1101033995205251072",
      "fullText" : "Really happy that @SanneJWWillems will present in our @wrmtudelft colloquium today (16.00) that focusses on #scicomm. Sanne will present her work on what chances people attach to words like \"often\" and \"almost never\", while I will present our latest hydrological jargon study. https://t.co/Qw89HMuJGX",
      "expandedUrl" : "https://twitter.com/i/web/status/1101033995205251072"
    }
  },
  {
    "like" : {
      "tweetId" : "1099314302832521217",
      "fullText" : "A nice review of the emerging #VR studies in experimental economics, by @JantsjeMol  https://t.co/OHLtKFxlVn #behavioraleconomics",
      "expandedUrl" : "https://twitter.com/i/web/status/1099314302832521217"
    }
  },
  {
    "like" : {
      "tweetId" : "1084931446056386560",
      "fullText" : "Prediction: if you are, or are thinking of becoming one of the growing number of #womeninVR, 2019 is your year.",
      "expandedUrl" : "https://twitter.com/i/web/status/1084931446056386560"
    }
  },
  {
    "like" : {
      "tweetId" : "1098494427113377792",
      "fullText" : "Here is my latest #OpenAccess paper https://t.co/RIvdBw5zL6 in @ClimDevJournal @unipotsdam . We look at the #Gender impacts of #flooding  on #wellbeing in #Vietnam and if #EbA for #CCA or #DRR can help - and yes they can! See more at  https://t.co/u6Atd2cPEq @weADAPT1 https://t.co/QOI03Tzn9v",
      "expandedUrl" : "https://twitter.com/i/web/status/1098494427113377792"
    }
  },
  {
    "like" : {
      "tweetId" : "1098509229554614272",
      "fullText" : "New paper now officially out (with @DSchindlerEcon, #StefanTrautmann and #YilongXu). Looks at selection effects in risky decisions under time pressure.\nhttps://t.co/JxDOizrUWT (open access)",
      "expandedUrl" : "https://twitter.com/i/web/status/1098509229554614272"
    }
  },
  {
    "like" : {
      "tweetId" : "1096781006001094661",
      "fullText" : "Did you miss Sanne Muis today? You can see and listen to her here: https://t.co/kZZdK0luuO \"Dr. Sanne Muis beschrijft in haar proefschrift een nieuwe, hydrodynamische methode waardoor extreme zeewaterstanden met meer nauwkeurigheid dan ooit kunnen worden vastgesteld.\" https://t.co/yQJ6FBetjU",
      "expandedUrl" : "https://twitter.com/i/web/status/1096781006001094661"
    }
  },
  {
    "like" : {
      "tweetId" : "1069690058578558976",
      "fullText" : "Proud and happy to author one of the first #VR publications in an econ journal. Virtual humans as co-workers: A novel methodology to study peer effects https://t.co/w8nuevffgJ or https://t.co/Jqpa3DXYPw #BehavioralEconomics @RWTH https://t.co/atvF0MkgGj",
      "expandedUrl" : "https://twitter.com/i/web/status/1069690058578558976"
    }
  },
  {
    "like" : {
      "tweetId" : "1534214968756822017",
      "fullText" : "Great day at Maastricht Behavioural and Experimental Economics symposium #MBEES. \n\nGreat talks from some great researchers, plus reconnecting with some old connections in real life @davidhagmann, @KColombe24, @AnnaNyvelt, @HendirkB, @MaxvLent",
      "expandedUrl" : "https://twitter.com/i/web/status/1534214968756822017"
    }
  },
  {
    "like" : {
      "tweetId" : "1534435666196582401",
      "fullText" : "This was a short visit to Maastricht at the #MBEES conference but incredibly nice to exchange with other researchers in person again https://t.co/j0osF224tq",
      "expandedUrl" : "https://twitter.com/i/web/status/1534435666196582401"
    }
  },
  {
    "like" : {
      "tweetId" : "1532455645085155344",
      "fullText" : "My boyfriend is exploring the Rocky Mountains today and he just sent me this photo and I couldn't be more proud of him &lt;3\n\n(Meanwhile I am having a lot of fun at NCAR in Boulder CO!) https://t.co/EOBWt8E6y7",
      "expandedUrl" : "https://twitter.com/i/web/status/1532455645085155344"
    }
  },
  {
    "like" : {
      "tweetId" : "1531979909194727424",
      "expandedUrl" : "https://twitter.com/i/web/status/1531979909194727424"
    }
  },
  {
    "like" : {
      "tweetId" : "1531298998027440132",
      "fullText" : "Most of you know me for my hurricane research. So for most it makes perfect sense why my PhD thesis is titled \"Weathering the Storm\". But there's also a personal reason.👇\n\nToday is #WorldMSDay2022 and I am grateful for how I am doing, and also hoping that one day we can #CureMS! https://t.co/pCx9BbbJgR",
      "expandedUrl" : "https://twitter.com/i/web/status/1531298998027440132"
    }
  },
  {
    "like" : {
      "tweetId" : "1531287907490742272",
      "fullText" : "Today I successfully defended my PhD thesis and got a Summa Cum Laude grade. I am thrilled to share these news with you all. https://t.co/fRamw5fbFN",
      "expandedUrl" : "https://twitter.com/i/web/status/1531287907490742272"
    }
  },
  {
    "like" : {
      "tweetId" : "1531166591009935363",
      "fullText" : "Apparently, the new neighbors are fellow academics. I hope they're nice and if not I'll rename my WiFi to eduroam and make them go crazy over their login details not working...",
      "expandedUrl" : "https://twitter.com/i/web/status/1531166591009935363"
    }
  },
  {
    "like" : {
      "tweetId" : "1529720085417545728",
      "expandedUrl" : "https://twitter.com/i/web/status/1529720085417545728"
    }
  },
  {
    "like" : {
      "tweetId" : "1529440153378357248",
      "fullText" : "📢 Paper alert! Curious to know how policies targeting food demand can contribute to the mitigation of the #environmental and #health impacts of #food? Our paper https://t.co/aTBMawIAFo, published @NatureFoodJnl, provides some answers. A 🧵 (1/n) https://t.co/qBsyhUa5am",
      "expandedUrl" : "https://twitter.com/i/web/status/1529440153378357248"
    }
  },
  {
    "like" : {
      "tweetId" : "1529459035820462082",
      "fullText" : "Nice cover indeed https://t.co/Dqd62Zs60h",
      "expandedUrl" : "https://twitter.com/i/web/status/1529459035820462082"
    }
  },
  {
    "like" : {
      "tweetId" : "1528753042027323399",
      "fullText" : "Zet alvast donderdag 3 november in je agenda voor de Dag van het gedrag! Dit jaar met Katy Milkman en Ralph Hertwig als keynote sprekers. Wil je zelf een bijdrage aan het programma leveren? Stuur dan jouw idee in voor een sessie of pitch! Deadline 17 juni. https://t.co/iQcHKHfLXB https://t.co/snTWPwJWEq",
      "expandedUrl" : "https://twitter.com/i/web/status/1528753042027323399"
    }
  },
  {
    "like" : {
      "tweetId" : "1528119698738786304",
      "fullText" : "Hoe meer ik Nederlands versta, hoe meer ik denk dat hagedis korter is voor 's-gravenhagedis 🦎 🙂",
      "expandedUrl" : "https://twitter.com/i/web/status/1528119698738786304"
    }
  },
  {
    "like" : {
      "tweetId" : "1528276288871575553",
      "fullText" : "I knew I would get #FOMO for not going to #EGU22 in person, but it appears that I mostly miss the #train2EGU... Have a good journey everyone! Enjoy the view and good luck with your presentations! (Looking forward to doing #train2IAHS next week.) 🚄 https://t.co/G0at03vMPT",
      "expandedUrl" : "https://twitter.com/i/web/status/1528276288871575553"
    }
  },
  {
    "like" : {
      "tweetId" : "1527516394878803968",
      "fullText" : "Folks, follow these cool young economists from UvA. \n@D_D_Pace\n@AkdenizAslihan\n@AyseGMermer",
      "expandedUrl" : "https://twitter.com/i/web/status/1527516394878803968"
    }
  },
  {
    "like" : {
      "tweetId" : "1526822756876156928",
      "fullText" : "Basically every math textbook https://t.co/3tXCphcz0G",
      "expandedUrl" : "https://twitter.com/i/web/status/1526822756876156928"
    }
  },
  {
    "like" : {
      "tweetId" : "1526938951340150784",
      "fullText" : "100% of the winners of lecturer of the year at @UvA_Amsterdam is MALE. Just saying.",
      "expandedUrl" : "https://twitter.com/i/web/status/1526938951340150784"
    }
  },
  {
    "like" : {
      "tweetId" : "1524348371447828483",
      "fullText" : "Boss: \"where are you going?\"\nMe: \"just doing what R told me to\" https://t.co/kzRGqoMoij",
      "expandedUrl" : "https://twitter.com/i/web/status/1524348371447828483"
    }
  },
  {
    "like" : {
      "tweetId" : "1521147415558074373",
      "fullText" : "Wow, that was tough! Just presented about gender bias to management team of institute where in last years 5 female TT staff left (vs 0 male TT). Hope I made a small dent in the glass ceiling, but it seems hard for those on the other side to look down through it. #WomenInAcademia",
      "expandedUrl" : "https://twitter.com/i/web/status/1521147415558074373"
    }
  },
  {
    "like" : {
      "tweetId" : "1520362732389908482",
      "fullText" : "Voor het eerst in dik twee jaar weer meespelen met #Brabantsinfonia. En dan meteen het Requiem van Mozart! Op 22 mei in Concerzaal Tilburg https://t.co/nxwEdNgoM4",
      "expandedUrl" : "https://twitter.com/i/web/status/1520362732389908482"
    }
  },
  {
    "like" : {
      "tweetId" : "1519069118871351296",
      "expandedUrl" : "https://twitter.com/i/web/status/1519069118871351296"
    }
  },
  {
    "like" : {
      "tweetId" : "1518999680021114886",
      "fullText" : "PhD submitted!\nWhat a moment and mixed emotions state it is, so intense and different from any project completion I have had experience of. With a mixture of tears and smiles, I hold this journey near my heart and grieve an exploration that changed me and the way I see the world. https://t.co/aa74n7SCon",
      "expandedUrl" : "https://twitter.com/i/web/status/1518999680021114886"
    }
  },
  {
    "like" : {
      "tweetId" : "1517415216836972545",
      "fullText" : "⏮ Webinar Replay Available - Using Virtual Reality for Risk Communication with @JantsjeMol - https://t.co/Fy5lGnZHVm #riskcommunication #crisiscommunications #VirtualReality https://t.co/D9jcD0eQVz",
      "expandedUrl" : "https://twitter.com/i/web/status/1517415216836972545"
    }
  },
  {
    "like" : {
      "tweetId" : "1517056220221296641",
      "fullText" : "Can you solve climate change? Test your decision-making with this game of the @FT https://t.co/W1xvymKXl7",
      "expandedUrl" : "https://twitter.com/i/web/status/1517056220221296641"
    }
  },
  {
    "like" : {
      "tweetId" : "1517071229924126721",
      "fullText" : "Interesting post, explaining where agricultural economics originated from and what it distinguishes from classical economic sciences\n\nhttps://t.co/BJmY189aFr",
      "expandedUrl" : "https://twitter.com/i/web/status/1517071229924126721"
    }
  },
  {
    "like" : {
      "tweetId" : "1514655210106404864",
      "fullText" : "Met dank aan  ⁦⁦@RTLnieuws⁩ en ⁦⁦@sweconederland⁩ : niet e-bikes en fietsers zijn gevaarlijk, maar de 50km wegen zonder vrijliggende fietspaden, waar automobilisten fietsers aanrijden. #30ishetnieuwe50\n https://t.co/qgiSMMl3h6",
      "expandedUrl" : "https://twitter.com/i/web/status/1514655210106404864"
    }
  },
  {
    "like" : {
      "tweetId" : "1514112281327587329",
      "fullText" : "I’ve written a textbook on improving your statistical inferences. It consists of the content I teach in workshops, and combines material from my MOOC’s, blog, and published work. It’s a free open educational resource: You can read it here: https://t.co/FdQIS63fVd",
      "expandedUrl" : "https://twitter.com/i/web/status/1514112281327587329"
    }
  },
  {
    "like" : {
      "tweetId" : "1513423168928731136",
      "fullText" : "🎉🎉🎉 Super excited to spend the next 3 years @TilburgU @TilburgU_TiSEM investigating the drivers of performance in modern work environments using insights from escape games. Thanks @NWO_SSH @NWONieuws for financing this endeavor with a #Veni grant. https://t.co/jmVYquPQHG",
      "expandedUrl" : "https://twitter.com/i/web/status/1513423168928731136"
    }
  },
  {
    "like" : {
      "tweetId" : "1512430849400188931",
      "fullText" : "humbled and honoured by the many congrats I received from so many people for my appointment as Prof of Critical Data Studies at @UvA_Humanities. It is a reminder that this is not a \"me\" story but a collective enterprise--and I have so many thanks in store for each of you! From...",
      "expandedUrl" : "https://twitter.com/i/web/status/1512430849400188931"
    }
  },
  {
    "like" : {
      "tweetId" : "1512042502500540425",
      "fullText" : "=Seeking your opinion &amp; advice=\n\nRecently saw paper announcements starting with \"after 1/2/3 years &amp; 20/35/50 pretests/pilots... paper published\" &amp; paper reports 1-3 experiments.\n\nHow todo open-science about pilots &amp; pretests?\nHow to define pretest/pilot?\nShould we share these?",
      "expandedUrl" : "https://twitter.com/i/web/status/1512042502500540425"
    }
  },
  {
    "like" : {
      "tweetId" : "1512017895315832834",
      "fullText" : "In September I submitted a beast of a thesis: 183 pages on the effect of #paymentmethod on #behavior &amp; #personalfinance management: #memory, #spending, #debt, #savings even #skew and underlying #distribution get a mention.\n\nRead the summary of it here:\n\nhttps://t.co/O2UNb4AnUA",
      "expandedUrl" : "https://twitter.com/i/web/status/1512017895315832834"
    }
  },
  {
    "like" : {
      "tweetId" : "1511620281793667077",
      "fullText" : "🙋🏻‍♀️Participants NEEDED! \nWe are organising an experiment about using #virtualreality to study pedestrian road crossing behaviour with #automatedvehicles.\n🕰 When: 11-29 April. \n📍 Where: @AMS_institute \n📝 Register https://t.co/PrJXB40v5X https://t.co/7qGHLVmXEA",
      "expandedUrl" : "https://twitter.com/i/web/status/1511620281793667077"
    }
  },
  {
    "like" : {
      "tweetId" : "1509805829352005632",
      "fullText" : "Het LNVH heeft besloten een beloningsstelsel in te stellen om gendergelijkheid in de academie te bevorderen. Wil jij zo'n stoer BBQ schort? Benoem een vrouw!\n\n#eenschortvooreenbenoeming #helpeenvrouw #womenprofessors #changeacademia #gendergelijkheid #vrouwelijkehoogleraren https://t.co/LZkmUCLt6r",
      "expandedUrl" : "https://twitter.com/i/web/status/1509805829352005632"
    }
  },
  {
    "like" : {
      "tweetId" : "1509847815241048069",
      "fullText" : "Als je goed kijkt zie je bovenaan de glijbaan een docent met een vast contract en onderzoekstijd. Hilarisch! https://t.co/P3ZC8ESvib",
      "expandedUrl" : "https://twitter.com/i/web/status/1509847815241048069"
    }
  },
  {
    "like" : {
      "tweetId" : "1509846153071894532",
      "fullText" : "Super leuk om dit leerzame item te zien van het @jeugdjournaal over #roddelen!\n\nTrots om mijn inzichten op deze toegankelijke manier te delen. Bekijk het item hieronder en deel het! Bedankt voor het leuke interview @LvandeM!\n\nhttps://t.co/duEQwSxYBu\n\n@VUamsterdam @FSW_VU @OrgVU",
      "expandedUrl" : "https://twitter.com/i/web/status/1509846153071894532"
    }
  },
  {
    "like" : {
      "tweetId" : "1508716923395231749",
      "fullText" : "We have to talk about the individual, organizational and societal 'costs' of performance measurement. \n\nThat's the main message of my commentary in Business &amp; Society (@BASeditors). \n\nThe best part? It's #openaccess!\n\nLink: https://t.co/cfcjNGNTQL\n\n#accotwitter #meetmaatschappij https://t.co/ZehdV43RSU",
      "expandedUrl" : "https://twitter.com/i/web/status/1508716923395231749"
    }
  },
  {
    "like" : {
      "tweetId" : "1507421233700384774",
      "fullText" : "@rogers_k8 I got a couple for you! One recent citation is Willems, S., Albers, C., &amp; Smeets, I. (2020), which is about Dutch interpretations of verbal probability phrases (here's a screenshot of a slide including  their figure from a recent deck I made for a lab meeting) https://t.co/jliOitDzAZ",
      "expandedUrl" : "https://twitter.com/i/web/status/1507421233700384774"
    }
  },
  {
    "like" : {
      "tweetId" : "1506590404703133698",
      "expandedUrl" : "https://twitter.com/i/web/status/1506590404703133698"
    }
  },
  {
    "like" : {
      "tweetId" : "1506422748297379843",
      "fullText" : "I was told yesterday that I was stunning by someone who just met me.\n\nAnd that's just really nice to hear :) https://t.co/6Q42lv86t9",
      "expandedUrl" : "https://twitter.com/i/web/status/1506422748297379843"
    }
  },
  {
    "like" : {
      "tweetId" : "1506191131998101507",
      "fullText" : "Can behavioral economists please do this as an experiment and survey people at the back of the line? I want to see this published as a peer reviewed article... https://t.co/725U5sBs3z",
      "expandedUrl" : "https://twitter.com/i/web/status/1506191131998101507"
    }
  },
  {
    "like" : {
      "tweetId" : "1505824196982722563",
      "fullText" : "I enjoyed doing this interview with @MoneyMindMerle. It’s about my career in Behavioural Science, and my advice to those getting started. You can read the internet view here: https://t.co/CH0JbvT5FE https://t.co/lfpoEZaEEp",
      "expandedUrl" : "https://twitter.com/i/web/status/1505824196982722563"
    }
  },
  {
    "like" : {
      "tweetId" : "1504433273015001094",
      "fullText" : "Trots dat dit artikel officieel gepubliceerd is! 🥳 https://t.co/85H7oUYacI",
      "expandedUrl" : "https://twitter.com/i/web/status/1504433273015001094"
    }
  },
  {
    "like" : {
      "tweetId" : "1504368945805107203",
      "fullText" : "[IVMer(s) of the Week] Today we travelled to Tenerife to teach a fieldwork course. For mental well-being and to start the 10 day craziness in a fun and relaxing way, we went outdoor bouldering. This is a staple for any international travel we do for work. https://t.co/aNCwSktM57",
      "expandedUrl" : "https://twitter.com/i/web/status/1504368945805107203"
    }
  },
  {
    "like" : {
      "tweetId" : "1504099149611945987",
      "fullText" : "#EconTwitter I and Dianna Amasino\n are very excited the announce the next CREED/\n@ResearchTI\n workshop on March 24, 16:30CET on #Discrimination and #Inequality with the excellent speakers \nBertil Tungodden, Joanna Lahey and @alexoimas  \n, Registration: https://t.co/4iCX64wDCg https://t.co/nRQ6dNaDBb",
      "expandedUrl" : "https://twitter.com/i/web/status/1504099149611945987"
    }
  },
  {
    "like" : {
      "tweetId" : "1504153631985217539",
      "expandedUrl" : "https://twitter.com/i/web/status/1504153631985217539"
    }
  },
  {
    "like" : {
      "tweetId" : "1503807564240334853",
      "fullText" : "Our trial, testing the effect of nudges towards meat- and dairy replacements in the supermarket, will be live soon! @CassSunstein https://t.co/Uhrw6CvnMM",
      "expandedUrl" : "https://twitter.com/i/web/status/1503807564240334853"
    }
  },
  {
    "like" : {
      "tweetId" : "1503601785965010945",
      "fullText" : "Community fieldwork in Kenya 🇰🇪 https://t.co/mV6Y9pMtuu",
      "expandedUrl" : "https://twitter.com/i/web/status/1503601785965010945"
    }
  },
  {
    "like" : {
      "tweetId" : "1501550011796054018",
      "fullText" : "I received my doctorate cum laude. Time to share that joyful moment. I examine the representation of Islam and Judaism in Enlightenment thought. And show the impact of this legacy on contemporary liberalism. \n@UvA_Amsterdam @UvA_Humanities https://t.co/AfMmh782Ky",
      "expandedUrl" : "https://twitter.com/i/web/status/1501550011796054018"
    }
  },
  {
    "like" : {
      "tweetId" : "1501559727746162689",
      "fullText" : "Nice responses to the exam question \"what can we learn from the COVID-19 response to deal with climate change?\" \n1. \"The best time to deal with climate change might have been 50 years ago, but the next best time is now.\"\n2. \"What happens in China doesn't stay in China.\"",
      "expandedUrl" : "https://twitter.com/i/web/status/1501559727746162689"
    }
  },
  {
    "like" : {
      "tweetId" : "1501278726033715202",
      "fullText" : "Hey @EconTwitter:\n\nDo you know of experimental or empirical work showing that individuals avoid information to protect or improve their performance going forward?",
      "expandedUrl" : "https://twitter.com/i/web/status/1501278726033715202"
    }
  },
  {
    "like" : {
      "tweetId" : "1501253287143641093",
      "fullText" : "Proud of our first twitter thread. https://t.co/eOQXkqGuIr",
      "expandedUrl" : "https://twitter.com/i/web/status/1501253287143641093"
    }
  },
  {
    "like" : {
      "tweetId" : "1500575138298974213",
      "fullText" : "I love Dutch collaborators: \"Look, regarding your draft, I'm not going to sugar-coat my thoughts...\"\n\nP.S. This is the kind of feedback I always want",
      "expandedUrl" : "https://twitter.com/i/web/status/1500575138298974213"
    }
  },
  {
    "like" : {
      "tweetId" : "1499623953324986368",
      "fullText" : "Friday funday! https://t.co/S3gWtoKyE2",
      "expandedUrl" : "https://twitter.com/i/web/status/1499623953324986368"
    }
  },
  {
    "like" : {
      "tweetId" : "1499035061240356864",
      "fullText" : "Burning the midnight oil undermines intrinsic motivation.\n\nNew data: working nights and weekends isn't just exhausting. It also reminds you that you could be doing something better with your time.\n\nSetting boundaries is key to protecting engagement and promoting quality work. https://t.co/SNHL1UQjMv",
      "expandedUrl" : "https://twitter.com/i/web/status/1499035061240356864"
    }
  },
  {
    "like" : {
      "tweetId" : "1499097344935186434",
      "fullText" : "Thanks for the explanation. I am sure that you do not need a health economist to explain that this explanation has missed the point. But let me provide some hints anyhow. 1/9 https://t.co/ztOj5XJzbi",
      "expandedUrl" : "https://twitter.com/i/web/status/1499097344935186434"
    }
  },
  {
    "like" : {
      "tweetId" : "1499046288394010634",
      "fullText" : "[CC: the most poetic academic spam email] \n\nDear Bloemendaal Nadia, \n\n✨May you spent this Day full of enjoyable reading. Authors are like a candle that burns out his self to give light to the scientific community ✨\n\nGuess it's time for this academic candle to get lit! https://t.co/zT6SLhEYXl",
      "expandedUrl" : "https://twitter.com/i/web/status/1499046288394010634"
    }
  },
  {
    "like" : {
      "tweetId" : "1498325042672721931",
      "fullText" : "I run field experiments with many organizations. Scholars often ask how they can get started.\n\nRule #1:  Never use the \"E\" word.  \n\nYou \"pilot\" or \"trial\" you don't experiment. Many organizations view the E word as repugnant.  For an op ed view see\nhttps://t.co/KSqbh8cfEK",
      "expandedUrl" : "https://twitter.com/i/web/status/1498325042672721931"
    }
  },
  {
    "like" : {
      "tweetId" : "1498334690637492225",
      "fullText" : "Hi everybody. I’m like, kinda bummed out by… well, everything at the moment. \n\nSo #EconTwitter: any ideas for the syllabus to a (obv hypothetical) class called Mood Boosting for Assistant Professors?\n\nPrerequisites include crippling anxiety, impostor syndrome, and Real Analysis.",
      "expandedUrl" : "https://twitter.com/i/web/status/1498334690637492225"
    }
  },
  {
    "like" : {
      "tweetId" : "1498235046422986755",
      "fullText" : "It has come in!\n\nAll hail Dr. van den Akker!\n\n@AcademicChatter #phdchat #AcademicTwitter #behavioralscience https://t.co/efHBkRuRRw",
      "expandedUrl" : "https://twitter.com/i/web/status/1498235046422986755"
    }
  },
  {
    "like" : {
      "tweetId" : "1496815867958644736",
      "fullText" : "Gerdien Bertram-Troost beleefde spannende uren vlak voor haar oratie vanwege storm Eunice: https://t.co/BcyLakpOYO",
      "expandedUrl" : "https://twitter.com/i/web/status/1496815867958644736"
    }
  },
  {
    "like" : {
      "tweetId" : "1496588026977390597",
      "fullText" : "There's a new board game in town 🤓 https://t.co/wQrlplftAH",
      "expandedUrl" : "https://twitter.com/i/web/status/1496588026977390597"
    }
  },
  {
    "like" : {
      "tweetId" : "1496468767550881796",
      "fullText" : "We have an open tenure track position on HCI &amp; data visualization research at @VU_Science @UserCentricDS  https://t.co/sCVdQ8CF1b",
      "expandedUrl" : "https://twitter.com/i/web/status/1496468767550881796"
    }
  },
  {
    "like" : {
      "tweetId" : "1496235447718408193",
      "fullText" : "Happy to report that I have been to seen a performance (from the Australian String Quartet) at the Sydney Opera House!\n\nI think I now had the proper Sydney experience!",
      "expandedUrl" : "https://twitter.com/i/web/status/1496235447718408193"
    }
  },
  {
    "like" : {
      "tweetId" : "1496107919691108357",
      "fullText" : "Dear all, I am more than happy to tell you that I am joining ifo’s Economics of Education center (@ifo_Education) as a 6-yr postdoc! Yesterday, I had a super enjoyable introductory day in Munich, and I cannot wait to start in September.",
      "expandedUrl" : "https://twitter.com/i/web/status/1496107919691108357"
    }
  },
  {
    "like" : {
      "tweetId" : "1494697984679944211",
      "expandedUrl" : "https://twitter.com/i/web/status/1494697984679944211"
    }
  },
  {
    "like" : {
      "tweetId" : "1493644528007352324",
      "fullText" : "Our new open-access paper in ERL @IOPenvironment  finds that plant-based meat will have only modest impacts on cattle production, cattle producers, and the environment in the short-term. @JaysonLusk @TonsorGlynn @SaloniShah101 https://t.co/BthW85E3qa https://t.co/8DnPyHTANs",
      "expandedUrl" : "https://twitter.com/i/web/status/1493644528007352324"
    }
  },
  {
    "like" : {
      "tweetId" : "1493593816150036480",
      "fullText" : "I’m thrilled to share that I’ll be joining @ChicagoBooth this July as a tenure-track faculty in the Behavioral Science unit. The new semester will bring huge changes—new job, new colleagues, new city—and I’m excited beyond words to see what the future holds. https://t.co/Gfl3OnVOvp",
      "expandedUrl" : "https://twitter.com/i/web/status/1493593816150036480"
    }
  },
  {
    "like" : {
      "tweetId" : "1493562009044099075",
      "fullText" : "How can Virtual Reality help Crime Research?\nIn her PhD thesis about preventing burglaries in urban neighborhoods, van Sintemaartensdijk uses a virtual environment (VE) to study the effects on criminal behavior when using special signs. To know more: https://t.co/ZEiR84pe0J https://t.co/8FZxjDugVm",
      "expandedUrl" : "https://twitter.com/i/web/status/1493562009044099075"
    }
  },
  {
    "like" : {
      "tweetId" : "1493525822501703685",
      "fullText" : "#Climate Adaptation Modelling: a new open book aiming to provide orientation in the large &amp; expanding methodological literature, presenting novelties, guiding in the practical application of #adaptation assessments &amp; suggesting lines for future #research. https://t.co/mzv0m4NCZB https://t.co/ckJ7P1LFSH",
      "expandedUrl" : "https://twitter.com/i/web/status/1493525822501703685"
    }
  },
  {
    "like" : {
      "tweetId" : "1493199857305141260",
      "fullText" : "@FryskeAkademy Hopelijk heeft Hans ook een beetje kunnen volgen hoeveel er op Twitter over zijn recente publicaties (mbt middeleeuwse geschiedenis) gesproken is!",
      "expandedUrl" : "https://twitter.com/i/web/status/1493199857305141260"
    }
  },
  {
    "like" : {
      "tweetId" : "1493456094181560321",
      "fullText" : "I just found an academic who researches reducing meat consumption through nudging and other behavioural interventions.\n\nThis legends' last name is Bacon. \n\nYou got to love the irony of it all...",
      "expandedUrl" : "https://twitter.com/i/web/status/1493456094181560321"
    }
  },
  {
    "like" : {
      "tweetId" : "1493273969541140484",
      "fullText" : "@Erwin87_breda Mijn man kwam vandaag mijn vergeten bammetjes naar mijn werk brengen. Trouwens, we zijn vandaag op de dag af 38 jaar samen! 🌈",
      "expandedUrl" : "https://twitter.com/i/web/status/1493273969541140484"
    }
  },
  {
    "like" : {
      "tweetId" : "1493288799312429063",
      "fullText" : "Almost 3 years of research on #socialinnovation and #communityenergy finally come together in this booklet👇 we're now in the process of discussing it with stakeholders 🚨 @NEWCOMERS_H2020 policy recommendations following soon https://t.co/qjLV5FoXN9",
      "expandedUrl" : "https://twitter.com/i/web/status/1493288799312429063"
    }
  },
  {
    "like" : {
      "tweetId" : "1493258980713328649",
      "fullText" : "Happy Valentine's Day. https://t.co/uP1GVaoArU",
      "expandedUrl" : "https://twitter.com/i/web/status/1493258980713328649"
    }
  },
  {
    "like" : {
      "tweetId" : "1493237932601262080",
      "fullText" : "NHC hurricane logos are red\nBut in STORM they are blue\nTo all my colleagues and coauthors I say\nI am so happy I get to work with you! https://t.co/KZo6eSLoC1",
      "expandedUrl" : "https://twitter.com/i/web/status/1493237932601262080"
    }
  },
  {
    "like" : {
      "tweetId" : "1493168955976044545",
      "expandedUrl" : "https://twitter.com/i/web/status/1493168955976044545"
    }
  }
]