window.YTD.ad_engagements.part0 = [
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1842607934724792536",
                  "tweetText" : "Here are the top AI tools of 2024.\n\nWe write 5-minute guides on how to use them in our free newsletter.\n\nJoin 500,000+ readers and find out how the early adopters are (actually) using AI:",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "The Rundown AI",
                  "screenName" : "@TheRundownAI"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@nonmayorpete"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@labenz"
                  },
                  {
                    "targetingType" : "List"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "The Netherlands"
                  }
                ],
                "impressionTime" : "2025-02-06 13:53:23"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-02-06 13:53:26",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1866497096909746656",
                  "tweetText" : "📉 De gemiddelde tienjaars hypotheekrente met NHG is in een jaar tijd met 1%-punt gedaald naar 3,55%. Door dalende kapitaalmarktrentes en een mogelijke ECB-renteverlaging wordt een verdere daling verwacht, wat de leenruimte voor huizenkopers vergroot.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Hypotheekrente.nl",
                  "screenName" : "@hypotheekrenteX"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "Desktop"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "English"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "The Netherlands"
                  }
                ],
                "impressionTime" : "2025-02-06 13:53:23"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-02-06 13:54:14",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1886444973823828456",
                  "tweetText" : "Paid advertisement from @CWP_GROUP: Reduce risks, boost profits and enjoy AI-driven international compliance with a platform created for trade experts, by trade experts, via @traydstream. https://t.co/9qoEa3Kg2B.",
                  "urls" : [
                    "https://t.co/9qoEa3Kg2B"
                  ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "The Associated Press",
                  "screenName" : "@AP"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@cepr_org"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@TradeandMoney"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@PennyG_Yale"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@yilmazkuday"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "English"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  }
                ],
                "impressionTime" : "2025-02-06 13:55:22"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-02-06 13:55:27",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2025-02-06 13:55:32",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2025-02-06 13:55:31",
                  "engagementType" : "VideoContent1secView"
                },
                {
                  "engagementTime" : "2025-02-06 13:55:30",
                  "engagementType" : "VideoContentPlaybackStart"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1867524618762039684",
                  "tweetText" : "𝗣𝗿𝗼𝗳𝗶𝘁𝗲𝗲𝗿 𝗻𝘂 𝘃𝗮𝗻 𝟮𝟬% 𝗪𝗶𝗻𝘁𝗲𝗿𝘃𝗼𝗼𝗿𝗱𝗲𝗲𝗹!❄️\n20% voordeel op bijna alles.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Koninklijke Auping",
                  "screenName" : "@AupingNL"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "List",
                    "targetingValue" : "Pro Targeting - Negative engagers AupingNL specific - Netherlands/Global"
                  },
                  {
                    "targetingType" : "List",
                    "targetingValue" : "Pro Targeting - Exclusion Audience: negative engagers - Global"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "The Netherlands"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  }
                ],
                "impressionTime" : "2025-02-06 13:53:23"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-02-06 13:53:26",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2025-02-06 13:53:27",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2025-02-06 13:53:47",
                  "engagementType" : "VideoSession"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1869146806208397787",
                  "tweetText" : "🚀 Real-time communication APIs loved by developers. Start building your proof of concept today. 🛠️",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Stream",
                  "screenName" : "@getstream_io"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Web development"
                  },
                  {
                    "targetingType" : "Website Activity",
                    "targetingValue" : "Visited Site"
                  },
                  {
                    "targetingType" : "Website Activity",
                    "targetingValue" : "sign_up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "The Netherlands"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "Desktop"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 to 54"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "English"
                  }
                ],
                "impressionTime" : "2025-02-06 13:55:22"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-02-06 13:55:36",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2025-02-06 13:55:38",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2025-02-06 13:55:37",
                  "engagementType" : "VideoContent1secView"
                },
                {
                  "engagementTime" : "2025-02-06 13:55:39",
                  "engagementType" : "VideoContentViewV2"
                },
                {
                  "engagementTime" : "2025-02-06 13:55:39",
                  "engagementType" : "VideoContentViewThreshold"
                },
                {
                  "engagementTime" : "2025-02-06 13:55:42",
                  "engagementType" : "VideoContent6secView"
                },
                {
                  "engagementTime" : "2025-02-06 13:55:36",
                  "engagementType" : "VideoContentPlaybackStart"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TweetConversation",
                "promotedTweetInfo" : {
                  "tweetId" : "1884523879613497715",
                  "tweetText" : "Hoe ziet de samenwerking eruit die leidt tot minder incidenten in de stadions? Je ontdekt het in deze video!",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "KNVB",
                  "screenName" : "@KNVB"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Soccer"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "The Netherlands"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "English"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "21 to 54"
                  }
                ],
                "impressionTime" : "2025-02-06 13:55:12"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-02-06 13:55:16",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2025-02-06 13:55:17",
                  "engagementType" : "VideoContentViewThreshold"
                },
                {
                  "engagementTime" : "2025-02-06 13:55:15",
                  "engagementType" : "VideoContent1secView"
                },
                {
                  "engagementTime" : "2025-02-06 13:55:17",
                  "engagementType" : "VideoContentViewV2"
                },
                {
                  "engagementTime" : "2025-02-06 13:55:20",
                  "engagementType" : "VideoContent6secView"
                },
                {
                  "engagementTime" : "2025-02-06 13:55:21",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2025-02-06 13:55:13",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2025-02-06 13:55:14",
                  "engagementType" : "VideoContentPlaybackStart"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1884205892167401586",
                  "tweetText" : "Personeelstekort? Tijdgebrek? Ingewikkelde materie? Uitbesteden kan uitkomst bieden. \nEen specialist werkt vaak sneller en maakt minder fouten. \nZo kun jij focussen op de groei van je bedrijf. \nBenieuwd waar je op kunt letten bij uitbesteden? Check: https://t.co/R8QAGQ5wQ0",
                  "urls" : [
                    "https://t.co/R8QAGQ5wQ0"
                  ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Kamer van Koophandel",
                  "screenName" : "@KVK_NL"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Entrepreneurship"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "The Netherlands"
                  }
                ],
                "impressionTime" : "2025-02-06 13:53:23"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-02-06 13:55:23",
                  "engagementType" : "VideoContentMrcView"
                },
                {
                  "engagementTime" : "2025-02-06 13:54:55",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2025-02-06 13:55:10",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2025-02-06 13:55:30",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2025-02-06 13:55:22",
                  "engagementType" : "VideoContent1secView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1869146554604683331",
                  "tweetText" : "We empower developers to build in-app chat, video &amp; audio, and feeds, faster with enterprise-grade reliability. 📲🔧",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Stream",
                  "screenName" : "@getstream_io"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Web development"
                  },
                  {
                    "targetingType" : "Website Activity",
                    "targetingValue" : "Visited Site"
                  },
                  {
                    "targetingType" : "Website Activity",
                    "targetingValue" : "sign_up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "The Netherlands"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 to 54"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "Desktop"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "English"
                  }
                ],
                "impressionTime" : "2025-02-06 13:53:23"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-02-06 13:55:34",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2025-02-06 13:55:25",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2025-02-06 13:55:25",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1899093431680671855",
                  "tweetText" : "Elite freerunning athletes attempt parkour moves from Assassin's Creed Shadows",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Assassin's Creed",
                  "screenName" : "@assassinscreed"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Assassin's Creed"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "The Netherlands"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 to 49"
                  }
                ],
                "impressionTime" : "2025-03-11 14:25:56"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-03-11 14:26:38",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2025-03-11 14:26:40",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2025-03-11 14:27:01",
                  "engagementType" : "VideoSession"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1898993446284849658",
                  "tweetText" : "The best shoes are the ones you forget you're wearing 😍 👟 Experience barefoot comfort with zero bulk, total flexibility, and a natural fit that moves with you. No stiff soles, no restrictions—just pure comfort for your feet. Try them today and feel the difference!",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Canles",
                  "screenName" : "@canlesofficial"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "The Netherlands"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "Desktop"
                  }
                ],
                "impressionTime" : "2025-03-11 14:25:56"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-03-11 14:26:05",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1864979368382206053",
                  "tweetText" : "Betaal alleen wat je verbruikt, zonder verborgen verrassingen! 💡",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "easyEnergy.com",
                  "screenName" : "@easyEnergycom"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "The Netherlands"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "Dutch"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "Desktop"
                  }
                ],
                "impressionTime" : "2025-03-11 14:25:56"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-03-11 14:27:11",
                  "engagementType" : "VideoSession"
                },
                {
                  "engagementTime" : "2025-03-11 14:26:59",
                  "engagementType" : "VideoContent1secView"
                },
                {
                  "engagementTime" : "2025-03-11 14:26:45",
                  "engagementType" : "ChargeableImpression"
                },
                {
                  "engagementTime" : "2025-03-11 14:26:59",
                  "engagementType" : "VideoContentPlayback25"
                },
                {
                  "engagementTime" : "2025-03-11 14:26:59",
                  "engagementType" : "VideoContentPlayback50"
                },
                {
                  "engagementTime" : "2025-03-11 14:26:58",
                  "engagementType" : "VideoContentPlaybackStart"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1899424796821041517",
                  "tweetText" : "$BTC / $USDT - TA OTD 📊 - In partnership with @OKX\n\n$BTC keeps dropping with a fresh lower low printed just last night.\n\nSo the question here is simple, is this $76K level the bottom or should we expect further dips?\n\nWell, just follow me here to find out!\n\n👇 https://t.co/Xu0pHE4wMN",
                  "urls" : [ ],
                  "mediaUrls" : [
                    "https://t.co/Xu0pHE4wMN"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Sjuul | AltCryptoGems",
                  "screenName" : "@AltCryptoGems"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "The Netherlands"
                  }
                ],
                "impressionTime" : "2025-03-11 14:24:10"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-03-11 14:24:12",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1897364756606149092",
                  "tweetText" : "Big tech is moving to Riyadh! @alat_tech and @LENOVO are building a manufacturing facility in #RiyadhIntegrated, which is operated by @SILZ_KSA, producing millions of Saudi-Made laptops and desktops, as well as servers by 2026, and creating +60k direct and indirect jobs. https://t.co/Q8N3qgAXh5",
                  "urls" : [ ],
                  "mediaUrls" : [
                    "https://t.co/Q8N3qgAXh5",
                    "https://t.co/Q8N3qgAXh5",
                    "https://t.co/Q8N3qgAXh5"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "SILZ",
                  "screenName" : "@SILZ_KSA"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Technology"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "English"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "The Netherlands"
                  }
                ],
                "impressionTime" : "2025-03-11 14:25:56"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-03-11 14:27:01",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1909550937472987375",
                  "tweetText" : "Ready to transform your body with just 15 minutes a day?\n\n💪 Join thousands who are getting sculpted with Wall Pilates by Zing!\n\n✨ Fast results, AI body scan tracking &amp; fun workouts you’ll love!\n\n🧘‍♀️ Start your journey today — your future self will thank you!",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Zing",
                  "screenName" : "@ZingAICoach"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Women"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "The Netherlands"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "English"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  }
                ],
                "impressionTime" : "2025-04-09 07:35:21"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-04-09 07:35:23",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1861376858413015222",
                  "tweetText" : "Het kost 7.000 liter water om slechts één jeans te produceren. Dutch Clean Tech bouwt waterzuiveringen waardoor de textielindustrie water kan hergebruiken. Dit is een unieke kans om te beleggen met impact. Vraag vandaag de brochure nog aan.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Dutch Clean Tech",
                  "screenName" : "@Dutchclean_tech"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "The Netherlands"
                  }
                ],
                "impressionTime" : "2025-04-09 07:35:21"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-04-09 07:35:27",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1894731492313768292",
                  "tweetText" : "Jezelf voorbereiden op de huidige en de volgende golf van Bitcoin-adoptie?\nDownload de gratis Bitcoin Bundel ⬇️\n\nInhoud:\n✅ Mini-cursus\n✅ Bitcoin Bullmarkt rapport\n✅ Bitcoin DCA sheet \nen meer..\n\nDownload gratis: https://t.co/tpU3tZM8LZ",
                  "urls" : [
                    "https://t.co/tpU3tZM8LZ"
                  ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Madelon Vos",
                  "screenName" : "@MadelonBackup"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "Desktop"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 and up"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "Dutch"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "The Netherlands"
                  }
                ],
                "impressionTime" : "2025-04-09 07:35:21"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2025-04-09 07:35:34",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  }
]