window.YTD.direct_messages.part0 = [
  {
    "dmConversation" : {
      "conversationId" : "16629918-1096413470554292225",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "16629918",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "yo se \"LLAQ**************571.99 EUR\"",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1455458125893541895",
            "createdAt" : "2021-11-02T08:53:53.047Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "16629918",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "tengo una bona a jantsje@gmail.com",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1455457509129457670",
            "createdAt" : "2021-11-02T08:51:26.003Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "16629918",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "hola!",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1455457395992317961",
            "createdAt" : "2021-11-02T08:50:59.035Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "21743551-1096413470554292225",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "21743551",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "het is gelukt!",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1686386695414128646",
            "createdAt" : "2023-08-01T14:41:34.457Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "21743551",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "dankjewel!",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1686385232038289413",
            "createdAt" : "2023-08-01T14:35:45.567Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "21743551",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "31-12-2022, formuliertje@outlook.com",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1686385174484033540",
            "createdAt" : "2023-08-01T14:35:31.838Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "21743551",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Melle Verdenius",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1686383876208541700",
            "createdAt" : "2023-08-01T14:30:22.327Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "21743551",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "pasnummer 61009720275",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1686383857300582404",
            "createdAt" : "2023-08-01T14:30:17.788Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "21743551",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hoi! Ik heb een nieuw account aangemaakt voor mijn zoon Melle, maar omdat mijn eigen emailadres al bestond in het systeem heb ik een ander adres gebruikt, alleen is dat niet goed opgeslagen.. Dus nu kan ik niet registreren, want ik kan het emailadres niet wijzigen...",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1686383750463262724",
            "createdAt" : "2023-08-01T14:29:52.397Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "1116676806-1096413470554292225",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1116676806",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Groet Jantsje",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1365347468188213260",
            "createdAt" : "2021-02-26T17:06:18.075Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1116676806",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "ik wil niet annuleren ik zou graag gewoon de bestelling ontvangen!",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1365347435179110404",
            "createdAt" : "2021-02-26T17:06:10.211Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1116676806",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "en vandaag krijg ik een mail dat ík geannuleerd heb?",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1365347376064585735",
            "createdAt" : "2021-02-26T17:05:56.104Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1116676806",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "zou op 23 feb bezorgd moeten worden",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1365347315268149252",
            "createdAt" : "2021-02-26T17:05:41.608Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1116676806",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Deze had een maand levertijd",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1365347281722089476",
            "createdAt" : "2021-02-26T17:05:33.627Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1116676806",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hallo! Ik had een bestelling met nummer 1164306613",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1365347238290071559",
            "createdAt" : "2021-02-26T17:05:23.276Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "1142884112-1096413470554292225",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1142884112",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hoi Thijs, leuk om kennis te maken! Prima dat je mijn foto hebt gebruikt, fijn dat je het nog even checkt. Groet Jantsje",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1589194294816030724",
            "createdAt" : "2022-11-06T09:53:40.366Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "1218566827-1096413470554292225",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1218566827",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Ja het is bezorgd, bedankt.",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1368625402957209605",
            "createdAt" : "2021-03-07T18:11:38.596Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1218566827",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hallo, ik heb weer niks ontvangen in het verwachte tijdslot (vandaag 18-22)",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1367582588962013189",
            "createdAt" : "2021-03-04T21:07:52.359Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1218566827",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "heb meteen betaald!",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1366321251053101061",
            "createdAt" : "2021-03-01T09:35:45.955Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1218566827",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "4 maart is prima! Moet ik nu opnieuw betalen en komt het andere bedrag terug?",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1366320675884060676",
            "createdAt" : "2021-03-01T09:33:28.827Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1218566827",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Ja heel graag!",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1366063124399468556",
            "createdAt" : "2021-02-28T16:30:03.767Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1218566827",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hoi Linsey, dat zou fijn zijn! Ik begrijp dat het nu niet heel makkelijk is allemaal, maar na 30 dagen levertijd vond ik het wel echt stom dat ik wel een track en trace code kreeg, maar dat er niemand kwam opdagen, en dat de bestelling toen opeens geannuleerd werd :( Ik zit inmiddels wel een beetje te wachten op een aantal spullen uit bestelling! Groet Jantsje",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1365961284555005958",
            "createdAt" : "2021-02-28T09:45:23.258Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1218566827",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Bestel datum 27-1",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1365717283042115595",
            "createdAt" : "2021-02-27T17:35:48.759Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1218566827",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Jantsje Mol, Jacob Catsstraat 7 2274 GS Voorburg",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1365717114947047432",
            "createdAt" : "2021-02-27T17:35:08.700Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1218566827",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Excuus verkeerde account, heb hem al aan IkeaHelpt verstuurd!",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1365347575977701384",
            "createdAt" : "2021-02-26T17:06:43.768Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1218566827",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "want ik wil dus niet annuleren, ik zou graag gewoon mijn bestelling ontvangen!",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1365346982378819591",
            "createdAt" : "2021-02-26T17:04:22.252Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1218566827",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "*dit kunnen rechtzetten",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1365346907221024779",
            "createdAt" : "2021-02-26T17:04:04.328Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1218566827",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hi! Ik had een bestelling 1164306613 en die had een maand levertijd. Hij zou deze week bezorgd worden. Hij kwam niet. En nu krijg ik een mail dat ik heb geannuleerd heb? Ik hoop dat jullie die kunnen rechtzetten. Groet Jantsje",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1365346803101630475",
            "createdAt" : "2021-02-26T17:03:39.544Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "1475691308-1096413470554292225",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Oh, thank you very much. And, indeed, I cannot make it this time to the workshop, but may be next year.",
            "mediaUrls" : [ ],
            "senderId" : "1475691308",
            "id" : "1229777252897959941",
            "createdAt" : "2020-02-18T14:38:39.950Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1475691308",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I’m curious about your JBEE article! All the best with the last writing efforts.",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1229773244888223748",
            "createdAt" : "2020-02-18T14:22:44.355Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1475691308",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "No problem! I think they are still open for participation (non presenting) but I guess that is a bit on short notice 😬",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1229773067955642372",
            "createdAt" : "2020-02-18T14:22:02.193Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I am not finished yet with the paper for JBEE. I hope, that I can submit it in the next two or three weeks.",
            "mediaUrls" : [ ],
            "senderId" : "1475691308",
            "id" : "1229768097290162181",
            "createdAt" : "2020-02-18T14:02:17.078Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "OK, thanks for the information. I met Timo Goeschl at some conference, I think.",
            "mediaUrls" : [ ],
            "senderId" : "1475691308",
            "id" : "1229767823322492932",
            "createdAt" : "2020-02-18T14:01:11.768Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1475691308",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Did you submit your VR experiment to JBEE already?",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1229766269345390601",
            "createdAt" : "2020-02-18T13:55:01.252Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1475691308",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hi Özgür! I think I was on the email list from attending the workshop two years ago in Hamburg... And I met Florian Diekert in Philadelphia so he reminded me :)",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1229766015095123972",
            "createdAt" : "2020-02-18T13:54:00.649Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hi Jantsje, since I cannot remember having seen an announcement for the workshop you attend in Heidelberg, how did you learn about it? ESA? Which newsletter do I have to subscribe? Best wishes...",
            "mediaUrls" : [ ],
            "senderId" : "1475691308",
            "id" : "1229763536538218501",
            "createdAt" : "2020-02-18T13:44:09.735Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Great! I think VR can have a real impact in the environmental context. Best wishes...",
            "mediaUrls" : [ ],
            "senderId" : "1475691308",
            "id" : "1223249644869824518",
            "createdAt" : "2020-01-31T14:20:16.904Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1475691308",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I will present the design at the EEE workshop in Heidelberg in February (19-20)",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1223222116243443716",
            "createdAt" : "2020-01-31T12:30:53.568Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1475691308",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I'm curious how that will work out. I'll keep you posted!",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1223221940850253829",
            "createdAt" : "2020-01-31T12:30:11.753Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1475691308",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/TX5ScXFS3t",
                "expanded" : "http://journals.sagepub.com/doi/10.1177/0022427818819696",
                "display" : "journals.sagepub.com/doi/10.1177/00…"
              }
            ],
            "text" : "Sounds good, JBEE now has 2 VR econ papers so they might be up for more! I'm setting up a new VR project at the moment, in which we want participants to experience a home being flooded (after all I work at the institute of environmental studies...). Exciting VR lab around the corner (https://t.co/TX5ScXFS3t this is something they recently built) so I",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1223221879852404742",
            "createdAt" : "2020-01-31T12:29:58.117Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "And you, some new VR projects?",
            "mediaUrls" : [ ],
            "senderId" : "1475691308",
            "id" : "1223220805066272773",
            "createdAt" : "2020-01-31T12:25:40.963Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Thanks, everything is well. We have some people in Erfurt doing experiments. At the moment, I still try to publish some papers, some of them involving VR experiments. The one with donations, I plan to submit to JBEE soon.",
            "mediaUrls" : [ ],
            "senderId" : "1475691308",
            "id" : "1223220678314295301",
            "createdAt" : "2020-01-31T12:25:10.766Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1475691308",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "How are you by the way? I heard you are back in Erfurt? Any new VR projects planned or in the pipeline? Or conventional lab experiments :)",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1223203402697650180",
            "createdAt" : "2020-01-31T11:16:31.908Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1475691308",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I'm really excited about the publication!",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1223203233914597380",
            "createdAt" : "2020-01-31T11:15:51.665Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1475691308",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hi Özgür! Thanks! Good to hear that it works now :)",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1223203192588185604",
            "createdAt" : "2020-01-31T11:15:41.812Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Sorry, OK, now it works :-)",
            "mediaUrls" : [ ],
            "senderId" : "1475691308",
            "id" : "1223196583564664837",
            "createdAt" : "2020-01-31T10:49:26.118Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hi Jantsje, congrats for your publication in ExpEcon! Before I re-tweet this good news, I just wanted to ask you to check the link to the paper in your tweet. It didn't work for me.",
            "mediaUrls" : [ ],
            "senderId" : "1475691308",
            "id" : "1223196334473326597",
            "createdAt" : "2020-01-31T10:48:26.726Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "1869223770-1096413470554292225",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1869223770",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Je bent van harte welkom!",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1156209024150450181",
            "createdAt" : "2019-07-30T14:24:47.379Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Ik kom tzt kijken hoor!",
            "mediaUrls" : [ ],
            "senderId" : "1869223770",
            "id" : "1156179110407868420",
            "createdAt" : "2019-07-30T12:25:55.379Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1869223770",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Oh wat fijn! Ja hoor alles goed hier! Bijna toe aan laatste jaar van promotie traject 😬",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1156176789049397252",
            "createdAt" : "2019-07-30T12:16:41.926Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Ja, ben weer thuis en alles onder controle! Alles goed met jou? Arnoud-Jan",
            "mediaUrls" : [ ],
            "senderId" : "1869223770",
            "id" : "1156168857322688517",
            "createdAt" : "2019-07-30T11:45:10.858Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1869223770",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Jeetje ArnoudJan, wat een heftig bericht! Fijn dat het nu tijd is voor opluchting. Groet uit Den Haag, Jantsje",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1156167030317469700",
            "createdAt" : "2019-07-30T11:37:55.259Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "2875434232-1096413470554292225",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "2875434232",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hoi Dennie! Dankjewel :) Laat maar weten als je boekenkast verhuisd is, dank stuur ik er graag eentje op! Jij ook heel veel plezier in Essex en tot ziens inderdaad. Groetjes Jantsje",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1437373162161909765",
            "createdAt" : "2021-09-13T11:10:41.660Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Veel succes en plezier aan de UvA en ongetwijfeld tot ziens!",
            "mediaUrls" : [ ],
            "senderId" : "2875434232",
            "id" : "1437361216645648390",
            "createdAt" : "2021-09-13T10:23:13.610Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Je Twitter bio kan aangepast 😉",
            "mediaUrls" : [ ],
            "senderId" : "2875434232",
            "id" : "1437361076174213124",
            "createdAt" : "2021-09-13T10:22:40.124Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Gefeliciteerd Jantsje! Ik zal je geen boek vragen omdat ik nog midden in een verhuizing zit, maar heel cool dat je nu Dr Mol bent!",
            "mediaUrls" : [ ],
            "senderId" : "2875434232",
            "id" : "1437360981127143428",
            "createdAt" : "2021-09-13T10:22:17.454Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "3241897073-1096413470554292225",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [
              {
                "senderId" : "1096413470554292225",
                "reactionKey" : "funny",
                "eventId" : "1499755290572595208",
                "createdAt" : "2022-03-04T14:35:00.046Z"
              }
            ],
            "urls" : [ ],
            "text" : "which in the UK means the whole degree...I forgot how to speak my own language!",
            "mediaUrls" : [ ],
            "senderId" : "3241897073",
            "id" : "1499751334781796357",
            "createdAt" : "2022-03-04T14:19:16.933Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "because I told them I have designed pleanty of courses",
            "mediaUrls" : [ ],
            "senderId" : "3241897073",
            "id" : "1499751265810661386",
            "createdAt" : "2022-03-04T14:19:00.490Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Idiot here had to design two whole degree programmes",
            "mediaUrls" : [ ],
            "senderId" : "3241897073",
            "id" : "1499751195245744141",
            "createdAt" : "2022-03-04T14:18:43.668Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Should be careful of that!",
            "mediaUrls" : [ ],
            "senderId" : "3241897073",
            "id" : "1499751133467787268",
            "createdAt" : "2022-03-04T14:18:28.939Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [
              {
                "senderId" : "1096413470554292225",
                "reactionKey" : "like",
                "eventId" : "1499755239041388545",
                "createdAt" : "2022-03-04T14:34:47.760Z"
              }
            ],
            "urls" : [ ],
            "text" : "I hope the same, I have at least one PhD student starting in October I hope",
            "mediaUrls" : [ ],
            "senderId" : "3241897073",
            "id" : "1499751094800502790",
            "createdAt" : "2022-03-04T14:18:19.716Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "2 years probation, and then a open ended contract",
            "mediaUrls" : [ ],
            "senderId" : "3241897073",
            "id" : "1499751024919261188",
            "createdAt" : "2022-03-04T14:18:03.065Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "3241897073",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "what kind of contract do you have?",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1499750886557499399",
            "createdAt" : "2022-03-04T14:17:30.080Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "3241897073",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I managed to get a course on my own (climate  change economics haha, teaching macro)",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1499750839354855442",
            "createdAt" : "2022-03-04T14:17:18.815Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "3241897073",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I guess I have to find some grant money so they cannot get rid of me",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1499750787790082055",
            "createdAt" : "2022-03-04T14:17:06.520Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "3241897073",
            "reactions" : [
              {
                "senderId" : "3241897073",
                "reactionKey" : "funny",
                "eventId" : "1499750922938953735",
                "createdAt" : "2022-03-04T14:17:38.724Z"
              }
            ],
            "urls" : [ ],
            "text" : "ah yes I hope so too, thats my plan :)",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1499750743267495952",
            "createdAt" : "2022-03-04T14:16:55.902Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I hope they want to keep you after its done!",
            "mediaUrls" : [ ],
            "senderId" : "3241897073",
            "id" : "1499750672417398794",
            "createdAt" : "2022-03-04T14:16:39.013Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "So that was like what I had in Potsdam then",
            "mediaUrls" : [ ],
            "senderId" : "3241897073",
            "id" : "1499750634333130757",
            "createdAt" : "2022-03-04T14:16:29.942Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "maybe we have the same programme then :D",
            "mediaUrls" : [ ],
            "senderId" : "3241897073",
            "id" : "1499750599780442118",
            "createdAt" : "2022-03-04T14:16:21.697Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "3241897073",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I have a 4 year contract, first year is over now",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1499750425125343236",
            "createdAt" : "2022-03-04T14:15:40.056Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "3241897073",
            "reactions" : [
              {
                "senderId" : "3241897073",
                "reactionKey" : "funny",
                "eventId" : "1499750549977190400",
                "createdAt" : "2022-03-04T14:16:09.803Z"
              }
            ],
            "urls" : [ ],
            "text" : "oh yes mine is until July but i have more time to finish my \"portfolio\"",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1499750393122897930",
            "createdAt" : "2022-03-04T14:15:32.430Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "3241897073",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "so much talking about just normal things",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1499750294372204553",
            "createdAt" : "2022-03-04T14:15:08.879Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "haha, at least your one ends soon, mine is 2 years long",
            "mediaUrls" : [ ],
            "senderId" : "3241897073",
            "id" : "1499750272545009674",
            "createdAt" : "2022-03-04T14:15:03.688Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "How long is your post-doc for?",
            "mediaUrls" : [ ],
            "senderId" : "3241897073",
            "id" : "1499750176520654861",
            "createdAt" : "2022-03-04T14:14:40.778Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "3241897073",
            "reactions" : [
              {
                "senderId" : "3241897073",
                "reactionKey" : "like",
                "eventId" : "1499750188625412097",
                "createdAt" : "2022-03-04T14:14:43.646Z"
              }
            ],
            "urls" : [ ],
            "text" : "i'm at lecture 3/12 and bored as fuck",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1499750153137405960",
            "createdAt" : "2022-03-04T14:14:35.209Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "3241897073",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "yes I have the same",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1499750125262057479",
            "createdAt" : "2022-03-04T14:14:28.578Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "it is awful, but required to keep my job!",
            "mediaUrls" : [ ],
            "senderId" : "3241897073",
            "id" : "1499750094236753928",
            "createdAt" : "2022-03-04T14:14:21.161Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Oh I have to go one of them as well",
            "mediaUrls" : [ ],
            "senderId" : "3241897073",
            "id" : "1499750054810337289",
            "createdAt" : "2022-03-04T14:14:11.765Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "3241897073",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "but apart from that postdoc life is good :)",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1499749933670453253",
            "createdAt" : "2022-03-04T14:13:42.888Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "3241897073",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "i'm trying to survive a BKO course (you know the teaching qual thing)",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1499749895959465997",
            "createdAt" : "2022-03-04T14:13:33.904Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "3241897073",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "my goodness",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1499749855199207441",
            "createdAt" : "2022-03-04T14:13:24.177Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "though I just got 60 essays to mark...so there is that",
            "mediaUrls" : [ ],
            "senderId" : "3241897073",
            "id" : "1499749790363668488",
            "createdAt" : "2022-03-04T14:13:08.717Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "It is busy AF, I am always just waiting for the term to end to do actual stuff",
            "mediaUrls" : [ ],
            "senderId" : "3241897073",
            "id" : "1499749729542021129",
            "createdAt" : "2022-03-04T14:12:54.213Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I lived in the NL without a bike, I am stubbon enough to make the world fit me",
            "mediaUrls" : [ ],
            "senderId" : "3241897073",
            "id" : "1499749647702704139",
            "createdAt" : "2022-03-04T14:12:34.699Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "3241897073",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Can you survive without a bike?",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1499749487081889804",
            "createdAt" : "2022-03-04T14:11:56.405Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "3241897073",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "How is life in the UK nowadays?",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1499749449576456202",
            "createdAt" : "2022-03-04T14:11:47.476Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Also, how is the UvA treating you?",
            "mediaUrls" : [ ],
            "senderId" : "3241897073",
            "id" : "1499749318407995402",
            "createdAt" : "2022-03-04T14:11:16.193Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "please tell me afterwards?",
            "mediaUrls" : [ ],
            "senderId" : "3241897073",
            "id" : "1499749279644139539",
            "createdAt" : "2022-03-04T14:11:06.948Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Did you cut it before first using the picture or afterwards",
            "mediaUrls" : [ ],
            "senderId" : "3241897073",
            "id" : "1499749230658957316",
            "createdAt" : "2022-03-04T14:10:55.271Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "3241897073",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "but I had to cut the VU logo off because now i'm at UvA..",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1499749147242553358",
            "createdAt" : "2022-03-04T14:10:35.389Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "3241897073",
            "reactions" : [
              {
                "senderId" : "3241897073",
                "reactionKey" : "agree",
                "eventId" : "1499749150283476997",
                "createdAt" : "2022-03-04T14:10:36.086Z"
              }
            ],
            "urls" : [ ],
            "text" : "I got a new photo from the PhD defense so I'm using that now",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1499749095916908549",
            "createdAt" : "2022-03-04T14:10:23.143Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "3241897073",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "haha nice!",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1499749044909916169",
            "createdAt" : "2022-03-04T14:10:10.994Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Also, smart choice!",
            "mediaUrls" : [ ],
            "senderId" : "3241897073",
            "id" : "1499749044733763592",
            "createdAt" : "2022-03-04T14:10:10.948Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "it honestly never consider to pt a photo in there...I hate photos of my self, I am still using my photo from 2013 when I first joined the IVM",
            "mediaUrls" : [ ],
            "senderId" : "3241897073",
            "id" : "1499748990757355524",
            "createdAt" : "2022-03-04T14:09:58.094Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "3241897073",
            "reactions" : [
              {
                "senderId" : "3241897073",
                "reactionKey" : "like",
                "eventId" : "1499749003478638594",
                "createdAt" : "2022-03-04T14:10:01.087Z"
              }
            ],
            "urls" : [ ],
            "text" : "sometimes I use it as positive discimination in my advantage though :P",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1499748868627517444",
            "createdAt" : "2022-03-04T14:09:28.953Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I can see how that would work",
            "mediaUrls" : [ ],
            "senderId" : "3241897073",
            "id" : "1499748808678379537",
            "createdAt" : "2022-03-04T14:09:14.665Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "hahah, fair enoguh!",
            "mediaUrls" : [ ],
            "senderId" : "3241897073",
            "id" : "1499748759605067782",
            "createdAt" : "2022-03-04T14:09:02.962Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "3241897073",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "and I didn't want to put pronoun stuff in the bio ;-) so I figured the photo should solve it",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1499748715380232201",
            "createdAt" : "2022-03-04T14:08:52.416Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "3241897073",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "hi paul! I have my photo on my CV because many people think that I'm a guy, as they have never seen my first name before..",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1499748528041644042",
            "createdAt" : "2022-03-04T14:08:07.755Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "3241897073",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/9TaGoR0fxY",
                "expanded" : "https://twitter.com/i/stickers/image/10001",
                "display" : "twitter.com/i/stickers/ima…"
              }
            ],
            "text" : " https://t.co/9TaGoR0fxY",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1117703224222523396",
            "createdAt" : "2019-04-15T08:16:29.282Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "haha, thanks! I am good overall. Though, I do like the idea of Page Nerds",
            "mediaUrls" : [ ],
            "senderId" : "3241897073",
            "id" : "1117691924356456452",
            "createdAt" : "2019-04-15T07:31:35.171Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "3241897073",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I’m good thanks! I hope you are too",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1117690408996343812",
            "createdAt" : "2019-04-15T07:25:33.879Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "3241897073",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Nrs",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1117690336179040261",
            "createdAt" : "2019-04-15T07:25:16.519Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "3241897073",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Not many changes.. mostly page nerd",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1117690316910485509",
            "createdAt" : "2019-04-15T07:25:11.923Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "3241897073",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I think we used version three but I ordered the latest version last year",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1117690233984778244",
            "createdAt" : "2019-04-15T07:24:52.155Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "3241897073",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/iukO3LuktX",
                "expanded" : "https://twitter.com/messages/media/1117690100207575044",
                "display" : "pic.twitter.com/iukO3LuktX"
              }
            ],
            "text" : "This one? https://t.co/iukO3LuktX",
            "mediaUrls" : [
              "https://ton.twitter.com/dm/1117690100207575044/1117690013473546240/apscp7uG.jpg"
            ],
            "senderId" : "1096413470554292225",
            "id" : "1117690100207575044",
            "createdAt" : "2019-04-15T07:24:20.577Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "3241897073",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hi!",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1117689862914826245",
            "createdAt" : "2019-04-15T07:23:23.681Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "p.s. also hope you are good!",
            "mediaUrls" : [ ],
            "senderId" : "3241897073",
            "id" : "1117679394967961604",
            "createdAt" : "2019-04-15T06:41:47.932Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hi di hi! I have a quick question for you. When I left IVM in a rush, I left behind the Environmental Economic textbook that we used for the class. Do you remember its name? If I know that I can ask the publisher to send me a free copy. Thanks!",
            "mediaUrls" : [ ],
            "senderId" : "3241897073",
            "id" : "1117679342555992068",
            "createdAt" : "2019-04-15T06:41:35.446Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "3252191259-1096413470554292225",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "sounds great! enjoy the conference and the copenhagen (and the food in copenhagen in particular🤓)",
            "mediaUrls" : [ ],
            "senderId" : "3252191259",
            "id" : "1550020704002777092",
            "createdAt" : "2022-07-21T07:31:48.510Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "3252191259",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I'm currently at the social dilemmas conference in copenhagen, will check also the climate change session tomororw",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1550020244302925829",
            "createdAt" : "2022-07-21T07:29:58.914Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "3252191259",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "m",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1550020172957843463",
            "createdAt" : "2022-07-21T07:29:41.894Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "3252191259",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "oh cool! I",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1550020172345491460",
            "createdAt" : "2022-07-21T07:29:41.752Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "maybe this is interesting and we can have some ideas from here (bec we also talked about whether how wenare presenting info change people’s mind)",
            "mediaUrls" : [ ],
            "senderId" : "3252191259",
            "id" : "1550016467478904836",
            "createdAt" : "2022-07-21T07:14:58.454Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/TRleCKcNRA",
                "expanded" : "https://twitter.com/S_Stantcheva/status/1549744980243222529",
                "display" : "twitter.com/S_Stantcheva/s…"
              }
            ],
            "text" : "https://t.co/TRleCKcNRA",
            "mediaUrls" : [ ],
            "senderId" : "3252191259",
            "id" : "1550016284615753735",
            "createdAt" : "2022-07-21T07:14:14.860Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "3559972936-1096413470554292225",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "3559972936",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hi Ellen, Jantsje here from the data viz tweet :) If you have any particular papers that good be reading material for my students, that would be really helpful. It is a course in Climate Change Economics, but I'll do the tutorials about modelling and data visualization. Probably email works easiest: j.m.mol@uva.nl Best, Jantsje",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1441292889229721607",
            "createdAt" : "2021-09-24T06:46:17.418Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "764097710882455552-1096413470554292225",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Great plan. Hope you have a good holiday",
            "mediaUrls" : [ ],
            "senderId" : "764097710882455552",
            "id" : "1692939579253223635",
            "createdAt" : "2023-08-19T16:40:23.679Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "764097710882455552",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hi Tony! Sounds good! What about end of September? I currently have some grading and grant proposal deadlines, as well as an upcoming holiday :) but I could start right after that. The Kunreuther &amp; Slovic blog serves well as inspiration. Shall we get in touch mid-September? I would prefer email (j.m.mol@uva.nl) since I am not always checking this platform. Best, Jantsje",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1691717213802180938",
            "createdAt" : "2023-08-16T07:43:09.055Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/fnuDp5ggBx",
                "expanded" : "https://bppblog.com/2020/04/29/a-lesson-for-climate-change-from-the-coronavirus-pandemic-act-now/",
                "display" : "bppblog.com/2020/04/29/a-l…"
              }
            ],
            "text" : "You’re welcome to name your own deadline and I’ll try to remember to nudge you nearer the time. It would be a nice piece to have, but at a time that works best for you. Our blogs are for a wide readership, so shouldn’t involve great effort, but be fairly conversational in style.  You might be interested in this Kunreuther &amp; Slovic blog on public understanding of exponential change https://t.co/fnuDp5ggBx",
            "mediaUrls" : [ ],
            "senderId" : "764097710882455552",
            "id" : "1691173914527858863",
            "createdAt" : "2023-08-14T19:44:16.466Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "764097710882455552",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hi Tony! Apologies for my late reply, it is a little crazy with thesis grading deadlines here. Yes it is sad we have to continue our research without and lives without Howard. I would be happy to write something for the BPP blog, but I am not sure how soon I could deliver this... Do you have a deadline in mind? Best, Jantsje",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1691097202889027972",
            "createdAt" : "2023-08-14T14:39:26.950Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "In light of the sad loss of Howard Kunreuther, I wondered if  you might agree to write a short blog for us perhaps following up on the BPP article with Howard Kunreuther on norm nudging on flood insurance that you worked on, or some other aspect of your work that followed this? Tony (LSE, BPP Blog editor)",
            "mediaUrls" : [ ],
            "senderId" : "764097710882455552",
            "id" : "1688485726646644740",
            "createdAt" : "2023-08-07T09:42:22.470Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "56710503-1096413470554292225",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "56710503",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Good luck with the book writing!!",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1469380214807486476",
            "createdAt" : "2021-12-10T18:55:17.658Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Awesome, thank you Jantsje!",
            "mediaUrls" : [ ],
            "senderId" : "56710503",
            "id" : "1469373359125315592",
            "createdAt" : "2021-12-10T18:28:03.140Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "56710503",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/Q5otgcGdtL",
                "expanded" : "https://www.jantsje.nl/publication/mol-2022/",
                "display" : "jantsje.nl/publication/mo…"
              }
            ],
            "text" : "Hi! Jantsje here! I submitted my final chapter as registered report at Nature Human Behavior but it was rejected. Submitted next at JDM and the editor was interested so he “reviewed” that version and requested a prereg at OSF. It was a VR paper with a short window of opportunity (with COVID and lab time and the end of the phd) so I had to collect data almost straightaway. Two revisions later it was accepted, so it will be in the January issue 🙂 https://t.co/Q5otgcGdtL let me know if you have more questions! Jantsje",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1469373158524338203",
            "createdAt" : "2021-12-10T18:27:15.492Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "793040829824831488-1096413470554292225",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "793040829824831488",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/BswWME51b7",
                "expanded" : "https://twitter.com/NL_Wetenschap/status/1127955733406998529",
                "display" : "twitter.com/NL_Wetenschap/…"
              }
            ],
            "text" : "https://t.co/BswWME51b7",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1127961445461831685",
            "createdAt" : "2019-05-13T15:38:59.825Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "864470119745015808-1096413470554292225",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "864470119745015808",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hoi Marten! Ja klinkt goed, een uur of twee misschien? Groet Jantsje",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1363918092515033094",
            "createdAt" : "2021-02-22T18:26:28.310Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "867914691783340032-1096413470554292225",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "867914691783340032",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/aiNGO2fRQw",
                "expanded" : "https://www.youtube.com/channel/UCnN8TaVYe83472ewz9CH9HA",
                "display" : "youtube.com/channel/UCnN8T…"
              }
            ],
            "text" : "Hey Eugen, thanks for the invite! I'm currently a bit busy because my defense will take place next week. Sept 10th 1.45pm Amsterdam time, should be early morning in Philadelphia.. If you want you can watch the livestream: https://t.co/aiNGO2fRQw \n\nCurrently no new projects on social norms. I have the one that is published in BPP. I have a new one with Shaul coming up with a government partner, but I cannot communicate about that one yet. \nIf I have something later this year, I'll let you know!",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1432596739043864581",
            "createdAt" : "2021-08-31T06:50:53.652Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hey Jantsje, do you currently have any ongoing work on social norms and behavior change? We are looking for submissions (5-minute pre-recorded videos) from erst career researchers to feature them ahead of our main speakers in our NoBeC talks speaker series. This gives them great exposure (usually 75-100 participants) to an interdisciplinary crowd. \n\nHappy to provide more information if you’re interested!",
            "mediaUrls" : [ ],
            "senderId" : "867914691783340032",
            "id" : "1432323322398887940",
            "createdAt" : "2021-08-30T12:44:26.044Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Sure thing!",
            "mediaUrls" : [ ],
            "senderId" : "867914691783340032",
            "id" : "1390376331985227782",
            "createdAt" : "2021-05-06T18:42:04.173Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "867914691783340032",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Your constructive reviews really helped 🙂 so I’m returning the congratulations! 🎉 (not sure what the policy is on thanking reviewers in public, but just so you know I really appreciated that!)",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1390355915560345611",
            "createdAt" : "2021-05-06T17:20:56.532Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "867914691783340032",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Yes, both work. Thanks a million and good luck with the paper!",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1149201055214919684",
            "createdAt" : "2019-07-11T06:17:37.380Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/808LE06q6H",
                "expanded" : "http://aspredicted.org/blind.php?x=er484s",
                "display" : "aspredicted.org/blind.php?x=er…"
              },
              {
                "url" : "https://t.co/o5JKVPmD3E",
                "expanded" : "http://aspredicted.org/blind.php?x=6n9kg8",
                "display" : "aspredicted.org/blind.php?x=6n…"
              }
            ],
            "text" : "I was able to retrieve the URLs for the two pre-registrations from the website, let me know if they work for you:\nhttps://t.co/808LE06q6H\nhttps://t.co/o5JKVPmD3E",
            "mediaUrls" : [ ],
            "senderId" : "867914691783340032",
            "id" : "1149079995702231044",
            "createdAt" : "2019-07-10T22:16:34.560Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "So weird and useless lol it’s run by our Wharton colleagues, I should let them know sometime",
            "mediaUrls" : [ ],
            "senderId" : "867914691783340032",
            "id" : "1148968023203766276",
            "createdAt" : "2019-07-10T14:51:38.216Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "867914691783340032",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/JnOR1sqiLg",
                "expanded" : "https://aspredicted.org/messages/terms.php",
                "display" : "aspredicted.org/messages/terms…"
              }
            ],
            "text" : "Yes, I thought so too at first.. But more info here confirms that there is no search engine yet: https://t.co/JnOR1sqiLg .Thanks!",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1148966180461432837",
            "createdAt" : "2019-07-10T14:44:18.897Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hey, absolutely. I’ll send you the link as soon as I get home. I thought one would be able to find it through the aspredicted website using the name/number we provide in the footnote. But good to know, maybe we should replace it with direct links",
            "mediaUrls" : [ ],
            "senderId" : "867914691783340032",
            "id" : "1148935743483580420",
            "createdAt" : "2019-07-10T12:43:22.153Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "867914691783340032",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/QflwOsKYr1",
                "expanded" : "https://ssrn.com/abstract=3416399",
                "display" : "ssrn.com/abstract=34163…"
              }
            ],
            "text" : "Hi! I hope you are still enjoying your travels! I just read your latest article https://t.co/QflwOsKYr1 and I think it is really cool. Could you provide me with the preregistration URL? In the paper you mention the number, but as of yet, aspredicted is not crawled by the search engines, so I cannot find the preregistration documents. I'm working on a preregistration at the moment and it would be nice to read some relevant examples. Thanks a lot!  Jantsje",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1148934256279859204",
            "createdAt" : "2019-07-10T12:37:27.593Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "867914691783340032",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Sounds good, I’ll send you an email by then. Enjoy the Europe travels!",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1141946930169286660",
            "createdAt" : "2019-06-21T05:52:19.193Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Yeah it’s all on same campus and our building is right next to the Wharton buildings. We do have a speaker series Friday. Feel feee to hit me up via email closer to your arrival and I can send you the list of speakers that might overlap with your stay",
            "mediaUrls" : [ ],
            "senderId" : "867914691783340032",
            "id" : "1141944122531622916",
            "createdAt" : "2019-06-21T05:41:09.798Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "867914691783340032",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hi Eugen! Thanks for the quick response, I will reach out to the Nobec email. I am definitely planning to attend. By the way, if you have any other seminars at the Behavioral Ethics Lab in sept oct I would be happy to meet fellow behavioral economists 🙃 it’s not that far from Wharton right? Enjoy your travels and see you there! Jantsje",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1141941253648633860",
            "createdAt" : "2019-06-21T05:29:45.823Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hi Jantsje! I’m currently traveling and not handing the applications, our administrative assistant is. As far as I recall there was a main list and a waiting list, hence chances are you’re on the latter if you haven’t heard back yet. Feel free to reach out to the Nobec email and Ann will get back to you shortly. In any case, you’re more than welcome to attend even if the talk didn’t make the cut. The workshop benefits from both presenters and attendees :)",
            "mediaUrls" : [ ],
            "senderId" : "867914691783340032",
            "id" : "1141827431835348996",
            "createdAt" : "2019-06-20T21:57:28.588Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "867914691783340032",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hi Eugen! I heard some Twitter rumours that the emails for NoBeC2019 were out, but I did not see anything yet 🤷‍♀️ I planned a research visit to the Risk Center of the Wharton School at UPenn this fall I would be able to attend/present (no coincidence 😉) Could you give me an update? Thanks! Jantsje, Institute for Environmental Studies, VU Amsterdam",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1141780259383271428",
            "createdAt" : "2019-06-20T18:50:01.982Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "902579331599396864-1096413470554292225",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "902579331599396864",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Yeah I survived.. let’s see what happens now 😬 tomorrow I won’t be there cause no interviews and exams waiting to be graded..",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1207355125515337732",
            "createdAt" : "2019-12-18T17:41:08.200Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "902579331599396864",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I hope you are doing well 🙃",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1207348805403914245",
            "createdAt" : "2019-12-18T17:16:01.369Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "902579331599396864",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Simone! I think I saw you today at the econjobmarket.. but I was a bit nervous because it was 10 mins before my interview..",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1207348755588100100",
            "createdAt" : "2019-12-18T17:15:49.495Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "976436958363873280-1096413470554292225",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I think it's just the result of last year's market. Too many people are unhappy. You see many quit academia or switch jobs...",
            "mediaUrls" : [ ],
            "senderId" : "976436958363873280",
            "id" : "1508404594333859853",
            "createdAt" : "2022-03-28T11:24:14.776Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "not this time :D",
            "mediaUrls" : [ ],
            "senderId" : "976436958363873280",
            "id" : "1508404489778302983",
            "createdAt" : "2022-03-28T11:23:49.843Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "976436958363873280",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "oh I thought maybe you sent something there!",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1508401229122134025",
            "createdAt" : "2022-03-28T11:10:52.444Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "hihi ;) I swear I am not running that account!",
            "mediaUrls" : [ ],
            "senderId" : "976436958363873280",
            "id" : "1508385402163507209",
            "createdAt" : "2022-03-28T10:07:59.011Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "976436958363873280",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "awww",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1508382320499249158",
            "createdAt" : "2022-03-28T09:55:44.279Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/uz0BbwW6NG",
                "expanded" : "https://twitter.com/anonymousprofs/status/1508272186582310912",
                "display" : "twitter.com/anonymousprofs…"
              }
            ],
            "text" : "https://t.co/uz0BbwW6NG",
            "mediaUrls" : [ ],
            "senderId" : "976436958363873280",
            "id" : "1508331647262941188",
            "createdAt" : "2022-03-28T06:34:22.852Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "976436958363873280",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Woop woop",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1498788157948579846",
            "createdAt" : "2022-03-01T22:31:57.677Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I think we will for sure",
            "mediaUrls" : [ ],
            "senderId" : "976436958363873280",
            "id" : "1498788089438904327",
            "createdAt" : "2022-03-01T22:31:41.343Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "976436958363873280",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Sounds good to me! Let’s see maybe we have data before may first",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1498787978885447686",
            "createdAt" : "2022-03-01T22:31:14.987Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "thank youuu",
            "mediaUrls" : [ ],
            "senderId" : "976436958363873280",
            "id" : "1498786684510556168",
            "createdAt" : "2022-03-01T22:26:06.387Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "would we submit?",
            "mediaUrls" : [ ],
            "senderId" : "976436958363873280",
            "id" : "1498786643582636040",
            "createdAt" : "2022-03-01T22:25:56.632Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "976436958363873280",
            "reactions" : [
              {
                "senderId" : "976436958363873280",
                "reactionKey" : "like",
                "eventId" : "1498786598963625985",
                "createdAt" : "2022-03-01T22:25:45.973Z"
              }
            ],
            "urls" : [ ],
            "text" : "and thanks for the amazing work of today! I had some meetings but I’ll have a look tomorrow! (And we zoom 😊)",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1498785476471316484",
            "createdAt" : "2022-03-01T22:21:18.365Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "976436958363873280",
            "reactions" : [
              {
                "senderId" : "976436958363873280",
                "reactionKey" : "like",
                "eventId" : "1498786585873162241",
                "createdAt" : "2022-03-01T22:25:42.847Z"
              }
            ],
            "urls" : [ ],
            "text" : "Cool! So many women on the committee",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1498785346322153477",
            "createdAt" : "2022-03-01T22:20:47.334Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/Df22hT5FFh",
                "expanded" : "https://twitter.com/MarketDesignBot/status/1497240079496007680",
                "display" : "twitter.com/MarketDesignBo…"
              }
            ],
            "text" : "Thoughts? https://t.co/Df22hT5FFh",
            "mediaUrls" : [ ],
            "senderId" : "976436958363873280",
            "id" : "1498775297365266439",
            "createdAt" : "2022-03-01T21:40:51.502Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/TwOtCTI0Jl",
                "expanded" : "https://twitter.com/solda_eco/status/1448197061673881601",
                "display" : "twitter.com/solda_eco/stat…"
              }
            ],
            "text" : "relevant? https://t.co/TwOtCTI0Jl",
            "mediaUrls" : [ ],
            "senderId" : "976436958363873280",
            "id" : "1448574442163015687",
            "createdAt" : "2021-10-14T09:00:34.924Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "That sounds great, actually! We should do that!!!\n\nThanks, today I should hear back, I am desperate for some good news finally",
            "mediaUrls" : [ ],
            "senderId" : "976436958363873280",
            "id" : "1353639622283243524",
            "createdAt" : "2021-01-25T09:43:30.044Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "976436958363873280",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I'll keep my fingers crossed for you!!",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1353629977514823684",
            "createdAt" : "2021-01-25T09:05:10.552Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "976436958363873280",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "ooo can we order ribs and have skype and have ribs together with the three of us?",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1353629938558119940",
            "createdAt" : "2021-01-25T09:05:01.263Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Eh, it's waiting time. Fingers crossed something works out eventually :)\nHugs back! Miss you, the lockdown is getting a little long, we need more ribs in our lives ;)",
            "mediaUrls" : [ ],
            "senderId" : "976436958363873280",
            "id" : "1353603811865206788",
            "createdAt" : "2021-01-25T07:21:12.190Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "976436958363873280",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "hugs hugs",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1353599456910958596",
            "createdAt" : "2021-01-25T07:03:53.874Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "976436958363873280",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "how is the job search",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1353599385679093764",
            "createdAt" : "2021-01-25T07:03:36.890Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "976436958363873280",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "oh cool, sounds interesting!",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1353599360169291788",
            "createdAt" : "2021-01-25T07:03:30.808Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/O8ufKYWaJe",
                "expanded" : "https://twitter.com/stroebel_econ/status/1352740498637811714",
                "display" : "twitter.com/stroebel_econ/…"
              }
            ],
            "text" : "https://t.co/O8ufKYWaJe",
            "mediaUrls" : [ ],
            "senderId" : "976436958363873280",
            "id" : "1352760503366520836",
            "createdAt" : "2021-01-22T23:30:11.781Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "It is not that expensive,  so good luck😉 and maybe see you there!",
            "mediaUrls" : [ ],
            "senderId" : "976436958363873280",
            "id" : "1232778965946904581",
            "createdAt" : "2020-02-26T21:26:24.117Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "976436958363873280",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Thanks!",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1232691196130099204",
            "createdAt" : "2020-02-26T15:37:38.138Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "976436958363873280",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I’ll keep the deadline in mind!",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1232691181580115973",
            "createdAt" : "2020-02-26T15:37:34.685Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "976436958363873280",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "But if I have budget left I’ll spend it on PCBS for sure!!",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1232691136562651140",
            "createdAt" : "2020-02-26T15:37:23.953Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "976436958363873280",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Ooo that is so cool! I would love to go but Wouter really wants me to go to EAERE so if that works out I already spent my conference budget..",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1232690892089307140",
            "createdAt" : "2020-02-26T15:36:25.667Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hey, at the PCBS they are going  to do a feature of some VR technology. Im sure they would be very open to your work if you have stuff to submit",
            "mediaUrls" : [ ],
            "senderId" : "976436958363873280",
            "id" : "1232669003912564740",
            "createdAt" : "2020-02-26T14:09:27.231Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "992348051519008768-1096413470554292225",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Top, tot zo!",
            "mediaUrls" : [ ],
            "senderId" : "992348051519008768",
            "id" : "1501534480707854344",
            "createdAt" : "2022-03-09T12:24:52.048Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "992348051519008768",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Oh leuk! Ik plan even m’n route en ik wilde eerst langs noord aa, dus ik denk over een uur ongeveer",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1501534314705702916",
            "createdAt" : "2022-03-09T12:24:12.472Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Adam Pijnackerstraat 8",
            "mediaUrls" : [ ],
            "senderId" : "992348051519008768",
            "id" : "1501534032726736909",
            "createdAt" : "2022-03-09T12:23:05.243Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Ja ik ben thuis! Leuk als je even langskomt!",
            "mediaUrls" : [ ],
            "senderId" : "992348051519008768",
            "id" : "1501533958156304390",
            "createdAt" : "2022-03-09T12:22:47.465Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "992348051519008768",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "de sokken zijn eindelijk bezorgd 🙂",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1501533658175393798",
            "createdAt" : "2022-03-09T12:21:35.943Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "992348051519008768",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hee Kees! Ik ga zo een rondje fietsen, ben je toevallig thuis?",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1501533598515666948",
            "createdAt" : "2022-03-09T12:21:21.719Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "1083319259403612160-1096413470554292225",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1083319259403612160",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "2020global",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1304316762150842372",
            "createdAt" : "2020-09-11T07:12:03.810Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1083319259403612160",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Ja natuurlijk!",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1304316755876216836",
            "createdAt" : "2020-09-11T07:12:02.317Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1083319259403612160",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/NhdvsYWUEC",
                "expanded" : "https://ivm.labs.vu.nl/room/demo_debuggers/",
                "display" : "ivm.labs.vu.nl/room/demo_debu…"
              }
            ],
            "text" : "Dat zou super zijn! Deadline is maandagochtend 8 uur. Dit is de link https://t.co/NhdvsYWUEC en als participant-label kan je “twitter1” gebruiken. Dit is de laatste check op typfouten en JavaScript errors, dus als er foutmeldingen komen hoor ik het graag!",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1159565679743381510",
            "createdAt" : "2019-08-08T20:42:56.495Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "1096413470554292225-1105150927168782337",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1105150927168782337",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I think I got it!",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1455485694349037576",
            "createdAt" : "2021-11-02T10:43:25.832Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1105150927168782337",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "oh interesting, let me check!",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1455485174502805515",
            "createdAt" : "2021-11-02T10:41:21.893Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1105150927168782337",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "great!",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1455485015056396293",
            "createdAt" : "2021-11-02T10:40:43.872Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1105150927168782337",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "you know where to find the livestream?",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1455484165940518925",
            "createdAt" : "2021-11-02T10:37:21.436Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1105150927168782337",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "my paypal is at jantsje@gmail.com",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1455484102312857607",
            "createdAt" : "2021-11-02T10:37:06.261Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1105150927168782337",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "oh yes both are possible",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1455483986571104264",
            "createdAt" : "2021-11-02T10:36:38.664Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1105150927168782337",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/VndvLxEtU7",
                "expanded" : "https://tikkie.me/pay/1rss92gjnkg919rk09ri",
                "display" : "tikkie.me/pay/1rss92gjnk…"
              }
            ],
            "text" : "https://t.co/VndvLxEtU7 here is a new link",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1455482345042100231",
            "createdAt" : "2021-11-02T10:30:07.330Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1105150927168782337",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "yes that is possible!",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1455482287827656709",
            "createdAt" : "2021-11-02T10:29:53.658Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "1096413470554292225-1159390271873986560",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Yes, that's right :)",
            "mediaUrls" : [ ],
            "senderId" : "1159390271873986560",
            "id" : "1392379939580747786",
            "createdAt" : "2021-05-12T07:23:41.451Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1159390271873986560",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "but all publicity is good publicity ;-)",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1392379483722862596",
            "createdAt" : "2021-05-12T07:21:52.760Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1159390271873986560",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "very interesting indeed!",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1392379441519767558",
            "createdAt" : "2021-05-12T07:21:42.697Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/uUcBbbt4Bi",
                "expanded" : "https://twitter.com/BPPjournal/status/1392099134853861376",
                "display" : "twitter.com/BPPjournal/sta…"
              }
            ],
            "text" : "Interesting choice of picture... Flooding...Diving? https://t.co/uUcBbbt4Bi",
            "mediaUrls" : [ ],
            "senderId" : "1159390271873986560",
            "id" : "1392370101161283590",
            "createdAt" : "2021-05-12T06:44:35.799Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1159390271873986560",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Oh yeah!",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1240894357827436550",
            "createdAt" : "2020-03-20T06:54:04.301Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/u4D8s9CHF8",
                "expanded" : "https://twitter.com/PMickwitz/status/1240595087442272256",
                "display" : "twitter.com/PMickwitz/stat…"
              }
            ],
            "text" : "Skype coffee breaks seem to work in Sweden ;) https://t.co/u4D8s9CHF8",
            "mediaUrls" : [ ],
            "senderId" : "1159390271873986560",
            "id" : "1240711216382779397",
            "createdAt" : "2020-03-19T18:46:20.009Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "1096413470554292225-1168227245338628096",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Thank you! And thanks for the compliment 😃. We always like it when other researchers find value in it!\n\nGood luck with the rest of your pubs and if you ever want a tweet retweeted, just tag us!",
            "mediaUrls" : [ ],
            "senderId" : "1168227245338628096",
            "id" : "1262356917529333765",
            "createdAt" : "2020-05-18T12:18:37.284Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1168227245338628096",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "That's a nice tool! I added my ratings :)",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1262257229752909831",
            "createdAt" : "2020-05-18T05:42:29.869Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/23DCdBp3g3",
                "expanded" : "https://phdvoice.org/journalrater/",
                "display" : "phdvoice.org/journalrater/"
              }
            ],
            "text" : "Sorry to hear about your paper Jantsje. But your response to it is great 😃.\n\nWe have a freely accessible online database for researchers to rate their experiences of journals they’ve submitted to.\n\nIt’s also there for every researcher to use to help them pick journals with good reviewers, and so on. (https://t.co/23DCdBp3g3)\n\nWould you be willing to add your experience with this journal?\n\nAlternatively, we could ask you just 7 questions which you could answer and we can put the ratings up for you?\n\nYou can remain completely anonymous!\n\nIf not, then that’s okay, we understand 😃",
            "mediaUrls" : [ ],
            "senderId" : "1168227245338628096",
            "id" : "1261602938205671428",
            "createdAt" : "2020-05-16T10:22:34.634Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "121372044-1096413470554292225",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hoi Jantsje, graag gedaan namens mijn collega :)!  ^BE",
            "mediaUrls" : [ ],
            "senderId" : "121372044",
            "id" : "1603727712983605252",
            "createdAt" : "2022-12-16T12:24:17.294Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hoi WJ, dat is heel fijn, bedankt! Ik heb de mails inderdaad ontvangen, goed dat je het zegt van die automaat. Groet Jantsje",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1603462279638425604",
            "createdAt" : "2022-12-15T18:49:33.048Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/gUwd8gXQs8",
                "expanded" : "https://bit.ly/2ZXA5il",
                "display" : "bit.ly/2ZXA5il"
              }
            ],
            "text" : "Hoi Jantsje,\n\nExcuses voor de late reactie, het is nog steeds druk op dit kanaal.\n\nIk heb de beëindiging bevestigd. Je zult nog een e-mail ontvangen. Lees deze goed door, omdat de opzegging bevestigd dient te worden bij de kaartautomaat. In de e-mail staat voor welke datum je dit dient te doen. Zodra de opzegging is bevestigd zal het teveel betaalde abonnementsgeld op het bij ons bekende rekeningnummer worden overgemaakt, binnen 30 dagen. \n\nMocht je nog andere vragen hebben dan weet je ons te vinden! Zou je voor mij via de volgende link een kort klanttevredenheidsonderzoek in willen/kunnen vullen? Op deze manier kunnen wij onze dienstverlening verbeteren. Alvast bedankt en ik wens je een fijne dag! https://t.co/gUwd8gXQs8.  ^WJ",
            "mediaUrls" : [ ],
            "senderId" : "121372044",
            "id" : "1603438589597175812",
            "createdAt" : "2022-12-15T17:15:24.917Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Heel graag!",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1603096563580018692",
            "createdAt" : "2022-12-14T18:36:19.554Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hey! Wij kunnen je inderdaad helpen. Ik kan in dit geval het product dan meteen per morgen voor je stoppen. Is dat goed? ^DB",
            "mediaUrls" : [ ],
            "senderId" : "121372044",
            "id" : "1603073849406406663",
            "createdAt" : "2022-12-14T17:06:04.076Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Ik ben benieuwd of jullie kunnen helpen :)",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1603049986106818564",
            "createdAt" : "2022-12-14T15:31:14.610Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Het gaat om Amsterdam Zuid Zuidplein",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1602930592911327241",
            "createdAt" : "2022-12-14T07:36:49.039Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "J.M.Mol",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1602929964927557638",
            "createdAt" : "2022-12-14T07:34:19.318Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "geb datum 17-08-1990",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1602929842718113797",
            "createdAt" : "2022-12-14T07:33:50.181Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "jantsje@gmail.com",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1602929813953576964",
            "createdAt" : "2022-12-14T07:33:43.322Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "ov chipkaart nr 3528 0400 9853 0960",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1602929751240441861",
            "createdAt" : "2022-12-14T07:33:28.373Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Bedankt voor je bericht. Momenteel is het druk waardoor het langer kan duren voordat je een reactie krijgt. Excuses voor het ongemak. Wij proberen je zo spoedig mogelijk te helpen.\n\nHeb je een vraag over je abonnement of het wijzigen van je gegevens? Stuur dan alvast je voorletter(s), achternaam, postcode, huisnummer, e-mailadres en geboortedatum. Dan gaan we z.s.m. voor je aan de slag!",
            "mediaUrls" : [ ],
            "senderId" : "121372044",
            "id" : "1602929583858356228",
            "createdAt" : "2022-12-14T07:32:48.479Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Jantsje Mol, 2274 GS nr 7",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1602929564119977989",
            "createdAt" : "2022-12-14T07:32:43.762Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hallo NS! Ik heb een vraagje over mijn NS fietsenstalling abonnement op Amsterdam Zuid. Dat is op 1 nov 2022 verlopen, ook volgens de medewerker daar. Dat kwam voor mij wel goed uit omdat ik inmiddels zwangerschapsverlof heb, dus mijn fiets staat een paar maanden in de stalling op werk. Nu zag ik dat het abonnementsgeld wel is afgeschreven, dus ik had iets moeten stopzetten. Maar ik heb de nieuwe sticker nooit opgehaald.. kunnen jullie mijn abonnement stopzetten?  Groet Jantsje",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1602929243419189254",
            "createdAt" : "2022-12-14T07:31:27.312Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Geen dank. Fijne avond, samen. :) ^NK",
            "mediaUrls" : [ ],
            "senderId" : "121372044",
            "id" : "1382732172583444486",
            "createdAt" : "2021-04-15T16:26:54.552Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Oké ik stuur het door, dank!",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1382731558671499272",
            "createdAt" : "2021-04-15T16:24:28.185Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/jPuNqqz7HH",
                "expanded" : "https://bit.ly/2xJS9zd",
                "display" : "bit.ly/2xJS9zd"
              }
            ],
            "text" : "Hoi,\n\nIk mag helaas via jouw Twitter-account geen andere mensen helpen vanwege de strenge privacywetgeving. Jouw vriend mag zelf contact opnemen met een van onze andere kanalen: https://t.co/jPuNqqz7HH.\n\nKom je zo verder? ^NK",
            "mediaUrls" : [ ],
            "senderId" : "121372044",
            "id" : "1382724636090232838",
            "createdAt" : "2021-04-15T15:56:57.716Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "als jullie zijn kaart ook willen resetten mocht je daar hetzelfde probleem zien? Hij reisde dus ook op 3 april hetzelfde traject",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1382724147428622345",
            "createdAt" : "2021-04-15T15:55:01.215Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "kaart nummer 3528 0434 3161 1893",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1382723968654831622",
            "createdAt" : "2021-04-15T15:54:18.580Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Stefan verdenius",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1382723825285095431",
            "createdAt" : "2021-04-15T15:53:44.403Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "ook Jacob Catsstraat 7 in Voorburg",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1382723805500600324",
            "createdAt" : "2021-04-15T15:53:39.683Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "22-08-1990 geboortedatum",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1382723755223482375",
            "createdAt" : "2021-04-15T15:53:27.696Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Oh ik was nog vergeten dat mijn vriend hetzelfde probleem had (hij heeft geen Twitter)",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1382723711300669453",
            "createdAt" : "2021-04-15T15:53:17.223Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Als je dan geen verdere vragen meer aan mij hebt wens ik jou namens mijzelf en mijn collega's een hele fijne dag verder! :) ^OC",
            "mediaUrls" : [ ],
            "senderId" : "121372044",
            "id" : "1382619167409512453",
            "createdAt" : "2021-04-15T08:57:52.015Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Oke dankjewel!",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1382617729086144516",
            "createdAt" : "2021-04-15T08:52:09.091Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/JOvp0C02uD",
                "expanded" : "https://bit.ly/3d28NLO",
                "display" : "bit.ly/3d28NLO"
              }
            ],
            "text" : "Ik ga er dan vanuit dat het helemaal goed zal gaan. Mocht het toch anders lopen, stuur mij dan even een berichtje want dan kan ik nogmaals een kijkje voor je nemen. Weet je voor nu zo voldoende van mij en mijn collega's? ^OC\n\nPS: Zou je nog een kort klanttevredenheidsonderzoek willen invullen over de dienstverlening via dit kanaal? Dat kan via deze link: https://t.co/JOvp0C02uD. Alvast bedankt voor de medewerking!",
            "mediaUrls" : [ ],
            "senderId" : "121372044",
            "id" : "1382617578665877518",
            "createdAt" : "2021-04-15T08:51:33.231Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Ja ik ben van plan om zondag met de trein te gaan",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1382616566311833605",
            "createdAt" : "2021-04-15T08:47:31.863Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hi, Jantsje. Vreemd, maar ik zie bij reisdatum 3 april ook een tweede klas reis staan. Ik ga jouw abonnement resetten en hoop het probleem daarmee op te lossen. Daar hoef jij verder niets voor te doen. Mocht je komend weekend van de trein gebruik maken, laat je mij dan even weten of alles goed is verlopen?  ^GV",
            "mediaUrls" : [ ],
            "senderId" : "121372044",
            "id" : "1382613703653261317",
            "createdAt" : "2021-04-15T08:36:09.352Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Oke iets meer dan een week later, maar kunnen jullie nogmaals checken hoe het zit?",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1382611016861765637",
            "createdAt" : "2021-04-15T08:25:28.774Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/WGXhUu7FCS",
                "expanded" : "https://bit.ly/2WL5yBR",
                "display" : "bit.ly/2WL5yBR"
              }
            ],
            "text" : "Dank je wel voor het begrip hierbij en helemaal top! Kan ik verder nog iets voor je doen? Of weet je voor nu dan voldoende? Als je geen vragen meer hebt wens ik je een fijne dag verder en alvast fijne Paasdagen! Wil je dan deze klanttevredenheidsenquête nog invullen: https://t.co/WGXhUu7FCS? Alvast bedankt! ^JV",
            "mediaUrls" : [ ],
            "senderId" : "121372044",
            "id" : "1378375714546855940",
            "createdAt" : "2021-04-03T15:55:54.034Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Yes ik stuur volgende week weer een berichtje!",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1378374286902169606",
            "createdAt" : "2021-04-03T15:50:13.635Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Ik zie dat deze reis van vandaag  nog niet volledig verwerkt is onder jouw gegevens, waardoor ik de klasse voor deze reis nog niet zie staan. Omdat het riesproduct NS Flex is kan dit tot 48 uur duren. Bij het contract zelf staat bij jouw NS Flex Weekend vrij wel eerste klasse. Wil je dan volgende week nog een keer contact opnemen hiervoor? Dan kijken we graag nog even naar de details van deze reis voor je. ^JV",
            "mediaUrls" : [ ],
            "senderId" : "121372044",
            "id" : "1378366519927832584",
            "createdAt" : "2021-04-03T15:19:21.851Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Steenwijk Den Haag centraal 13.46 vertrek",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1378364835696627717",
            "createdAt" : "2021-04-03T15:12:40.297Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Wat vreemd! Welke reis heb je precies gemaakt? ^MZ",
            "mediaUrls" : [ ],
            "senderId" : "121372044",
            "id" : "1378344413320130564",
            "createdAt" : "2021-04-03T13:51:31.221Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Ja ik heb het over vandaag. Toen ze mijn pas scande zag ze een tweede klas abonnement staan",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1378343184368070666",
            "createdAt" : "2021-04-03T13:46:38.218Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hoi Jantsje,\n\nDat is vreemd. Ik zie inderdaad een actief Weekend Vrij abonnement 1e klasse op jouw kaart staan sinds 02 maart 2021. Wat je verteld, gaat over vandaag toch? Doordeweeks reis je namelijk wel 2e klasse.^KH",
            "mediaUrls" : [ ],
            "senderId" : "121372044",
            "id" : "1378335616178515979",
            "createdAt" : "2021-04-03T13:16:33.816Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Nee ze was aardig en we mochten blijven zitten :) 2274GS 7 17.08-1990 Jantsje Maria Mol jantsje@gmail.com",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1378331955637407751",
            "createdAt" : "2021-04-03T13:02:01.082Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hoi,\n\nWat raar zeg en vooral vervelend voor jou. Heb je nu een boete gekregen? \n\nIk zoek graag uit wat er aan de hand is. Heb je voor mij je postcode, huisnummer, geboortedatum, volledige naam en e-mailadres. We kijken graag meg je mee.  ^JE",
            "mediaUrls" : [ ],
            "senderId" : "121372044",
            "id" : "1378327881357594629",
            "createdAt" : "2021-04-03T12:45:49.703Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hoi NS, ik heb per 2 maart 2021 een NS flex abonnement met weekend vrij eerste klas en korting door de weeks. Nu werd ik net gecontroleerd en volgens de conducteur staat er 2e klas op de kaart. Ik betaal wel 40 euro per maand (31 weekend vrij + 6 eerste klas weekend + 3 week korting). Moet ik voor elke weekend reis handmatig  1e klas op de kaart zetten? Ik dacht dat dit automatisch ging? Groet Jantsje",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1378327037740482567",
            "createdAt" : "2021-04-03T12:42:28.587Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/DyVmMX8KCh",
                "expanded" : "https://bit.ly/2zVGlgn",
                "display" : "bit.ly/2zVGlgn"
              }
            ],
            "text" : "Dan wil ik je een fijne avond wensen! Wil je oNS nog laten weten hoe je dit contact hebt ervaren? Dat kan via het volgende linkje en is ter verbetering van onze dienstverlening: https://t.co/DyVmMX8KCh.\n ^KH",
            "mediaUrls" : [ ],
            "senderId" : "121372044",
            "id" : "1321495588836442122",
            "createdAt" : "2020-10-28T16:54:35.277Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Nee dat is het, dankjewel!",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1321493449162575878",
            "createdAt" : "2020-10-28T16:46:05.123Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/9pPVDTuLso",
                "expanded" : "https://bit.ly/2JLGEgo",
                "display" : "bit.ly/2JLGEgo"
              }
            ],
            "text" : "Hoi Jantsje, \n\nFijn! De beëindiging staat voor je klaar. Vergeet je dit niet bij de kaartautomaat of een OV-chipkaart servicepunt te bevestigen? Hier kun je de servicepunten bij jou in de buurt vinden: https://t.co/9pPVDTuLso.\n\nHeb je verder nog vragen voor mij? ^KH",
            "mediaUrls" : [ ],
            "senderId" : "121372044",
            "id" : "1321488605546766340",
            "createdAt" : "2020-10-28T16:26:50.321Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hoi EH, liever niet omzetten naar NS Flex, want ik heb dus op mn andere kaart al NS Flex :)\n\nPer 3.11.2020 lijkt me top, ik kan inderdaad bevestigen op het station. \n\nGroet Jantsje",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1321480468748029957",
            "createdAt" : "2020-10-28T15:54:30.353Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hoi Jantsje, \n\nWat jammer om te lezen dat je jouw abonnement wilt opzeggen. Ik kan mij dit, gezien de reden, voorstellen. Uiteraard vinden we het alsnog jammer! Wil je wellicht dit abonnement ook omzetten naar NS Flex? Dan zou je ook met deze OV-chipkaart op rekening kunnen reizen. \n\nZo niet, kan ik een beëindiging voor je aanvragen per 03.11.2020. Je dient dit dan wel te bevestigen bij een automaat op het station of een oplaadpunt in een winkel. Is dat mogelijk voor je? \n\nGroetjes, ^EH",
            "mediaUrls" : [ ],
            "senderId" : "121372044",
            "id" : "1321479811072692234",
            "createdAt" : "2020-10-28T15:51:53.570Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "het gaat om deze kaart: 3528 0104 8316 2521",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1321464101416173575",
            "createdAt" : "2020-10-28T14:49:28.079Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "JM Mol, Jacob Catsstraat 7, 2274 GS Voorburg, 17-08-1990",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1321464007539200010",
            "createdAt" : "2020-10-28T14:49:05.697Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hallo NS, ik zou graag mijn traject vrij abonnement opzeggen, omdat ik het komende jaar niet meer hoef te reizen naar werk. Ik heb nog wel een andere kaart met NS flex, dus degene waar nu een traject vrij abonnement op staat  wil ik graag echt opzeggen",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1321463896365060101",
            "createdAt" : "2020-10-28T14:48:39.206Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/ODBROsXGvF",
                "expanded" : "http://bit.ly/2OpQMMc",
                "display" : "bit.ly/2OpQMMc"
              }
            ],
            "text" : "Ik ben blij dat je dit waardeert Jantsje! EN bedankt voor je suggestie. Ik wil dit graag doorzetten zodat mijn collega's hiervan op de hoogte zijn. Bedankt voor je bericht! Mocht je nog vragen hebben dan weet je ons te vinden! Zou je voor mij via de volgende link een kort klanttevredenheidsonderzoek in willen/kunnen vullen? Op deze manier kunnen wij onze dienstverlening verbeteren. Alvast bedankt en ik wens je een fijne dag! https://t.co/ODBROsXGvF.  ^WY",
            "mediaUrls" : [ ],
            "senderId" : "121372044",
            "id" : "1194555619493253125",
            "createdAt" : "2019-11-13T10:00:28.151Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Ik waardeer het zeker dat je meedenkt! Ik houd het bij de huidige situatie dan. Misschien een idee voor in de toekomst om bij de 0.00 euro van vandaag en gisteren op een traject kaart in NS online iets te zetten dat het nog niet ge-update is? En het zou ook schelen als het wijzigen van traject online zonder problemen lukt, in plaats van via Twitter 😉 anyway thanks voor de hulp en succes verder",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1194552348804288518",
            "createdAt" : "2019-11-13T09:47:28.356Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Dat klopt inderdaad. Ik snap natuurlijk heel goed als dit ook geen optie voor je is. Ik probeer mee te denken naar een eventuele andere mogelijkheid. Mocht mijn geboden optie niets zijn dan ben ik bang dat wij helaas niets voor je kunnen betekenen. In dat geval wil ik dan mijn excuses aanbieden voor de verwarrende en foutieve informatie. Ik wacht je reactie af! ^WY",
            "mediaUrls" : [ ],
            "senderId" : "121372044",
            "id" : "1194550250368843782",
            "createdAt" : "2019-11-13T09:39:08.044Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Optie die jij voorstelt is 309 euro plus kosten van alle weekend reizen",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1194546380309749766",
            "createdAt" : "2019-11-13T09:23:45.350Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Andere opties is de enkeltjes blijven betalen tot 3-12 en dan traject wijzigen naar Amsterdam zuid - Den Haag NOI. Dat kost 30.80 plus kosten enkeltjes, dat zijn er 27 als ik goed tel voor alle werkdagen, inclusief terugreis vandaag. Totale kosten 317 euro.",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1194546239209119748",
            "createdAt" : "2019-11-13T09:23:11.715Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Oké dus als ik het goed begrijp heb ik dan vanaf vandaag voor 1 maand: (1) geen weekend vrij abo (2) een maand trajectkaart a 339 euro (3) geld terug van abonnement van afgelopen maand a 30.80 euro (4) geen geld terug van alle vol tarief enkeltjes van de afgelopen weken",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1194545346279616516",
            "createdAt" : "2019-11-13T09:19:38.828Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Ik begrijp het. Helaas kun je de wijziging niet annuleren. En doordat de wijziging voor het traject al is doorgevoerd moet ik helaas aangeven dat het coulance aanbod van mijn collega dus niet mogelijk is. De reden dat ik vroeg of je nog een andere persoonlijke kaart had was omdat je dan misschien een maandabonnement op deze kaart had kunnen plaatsen. Maar helaas is dit ook geen optie, aangezien hier NS Flex op staat. Een optie die ik je nog kan bieden: Ik kan je NS Flex Weekend Vrij abonnement per vandaag beëindigen. Jij dient dit vandaag dan te deactiveren bij de kaartautomaat op het station. Nadat je dit hebt gedaan kun je een Traject Vrij maandabonnement op deze kaart aanvragen zodat je de aankomende maand dan kunt reizen. Zodra de wijziging voor het Traject Vrij jaarabonnement van start is gegaan kun je ons een bericht sturen. Als wij dan kunnen zien dat je niet met je jaarabonnement hebt gereisd de afgelopen maand dan kunnen wij de abonnementskosten van de laatste maand voor je vergoeden. Dit is helaas de enige optie die ik je nog kan bieden. Zou dit een optie voor je kunnen zijn? Ik wacht je reactie af! ^WY",
            "mediaUrls" : [ ],
            "senderId" : "121372044",
            "id" : "1194541699076415492",
            "createdAt" : "2019-11-13T09:05:09.269Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Kan ik niet iets annuleren door het op te halen?",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1194535629738131460",
            "createdAt" : "2019-11-13T08:41:02.216Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "3528 0200 9670 6523",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1194535572867600388",
            "createdAt" : "2019-11-13T08:40:48.665Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Ik heb inderdaad een andere persoonlijke OV chipkaart met een NS Flex abonnement erop",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1194535436070338564",
            "createdAt" : "2019-11-13T08:40:16.040Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Goedemorgen Jantsje. Ik wil graag even terugkomen op het aanbod van mijn collega. Helaas is dit namelijk niet mogelijk. Dit omdat mijn collega daarvoor al een nieuwe wijziging voor je heeft doorgevoerd. Aangezien er dus al een wijziging klaarstaat bij de kaartautomaat op het station kunnen wij geen nieuwe wijziging en/of beëindiging doorvoeren. De eerste wijziging moet namelijk eerst komen te vervallen. Excuses voor het ongemak. Ben jij toevallig in het bezit van nog een andere persoonlijke OV chipkaart? Ik wacht je reactie af! ^WY",
            "mediaUrls" : [ ],
            "senderId" : "121372044",
            "id" : "1194534132086431748",
            "createdAt" : "2019-11-13T08:35:05.155Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hallo AA, ik vind het echt super dat je me wilt helpen! Ik zie je berichtje nu pas dus ik heb vanmorgen gewoon ingecheckt, maar ik zou graag op je aanbod ingaan. Overigens is Den Haag Laan van NOI - Amsterdam Zuid mijn normale traject, dus dan zou ik vandaag een nieuw jaar abonnement bestellen, nadat ik de annulering heb opgehaald op de automaat.",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1194522571687055364",
            "createdAt" : "2019-11-13T07:49:08.937Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Goedenavond,\n\nVoor deze maand ga ik dat helaas niet meer kunnen doen. Voor hoe lang zou dit moeten gelden? en ga je na die periode weer verder op het traject dat je nu hebt?\n\nWat ik dan eventueel als coulance zou kunnen doen in dit geval is jouw abonnement met terugwerkende kracht per 03.11.2019 beëindigen. Als je dit morgen dan bij een kaartautomaat meteen bevestigd kun je daarna een Traject Vrij maand abonnement bestellen. Wanneer deze afloopt, en je ook weer je normale traject gaat reizen kun je gewoon weer het jaar abonnement bestellen.\n\nDit is een beetje een ongebruikelijke oplossing mar ik wil je graag helpen.\n^AA",
            "mediaUrls" : [ ],
            "senderId" : "121372044",
            "id" : "1194311430398451717",
            "createdAt" : "2019-11-12T17:50:08.939Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Ja dat weet ik maar ik moet op dit moment lesgeven dus ik ben echt wel gebonden aan de spits",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1194303526220025863",
            "createdAt" : "2019-11-12T17:18:44.427Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Wij bieden helaas geen weekabonnementen aan. Reis je ook tijdens de daluren? Zo ja, reis je in dat geval met 40% korting. ^AH",
            "mediaUrls" : [ ],
            "senderId" : "121372044",
            "id" : "1194276755210723332",
            "createdAt" : "2019-11-12T15:32:21.718Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Heb je nog advies hoe ik de komende tijd niet al te duur naar Amsterdam heen en weer kan? Er is geen week abo of zo?",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1194269145128415238",
            "createdAt" : "2019-11-12T15:02:07.333Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Die transacties zijn waarschijnlijk nog niet verwerkt. Ik heb het traject voor je gewijzigd. Je dient nog wel langs de kaartautomaat om de bevestiging op te halen. Kan ik je verder nog ergens mee helpen? ^AH",
            "mediaUrls" : [ ],
            "senderId" : "121372044",
            "id" : "1194249269957529604",
            "createdAt" : "2019-11-12T13:43:08.735Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Oké en waarom zie ik dan kosten 0.00 voor vandaag en gisteren?",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1194230041644806148",
            "createdAt" : "2019-11-12T12:26:44.337Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Ja graag.",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1194229934451044356",
            "createdAt" : "2019-11-12T12:26:18.782Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Dat is helaas niet meer mogelijk. De eerstvolgende mogelijkheid is per 03.12.2019. Zal ik de wijziging voor je doorvoeren? ^AH",
            "mediaUrls" : [ ],
            "senderId" : "121372044",
            "id" : "1194229609430167556",
            "createdAt" : "2019-11-12T12:25:01.303Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Ik had het omgezet maar blijkbaar is het niet opgeslagen en nu wordt de maand november heel duur 😳",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1194218992715608068",
            "createdAt" : "2019-11-12T11:42:50.071Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Nou per 3-12 sowieso maar als er nog iets voor de maand november geregeld kan worden ook graag.. want ik moet nu gewoon weer elke dag heen en weer!",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1194218756072968201",
            "createdAt" : "2019-11-12T11:41:53.651Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hoi Jantsje,\n\nIk heb even voor je gekeken en zie inderdaad in het systeem staan dat je nog een abonnement op het traject Sliedrecht, Hardinxveld Blauwe Zoom hebt staan. Ik kan dit wel voor je aanpassen, maar dit kan pas per 03.12.2019. Ik vrees alleen dat dit voor jou te laat is of niet? Kan je mij dit aangeven? ^SA",
            "mediaUrls" : [ ],
            "senderId" : "121372044",
            "id" : "1194216749551542281",
            "createdAt" : "2019-11-12T11:33:55.280Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hi WY,\nHier mijn gegevens:\nJacob Catsstraat 7 Voorburg \n17-08-1990\njantsje@gmail.com 3528 0194 8316 2521",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1194196075831332868",
            "createdAt" : "2019-11-12T10:11:46.256Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Goedemorgen Jantsje. Ik ga kijken wat ik voor je kan doen! Mag ik je volledige NAW-gegevens, geboortedatum, kaartnummer en mailadres ajb? ^WY",
            "mediaUrls" : [ ],
            "senderId" : "121372044",
            "id" : "1194172486658805764",
            "createdAt" : "2019-11-12T08:38:02.176Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hallo! Ik wilde het abonnement per 3-11 weer terugzetten naar Den Haag laan van noi - Amsterdam zuid, en ik dacht ook dat dat gelukt was te zien aan de 0.0 euro als ik inlogde.. maar nu zie ik als ik verder klik toch nog het Sliedrecht abonnement staan en prijzen van m’n oudere ritten.. kunnen jullie helpen?",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1194157906373074948",
            "createdAt" : "2019-11-12T07:40:05.964Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Ik heb je abonnement gewijzigd per 03.09.2019 naar het traject Sliedrecht - Hardinxveld Blauwe Zoom. Je krijgt ook nog een e-mail ter bevestiging. Kan ik je nog met iets anders helpen? ^LS",
            "mediaUrls" : [ ],
            "senderId" : "121372044",
            "id" : "1166625488653230085",
            "createdAt" : "2019-08-28T08:16:06.041Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Ja gaat lukken!",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1166605993846956039",
            "createdAt" : "2019-08-28T06:58:38.113Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Top! Voordat ik het erin zet moet ik nog wel even vragen of het je gaat lukken om de wijziging op te halen vóór 03.09.2019 bij een kaartautomaat. Gaat dat lukken? ^RM",
            "mediaUrls" : [ ],
            "senderId" : "121372044",
            "id" : "1166430201326317572",
            "createdAt" : "2019-08-27T19:20:05.908Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Ja ik ga akkoord",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1166373535763369990",
            "createdAt" : "2019-08-27T15:34:55.799Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/yED9OGT7Mt",
                "expanded" : "http://bit.ly/2oSSFEk",
                "display" : "bit.ly/2oSSFEk"
              },
              {
                "url" : "https://t.co/PKxFXbDetu",
                "expanded" : "http://bit.ly/2GVk2ph",
                "display" : "bit.ly/2GVk2ph"
              }
            ],
            "text" : "Hartelijk dank voor de aanvullende informatie. Hierbij kan ik je traject per 3 september 2019 wijzigen naar het traject Sliedrecht - Hardinxveld Blauwe Zoom. Het nieuwe maandbedrag is: € 30,80. Wil je dat ik de wijziging doorvoer? Dan ontvang ik graag je officiële akkoord:\n\nOp dit abonnement zijn de Algemene Voorwaarden van toepassing voor het vervoer van reizigers en hun handbagage van de Nederlandse Spoorwegen (AVR-NS), de Algemene Voorwaarden OV-chipkaart en de productvoorwaarden van de door je bestelde abonnementen. Deze zijn te raadplegen op https://t.co/yED9OGT7Mt en worden op verzoek kosteloos toegestuurd. Meer informatie over de rechten en plichten van reizigers is te vinden op https://t.co/PKxFXbDetu. \n\nGa je akkoord met de automatische incasso van de abonnementsgelden en gebruikskosten? ^SV",
            "mediaUrls" : [ ],
            "senderId" : "121372044",
            "id" : "1166323701131948037",
            "createdAt" : "2019-08-27T12:16:54.296Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Oké doe ik. JM Mol Jacob Catsstraat 7 Voorburg, 17-08-1990, jantsje@gmail.com",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1166298111301574660",
            "createdAt" : "2019-08-27T10:35:13.203Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Je dient voor 03.11 dan nog even contact op te nemen om het traject weer te wijzigen. Je zal na iedere wijziging ook even langs de kaartautomaat moeten om de bevestiging op te halen. Zou je mij nog kunnen voorzien van je NAW-gegevens, geb.datum en e-mailadres. ^AH",
            "mediaUrls" : [ ],
            "senderId" : "121372044",
            "id" : "1166287896518828037",
            "createdAt" : "2019-08-27T09:54:37.845Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Oke, dan zou ik graag van 3-9-2019 tot 3-11-2019 het traject veranderen naar Sliedrecht - Hardinxveld Blauwe Zoom, en dan per 3-11-2019 weer terug naar Laan van NOI - Amsterdam Zuid",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1166271067574493188",
            "createdAt" : "2019-08-27T08:47:45.472Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hallo Jantsje, Je kunt het traject per ingangsdatum laten wijzigen. Heb je al een traject in gedachte? ^AH",
            "mediaUrls" : [ ],
            "senderId" : "121372044",
            "id" : "1166231950891343877",
            "createdAt" : "2019-08-27T06:12:19.319Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Klopt het dat ik het traject elke maand kan wijzigen? Ik ben van 30 augustus tot 30 oktober in het buitenland, dus ik zou graag die twee maanden het goedkoopste traject willen, en daarna weer den haag NOI - Amsterdam Zuid",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1166106117790978053",
            "createdAt" : "2019-08-26T21:52:18.379Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Bedankt voor het sturen van jouw gegevens! Ik wil graag controleren of ik jouw traject kan wijzigen. Per wanneer wil jij jouw traject wijzigen en welk traject wil jij graag doorvoeren? ^FL",
            "mediaUrls" : [ ],
            "senderId" : "121372044",
            "id" : "1166049032554340358",
            "createdAt" : "2019-08-26T18:05:28.220Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Jantsje@gmail.com",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1165991895660728324",
            "createdAt" : "2019-08-26T14:18:25.701Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "3528 0104 8316 2521",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1165991859279339524",
            "createdAt" : "2019-08-26T14:18:17.031Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "17-08-1990",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1165991714559004677",
            "createdAt" : "2019-08-26T14:17:42.534Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "JM Mol 2274 GS nr 7",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1165991681893838857",
            "createdAt" : "2019-08-26T14:17:34.739Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Ik wil graag met jou meekijken wat mogelijk is. Graag ontvang ik de volgende gegevens: voorletters, achternaam, postcode, huisnummer, geboortedatum, OV-chipkaartnummer en e-mailadres. ^LU",
            "mediaUrls" : [ ],
            "senderId" : "121372044",
            "id" : "1165988931986481156",
            "createdAt" : "2019-08-26T14:06:39.116Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Maar op mijn NS staat “uw aanvraag kan niet worden verwerkt”",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1165961178574655494",
            "createdAt" : "2019-08-26T12:16:22.172Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hoi ik heb een vraagje. Ik ga voor 2 maanden naar het buitenland en ik wil mijn trajectkaart in die tijd graag naar een goedkoop traject wijzigen",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1165961048970711046",
            "createdAt" : "2019-08-26T12:15:51.287Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Graag gedaan. nog een fijne dag toegewenst! ^BG",
            "mediaUrls" : [ ],
            "senderId" : "121372044",
            "id" : "1130736992789000198",
            "createdAt" : "2019-05-21T07:28:01.853Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Bedankt voor jullie snelle reacties hier!",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1130736045094559750",
            "createdAt" : "2019-05-21T07:24:15.958Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Oké dankjewel, dan doe ik dat!",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1130735977327222790",
            "createdAt" : "2019-05-21T07:23:59.747Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Dat klopt, Jantsje. Je kunt het beste een reply e-mail sturen op de afwijzing. Hierdoor komt de mail direct bij onze afdeling claims terecht. ^BG",
            "mediaUrls" : [ ],
            "senderId" : "121372044",
            "id" : "1130735634040143876",
            "createdAt" : "2019-05-21T07:22:37.896Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Bedoel je dat ik op de mail moet antwoorden? In mijn NS kan ik de afgewezen claim wel zien maar verder niks doen.. 🤷‍♀️",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1130728590625124358",
            "createdAt" : "2019-05-21T06:54:38.617Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Dankjewel! Wil je op het bezwaar reageren dat je hebt gekregen? Dan kan de claim door de juiste afdeling opnieuw in behandeling worden genomen! Ik zie niets bij je reishistorie staan waardoor dat fout moet gaan! ^ML",
            "mediaUrls" : [ ],
            "senderId" : "121372044",
            "id" : "1130725017120059396",
            "createdAt" : "2019-05-21T06:40:26.626Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "De vriesstraat 81 Den Haag",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1130709702147358725",
            "createdAt" : "2019-05-21T05:39:35.260Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "17-08-1990",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1130709662158999556",
            "createdAt" : "2019-05-21T05:39:25.717Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "NL09ABNA0425194272",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1130709627333632005",
            "createdAt" : "2019-05-21T05:39:17.422Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Haha je hebt gelijk ik typte fout! 1990",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1130709560761753604",
            "createdAt" : "2019-05-21T05:39:01.544Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hi Jantsje, weet je zeker dat je de juiste geboortedatum hebt vermeld? Ik heb een ander geboortejaar in onze administratie staan.  ^GV",
            "mediaUrls" : [ ],
            "senderId" : "121372044",
            "id" : "1130591578937057285",
            "createdAt" : "2019-05-20T21:50:12.503Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Fijn dat je ernaar wilt kijken! Groet Jantsje",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1130565508766552068",
            "createdAt" : "2019-05-20T20:06:36.881Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hi LR,\nJa precies! Hier mijn gegevens:\nDe Vriesstraat 81 Den Haag \n17-08-1999\nNL09ABNA042519472",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1130565425228599300",
            "createdAt" : "2019-05-20T20:06:16.959Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hi Jantsje,\n\nBegrijp ik het goed dat deze reis normaal binnen je Traject Vrij abonnement valt? Dan kijk ik er graag naar. Kan je me daarvoor je adres, geboortedatum en IBAN geven? Alvast bedankt.\n\nGroet, ^LR",
            "mediaUrls" : [ ],
            "senderId" : "121372044",
            "id" : "1130502144451387396",
            "createdAt" : "2019-05-20T15:54:49.670Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "121372044",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hoi NS! Ik wilde op 8 mei om 7.21 van Den Haag laan van NOI naar Amsterdam Zuid, maar er was een storing tussen leiden en Schiphol, dus ik ben op advies van de conducteur via Haarlem en Amsterdam centraal gegaan. Daar heb ik de Noord-Zuidlijn gepakt. Uiteindelijk was ik daar 8.35, ruim een halfuur later dan gebruikelijk. Het kostte zon 6 euro extra voor metro en centraal-zuid niet op trajectkaart. Ik heb de claim bij vertraging op jullie site ingevoerd maar die zegt dat er geen vertraging was, dus is mn claim afgewezen. Maar ik was wel met extra kosten een halfuur laten op mn werk. \n\nKunnen jullie mij helpen? \n\nGroetjes Jantsje",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1130492681719832581",
            "createdAt" : "2019-05-20T15:17:13.571Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "1096413470554292225-1268869739566247940",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hear you soon :)",
            "mediaUrls" : [ ],
            "senderId" : "1268869739566247940",
            "id" : "1322130202911297541",
            "createdAt" : "2020-10-30T10:56:19.047Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I will do that!",
            "mediaUrls" : [ ],
            "senderId" : "1268869739566247940",
            "id" : "1322130179817431044",
            "createdAt" : "2020-10-30T10:56:13.540Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1268869739566247940",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Ah and so cool that you have a lab! You should get in touch with them and ask about the possibilities",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1322129898543173637",
            "createdAt" : "2020-10-30T10:55:06.484Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1268869739566247940",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Yes lets keep in touch, I would like that :)",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1322129774811164676",
            "createdAt" : "2020-10-30T10:54:36.981Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/hgA3CkEChj",
                "expanded" : "https://www.nottingham.ac.uk/research/groups/mixedrealitylab/index.aspx",
                "display" : "nottingham.ac.uk/research/group…"
              }
            ],
            "text" : "Ps You were right...We actually have a lab, just not in economics (https://t.co/hgA3CkEChj)",
            "mediaUrls" : [ ],
            "senderId" : "1268869739566247940",
            "id" : "1322128605577646085",
            "createdAt" : "2020-10-30T10:49:58.244Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Thank you so much for your time and help. Let's keep in touch :)",
            "mediaUrls" : [ ],
            "senderId" : "1268869739566247940",
            "id" : "1322125891179286538",
            "createdAt" : "2020-10-30T10:39:11.055Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I will also have a look and see what has been done and maybe find those paper that looked into the effect of meeting refugees. I know I read them, but cannot find them in my folder's mess.",
            "mediaUrls" : [ ],
            "senderId" : "1268869739566247940",
            "id" : "1322125790201470982",
            "createdAt" : "2020-10-30T10:38:46.978Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I will keep you updated. I will see if there is anyone in the psychology and communication department using the instruments and see what can be done about that.",
            "mediaUrls" : [ ],
            "senderId" : "1268869739566247940",
            "id" : "1322125105913352199",
            "createdAt" : "2020-10-30T10:36:03.830Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "100% plus I think that they also needed to remind me about the excitement of doing research.",
            "mediaUrls" : [ ],
            "senderId" : "1268869739566247940",
            "id" : "1322124796122009604",
            "createdAt" : "2020-10-30T10:34:49.971Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1268869739566247940",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I think every researcher needs some sideline projects and sometimes they turn out to be the most fun",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1322123982779404292",
            "createdAt" : "2020-10-30T10:31:36.053Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1268869739566247940",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Yes I'd like to be involved if you are planning to run something. Happy to help with literature stuff and maybe connecting the one tech people to the other",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1322123803187699717",
            "createdAt" : "2020-10-30T10:30:53.234Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "If you are too busy, I understand it.",
            "mediaUrls" : [ ],
            "senderId" : "1268869739566247940",
            "id" : "1322123679011098629",
            "createdAt" : "2020-10-30T10:30:23.630Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Great point. I will do that. Would that be something you could be interesting in taking part?",
            "mediaUrls" : [ ],
            "senderId" : "1268869739566247940",
            "id" : "1322123531082178564",
            "createdAt" : "2020-10-30T10:29:48.359Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1268869739566247940",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I think the idea is very interesting, I don't know how far some others got with it yet, so I guess you first have to check that",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1322123333945708549",
            "createdAt" : "2020-10-30T10:29:01.361Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1268869739566247940",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Are you sure the instruments are not there? Sometimes a psychology or communications department does have it",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1322123213845966852",
            "createdAt" : "2020-10-30T10:28:32.723Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "So apart from the very bad way in which I explained it, do you think that the idea could be interesting? I am don't know anything about the field, so I don't know how to judge it. The problem would also be that in Nottingham we do not have the instruments needed.",
            "mediaUrls" : [ ],
            "senderId" : "1268869739566247940",
            "id" : "1322122981364146180",
            "createdAt" : "2020-10-30T10:27:37.297Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I see you point, also part of your face would be cover but it would be a very cool picture!",
            "mediaUrls" : [ ],
            "senderId" : "1268869739566247940",
            "id" : "1322122550932049924",
            "createdAt" : "2020-10-30T10:25:54.674Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1268869739566247940",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Anyway I'm happy to help!",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1322121185119903748",
            "createdAt" : "2020-10-30T10:20:29.041Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1268869739566247940",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "But maybe that makes it too much of a one-trick pony",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1322120993226280965",
            "createdAt" : "2020-10-30T10:19:43.290Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1268869739566247940",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I was thinking of changing my picture to one with a VR headset on :)",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1322120947135033348",
            "createdAt" : "2020-10-30T10:19:32.298Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "In any case, I don't think I thanked you for the papers you sent me.  They sound relevant and very exciting!",
            "mediaUrls" : [ ],
            "senderId" : "1268869739566247940",
            "id" : "1322120754532667397",
            "createdAt" : "2020-10-30T10:18:46.380Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "For example, I have been told that my picture doesn't look professional enough. I answered that if a university has a problem with that, it is probably not the right place for me.",
            "mediaUrls" : [ ],
            "senderId" : "1268869739566247940",
            "id" : "1322119919018909701",
            "createdAt" : "2020-10-30T10:15:27.178Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I totally agree with you!",
            "mediaUrls" : [ ],
            "senderId" : "1268869739566247940",
            "id" : "1322119596510482437",
            "createdAt" : "2020-10-30T10:14:10.289Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1268869739566247940",
            "reactions" : [
              {
                "senderId" : "1268869739566247940",
                "reactionKey" : "like",
                "eventId" : "1322119546514382848",
                "createdAt" : "2020-10-30T10:13:58.348Z"
              }
            ],
            "urls" : [ ],
            "text" : "But I just told myself they were trying to find a job at a bank ;-)",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1322119328527994884",
            "createdAt" : "2020-10-30T10:13:06.392Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1268869739566247940",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "The people I saw in Rotterdam also looked all buttoned up and stuff",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1322119264543924228",
            "createdAt" : "2020-10-30T10:12:51.137Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1268869739566247940",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I think there is nothing wrong with being yourself!",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1322119171673640965",
            "createdAt" : "2020-10-30T10:12:28.995Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I did have one interview recently but I was super clumsy. The researchers that come to my university for the job market do not look at all like me. They are anxious as well for sure, but I guess that they are a lot better at hiding it.",
            "mediaUrls" : [ ],
            "senderId" : "1268869739566247940",
            "id" : "1322118588967407620",
            "createdAt" : "2020-10-30T10:10:10.068Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1268869739566247940",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Online has pros and cons, but the pro is you dont need to walk in a hotel room with all males on chairs waiting for you",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1322118503810404356",
            "createdAt" : "2020-10-30T10:09:49.769Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1268869739566247940",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I thought that was the weirdest place ever to meet you potential employer",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1322118364358168580",
            "createdAt" : "2020-10-30T10:09:16.516Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1268869739566247940",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Well at least with covid you dont have to go to the hotel thing",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1322118314437545988",
            "createdAt" : "2020-10-30T10:09:04.618Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I am an anxious type, so that doesn't particularly help 🤦‍♀️",
            "mediaUrls" : [ ],
            "senderId" : "1268869739566247940",
            "id" : "1322118122724298756",
            "createdAt" : "2020-10-30T10:08:18.909Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "This year it was meant to be in Nottingham...in that case, I would probably have gone as well.",
            "mediaUrls" : [ ],
            "senderId" : "1268869739566247940",
            "id" : "1322117973692264454",
            "createdAt" : "2020-10-30T10:07:43.377Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1268869739566247940",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "That may be a bit overselling it, but it certainly has interesting possibilities",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1322117758436417540",
            "createdAt" : "2020-10-30T10:06:52.052Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1268869739566247940",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Sometimes they call VR the empathy machine",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1322117691013058564",
            "createdAt" : "2020-10-30T10:06:35.977Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1268869739566247940",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Got a bit more stressed with 2020 progressing and not so many jobs over summer.. But then this job at UvA was advertised and I was even more stressed because I felt it had my name on it, haha",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1322117539305054213",
            "createdAt" : "2020-10-30T10:05:59.824Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1268869739566247940",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I had only 1 interview, which was fun, but I did not get the job, but my PhD contract lasted until okt this year, so I was not so stressed",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1322117345888927749",
            "createdAt" : "2020-10-30T10:05:13.694Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1268869739566247940",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I went to the european job market in Rotterdam last year, but mainly because it was a 30 min metro ride",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1322117208525410308",
            "createdAt" : "2020-10-30T10:04:40.944Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1268869739566247940",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Oh that sounds like a good decision!",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1322117110370361348",
            "createdAt" : "2020-10-30T10:04:17.542Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I will be in Nottingham for two more years. My supervisors thought that I should go on the job market this year but I refused. I think doing it once it is already stressful but doing it with the idea that I might have to go back, doesn't make it very attractive 😂",
            "mediaUrls" : [ ],
            "senderId" : "1268869739566247940",
            "id" : "1322113857482072070",
            "createdAt" : "2020-10-30T09:51:21.993Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "What got me thinking about this all issue is a recent paper that suggests that by meeting refugees people's attitudes towards them changes. To some extent, I think that it would be cool to take it even a step further and see whether making people step into refugee's shoes would make change their mind.",
            "mediaUrls" : [ ],
            "senderId" : "1268869739566247940",
            "id" : "1322113364110286852",
            "createdAt" : "2020-10-30T09:49:24.366Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1268869739566247940",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Are you on this crazy river already that they call the job market?",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1322113138901323780",
            "createdAt" : "2020-10-30T09:48:30.672Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1268869739566247940",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "How long are you still in Nottingham?",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1322113095976783876",
            "createdAt" : "2020-10-30T09:48:20.435Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1268869739566247940",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Yes it is really fun so far!",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1322112938002579460",
            "createdAt" : "2020-10-30T09:47:42.768Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "The University of Amsterdam is such a nice place. Shaul seems like a cool guy.",
            "mediaUrls" : [ ],
            "senderId" : "1268869739566247940",
            "id" : "1322112347780075524",
            "createdAt" : "2020-10-30T09:45:22.063Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1268869739566247940",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Yes thanks 😊",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1322112237323067396",
            "createdAt" : "2020-10-30T09:44:55.719Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "So I heard. Congratulations!!!",
            "mediaUrls" : [ ],
            "senderId" : "1268869739566247940",
            "id" : "1322112112483860485",
            "createdAt" : "2020-10-30T09:44:25.952Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1268869739566247940",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "And I have a post-doc job starting January with some time for extra projects so keep me posted if you are really starting something :)",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1322111997459238918",
            "createdAt" : "2020-10-30T09:43:58.530Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1268869739566247940",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I'm glad it did!",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1322111898654035973",
            "createdAt" : "2020-10-30T09:43:34.970Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1268869739566247940",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/5WJgx58Fz8",
                "expanded" : "https://doi.org/10.1016/j.socec.2019.02.007",
                "display" : "doi.org/10.1016/j.soce…"
              }
            ],
            "text" : "https://t.co/5WJgx58Fz8 sorry now with link",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1322111871323906053",
            "createdAt" : "2020-10-30T09:43:28.497Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Well, your presentation did open a whole new world to me :)",
            "mediaUrls" : [ ],
            "senderId" : "1268869739566247940",
            "id" : "1322111864063643652",
            "createdAt" : "2020-10-30T09:43:26.722Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1268869739566247940",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I wrote this review on VR for economics a while ago, you might find some useful references in there too 10.1016/j.socec.2019.02.007",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1322111778692759557",
            "createdAt" : "2020-10-30T09:43:06.373Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1268869739566247940",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Yes thanks, I'm honored you think of me :)",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1322111614322135044",
            "createdAt" : "2020-10-30T09:42:27.183Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1268869739566247940",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/k05zGXKnB9",
                "expanded" : "https://doi.org/10.1371/journal.pone.0223631",
                "display" : "doi.org/10.1371/journa…"
              }
            ],
            "text" : "Also I found this: https://t.co/k05zGXKnB9",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1322111557652852740",
            "createdAt" : "2020-10-30T09:42:14.101Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "This idea has been stuck in the back of my head for a while now :)",
            "mediaUrls" : [ ],
            "senderId" : "1268869739566247940",
            "id" : "1322111524710846468",
            "createdAt" : "2020-10-30T09:42:05.815Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "That's so cool! Thank you so much for your help.",
            "mediaUrls" : [ ],
            "senderId" : "1268869739566247940",
            "id" : "1322111406339227652",
            "createdAt" : "2020-10-30T09:41:37.594Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1268869739566247940",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/37rzunyKU4",
                "expanded" : "https://papers.ssrn.com/sol3/papers.cfm?abstract_id=3072002",
                "display" : "papers.ssrn.com/sol3/papers.cf…"
              }
            ],
            "text" : "https://t.co/37rzunyKU4",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1322111309165563908",
            "createdAt" : "2020-10-30T09:41:14.750Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1268869739566247940",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Let me check, I think there is a working paper around.",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1322111160733388805",
            "createdAt" : "2020-10-30T09:40:39.035Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1268869739566247940",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I think Ozgur Gurkerk has done something like this, to see if it would increase charity donations",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1322111127388672004",
            "createdAt" : "2020-10-30T09:40:31.085Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1268869739566247940",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hi Monika! I do remember you :)",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1322111073638600709",
            "createdAt" : "2020-10-30T09:40:18.272Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/XOofl3oidr",
                "expanded" : "https://www.weforum.org/agenda/2020/02/can-a-video-game-save-a-life-african-refugee-puts-players-in-his-race-for-survival",
                "display" : "weforum.org/agenda/2020/02…"
              }
            ],
            "text" : "https://t.co/XOofl3oidr",
            "mediaUrls" : [ ],
            "senderId" : "1268869739566247940",
            "id" : "1322105178292707332",
            "createdAt" : "2020-10-30T09:16:52.715Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hi Jantsje, I am sure you do not remember me but I was the host in your session at the ESA around the clock conference. I recently found out about a video game that is supposed to put you into the shoes of a refugee and I got really excited as I was thinking about potential applications. Your name came to my mind as you are the only person I know of that has been using virtual tools to influence real-life outcomes. So I was thinking, would it be too crazy to use something similar to this videogame (or this video game with the developer's authorisation) and see whether it influences attitudes towards refugees? Sorry for the out of the blue question. Best, Monika",
            "mediaUrls" : [ ],
            "senderId" : "1268869739566247940",
            "id" : "1322105136907431945",
            "createdAt" : "2020-10-30T09:16:42.864Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "1096413470554292225-1316360546673930241",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Enjoy your skiing trip, and see you in a few weeks then 🙂",
            "mediaUrls" : [ ],
            "senderId" : "1316360546673930241",
            "id" : "1488818480740712455",
            "createdAt" : "2022-02-02T10:16:01.417Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1316360546673930241",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hi Caroline! Nice to see you here too :) This week I work from home and I'll be skiing next week. But after that I will come to the office more often! Looking forward to meet! Safe travels!",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1488801768779702276",
            "createdAt" : "2022-02-02T09:09:36.983Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hi Jantsje - great to connect with you here on twitter as well! I'm coming to Amsterdam tomorrow - let me know if you want to meet up at some point 🙂",
            "mediaUrls" : [ ],
            "senderId" : "1316360546673930241",
            "id" : "1488792938444427268",
            "createdAt" : "2022-02-02T08:34:31.652Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "1096413470554292225-1471960578017009670",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1471960578017009670",
            "reactions" : [
              {
                "senderId" : "1471960578017009670",
                "reactionKey" : "agree",
                "eventId" : "1501541564769873921",
                "createdAt" : "2022-03-09T12:53:01.006Z"
              }
            ],
            "urls" : [ ],
            "text" : "Haha no the conference takes two days 😉 you can reach me at j.m.mol@uva.nl",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1501527202961268743",
            "createdAt" : "2022-03-09T11:55:56.899Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "OK, let's discuss further by email or a quick call. My email address is phil@iarcc.org (Philippe Borremans).",
            "mediaUrls" : [ ],
            "senderId" : "1471960578017009670",
            "id" : "1501515966823424014",
            "createdAt" : "2022-03-09T11:11:17.993Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Not a joke? 😅",
            "mediaUrls" : [ ],
            "senderId" : "1471960578017009670",
            "id" : "1501515821453037578",
            "createdAt" : "2022-03-09T11:10:43.332Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1471960578017009670",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Cool, congratulations on the launch! Early April could work for me (except April 1st, when I have another conference)",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1501497396110536708",
            "createdAt" : "2022-03-09T09:57:30.390Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "On the academic side we're having partnerships set up with ECREA, EUPRERA and the Africa Business School (for the moment).",
            "mediaUrls" : [ ],
            "senderId" : "1471960578017009670",
            "id" : "1501495414155055109",
            "createdAt" : "2022-03-09T09:49:37.856Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/ueSnaxVdFO",
                "expanded" : "https://www.iarcc.org/live-webinar/iarcc-launch-webinar/register",
                "display" : "iarcc.org/live-webinar/i…"
              }
            ],
            "text" : "We're launching this Thursday with around 120 members... We're planning the webinar series for the rest of the year. One on crisis simulations, another one on stakeholder management etc... We could plan your for early April if that's OK for you. And, you're of course welcome to our launch tomorrow at 10:00 CET. https://t.co/ueSnaxVdFO",
            "mediaUrls" : [ ],
            "senderId" : "1471960578017009670",
            "id" : "1501495196722290692",
            "createdAt" : "2022-03-09T09:48:46.065Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1471960578017009670",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Sounds good! Glad to hear you like my research. How many members do you currently have? Did you have any other webinars planned already?",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1501483030959075333",
            "createdAt" : "2022-03-09T09:00:25.469Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hi Jantsje! The IARCC (International Association of Risk &amp; Crisis Communication) is a non-profit and is planning monthly webinars for its members on all things risk and crisis comms. Your research is really fascinating, and we would like to invite you to present it at one of our webinars whenever it suits you. Our members are academics, researchers, practitioners and policymakers working on risk and crisis communication. What do you think?",
            "mediaUrls" : [ ],
            "senderId" : "1471960578017009670",
            "id" : "1501477408721018888",
            "createdAt" : "2022-03-09T08:38:05.042Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "138062686-1096413470554292225",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hey Jantsje, ja als er nieuws binnen komt dan zal jij het als eerste horen. Ik hoop dan ook dat je sokken snel door de douane komt en ik wens je nog een fijne avond! Groetjes Annefloor",
            "mediaUrls" : [ ],
            "senderId" : "138062686",
            "id" : "1484229094896250885",
            "createdAt" : "2022-01-20T18:19:26.564Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "138062686",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hoi Gökhan, op zich wel logisch dat jullie daar geen invloed op hebben ;-) Maar fijn om te weten dat het maximaal 30 dagen zijn... Wel vreemd dat ze sokken checken bij de douane, maar goed. Als er iets mis is, hoor ik dat dan vanzelf? Groetjes, Jantsje",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1484177172747087879",
            "createdAt" : "2022-01-20T14:53:07.360Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hey Jantsje,\n\nHelaas hebben wij geen invloed op de douane. Ik ga je vriendelijk vragen om even af te wachten, dit kan tot 30 dagen duren. Groetjes, Gökhan.",
            "mediaUrls" : [ ],
            "senderId" : "138062686",
            "id" : "1484167064139055109",
            "createdAt" : "2022-01-20T14:12:57.277Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "138062686",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/lUdof04oMh",
                "expanded" : "https://www.royalmail.com/track-your-item#/tracking-results/LG833785073GB",
                "display" : "royalmail.com/track-your-ite…"
              }
            ],
            "text" : "zie hier https://t.co/lUdof04oMh",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1484115353957457929",
            "createdAt" : "2022-01-20T10:47:28.988Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "138062686",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "postcode ontvanger 2274GS",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1484115319698374664",
            "createdAt" : "2022-01-20T10:47:20.477Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "138062686",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "LG833785073GB dit is het nummer",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1484115294067077132",
            "createdAt" : "2022-01-20T10:47:14.361Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "138062686",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "hallo! Ik verwacht een zending uit het VK, maar volgens de website van Royal Mail is hij al 5 dagen bij de NL douane? Het gaat om een paar sokken...",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1484115264635650053",
            "createdAt" : "2022-01-20T10:47:07.355Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "142608485-1096413470554292225",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "142608485",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hello?",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1452684362563166219",
            "createdAt" : "2021-10-25T17:11:56.370Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "142608485",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "any chance you could check out how to use it?",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1451133586187374597",
            "createdAt" : "2021-10-21T10:29:42.446Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "142608485",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "at jantsje@Gmail.com",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1451133560170090511",
            "createdAt" : "2021-10-21T10:29:36.258Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "142608485",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "it only says \"LLAQ**************571.99 EUR\"",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1451133548421845000",
            "createdAt" : "2021-10-21T10:29:33.462Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "142608485",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "hello Iberia! I have a voucher but I cannot find the full code in my email",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1451133472089808901",
            "createdAt" : "2021-10-21T10:29:15.266Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "323786864-1096413470554292225",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hey Jantsje, it might be easier if we do this via email. Would you mind letting me know your availability for early November via M.van-Den-Akker@warwick.ac.uk",
            "mediaUrls" : [ ],
            "senderId" : "323786864",
            "id" : "1442551607028244485",
            "createdAt" : "2021-09-27T18:07:59.129Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "awesome :) do you have a preferred timeslot?",
            "mediaUrls" : [ ],
            "senderId" : "323786864",
            "id" : "1440619782546493448",
            "createdAt" : "2021-09-22T10:11:36.286Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "323786864",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Thanks! And yes early November sounds good to me!",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1440597941438189580",
            "createdAt" : "2021-09-22T08:44:48.936Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hey Jantsje! Congratulations :) Would you still be good for recording early November?",
            "mediaUrls" : [ ],
            "senderId" : "323786864",
            "id" : "1440592156146630662",
            "createdAt" : "2021-09-22T08:21:49.618Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "323786864",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "It is now officially after! Let me know when you want to get in touch :) I'm quite flexible so if you need to do other stuff (like your own PhD!) first, no worries from my side.. I have a Dutch radio interview next week so I can practice a bit ;-)",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1440562380459569156",
            "createdAt" : "2021-09-22T06:23:30.563Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "323786864",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "hahaha hell yes!",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1364224590629675018",
            "createdAt" : "2021-02-23T14:44:23.155Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "haha",
            "mediaUrls" : [ ],
            "senderId" : "323786864",
            "id" : "1364224458106445836",
            "createdAt" : "2021-02-23T14:43:51.567Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "No let's do after, I want to know EVERYTHING",
            "mediaUrls" : [ ],
            "senderId" : "323786864",
            "id" : "1364224449537400842",
            "createdAt" : "2021-02-23T14:43:49.545Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "323786864",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Yeah or when the defense is planned, if you want to talk about how to prep :o",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1364223465062948874",
            "createdAt" : "2021-02-23T14:39:54.811Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "So after the defense probably makes more sense :)",
            "mediaUrls" : [ ],
            "senderId" : "323786864",
            "id" : "1364223255284834310",
            "createdAt" : "2021-02-23T14:39:04.804Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "That's completely fine. We want to talk about the whole process of doing a PhD in behavioural science",
            "mediaUrls" : [ ],
            "senderId" : "323786864",
            "id" : "1364223220010737668",
            "createdAt" : "2021-02-23T14:38:56.382Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "323786864",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Depends a bit what you want to talk about :) I mean I don't have a defense date yet, so if we would like to refer to that, maybe later rather than sooner",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1364222681277550598",
            "createdAt" : "2021-02-23T14:36:47.952Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Do you have a preferred time/date? We're currently planning in recording in the month of March :)",
            "mediaUrls" : [ ],
            "senderId" : "323786864",
            "id" : "1364212586707845125",
            "createdAt" : "2021-02-23T13:56:41.195Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "It'd be lovely to have someone on who actually survived the whole submitting a thesis malarkey!",
            "mediaUrls" : [ ],
            "senderId" : "323786864",
            "id" : "1362703325016244235",
            "createdAt" : "2021-02-19T09:59:25.172Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Well that is good news",
            "mediaUrls" : [ ],
            "senderId" : "323786864",
            "id" : "1362703258175877124",
            "createdAt" : "2021-02-19T09:59:09.235Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "323786864",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hi Merle! I would be happy to talk about the podcast :)",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1362700661809373188",
            "createdAt" : "2021-02-19T09:48:50.208Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "376743496-1096413470554292225",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "376743496",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Haha ja leuk! Geen probleem ik moest ook even denken waar ik je van kende zo in een hele andere outfit..",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1444328578460659727",
            "createdAt" : "2021-10-02T15:49:02.115Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Leuk je zo toevallig eens in 'levende lijve' tegen te komen, het duurde bij mij even voordat ik het zag, sorry!",
            "mediaUrls" : [ ],
            "senderId" : "376743496",
            "id" : "1444305782615560201",
            "createdAt" : "2021-10-02T14:18:27.168Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "383094940-1096413470554292225",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "383094940",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I will send you a message! And yes, thanks :) I'm looking forward to it!",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1382617902289944581",
            "createdAt" : "2021-04-15T08:52:50.388Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hi, Feel free to email me at christian.reynolds@city.ac.uk\nLooks like you are doing some great research! (and congrats on the Viva - as i see from your tweets :D)",
            "mediaUrls" : [ ],
            "senderId" : "383094940",
            "id" : "1382617336105013254",
            "createdAt" : "2021-04-15T08:50:35.414Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "469459231-1096413470554292225",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "469459231",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Thanks!",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1433799791436251146",
            "createdAt" : "2021-09-03T14:31:23.678Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I can imagine, my best vibes and wishes!! TTYL",
            "mediaUrls" : [ ],
            "senderId" : "469459231",
            "id" : "1433799516227084298",
            "createdAt" : "2021-09-03T14:30:18.070Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "469459231",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "only next week a but busy with the defense but the week after I have time!",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1433799396035022852",
            "createdAt" : "2021-09-03T14:29:49.416Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "469459231",
            "reactions" : [
              {
                "senderId" : "469459231",
                "reactionKey" : "like",
                "eventId" : "1433799375759814664",
                "createdAt" : "2021-09-03T14:29:44.556Z"
              }
            ],
            "urls" : [ ],
            "text" : "Yes no problem also happy to talk on zoom. Drop nr an email: j.m.mol@uva.nl",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1433799313314959365",
            "createdAt" : "2021-09-03T14:29:29.688Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I will take a look at your work and if it is not to much trouble for you , I will get back at you",
            "mediaUrls" : [ ],
            "senderId" : "469459231",
            "id" : "1433799096335224842",
            "createdAt" : "2021-09-03T14:28:37.953Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "469459231",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Yeah sounds good! I’m always impressed by field studies and how the operationalize stuff",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1433798964952903685",
            "createdAt" : "2021-09-03T14:28:06.627Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "But I am thinking that for some new projects with a more literate population or in more developed areas it will be cool to think to do something among your line of research",
            "mediaUrls" : [ ],
            "senderId" : "469459231",
            "id" : "1433797457213800459",
            "createdAt" : "2021-09-03T14:22:07.177Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "It is hard to run these on the field with Quechua or aymara speakers and computarized",
            "mediaUrls" : [ ],
            "senderId" : "469459231",
            "id" : "1433797051356155913",
            "createdAt" : "2021-09-03T14:20:30.393Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "469459231",
            "reactions" : [
              {
                "senderId" : "469459231",
                "reactionKey" : "like",
                "eventId" : "1433797093840326662",
                "createdAt" : "2021-09-03T14:20:40.505Z"
              }
            ],
            "urls" : [ ],
            "text" : "Ah related to moral hazard",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1433796987443421190",
            "createdAt" : "2021-09-03T14:20:15.149Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "People changes their allocation of private investment vs public goods",
            "mediaUrls" : [ ],
            "senderId" : "469459231",
            "id" : "1433796935815737351",
            "createdAt" : "2021-09-03T14:20:02.852Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "We were more interested in seeing if once the bank builds some flooding defense",
            "mediaUrls" : [ ],
            "senderId" : "469459231",
            "id" : "1433796796627787781",
            "createdAt" : "2021-09-03T14:19:29.658Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Cool. I will take a look, I am still affiliated with some people at the IADB and World Bank",
            "mediaUrls" : [ ],
            "senderId" : "469459231",
            "id" : "1433796660472262661",
            "createdAt" : "2021-09-03T14:18:57.217Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "469459231",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "and is it about mitigating floods or completely migrating?",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1433796631527362566",
            "createdAt" : "2021-09-03T14:18:50.298Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "469459231",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "My floodgame code is open source on GitHub so it you ever want to use (parts) feel free! Links are also on my website",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1433796471439216658",
            "createdAt" : "2021-09-03T14:18:12.136Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Then from there like 300 participated in a framed public good games with shocks (flooding)",
            "mediaUrls" : [ ],
            "senderId" : "469459231",
            "id" : "1433796343504506887",
            "createdAt" : "2021-09-03T14:17:41.626Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "We have 683 observations of risk, ambiguity, loss aversion and time preferences",
            "mediaUrls" : [ ],
            "senderId" : "469459231",
            "id" : "1433796169164066823",
            "createdAt" : "2021-09-03T14:17:00.063Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "469459231",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "oh that is super interesting! What kind of experiments have you been running?",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1433795985440923652",
            "createdAt" : "2021-09-03T14:16:16.262Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "It is interesting because we have a large proportion of indigenous people that has been usually exposed to floods",
            "mediaUrls" : [ ],
            "senderId" : "469459231",
            "id" : "1433795853773414407",
            "createdAt" : "2021-09-03T14:15:44.865Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "And the government of Bolivia",
            "mediaUrls" : [ ],
            "senderId" : "469459231",
            "id" : "1433795712811245575",
            "createdAt" : "2021-09-03T14:15:11.259Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "We are still submitting reports to the Inter American  Development Bank",
            "mediaUrls" : [ ],
            "senderId" : "469459231",
            "id" : "1433795623661223949",
            "createdAt" : "2021-09-03T14:14:50.006Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "469459231",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "ill have a look at yours that sounds awesome!",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1433795475275239428",
            "createdAt" : "2021-09-03T14:14:14.632Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "469459231",
            "reactions" : [
              {
                "senderId" : "469459231",
                "reactionKey" : "like",
                "eventId" : "1433795457885556740",
                "createdAt" : "2021-09-03T14:14:10.462Z"
              }
            ],
            "urls" : [
              {
                "url" : "https://t.co/tUX9TO4b6f",
                "expanded" : "http://www.jantsje.nl",
                "display" : "jantsje.nl"
              }
            ],
            "text" : "Most of my work is freely available from my website https://t.co/tUX9TO4b6f",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1433795405209346056",
            "createdAt" : "2021-09-03T14:13:57.960Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "469459231",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hi Hernan nice to meet you!",
            "mediaUrls" : [ ],
            "senderId" : "1096413470554292225",
            "id" : "1433795258106667014",
            "createdAt" : "2021-09-03T14:13:22.851Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I would love to read your research",
            "mediaUrls" : [ ],
            "senderId" : "469459231",
            "id" : "1433794149774512187",
            "createdAt" : "2021-09-03T14:08:58.605Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I have been running some lab in the field Bolivia, in flooding areas",
            "mediaUrls" : [ ],
            "senderId" : "469459231",
            "id" : "1433794001040297997",
            "createdAt" : "2021-09-03T14:08:23.144Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "I am very interested in flooding + experimental",
            "mediaUrls" : [ ],
            "senderId" : "469459231",
            "id" : "1433793743463886855",
            "createdAt" : "2021-09-03T14:07:21.736Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1096413470554292225",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hi Jantsje greetings from a fellow experimentalist",
            "mediaUrls" : [ ],
            "senderId" : "469459231",
            "id" : "1433793671598690317",
            "createdAt" : "2021-09-03T14:07:04.595Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  }
]