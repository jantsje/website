window.YTD.personalization.part0 = [
  {
    "p13nData" : {
      "demographics" : {
        "languages" : [
          {
            "language" : "English",
            "isDisabled" : false
          },
          {
            "language" : "Dutch",
            "isDisabled" : false
          }
        ],
        "genderInfo" : {
          "gender" : "female"
        }
      },
      "interests" : {
        "interests" : [
          {
            "name" : "#HappyMonday",
            "isDisabled" : false
          },
          {
            "name" : "Accounting",
            "isDisabled" : false
          },
          {
            "name" : "Agriculture",
            "isDisabled" : false
          },
          {
            "name" : "Akhbar (أخبار الآن)",
            "isDisabled" : false
          },
          {
            "name" : "Alabama",
            "isDisabled" : false
          },
          {
            "name" : "Amazon - AI",
            "isDisabled" : false
          },
          {
            "name" : "Animal Crossing",
            "isDisabled" : false
          },
          {
            "name" : "Animals",
            "isDisabled" : true
          },
          {
            "name" : "Animation",
            "isDisabled" : true
          },
          {
            "name" : "Art",
            "isDisabled" : false
          },
          {
            "name" : "Artificial intelligence",
            "isDisabled" : false
          },
          {
            "name" : "Arts & culture",
            "isDisabled" : false
          },
          {
            "name" : "B2B",
            "isDisabled" : true
          },
          {
            "name" : "BBC",
            "isDisabled" : false
          },
          {
            "name" : "BBC News",
            "isDisabled" : false
          },
          {
            "name" : "Beer",
            "isDisabled" : false
          },
          {
            "name" : "Biology",
            "isDisabled" : true
          },
          {
            "name" : "Biotech and biomedical",
            "isDisabled" : false
          },
          {
            "name" : "Birdwatching",
            "isDisabled" : false
          },
          {
            "name" : "Blogging",
            "isDisabled" : false
          },
          {
            "name" : "Books",
            "isDisabled" : false
          },
          {
            "name" : "Bread",
            "isDisabled" : true
          },
          {
            "name" : "Brown University",
            "isDisabled" : false
          },
          {
            "name" : "Business & finance",
            "isDisabled" : false
          },
          {
            "name" : "CBS",
            "isDisabled" : false
          },
          {
            "name" : "California Institute of Technology",
            "isDisabled" : false
          },
          {
            "name" : "California wildfires",
            "isDisabled" : false
          },
          {
            "name" : "Cambridge University",
            "isDisabled" : false
          },
          {
            "name" : "Carnegie Mellon University",
            "isDisabled" : false
          },
          {
            "name" : "Cats",
            "isDisabled" : false
          },
          {
            "name" : "Celebrities",
            "isDisabled" : true
          },
          {
            "name" : "Chemistry",
            "isDisabled" : false
          },
          {
            "name" : "Chris Paul",
            "isDisabled" : false
          },
          {
            "name" : "Climate change",
            "isDisabled" : false
          },
          {
            "name" : "Cocktails",
            "isDisabled" : false
          },
          {
            "name" : "Cocktails and beer",
            "isDisabled" : false
          },
          {
            "name" : "Coffee",
            "isDisabled" : true
          },
          {
            "name" : "Columbia University",
            "isDisabled" : false
          },
          {
            "name" : "Comics",
            "isDisabled" : false
          },
          {
            "name" : "Computer programming",
            "isDisabled" : true
          },
          {
            "name" : "Console gaming",
            "isDisabled" : false
          },
          {
            "name" : "Construction",
            "isDisabled" : false
          },
          {
            "name" : "Coors Light",
            "isDisabled" : false
          },
          {
            "name" : "Cornell University",
            "isDisabled" : false
          },
          {
            "name" : "Coursera",
            "isDisabled" : false
          },
          {
            "name" : "Cycling",
            "isDisabled" : false
          },
          {
            "name" : "Dartmouth College",
            "isDisabled" : false
          },
          {
            "name" : "Data science",
            "isDisabled" : false
          },
          {
            "name" : "Data visualization",
            "isDisabled" : false
          },
          {
            "name" : "Dining Out",
            "isDisabled" : false
          },
          {
            "name" : "Dominic Cummings",
            "isDisabled" : false
          },
          {
            "name" : "Donald Trump",
            "isDisabled" : true
          },
          {
            "name" : "Drink Experience",
            "isDisabled" : false
          },
          {
            "name" : "Economics",
            "isDisabled" : false
          },
          {
            "name" : "Education",
            "isDisabled" : true
          },
          {
            "name" : "Electric vehicles",
            "isDisabled" : false
          },
          {
            "name" : "Entertainment",
            "isDisabled" : true
          },
          {
            "name" : "Entertainment franchises",
            "isDisabled" : false
          },
          {
            "name" : "Entertainment industry",
            "isDisabled" : false
          },
          {
            "name" : "Environmentalism",
            "isDisabled" : false
          },
          {
            "name" : "Everyday Astronaut",
            "isDisabled" : false
          },
          {
            "name" : "Famous comedians",
            "isDisabled" : false
          },
          {
            "name" : "Fashion",
            "isDisabled" : true
          },
          {
            "name" : "Fashion & beauty",
            "isDisabled" : false
          },
          {
            "name" : "Fashion magazines",
            "isDisabled" : false
          },
          {
            "name" : "Felix Salmon",
            "isDisabled" : true
          },
          {
            "name" : "Fitness",
            "isDisabled" : false
          },
          {
            "name" : "Food",
            "isDisabled" : true
          },
          {
            "name" : "French fries",
            "isDisabled" : false
          },
          {
            "name" : "GPS and maps",
            "isDisabled" : false
          },
          {
            "name" : "Game development",
            "isDisabled" : false
          },
          {
            "name" : "Gaming",
            "isDisabled" : true
          },
          {
            "name" : "Geography",
            "isDisabled" : true
          },
          {
            "name" : "GitHub",
            "isDisabled" : true
          },
          {
            "name" : "Global Economy",
            "isDisabled" : true
          },
          {
            "name" : "Global Environmental Issues",
            "isDisabled" : true
          },
          {
            "name" : "Google",
            "isDisabled" : true
          },
          {
            "name" : "Google Docs",
            "isDisabled" : false
          },
          {
            "name" : "Government institutions",
            "isDisabled" : false
          },
          {
            "name" : "Graduate school",
            "isDisabled" : true
          },
          {
            "name" : "Green living",
            "isDisabled" : false
          },
          {
            "name" : "Harry Potter",
            "isDisabled" : true
          },
          {
            "name" : "Harvard University",
            "isDisabled" : true
          },
          {
            "name" : "Harvard University",
            "isDisabled" : false
          },
          {
            "name" : "Home improvement",
            "isDisabled" : false
          },
          {
            "name" : "IKEA",
            "isDisabled" : false
          },
          {
            "name" : "Instagram",
            "isDisabled" : false
          },
          {
            "name" : "Insurance",
            "isDisabled" : false
          },
          {
            "name" : "Investing",
            "isDisabled" : false
          },
          {
            "name" : "Johns Hopkins University",
            "isDisabled" : false
          },
          {
            "name" : "Journalists",
            "isDisabled" : false
          },
          {
            "name" : "Keurig",
            "isDisabled" : false
          },
          {
            "name" : "LEGO Masters",
            "isDisabled" : false
          },
          {
            "name" : "Machine learning",
            "isDisabled" : false
          },
          {
            "name" : "MailChimp",
            "isDisabled" : false
          },
          {
            "name" : "Marie Claire",
            "isDisabled" : false
          },
          {
            "name" : "Marine life",
            "isDisabled" : false
          },
          {
            "name" : "Mark Rutte",
            "isDisabled" : false
          },
          {
            "name" : "Marvel Universe",
            "isDisabled" : false
          },
          {
            "name" : "Massachusetts Institute of Technology",
            "isDisabled" : false
          },
          {
            "name" : "Mathematics",
            "isDisabled" : false
          },
          {
            "name" : "McGill University",
            "isDisabled" : false
          },
          {
            "name" : "Men's Tour de France",
            "isDisabled" : false
          },
          {
            "name" : "Michel Vorm",
            "isDisabled" : false
          },
          {
            "name" : "Microsoft",
            "isDisabled" : false
          },
          {
            "name" : "Microsoft Excel",
            "isDisabled" : false
          },
          {
            "name" : "Microsoft Office",
            "isDisabled" : false
          },
          {
            "name" : "Mindy Kaling",
            "isDisabled" : false
          },
          {
            "name" : "Music",
            "isDisabled" : false
          },
          {
            "name" : "New York University",
            "isDisabled" : false
          },
          {
            "name" : "News",
            "isDisabled" : false
          },
          {
            "name" : "News outlets",
            "isDisabled" : false
          },
          {
            "name" : "Nintendo",
            "isDisabled" : false
          },
          {
            "name" : "Northwestern University",
            "isDisabled" : false
          },
          {
            "name" : "Oceanography",
            "isDisabled" : false
          },
          {
            "name" : "Oculus",
            "isDisabled" : false
          },
          {
            "name" : "Olympic Cycling",
            "isDisabled" : false
          },
          {
            "name" : "Open source",
            "isDisabled" : false
          },
          {
            "name" : "PC gaming",
            "isDisabled" : false
          },
          {
            "name" : "Paleontology",
            "isDisabled" : false
          },
          {
            "name" : "Personal finance",
            "isDisabled" : false
          },
          {
            "name" : "Podcasts & radio",
            "isDisabled" : false
          },
          {
            "name" : "Political figures",
            "isDisabled" : false
          },
          {
            "name" : "Political issues",
            "isDisabled" : false
          },
          {
            "name" : "Politics",
            "isDisabled" : false
          },
          {
            "name" : "Politics",
            "isDisabled" : false
          },
          {
            "name" : "Pop",
            "isDisabled" : false
          },
          {
            "name" : "Psychology",
            "isDisabled" : false
          },
          {
            "name" : "R. Kelly",
            "isDisabled" : false
          },
          {
            "name" : "Reddit",
            "isDisabled" : false
          },
          {
            "name" : "Renewable energy",
            "isDisabled" : false
          },
          {
            "name" : "Retail industry",
            "isDisabled" : false
          },
          {
            "name" : "Retirement planning",
            "isDisabled" : false
          },
          {
            "name" : "Running",
            "isDisabled" : false
          },
          {
            "name" : "San Francisco transit",
            "isDisabled" : false
          },
          {
            "name" : "Saving and finance",
            "isDisabled" : false
          },
          {
            "name" : "Sci-fi & fantasy",
            "isDisabled" : false
          },
          {
            "name" : "Sci-fi & fantasy books",
            "isDisabled" : false
          },
          {
            "name" : "Science",
            "isDisabled" : false
          },
          {
            "name" : "Science news",
            "isDisabled" : false
          },
          {
            "name" : "Shoes",
            "isDisabled" : false
          },
          {
            "name" : "Shopping",
            "isDisabled" : false
          },
          {
            "name" : "Soccer",
            "isDisabled" : false
          },
          {
            "name" : "Soccer",
            "isDisabled" : false
          },
          {
            "name" : "Social media",
            "isDisabled" : false
          },
          {
            "name" : "Soups",
            "isDisabled" : false
          },
          {
            "name" : "Space and astronomy",
            "isDisabled" : false
          },
          {
            "name" : "Sports",
            "isDisabled" : false
          },
          {
            "name" : "Stanford University",
            "isDisabled" : false
          },
          {
            "name" : "Street art",
            "isDisabled" : false
          },
          {
            "name" : "Sustainability",
            "isDisabled" : false
          },
          {
            "name" : "Tech industry",
            "isDisabled" : false
          },
          {
            "name" : "Tech news",
            "isDisabled" : false
          },
          {
            "name" : "Technology",
            "isDisabled" : false
          },
          {
            "name" : "Technology",
            "isDisabled" : false
          },
          {
            "name" : "Television",
            "isDisabled" : false
          },
          {
            "name" : "Tennis",
            "isDisabled" : false
          },
          {
            "name" : "The Elder Scrolls",
            "isDisabled" : false
          },
          {
            "name" : "The New Yorker",
            "isDisabled" : false
          },
          {
            "name" : "The Onion",
            "isDisabled" : false
          },
          {
            "name" : "The Wall Street Journal",
            "isDisabled" : false
          },
          {
            "name" : "Tiger King (Netflix)",
            "isDisabled" : false
          },
          {
            "name" : "Tom Scott",
            "isDisabled" : false
          },
          {
            "name" : "Travel",
            "isDisabled" : false
          },
          {
            "name" : "Travel Actions",
            "isDisabled" : false
          },
          {
            "name" : "University of Bristol",
            "isDisabled" : false
          },
          {
            "name" : "University of British Columbia",
            "isDisabled" : false
          },
          {
            "name" : "University of California Berkeley",
            "isDisabled" : false
          },
          {
            "name" : "University of California Los Angeles",
            "isDisabled" : false
          },
          {
            "name" : "University of California, Santa Barbara",
            "isDisabled" : false
          },
          {
            "name" : "University of Chicago",
            "isDisabled" : false
          },
          {
            "name" : "University of Edinburgh",
            "isDisabled" : false
          },
          {
            "name" : "University of Melbourne",
            "isDisabled" : false
          },
          {
            "name" : "University of Oxford",
            "isDisabled" : false
          },
          {
            "name" : "University of Pennsylvania",
            "isDisabled" : false
          },
          {
            "name" : "University of Queensland",
            "isDisabled" : false
          },
          {
            "name" : "University of Toronto",
            "isDisabled" : false
          },
          {
            "name" : "VSauce",
            "isDisabled" : false
          },
          {
            "name" : "Veganism",
            "isDisabled" : false
          },
          {
            "name" : "Video games",
            "isDisabled" : false
          },
          {
            "name" : "Virtual reality",
            "isDisabled" : false
          },
          {
            "name" : "Visual arts",
            "isDisabled" : false
          },
          {
            "name" : "Weather",
            "isDisabled" : false
          },
          {
            "name" : "Weather",
            "isDisabled" : false
          },
          {
            "name" : "Web development",
            "isDisabled" : false
          },
          {
            "name" : "X",
            "isDisabled" : false
          },
          {
            "name" : "Yale University",
            "isDisabled" : false
          },
          {
            "name" : "YouTube",
            "isDisabled" : false
          },
          {
            "name" : "Zoom",
            "isDisabled" : false
          }
        ],
        "partnerInterests" : [ ],
        "audienceAndAdvertisers" : {
          "lookalikeAdvertisers" : [ ],
          "advertisers" : [ ],
          "doNotReachAdvertisers" : [ ],
          "catalogAudienceAdvertisers" : [ ],
          "numAudiences" : "0"
        },
        "shows" : [
          "AAF Football",
          "Barbie (2023)",
          "Barclays Premier League Football",
          "Barclays Premier League Soccer",
          "Bergen",
          "Better Call Saul",
          "Better Call Saul (Netflix UK)",
          "Big Brother Brasil",
          "Black Panther",
          "Blade Runner",
          "Britain's Got Talent (TV3)",
          "Brooklyn Nine-Nine",
          "Bundesliga Soccer",
          "Cyclisme : Tour d'Italie 2017",
          "Daredevil",
          "Disparue",
          "Don",
          "Don't Look Up",
          "Dune (2021)",
          "Dune: Part Two",
          "English Premier League Soccer",
          "Formula One Racing",
          "Fórmula 1",
          "Game of Thrones",
          "Ghosted: Love Gone Missing",
          "Gok : leçons de style",
          "Good Luck to You, Leo Grande",
          "House of the Dragon",
          "Intervention",
          "Jersey Shore",
          "Jersey Shore: Family Vacation",
          "Live: Formula 1 Motor Racing",
          "MLB Baseball",
          "Micky Flanagan's Detour De France",
          "NBA Basketball",
          "NFL Football",
          "Nine Perfect Strangers",
          "Pawn Stars",
          "Peacemaker",
          "Perfect Match (Netflix)",
          "Premier League",
          "Seinfeld",
          "Squid Game",
          "Still Open All Hours",
          "Survival of the Fittest",
          "Tech&Co",
          "The Crown (Netflix)",
          "The Godfather",
          "The Lord of the Rings: The Rings of Power",
          "The OA (Netflix)",
          "The Peripheral",
          "The Simpsons",
          "The Staircase",
          "Top 2000",
          "US Open",
          "Uncharted",
          "WWE Monday Night RAW",
          "Who Wants to Be a Millionaire?"
        ]
      },
      "locationHistory" : [ ],
      "inferredAgeInfo" : {
        "age" : [
          "13-54"
        ],
        "birthDate" : ""
      }
    }
  }
]