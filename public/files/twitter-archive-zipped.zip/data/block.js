window.YTD.block.part0 = [
  {
    "blocking" : {
      "accountId" : "1734667296818233344",
      "userLink" : "https://twitter.com/intent/user?user_id=1734667296818233344"
    }
  },
  {
    "blocking" : {
      "accountId" : "2444495658",
      "userLink" : "https://twitter.com/intent/user?user_id=2444495658"
    }
  },
  {
    "blocking" : {
      "accountId" : "20663500",
      "userLink" : "https://twitter.com/intent/user?user_id=20663500"
    }
  }
]