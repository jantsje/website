window.YTD.verified.part0 = [
  {
    "verified" : {
      "accountId" : "1096413470554292225",
      "verified" : false
    }
  }
]