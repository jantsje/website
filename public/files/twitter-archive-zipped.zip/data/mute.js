window.YTD.mute.part0 = [
  {
    "muting" : {
      "accountId" : "1180533698",
      "userLink" : "https://twitter.com/intent/user?user_id=1180533698"
    }
  },
  {
    "muting" : {
      "accountId" : "47400023",
      "userLink" : "https://twitter.com/intent/user?user_id=47400023"
    }
  }
]