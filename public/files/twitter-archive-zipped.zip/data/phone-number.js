window.YTD.phone_number.part0 = [
  {
    "device" : {
      "phoneNumber" : "+31623206073"
    }
  }
]