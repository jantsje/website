window.YTD.ads_revenue_sharing.part0 = [
  {
    "adsRevenueSharing" : {
      "payoutHistory" : [ ]
    }
  }
]