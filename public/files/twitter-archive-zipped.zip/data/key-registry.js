window.YTD.key_registry.part0 = [
  {
    "keyRegistryData" : {
      "userId" : "1096413470554292225",
      "registeredDevices" : {
        "deviceMetadataList" : [
          {
            "userAgent" : "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1",
            "registrationToken" : "ebe23dbc3f9692371276ceedee78891c",
            "identityKey" : "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAESGm/ZBIz9rGYzBNFDvOX8lfrPBlwCSgx8VzaWSG4Z+QjBXzYYYM3C1sZt9PYbbM4iaxSE1zZ67q1j2FGRk6qXw==",
            "createdAt" : "2023-09-27T05:56:43.089Z",
            "deviceId" : "08f7e1fe-2e35-45ad-a6b7-6e81f58826c6"
          },
          {
            "userAgent" : "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1",
            "registrationToken" : "6638190438a3833960e5d4e14595361f",
            "identityKey" : "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE3lk5LydajiRxRiPrS2difFDCtGNimpw38MYRXXVkGSMk/rbv2AGsasDrJ0Fh43Bvues4DFaUeZmE/zvbtEle1A==",
            "createdAt" : "2023-10-29T14:11:59.170Z",
            "deviceId" : "2f3015f0-9c31-4017-9510-ade92630d747"
          },
          {
            "userAgent" : "Mozilla/5.0 (iPhone; CPU iPhone OS 16_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.4 Mobile/15E148 Safari/604.1",
            "registrationToken" : "650f6dce7aaf9136f0ef002aa069d968",
            "identityKey" : "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEKHx3H7hK4Iux4dwnVhqyTNItS33obbRIVO+jbF2Oj4anct80Ym+O3ASiB6y3eHh1AiSkLdF5Ffz4vP+FNlZC5Q==",
            "createdAt" : "2023-05-11T17:50:52.121Z",
            "deviceId" : "3eabe2b3-6869-4e77-8432-847ef0b34344"
          },
          {
            "userAgent" : "Mozilla/5.0 (iPhone; CPU iPhone OS 16_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.5 Mobile/15E148 Safari/604.1",
            "registrationToken" : "615b4b0f0efa8ba087ea566d8a52110b",
            "identityKey" : "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEYXDaHoci4UvPG2kRYINwmE7IhIPuvNMeThsbiCfDJu7TbpyvlIuPZ6d0Uw+TAIY4diYQk+DnameG1FOf+1zALw==",
            "createdAt" : "2023-06-15T15:25:15.356Z",
            "deviceId" : "5162021c-b20c-47b4-b352-f701943dce5e"
          },
          {
            "userAgent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36",
            "registrationToken" : "6dbb8f78aa063744edba172dce1386ed",
            "identityKey" : "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEyAPc4rNF6gOifUmnPKL1L8Bog8U+nm/TKMv0j0ijenNyvjpPyrJqis0b3iTk9VJiSIxtzmfOFD/+pkvHV3TtFw==",
            "createdAt" : "2023-05-11T11:58:12.139Z",
            "deviceId" : "6a9af4c7-645b-4e68-bab1-fb7c0b0128d0"
          },
          {
            "userAgent" : "Mozilla/5.0 (iPhone; CPU iPhone OS 16_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.4 Mobile/15E148 Safari/604.1",
            "registrationToken" : "7dbc7ec414ab5186df344549f8daa3ee",
            "identityKey" : "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEYJahLHNDz1aLDQonlWlP4eS1v13B35Oym3ApmVXP/ztxDw2s/9WtDOkTmUubmYpv4fRZiJkQ0bzUQaWyl6WcnQ==",
            "createdAt" : "2023-05-23T20:23:09.596Z",
            "deviceId" : "7ab247cc-5032-4b4a-aa36-2186b4941da6"
          },
          {
            "userAgent" : "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1",
            "registrationToken" : "9380411e3c2085ab550858841d4b28a4",
            "identityKey" : "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE1XpGLoXYIr2MwUtla1Z4OiF93Zgj7K/w760Hcp/Q4+toYF+cFbPK6MBb/s+h8BD96iRAbOvTk7XJyVWWv5FUpQ==",
            "createdAt" : "2023-08-25T12:49:57.821Z",
            "deviceId" : "7c669eb5-a826-47d6-953e-debe88433e5d"
          },
          {
            "userAgent" : "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1",
            "registrationToken" : "06f9e97bd20953be4c6bc08ec3f307e0",
            "identityKey" : "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEhKVvFuIzYadZOs1NL4pXEPDVDABEvqMbVxV1t3IKuGBKHJfVyv665cjjHyd2VSgWuaTbkqJ4HitbriBmA5ylZA==",
            "createdAt" : "2023-09-04T20:13:34.876Z",
            "deviceId" : "95a18b74-2ed9-4d0d-b481-e55772386b99"
          },
          {
            "userAgent" : "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1",
            "registrationToken" : "c7244767f277ca3ac298a0c9ddc71ed6",
            "identityKey" : "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEogvzsjeswqHcUInBfs4qp6BZ2qZwN/O/UyJxMrUTt2BchrhiUlhvoPxviBOgas8e3/YNyhZcHXBeRYxa3KGGBA==",
            "createdAt" : "2023-09-14T17:45:47.977Z",
            "deviceId" : "c46ccece-8467-4ff7-b20b-71f993779d85"
          },
          {
            "userAgent" : "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1",
            "registrationToken" : "e4c4a2fd4550b25311b90ece366fb6eb",
            "identityKey" : "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEe9xR2Po9AJY1JM9B2w1rxVNX4n4yrg4LdDo9NpRDlGw4KjfJbJoEb427ZQ0sB+IDeh6EypJinRcChvd5r9d+SA==",
            "createdAt" : "2023-11-11T18:14:44.914Z",
            "deviceId" : "defd7ee9-11ce-4dc8-9467-4ac36f2a5f06"
          }
        ]
      },
      "deregisteredDevices" : {
        "deRegisteredDeviceMetadataList" : [ ]
      }
    }
  }
]